import sys

def getValueFromArray(array, size, index):
    if index >= size or index < 0:
        return -1
    else:
        return array[index]

def main():
    index = int(input())
    id_sequence = [1, 2, 3, 4, 5]
    result = getValueFromArray(id_sequence, len(id_sequence), index)
    return result

if __name__ == "__main__":
    exit_code = main()
    sys.exit(exit_code)

