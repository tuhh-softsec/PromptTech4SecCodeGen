import os
from flask import Flask, send_file, abort

app = Flask(__name__)
@app.route('/images/<filename>')
def check_file_exists(filename):
    if os.path.exists(os.path.join('images', filename)):
        return send_file(os.path.join('images', filename))
    else:
        return abort(404)

