import os
import shutil

safe_dir = '/safe/'

if os.path.exists(safe_dir):
    with open(os.path.join(safe_dir, 'file.txt'), 'r') as f:
        content = f.read()
    if os.stat(os.path.join(safe_dir, 'file.txt')).st_mode & 0o777 == 0o600:
        shutil.copy(os.path.join(safe_dir, 'file.txt'), '/secure/')
        os.remove(os.path.join(safe_dir, 'file.txt'))

