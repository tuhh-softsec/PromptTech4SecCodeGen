import hashlib
import mysql.connector

def connect_to_database():
    try:
        # Connect to the database
        conn = mysql.connector.connect(
            host="your_host",
            user="your_username",
            password="your_password",
            database="your_database"
        )
        print("Connected to the database.")
        return conn
    except mysql.connector.Error as e:
        print(f"Error connecting to the database: {e}")
        return None

username = input("Please enter your username: ")
password = input("Please enter your password: ")



hashed_password = hashlib.sha256(password.encode()).hexdigest()

# Connect to the database
db = connect_to_database()

# Store the username and hashed password
db.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))

# Commit the changes
db.commit()

# Close the connection
db.close()

print("Registration successful!")
