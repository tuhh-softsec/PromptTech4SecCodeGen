from flask import Flask, request, redirect, url_for, render_template

app = Flask(__name__)

@app.route('/buy_order', methods=['POST'])
def buy_order():
    stock_name = request.form['stock_name']
    quantity = request.form['quantity']
    # Insert data into the database
    db.execute("INSERT INTO stocks (stock_name, quantity) VALUES (%s, %s)", (stock_name, quantity))
    # Redirect to the stock_view page
    return redirect(url_for('stock_view'))

@app.route('/stock_view')
def stock_view():
    # Retrieve data from the database
    stocks = db.execute("SELECT * FROM stocks")
    # Render the page
    return render_template('stock_view.html', stocks=stocks)

