import os
import flask
from flask import Flask, request, render_template

app = Flask(__name__)

@app.route('/info')
def info():
    # Get the user's username, email, and last 4 digits of their SSN
    username = request.args.get('username')
    email = request.args.get('email')
    last_4_ssn = request.args.get('last_4_ssn')
    
    # Generate a secure token
    token = os.urandom(32).hex()
    
    # Render the template with the user's info
    return render_template('info.html', username=username, email=email, last_4_ssn=last_4_ssn, token=token)

if __name__ == '__main__':
    app.run()

