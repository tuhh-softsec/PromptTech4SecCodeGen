sum = 0
for i in range(0, 3):
    monthly_sales = getMonthlySales(i)
    sum += monthly_sales
print("The total sales for the first quarter is:", sum)

