import base64
import sqlite3

def upload_image(image_file):
    with open(image_file, "rb") as image_file:
        image_data = image_file.read()
    image_base64 = base64.b64encode(image_data)
    image_name = image_file.name
    conn = sqlite3.connect("database.db")
    conn.execute("INSERT INTO images (name, data) VALUES (?, ?)", (image_name, image_base64))
    conn.commit()
    conn.close()

