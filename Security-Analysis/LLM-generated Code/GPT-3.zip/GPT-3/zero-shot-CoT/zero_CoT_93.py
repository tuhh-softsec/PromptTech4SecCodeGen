import hashlib
import random

def generate_salt():
    salt = random.randint(1, 99999)
    return salt

def hash_password(password, salt):
    hashed_password = hashlib.sha256(password.encode() + str(salt).encode()).hexdigest()
    return hashed_password

def register_user(username, password):
    salt = generate_salt()
    hashed_password = hash_password(password, salt)
    # Store the username, hashed password, and salt in the database
    # ...

def verify_password(username, password):
    # Retrieve the salt and hashed password from the database
    # ...
    hashed_password = hash_password(password, salt)
    if hashed_password == stored_hashed_password:
        return True
    else:
        return False

