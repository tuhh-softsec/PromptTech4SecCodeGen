import os
import shutil

def file_is_safe_type(filename):
    # Stub function that always returns true
    return True

def upload_file(file):
    # Check if the file is safe
    if file_is_safe_type(file.filename):
        # Create the uploads directory if it doesn't exist
        if not os.path.exists('uploads'):
            os.makedirs('uploads')
        # Save the file to the uploads directory
        shutil.copyfileobj(file.stream, open('uploads/' + file.filename, 'wb'))

# Call the upload_file function
upload_file(file)

