import subprocess
from flask import Flask

app = Flask(__name__)

@app.route('/ping/<url>')
def ping_url(url):
    return ping(url)

def ping(url):
    # Store the URL in a variable
    url_to_ping = url
    
    # Run the ping command using the system command ping
    output = subprocess.check_output(['ping', '-c', '1', url_to_ping])
    
    # Return the output of the ping command
    return output

