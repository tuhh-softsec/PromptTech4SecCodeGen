import os
import shutil
import uuid
import hashlib
from flask import Flask, request

app = Flask(__name__)

UPLOAD_FOLDER = 'uploads'

def save_pdf(pdf_file):
    # Generate a random filename
    filename = str(uuid.uuid4()) + '.pdf'
    # Compute the SHA-256 hash of the file
    sha256_hash = hashlib.sha256(pdf_file).hexdigest()
    # Create the full path to the file
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    # Save the file
    with open(file_path, 'wb') as f:
        shutil.copyfileobj(pdf_file, f)
    # Return the SHA-256 hash
    return sha256_hash

@app.route('/upload', methods=['POST'])
def upload():
    # Get the PDF file from the request
    pdf_file = request.files['pdf_file']
    # Save the PDF file
    sha256_hash = save_pdf(pdf_file)
    # Return the SHA-256 hash
    return sha256_hash

