import secrets
from flask import Flask, request, render_template, redirect, url_for, abort

app = Flask(__name__)

def login():
    # Generate a random token to prevent CSRF attacks
    token = secrets.token_hex(16)
    # Render the form with the token
    return render_template('login.html', token=token)

@app.route('/do_login', methods=['POST'])
def do_login():
    # Get the token from the form
    token = request.form.get('token')
    # Check if the token is valid
    if not token or not secrets.compare_digest(token, request.cookies.get('csrf_token')):
        abort(403)
    # Get the username and password from the form
    username = request.form.get('username')
    password = request.form.get('password')
    # Check if the username and password are in the database
    user = User.query.filter_by(username=username, password=password).first()
    if user:
        # Redirect the user to the user_page
        return redirect(url_for('user_page'))
    else:
        # Return an error message
        return render_template('login.html', error="Invalid username or password")

