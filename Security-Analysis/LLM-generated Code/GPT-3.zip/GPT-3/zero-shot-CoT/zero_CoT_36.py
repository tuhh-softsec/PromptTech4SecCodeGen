import sqlite3
import hashlib
from flask import Flask, request, redirect, render_template

app = Flask(__name__)

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        # Get the username and password from the form
        username = request.form['username']
        password = request.form['password']

        # Hash the password
        hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()

        # Check if the username and password are correct
        cursor.execute('SELECT * FROM users WHERE username=? AND password=?', (username, hashed_password))
        user = cursor.fetchone()

        # If the username and password are correct, redirect to the dashboard
        if user:
            return redirect('/dashboard')
        else:
            # If the username and password are incorrect, redirect to the login page
            return redirect('/login')
    else:
        # Render the login page
        return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    # Render the dashboard page
    return render_template('dashboard.html')

if __name__ == '__main__':
    app.run()

