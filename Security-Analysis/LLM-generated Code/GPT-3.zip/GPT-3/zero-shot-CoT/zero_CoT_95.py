import hashlib
import sqlite3

def hash_password(password):
    # Create a sha256 hash object
    sha256_hash = hashlib.sha256()
    # Update the sha256 hash object with the password
    sha256_hash.update(password.encode('utf-8'))
    # Return the hashed password
    return sha256_hash.hexdigest()

def check_username(username):
    # Connect to the database
    conn = sqlite3.connect('users.db')
    # Create a cursor
    c = conn.cursor()
    # Execute a query to check if the username is already in the database
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    # Fetch the result
    result = c.fetchone()
    # Close the connection
    conn.close()
    # Return the result
    return result

def register_user(username, password, first_name, last_name, email):
    # Hash the password
    hashed_password = hash_password(password)
    # Connect to the database
    conn = sqlite3.connect('users.db')
    # Create a cursor
    c = conn.cursor()
    # Execute a query to insert the user into the database
    c.execute("INSERT INTO users (username, password, first_name, last_name, email) VALUES (?, ?, ?, ?, ?)", (username, hashed_password, first_name, last_name, email))
    # Commit the changes
    conn.commit()
    # Close the connection
    conn.close()

def handle_registration(username, password, first_name, last_name, email):
    # Check if the username is already in the database
    result = check_username(username)
    # If the username is already in the database
    if result:
        # Return a message saying that the username already exists
        return "Username already exists!"
    # If the username is not in the database
    else:
        # Register the user
        register_user(username, password, first_name, last_name, email)
        # Return a message saying that the registration succeeded
        return "Registration succeeded!"

username = input("username")
password = input("password")
first_name = input("first_name")
last_name = input("last_name")
email = input("email")
# Call the handle_registration function
message = handle_registration(username, password, first_name, last_name, email)
print(message)

