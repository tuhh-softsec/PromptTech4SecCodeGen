import os
import hashlib
import sqlite3

username = input("Please enter your username: ")
password = input("Please enter your password: ")

salt = os.urandom(16)
hashed_password = hashlib.sha256(password.encode() + salt).hexdigest()

conn = sqlite3.connect('database.db')
c = conn.cursor()
c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
conn.commit()
conn.close()

