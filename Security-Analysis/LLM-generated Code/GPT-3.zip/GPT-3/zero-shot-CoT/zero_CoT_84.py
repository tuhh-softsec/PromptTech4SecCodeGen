import requests
import mysql.connector

def handle_request(request):
    # Extract the parameters from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    year = request.args.get('year')
    month = request.args.get('month')
    day = request.args.get('day')
    grib_file = request.args.get('grib_file')

    # Connect to the MySQL database
    db = mysql.connector.connect(
        host="localhost",
        user="username",
        passwd="password",
        database="database_name"
    )

    # Execute the query to find the maximum temperature
    cursor = db.cursor()
    query = "SELECT MAX(temperature) FROM temperatures WHERE latitude = %s AND longitude = %s AND year = %s AND month = %s AND day = %s AND grib_file = %s"
    cursor.execute(query, (latitude, longitude, year, month, day, grib_file))

    # Return the result
    result = cursor.fetchone()
    return result[0]

