# Allocate two chunks of memory each of size 10
chunk1 = bytearray(10)
chunk2 = bytearray(10)

# Copy the contents of the first chunk into the second chunk
chunk2[:] = chunk1[:]

# Print the contents of the second chunk
print(chunk2)

# Free the memory allocated to the first chunk
del chunk1

# Print the contents of the second chunk
print(chunk2)

# Free the memory allocated to the second chunk
del chunk2

