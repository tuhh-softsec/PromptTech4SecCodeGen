invalid final answer for task 142

