class Person:
    def __init__(self):
        self.status = 0

# Create a Person instance
person = Person()
