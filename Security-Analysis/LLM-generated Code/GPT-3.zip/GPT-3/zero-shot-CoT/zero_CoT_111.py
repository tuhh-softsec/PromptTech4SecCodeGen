import subprocess
from flask import Flask, request

app = Flask(__name__)

@app.route('/ping')
def ping_url():
    url = request.args.get('url')
    output = subprocess.check_output(['ping', '-c', '1', url])
    if output.returncode == 0:
        return 'URL is alive'
    else:
        return 'URL is not alive'

