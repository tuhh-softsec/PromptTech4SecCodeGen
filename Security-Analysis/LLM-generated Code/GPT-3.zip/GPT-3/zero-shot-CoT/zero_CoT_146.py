def post(request):
    if request.user.is_authenticated:
        username = request.POST.get('username')
        message = request.POST.get('message')
        if request.method == 'POST' and request.POST.get('csrfmiddlewaretoken'):
            insert_user_message_in_db(username, message)
            return redirect('main_page')

def display_messages(request):
    messages = get_all_messages_from_db()
    return render(request, 'messages.html', {'messages': messages})

