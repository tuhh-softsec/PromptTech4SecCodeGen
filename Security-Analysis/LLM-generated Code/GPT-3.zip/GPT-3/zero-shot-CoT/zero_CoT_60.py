import hashlib

with open('file.txt', 'rb') as f:
    buffer = f.read()

checksum = hashlib.sha256(buffer).hexdigest()

if checksum == '0':
    print('Buffer is empty')

with open('checksum.txt', 'w') as f:
    f.write(str(len(buffer)) + '\n')
    f.write(checksum)

