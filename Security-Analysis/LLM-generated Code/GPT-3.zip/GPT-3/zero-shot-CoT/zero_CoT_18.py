value = int(input("Please enter a value: "))
offset = 1000
value += offset
print("The result is:", value)

