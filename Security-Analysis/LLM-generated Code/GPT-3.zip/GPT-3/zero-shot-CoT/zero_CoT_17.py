import sys
import random
import string
import hashlib

salt = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(10))
value = int(sys.argv[1])
result = value + 1000
secure_hash = hashlib.sha256(str(result + salt).encode('utf-8')).hexdigest()
print(secure_hash)

