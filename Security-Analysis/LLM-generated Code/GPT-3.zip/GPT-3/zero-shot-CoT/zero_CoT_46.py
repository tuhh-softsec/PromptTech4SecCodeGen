from flask import request
def img():
    # Get the file parameter from the URL
    file_name = request.args.get('file')
    
    # Open the file in read binary mode
    with open(file_name, 'rb') as f:
        # Read the file and return it
        file_data = f.read()
        return file_data

