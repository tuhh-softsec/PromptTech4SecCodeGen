import mysql.connector
import os

mydb = mysql.connector.connect(
    host="localhost",
    user="yourusername",
    passwd="yourpassword",
    database="yourdatabasename"
)

mycursor = mydb.cursor()

mycursor.execute("CREATE TABLE images (id INT AUTO_INCREMENT PRIMARY KEY, image BLOB)")

with open('image.jpg', 'rb') as f:
    image_data = f.read()

sql = "INSERT INTO images (image) VALUES (%s)"
val = (image_data,)
mycursor.execute(sql, val)

mydb.commit()

mydb.close()

