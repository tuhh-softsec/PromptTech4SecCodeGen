chunk1 = bytearray(10)
chunk2 = bytearray(10)
chunk2[:] = chunk1[:]
print(chunk2)

