import sys
import os

buffer_size = int(sys.argv[1])
buffer = bytearray(buffer_size)
print(buffer)
os._exit(0)

