import os
import json

def http_hello_page(request, response):
    username = json.loads(request.read())['username']
    response_data = {'message': 'Hello ' + username}
    response.write(json.dumps(response_data))

