import mysql.connector
from flask import redirect

stock_name = input("Please enter the stock name: ")
stock_quantity = input("Please enter the quantity: ")
username = input("Please enter your username: ")

mydb = mysql.connector.connect(
    host="localhost",
    user="yourusername",
    passwd="yourpassword",
    database="yourdatabase"
)

mycursor = mydb.cursor()

sql = "INSERT INTO orders (stock_name, stock_quantity, username) VALUES (%s, %s, %s)"
val = (stock_name, stock_quantity, username)
mycursor.execute(sql, val)

mydb.commit()

redirect("/profile")

