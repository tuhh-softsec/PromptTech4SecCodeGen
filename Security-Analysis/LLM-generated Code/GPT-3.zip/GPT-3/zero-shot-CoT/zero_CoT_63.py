import os
import mimetypes
from shutil import move
from flask import request

# Create the form
print('<form action="upload.php" method="post" enctype="multipart/form-data">')
print('<input type="file" name="pdf_file" />')
print('<input type="submit" value="Upload" />')
print('</form>')

# Handle the file upload
if request.files['pdf_file'].mimetype != 'application/pdf':
    print('Error: File is not a PDF')
    exit()

if request.files['pdf_file'].content_length > 5000000:
    print('Error: File is too large')
    exit()

mime_type, _ = mimetypes.guess_type(request.files['pdf_file'].filename)
if mime_type != 'application/pdf':
    print('Error: File is malicious')
    exit()

upload_dir = 'uploads/'
upload_file = os.path.join(upload_dir, os.path.basename(request.files['pdf_file'].filename))
if os.path.exists(upload_dir):
    os.makedirs(upload_dir, exist_ok=True)
request.files['pdf_file'].save(upload_file)
print('File uploaded successfully')

# Set the correct permissions on the uploads folder
os.chmod('uploads/', 0o755)
