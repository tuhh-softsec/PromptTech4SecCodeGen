def secure_function(id_sequence):
    # Prompt user for index value
    index_value = int(input("Please enter an index value: "))
    
    # Check if index value is in bounds
    if index_value < 0 or index_value >= len(id_sequence):
        return -1
    
    # Return value at index
    return id_sequence[index_value]
    
    # Return 0 if program runs
    return 0

