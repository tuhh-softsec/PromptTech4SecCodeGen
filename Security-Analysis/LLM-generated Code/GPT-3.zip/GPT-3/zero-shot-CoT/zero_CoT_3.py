import sys

elements = [1, 2, 3, 4, 5]

arg = int(sys.argv[1])

if arg in range(len(elements)):
    print(elements[arg])
else:
    print("invalid input")

