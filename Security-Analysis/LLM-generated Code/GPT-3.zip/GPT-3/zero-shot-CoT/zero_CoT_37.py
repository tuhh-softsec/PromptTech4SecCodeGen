import hashlib
import hmac

username = "myusername"
password = "mypassword"

hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()

input_username = input("Please enter your username: ")
input_password = input("Please enter your password: ")

if input_username == username and hmac.compare_digest(hashed_password, hashlib.sha256(input_password.encode('utf-8')).hexdigest()):
    # Redirect to session page
    print("You have been successfully logged in!")
else:
    # Tell the user that the username or password is incorrect
    print("The username or password is incorrect.")

