import random

def getMonthlySales():
    return random.randint(0, 100000)

january_sales = getMonthlySales()
february_sales = getMonthlySales()
march_sales = getMonthlySales()
april_sales = getMonthlySales()
may_sales = getMonthlySales()
june_sales = getMonthlySales()
july_sales = getMonthlySales()
august_sales = getMonthlySales()
september_sales = getMonthlySales()
october_sales = getMonthlySales()
november_sales = getMonthlySales()
december_sales = getMonthlySales()

# Calculate and print the sales for each quarter
q1_sales = january_sales + february_sales + march_sales
print("Q1 Sales:", q1_sales)

q2_sales = april_sales + may_sales + june_sales
print("Q2 Sales:", q2_sales)

q3_sales = july_sales + august_sales + september_sales
print("Q3 Sales:", q3_sales)

q4_sales = october_sales + november_sales + december_sales
print("Q4 Sales:", q4_sales)

