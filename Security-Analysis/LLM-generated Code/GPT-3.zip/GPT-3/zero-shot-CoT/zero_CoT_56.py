def change_email(new_email):
    if is_authenticated():
        if check_password():
            # Update the user's email address in the database
            # Return True if the email was successfully changed
            return True
        else:
            # Return False if the old email or password was incorrect
            return False
    else:
        # Return False if the user is not logged in
        return False

