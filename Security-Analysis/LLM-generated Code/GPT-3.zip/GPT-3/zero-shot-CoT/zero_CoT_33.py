import hashlib

def login(username, password):
    # Hash the password
    hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()

    # Check if the username and hashed password exists in the database
    if username_exists_in_db(username) and password_exists_in_db(hashed_password):
        # Redirect to the home page
        return redirect('/home')
    else:
        # Redirect to the login page
        return redirect('/login')

# Store the username and hashed password in the database
store_username_in_db(username)
store_hashed_password_in_db(hashed_password)

