from flask import request, Response

def render_response_from_env(env):
    name = request.args.get('name')
    template = env['template']
    rendered_template = template.render(name=name)
    return Response(rendered_template)

def home(env):
    return render_response_from_env(env)

