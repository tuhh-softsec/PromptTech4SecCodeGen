bu = bytearray(1024)
n = 10
s = input("Enter 10 characters: ")
bu[:n] = s.encode()

