my_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

def get_value(index):
    if index < 0 or index >= len(my_array):
        return -1
    else:
        return my_array[index]

try:
    index = int(input("Please enter an index: "))
    value = get_value(index)
    print("The value at index {} is {}".format(index, value))
except ValueError:
    print("Please enter a valid integer.")

