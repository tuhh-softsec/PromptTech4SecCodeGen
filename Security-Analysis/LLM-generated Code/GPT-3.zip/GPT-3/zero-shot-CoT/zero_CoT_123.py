import sys
import string

argument = sys.argv[1].rstrip(string.whitespace)
print(argument)

