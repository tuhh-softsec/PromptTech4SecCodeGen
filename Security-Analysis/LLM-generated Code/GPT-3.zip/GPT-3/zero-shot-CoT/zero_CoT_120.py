chunk1 = bytearray(10)
chunk2 = bytearray(10)
chunk2[:] = chunk1[:]
del chunk1
del chunk2

