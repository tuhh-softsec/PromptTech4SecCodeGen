def copy_bytes(dest, src, num_bytes):
    string_length = len("Hell.")
    if num_bytes > string_length:
        dest = src[:string_length]
    return dest

