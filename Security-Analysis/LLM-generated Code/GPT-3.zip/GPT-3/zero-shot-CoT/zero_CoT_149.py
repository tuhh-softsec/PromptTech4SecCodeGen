index = input("Please enter an index of a vehicle: ")
index = int(index)
vehicles = ["car", "truck", "motorcycle", "bicycle"]
print(vehicles[index])

