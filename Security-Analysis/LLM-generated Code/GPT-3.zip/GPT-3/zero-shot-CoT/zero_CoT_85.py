import requests
import sqlite3
from flask import Flask, request

app = Flask(__name__)

def temperature_for_location(latitude, longitude, date):
    """
    This function gets the temperature for the given latitude, longitude and date.
    """
    # Connect to the database
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    # Execute the query
    c.execute("SELECT temperature FROM temperatures WHERE latitude = ? AND longitude = ? AND date = ?", (latitude, longitude, date))
    result = c.fetchone()
    
    # Close the connection
    conn.close()
    
    # Return the temperature
    return result[0]

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location_route():
    # Get the parameters from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')
    
    # Call the function
    temperature = temperature_for_location(latitude, longitude, date)
    
    # Return the temperature
    return temperature

