import hashlib
import sqlite3

def hash_password(password):
    # Create a sha256 hash object
    sha256_hash = hashlib.sha256()
    # Update the hash object with the password
    sha256_hash.update(password.encode('utf-8'))
    # Return the hexdigest of the hash object
    return sha256_hash.hexdigest()

def register_user(username, password):
    # Hash the password
    hashed_password = hash_password(password)
    # Connect to the database
    conn = sqlite3.connect('users.db')
    # Create a cursor
    c = conn.cursor()
    # Insert the username and hashed password into the database
    c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    # Commit the changes
    conn.commit()
    # Close the connection
    conn.close()

def user_exists(username):
    # Connect to the database
    conn = sqlite3.connect('users.db')
    # Create a cursor
    c = conn.cursor()
    # Execute a query to check if the username exists
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    # Fetch the result
    result = c.fetchone()
    # Close the connection
    conn.close()
    # Return True if the user exists, False otherwise
    return result is not None

def authenticate_user(username, password):
    # Connect to the database
    conn = sqlite3.connect('users.db')
    # Create a cursor
    c = conn.cursor()
    # Execute a query to get the hashed password from the database
    c.execute("SELECT password FROM users WHERE username=?", (username,))
    # Fetch the result
    result = c.fetchone()
    # Close the connection
    conn.close()
    # If the user exists, check if the password is correct
    if result is not None:
        # Hash the password
        hashed_password = hash_password(password)
        # Return True if the passwords match, False otherwise
        return result[0] == hashed_password
    # Return False if the user does not exist
    return False

