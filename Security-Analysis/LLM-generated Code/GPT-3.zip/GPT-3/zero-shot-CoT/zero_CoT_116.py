import random

float1 = random.uniform(0, 1)
float2 = random.uniform(0, 1)
float3 = random.uniform(0, 1)

string1 = str(float1)
string2 = str(float2)
string3 = str(float3)

concatenated_string = string1 + string2 + string3

with open('random_floats.txt', 'w') as f:
    f.write(concatenated_string)

