import yaml

def calculate_price(query_parameter):
        # Parse the YAML payload
        payload = yaml.safe_load(query_parameter)
        # Extract the product_code and quantity
        product_code = payload['product_code']
        quantity = payload['quantity']
        # Calculate the total price
        total_price = product_code * quantity
        # Return the total price as a string
        return str(total_price)

# Example query parameter (replace with actual query parameter)
query_parameter = """
product_code: ABC123
quantity: 5
"""

# Call the function and handle exceptions
try:
    calculate_price(query_parameter)
except Exception as e:
    print(e)  # Print the exception if it occurs


