import flask
from flask import request, redirect

app = flask.Flask(__name__)

@app.route('/redirect/<url>')
def redirect_invalid_url(url):
    if not url.startswith('http://example.com'):
        return 'Error: Invalid URL'
    else:
        return redirect(url)

if __name__ == '__main__':
    app.run()

