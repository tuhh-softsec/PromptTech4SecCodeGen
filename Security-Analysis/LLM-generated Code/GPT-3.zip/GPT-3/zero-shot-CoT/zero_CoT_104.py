import os

secret_info = "This is a super secret message!"

with open("secret_file.txt", "w") as f:
    f.write(secret_info)


os.chmod("secret_file.txt", 0o400)

print("The secret file is called secret_file.txt")

