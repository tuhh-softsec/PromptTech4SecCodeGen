my_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

def get_value_at_index(index):
    if index < 0 or index >= len(my_array):
        return -1
    else:
        return my_array[index]

try:
    index = int(input("Please enter an integer: "))
    print(get_value_at_index(index))
except ValueError:
    print("Invalid input. Please enter an integer.")

