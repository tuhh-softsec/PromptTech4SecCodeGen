
buffer_size = 10
# Allocate a buffer of size buffer_size
buffer = bytearray(buffer_size)

# Free the buffer
del buffer

