import flask
from flask import Flask, request, redirect, session, render_template

app = Flask(__name__)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        do_login(username, password)
    else:
        return render_template('login.html')

def do_login(username, password):
    if username == 'admin' and password == 'password':
        session['username'] = username
        return redirect('/secret')
    else:
        return redirect('/login')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return render_template('secret.html')
    else:
        return redirect('/login')

