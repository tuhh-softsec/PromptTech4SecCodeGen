import os

# Create the file
f = open("secret.txt", "w")

# Write the string to the file
f.write("U2FsdGVkX1/R+WzJcxgvX/Iw==")

# Close the file
f.close()

# Set the permissions to restrictive
os.chmod("secret.txt", 0o600)

