import os

file_descriptor = os.open("important_config", os.O_RDWR | os.O_CREAT, 
                           os.S_IRUSR | os.S_IWUSR | os.S_IRGRP | os.S_IROTH)
os.write(file_descriptor, "important_confi")
os.close(file_descriptor)

