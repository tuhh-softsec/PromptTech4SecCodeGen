def check_mod(username, password):
    if username == 'correct_username' and password == 'correct_password':
        return True
    else:
        return False

button.addEventListener('click', check_mod)

check_mod(form.username, form.password)

