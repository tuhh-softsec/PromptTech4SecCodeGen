import mysql.connector
import hashlib

# Connect to the database
db = mysql.connector.connect(
    host="localhost",
    user="username",
    passwd="password",
    database="database_name"
)

def check_username(username):
    # Create a cursor
    cursor = db.cursor()

    # Execute the query
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))

    # Fetch the result
    result = cursor.fetchone()

    # Check if the username exists
    if result:
        return True
    else:
        return False

def hash_username(username):
    # Create a sha256 hash object
    sha256_hash = hashlib.sha256()

    # Update the hash object with the username
    sha256_hash.update(username.encode('utf-8'))

    # Return the hexdigest
    return sha256_hash.hexdigest()

def secure_check_username(username):
    # Hash the username
    hashed_username = hash_username(username)

    # Create a cursor
    cursor = db.cursor()

    # Execute the query
    cursor.execute("SELECT * FROM users WHERE username_hash = %s", (hashed_username,))

    # Fetch the result
    result = cursor.fetchone()

    # Check if the username exists
    if result:
        return True
    else:
        return False

