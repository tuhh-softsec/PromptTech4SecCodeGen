class Person:
    def __init__(self):
        self.status = 0
        self.name = ""

# Create a Person object
person_ptr = Person()
person_ptr.name = "Joh"
