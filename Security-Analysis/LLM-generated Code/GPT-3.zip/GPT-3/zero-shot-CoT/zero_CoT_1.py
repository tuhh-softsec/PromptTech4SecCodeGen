def copy_bytes(destination, source, num_bytes):
    """Copies a number of bytes from one memory location to another."""
    if num_bytes > len(source):
        raise ValueError("Number of bytes to copy is greater than the length of the source string.")
    for i in range(num_bytes):
        destination[i] = source[i]
    return destination

