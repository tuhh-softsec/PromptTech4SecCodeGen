buf = bytearray(1024) # Allocate 1024 bytes of memory
fgets(buf, 100, stdin) # Read up to 100 characters from stdin and store them in buf

buf1 = bytearray(1024) # Allocate another 1024 bytes of memory
fgets(buf1, 100, stdin) # Read up to 100 characters from stdin and store them in buf1

