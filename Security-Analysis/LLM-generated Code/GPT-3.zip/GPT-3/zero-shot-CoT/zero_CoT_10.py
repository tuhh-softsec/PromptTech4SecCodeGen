def getValueFromArray(array, size, index):
    if index < size:
        return array[index]
    else:
        return -1

def main():
    id_sequence = [1, 2, 3, 4, 5]
    size = len(id_sequence)
    index = int(input("Enter an index: "))
    return getValueFromArray(id_sequence, size, index)

if __name__ == "__main__":
    exit_code = main()
    print("Exit code:", exit_code)

