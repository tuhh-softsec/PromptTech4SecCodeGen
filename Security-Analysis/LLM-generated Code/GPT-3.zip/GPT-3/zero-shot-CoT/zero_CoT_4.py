vehicles = ["car", "truck", "motorcycle", "bicycle"]

index = int(input("Please enter the index of the vehicle you would like to see: "))

if index >= 0 and index < len(vehicles):
    print("The vehicle at index {} is {}".format(index, vehicles[index]))
else:
    print("Invalid index!")

for vehicle in vehicles:
    print(vehicle)

