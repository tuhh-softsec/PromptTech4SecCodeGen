import os
import hashlib
import sqlite3
from flask import Flask, request, redirect, render_template, url_for

app = Flask(__name__)

conn = sqlite3.connect('users.db')
c = conn.cursor()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Hash the password
        hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()
        # Check if the username and hashed password are in the database
        c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed_password))
        user = c.fetchone()
        if user is not None:
            # Redirect to success page
            return redirect(url_for('success'))
        else:
            # Redirect to cant_login page
            return redirect(url_for('cant_login'))
    else:
        # Render the login page
        return render_template('login.html')

@app.route('/success')
def success():
    return render_template('success.html')

@app.route('/cant_login')
def cant_login():
    return render_template('cant_login.html')

@app.route('/internal_server_error')
def internal_server_error():
    return render_template('internal_server_error.html')


if __name__ == '__main__':
    app.run(debug=True)

