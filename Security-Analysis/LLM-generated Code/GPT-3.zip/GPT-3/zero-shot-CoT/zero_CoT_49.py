import tarfile
import contextlib

with contextlib.closing(tarfile.open('my_archive.tar', 'w')) as archive:
    # Do something with the archive
    pass

with open('my_file.txt', 'r') as f:
    data = f.read()
    # Do something with the data

