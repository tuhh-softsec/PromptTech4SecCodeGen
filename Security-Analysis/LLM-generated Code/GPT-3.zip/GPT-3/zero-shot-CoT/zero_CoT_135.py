def check_mod(username, password, session):
    """Checks if the user is a moderator"""
    # Call auth_mod() with the username, password, and session
    is_moderator = auth_mod(username, password, session)
    # Return the result of auth_mod()
    return is_moderator

def auth_mod(username, password, session):
    """Authenticates the user as a moderator"""
    # Check if the user is a moderator
    is_moderator = check_if_moderator(username, password, session)
    # Return the result of check_if_moderator()
    return is_moderator

def check_if_moderator(username, password, session):
    """Checks if the user is a moderator"""
    # Connect to the database
    db = connect_to_db()
    # Query the database for the user
    user = db.query("SELECT * FROM users WHERE username = %s AND password = %s AND session = %s", (username, password, session))
    # Check if the user is a moderator
    is_moderator = user.is_moderator
    # Return the result
    return is_moderator

