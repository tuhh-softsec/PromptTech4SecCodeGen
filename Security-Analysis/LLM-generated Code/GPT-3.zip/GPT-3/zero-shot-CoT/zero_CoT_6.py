string = ""
num = int(string)
argc = 0
argv = ["./a.out"]

for i in range(1, argc):
    argv.append(argv[i])

