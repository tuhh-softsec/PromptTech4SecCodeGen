import os
import subprocess

username = "<username>"

os.system("getent passwd " + username)
output = subprocess.Popen("getent passwd " + username, stdout=subprocess.PIPE).stdout

