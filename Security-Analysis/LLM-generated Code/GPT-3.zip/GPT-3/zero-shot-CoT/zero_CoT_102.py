import os 

fd = os.open("important_config.txt", os.O_RDWR | os.O_CREAT, 0o700)
os.write(fd, "important_config")
os.close(fd)

