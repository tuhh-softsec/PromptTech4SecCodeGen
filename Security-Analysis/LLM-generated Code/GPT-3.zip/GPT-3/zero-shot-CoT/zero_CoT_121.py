import sys

if len(sys.argv) != 2:
    print("Error: Please provide exactly one argument")
    sys.exit(1)

if not isinstance(sys.argv[1], str):
    print("Error: Argument must be a string")
    sys.exit(1)

arg = sys.argv[1]
for i in range(len(arg) - 1, -1, -1):
    if arg[i] == ' ':
        arg = arg[:i]
    else:
        break

for i in range(len(arg) - 1, -1, -1):
    if arg[i] == '\n':
        arg = arg[:i]
    else:
        break

arg += '\0'

