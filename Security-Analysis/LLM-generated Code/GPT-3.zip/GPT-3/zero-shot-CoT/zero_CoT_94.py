import os
import hashlib

def generate_salt():
    return os.urandom(16)

def hash_password(password, salt):
    return hashlib.sha256(password.encode() + salt).hexdigest()

def register(username, password):
    salt = generate_salt()
    hashed_password = hash_password(password, salt)
    # Store username, salt, and hashed_password in the database

