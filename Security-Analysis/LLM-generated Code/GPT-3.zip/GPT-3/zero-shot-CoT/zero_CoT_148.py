from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/post', methods=['POST'])
def post():
    username = request.form.get('username')
    message = request.form.get('message')
    insert_user_message_in_db(username, message)
    return redirect('main_page')

def insert_user_message_in_db(username, message):
    # code to insert message into the database
    pass

html_code = """
<form action="{{ url_for('post') }}" method="post">
    {{ csrf_token() }}
    <input type="text" name="username" placeholder="Username" />
    <input type="text" name="message" placeholder="Message" />
    <input type="submit" value="Submit" />
</form>
"""

if __name__ == '__main__':
    app.run()
