import sys
import subprocess

username = sys.argv[1]

def run_command(username):
    command = "id " + username
    exit_status = subprocess.call(command, shell=True)
    return exit_status

exit_status = run_command(username)
print("Exit status:", exit_status)

