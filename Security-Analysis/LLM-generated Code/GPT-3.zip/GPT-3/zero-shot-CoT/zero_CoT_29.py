import urlparse
from flask import redirect

def redirect_url(url):
    parsed_url = urlparse.urlparse(url)
    domain_name = parsed_url.netloc
    if domain_name == 'example.com':
        redirect(url)
    else:
        abort(404)

