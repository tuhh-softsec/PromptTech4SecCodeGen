# Declare totalSales variable
totalSales = 0

# Add sales for each month
totalSales += salesForJanuary
totalSales += salesForFebruary
totalSales += salesForMarch

# Print total sales
print("Total sales:", totalSales)

