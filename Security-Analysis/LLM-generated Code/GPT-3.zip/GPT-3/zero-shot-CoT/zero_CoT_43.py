import os
import shutil

SAFE_DIR = '/path/to/safe/directory'

def read_file(filename):
    file_path = os.path.join(SAFE_DIR, filename)
    if check_file_integrity(filename) and check_file_exists(filename):
        with open(file_path, 'r') as f:
            return f.read()
    else:
        raise Exception('File is not secure!')

def check_file_integrity(filename):
    file_path = os.path.join(SAFE_DIR, filename)
    return shutil.check_integrity(file_path)

def check_file_exists(filename):
    file_path = os.path.join(SAFE_DIR, filename)
    return os.path.exists(file_path)

