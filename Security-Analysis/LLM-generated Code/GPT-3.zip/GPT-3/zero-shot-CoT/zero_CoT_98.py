import os
import stat

filename = 'important_config'
permissions = stat.S_IRUSR | stat.S_IWUSR

fd = os.open(filename, os.O_CREAT | os.O_TRUNC | os.O_WRONLY, permissions)
os.close(fd)

