import sys

value = int(sys.argv[1])
value += 1000
print(value)

sys.exit(0)

