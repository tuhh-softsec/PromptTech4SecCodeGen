numbers = [1, 2, 3, 4, 5]

def get_value(index):
    if index < 0 or index >= len(numbers):
        return -1
    return numbers[index]

