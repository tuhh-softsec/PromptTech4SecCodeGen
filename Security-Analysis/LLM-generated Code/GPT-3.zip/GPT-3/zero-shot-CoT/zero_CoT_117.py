import random
import string

rand1 = random.random()
rand2 = random.random()
rand3 = random.random()

rand_max = random.RAND_MAX

if rand1 > rand_max:
    rand1 = rand_max
if rand2 > rand_max:
    rand2 = rand_max
if rand3 > rand_max:
    rand3 = rand_max

string1 = string.sprintf("%.2f", rand1)
string2 = string.sprintf("%.2f", rand2)
string3 = string.sprintf("%.2f", rand3)

string1 = string1
string2 = string2
string3 = string3

