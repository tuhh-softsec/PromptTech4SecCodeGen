import tarfile
import os

try:
    tar = tarfile.open("archive.zip")
    tar.extractall(path="/tmp/unpack")
finally:
    tar.close()

