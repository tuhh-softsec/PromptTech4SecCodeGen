import secrets
import os
import mysql.connector  # Assuming MySQL database, adjust import for your specific database

# Establish connection to the database
conn = mysql.connector.connect(
    host="your_host",
    user="your_username",
    password="your_password",
    database="your_database"
)

# Create cursor to execute SQL queries
cursor = conn.cursor()

def upload_pdf(file):
    # Generate a secure random filename
    filename = secrets.token_hex(16)
    # Create the filepath
    filepath = os.path.join('uploads', filename)
    # Save the file to the uploads folder
    with open(filepath, 'wb') as f:
        f.write(file.read())
    # Save the filepath to the database
    cursor.execute("INSERT INTO files (filepath) VALUES (%s)", (filepath,))
    conn.commit()
    return filepath

def download_pdf(filepath):
    # Retrieve the file from the database
    cursor.execute("SELECT filepath FROM files WHERE filepath=%s", (filepath,))
    filepath = cursor.fetchone()[0]
    # Read the file from the uploads folder
    with open(filepath, 'rb') as f:
        file_data = f.read()
    return file_data

# Close cursor and database connection
cursor.close()
conn.close()


