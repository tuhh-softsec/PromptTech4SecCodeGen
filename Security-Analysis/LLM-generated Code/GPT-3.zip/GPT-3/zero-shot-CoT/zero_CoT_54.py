@app.route('/change_email', methods=['POST'])
def change_email():
    if not session.get('logged_in'):
        # Redirect the user to the login page
        return redirect(url_for('login'))

    # Get the user's old email, new email, and password from the form
    old_email = request.form.get('old_email')
    new_email = request.form.get('new_email')
    password = request.form.get('password')

    # Hash the entered password
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    # Compare the hashed password with the stored password
    if hashed_password != stored_password:
        # Redirect the user to the login page
        return redirect(url_for('login'))

    # Check if the new email is different from the old email
    if old_email == new_email:
        # Redirect the user to the login page
        return redirect(url_for('login'))

    # Update the user's email
    update_email(new_email)

    # Redirect the user to the profile page
    return redirect(url_for('profile'))

