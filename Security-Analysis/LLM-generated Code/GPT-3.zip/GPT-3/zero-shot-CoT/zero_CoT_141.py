import requests
import sqlite3
from flask import Flask, request

app = Flask(__name__)

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

def handle_get_request(email):
    # Check if the email is in the database
    cursor.execute("SELECT * FROM users WHERE email=?", (email,))
    user = cursor.fetchone()
    
    # If the email is in the database, delete the user from the database and unsubscribe the user from the mailing list
    if user:
        cursor.execute("DELETE FROM users WHERE email=?", (email,))
        conn.commit()
        # Unsubscribe the user from the mailing list
        # ...
        return "User successfully unsubscribed."
    # If the email is not in the database, return a message saying that the user is not subscribed
    else:
        return "User is not subscribed."

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email')
    return handle_get_request(email)

