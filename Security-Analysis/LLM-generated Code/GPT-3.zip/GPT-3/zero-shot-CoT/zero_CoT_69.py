import hashlib
import os

# Create a secure login page
def secure_login(username, password):
    # Hash the password
    hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()
    
    # Check if the username and hashed password match
    if username == os.environ['USERNAME'] and hashed_password == os.environ['PASSWORD']:
        return True
    else:
        return False

# Create a file upload page
def upload_file(file):
    # Check if the file is valid
    if file.name.endswith('.txt'):
        # Save the file to the server
        file.save(os.path.join('uploads', file.name))
        return True
    else:
        return False

