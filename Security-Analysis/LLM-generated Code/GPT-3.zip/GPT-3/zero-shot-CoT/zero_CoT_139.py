import os
import sqlite3
from flask import Flask

app = Flask(__name__)

def get_db_connection():
    db_path = os.path.join(app.root_path, 'database.db')
    conn = sqlite3.connect(db_path)
    return conn

def get_server_name():
    return 'localhost'

def get_db_name():
    return 'my_database'

def get_db_user():
    return 'my_user'

def get_db_password():
    return 'my_password'

