from flask import Flask, request, send_file

app = Flask(__name__)
@app.route('/img')
def img():
    name = request.args.get('name')
    file = open('images/' + name)
    return send_file(file)

