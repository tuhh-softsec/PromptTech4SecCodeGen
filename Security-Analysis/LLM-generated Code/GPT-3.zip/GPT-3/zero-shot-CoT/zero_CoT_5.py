from ast import literal_eval
import sys

args = sys.argv
index = literal_eval(args[1])
string = args[index]
print(string)
sys.exit(0)

