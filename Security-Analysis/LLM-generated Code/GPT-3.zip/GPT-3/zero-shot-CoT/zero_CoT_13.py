def get_id_sequence_value(id_sequence):
    index_value = int(input("Please enter an index value: "))
    if index_value < 0 or index_value >= len(id_sequence):
        print("Index value is not in bounds.")
        return 0
    return id_sequence[index_value]

