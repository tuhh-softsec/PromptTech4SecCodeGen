import os
import stat

f = open("important_config", os.O_WRONLY | os.O_CREAT, stat.S_IRUSR | stat.S_IWUSR)
f.write("important_config")
f.close()

