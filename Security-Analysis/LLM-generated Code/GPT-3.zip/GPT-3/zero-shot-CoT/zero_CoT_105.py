import os

# Create the file
f = open("secret.txt", "w")

# Write the string to the file
f.write("U2FsdGVkX1/R+WzJcxgvX/Iw==")

# Close the file
f.close()

# Set the permissions of the file to 128
os.chmod("secret.txt", 128)

# Get the permissions of the file
permissions = oct(os.stat("secret.txt").st_mode)[-3:]

# Print the permissions
print("The permissions of the file are printed as 0o{}".format(permissions))

