from flask import Flask
from html import escape

app = Flask(__name__)

@app.route('/hello/<username>')
def hello(username):
    return 'Hello ' + escape(username)

@app.route('/hello/<username>')
def hello_user(username):
    return hello(username)

if __name__ == '__main__':
    app.run()

