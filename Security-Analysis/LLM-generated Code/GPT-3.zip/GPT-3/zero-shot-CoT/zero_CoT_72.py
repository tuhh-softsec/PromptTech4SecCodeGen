class Person:
    def __init__(self):
        self.status = 0

def create_person():
    ptr = Person()
    return ptr

# Usage
person_ptr = create_person()
