import sqlite3
import json
from flask import Flask, request

app = Flask(__name__)

conn = sqlite3.connect('Senso.db')

def temperature_for_location(latitude, longitude, date):
    # Connect to the database
    c = conn.cursor()
    
    # Get the temperature for the given date
    c.execute("SELECT temperature FROM Senso WHERE latitude=? AND longitude=? AND date=?", (latitude, longitude, date))
    result = c.fetchone()
    
    # Return the temperature
    return json.dumps(result[0])

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location_route():
    # Get the parameters from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')
    
    # Call the function
    temperature = temperature_for_location(latitude, longitude, date)
    
    # Return the temperature
    return temperature

conn.close()

