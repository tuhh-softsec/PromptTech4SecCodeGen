import os
import sys

def execute_command(command):
    return os.popen(command).read()

username = sys.argv[1]
user_info = execute_command("cat /etc/passwd | grep " + username)
print(user_info)

