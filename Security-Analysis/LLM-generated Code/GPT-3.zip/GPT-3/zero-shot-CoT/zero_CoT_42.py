import os
import shutil

safe_dir = '/safe/'
file_name = input('Please enter the file name: ')

if os.path.exists(os.path.join(safe_dir, file_name)):
    with open(os.path.join(safe_dir, file_name), 'r') as f:
        content = f.read()
    print(content)
    shutil.copy(os.path.join(safe_dir, file_name), '/secure/')

