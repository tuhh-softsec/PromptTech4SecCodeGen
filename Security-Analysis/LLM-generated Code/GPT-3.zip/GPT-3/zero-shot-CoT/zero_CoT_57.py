import ctypes
buffer_size = 1024
buffer = bytearray(buffer_size)
for i in range(buffer_size):
    buffer[i] = ord('A')
buffer_ptr = ctypes.create_string_buffer(buffer)

