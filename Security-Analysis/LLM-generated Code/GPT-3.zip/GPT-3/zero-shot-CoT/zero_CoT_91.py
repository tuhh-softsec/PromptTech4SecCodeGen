import hashlib
import sqlite3

username = input("Please enter your username: ")
password = input("Please enter your password: ")

hashed_password = hashlib.sha256(password.encode()).hexdigest()

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
conn.commit()
conn.close()

