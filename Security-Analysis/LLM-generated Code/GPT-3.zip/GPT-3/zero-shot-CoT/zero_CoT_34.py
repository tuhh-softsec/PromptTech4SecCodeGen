import cgi
import sqlite3
import bcrypt

# Get the username and password from the form
form = cgi.FieldStorage()
username = form.getvalue('username')
password = form.getvalue('password')

# Connect to the database
conn = sqlite3.connect('users.db')
c = conn.cursor()

# Query the database to check if the username exists
c.execute("SELECT * FROM users WHERE username=?", (username,))
user = c.fetchone()

# If the username exists, check if the password is correct
if user:
    if bcrypt.checkpw(password.encode('utf-8'), user[1].encode('utf-8')):
        # Redirect the user to the home page
        print("Location: home.html\n")
    else:
        # Return if the password is incorrect
        print("Incorrect password")
else:
    # Return if the username does not exist
    print("Username does not exist")

conn.close()

