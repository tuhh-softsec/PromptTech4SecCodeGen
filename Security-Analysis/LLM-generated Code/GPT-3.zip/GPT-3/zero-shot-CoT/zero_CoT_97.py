import bcrypt
import sqlite3

username = input("Please enter your username: ")
password = input("Please enter your password: ")

hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

conn = sqlite3.connect('database.db')
c = conn.cursor()

c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))

conn.commit()
conn.close()

