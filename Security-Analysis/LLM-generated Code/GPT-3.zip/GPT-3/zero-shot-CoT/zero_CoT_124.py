def http_hello_page(request):
    username = request.body
    outputbuf = f"<html><body>Hello {username}!</body></html>"
    request.write(outputbuf)
    request.close()
    return

