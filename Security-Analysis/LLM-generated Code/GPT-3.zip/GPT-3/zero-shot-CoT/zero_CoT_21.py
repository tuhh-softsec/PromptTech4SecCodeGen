import random

a = random.randint(1001, 9999)
b = random.randint(1001, 9999)
c = random.randint(1001, 9999)

print("a :", a)
print("b :", b)
print("c :", c)

sum = a + b + c
print("sum:", sum)

sum2 = int(a) + int(b) + int(c)
print("sum2:", sum2)

