def change_email(old_email, new_email, confirm_password):
    if is_authenticated() and check_password(confirm_password) and check_email_exists(new_email):
        change_email(old_email, new_email)
        return True
    else:
        return False

