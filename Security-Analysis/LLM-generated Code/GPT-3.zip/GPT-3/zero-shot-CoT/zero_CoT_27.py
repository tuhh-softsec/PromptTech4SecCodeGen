import re
from flask import Flask, redirect, request

app = Flask(__name__)

@app.route('/', methods=['GET'])
def redirect_to_target():
    target = request.args.get('target')
    regex = re.compile(r'example\.com')
    if regex.match(target):
        return redirect(target)
    else:
        return redirect('/')

if __name__ == '__main__':
    app.run()

