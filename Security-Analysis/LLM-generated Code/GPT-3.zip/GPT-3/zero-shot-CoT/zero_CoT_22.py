import random
num1 = random.randint(10, 1000)
num2 = random.randint(10, 1000)
difference = num1 - num2
print("The difference between the two integers is:", difference)

