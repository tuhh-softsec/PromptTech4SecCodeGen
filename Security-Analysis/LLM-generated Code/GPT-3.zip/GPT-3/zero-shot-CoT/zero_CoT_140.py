import sqlite3
from flask import request

email = request.form.get('email')

def unsubscribe(email):
    # Connect to the database
    db = sqlite3.connect('database.db')

    # Create a cursor
    cursor = db.cursor()

    # Execute the query
    cursor.execute("SELECT * FROM users WHERE email=?", (email,))

    # Fetch the result
    result = cursor.fetchone()

    if result:
        # Execute the query
        cursor.execute("DELETE FROM users WHERE email=?", (email,))
        # Commit the changes
        db.commit()
    else:
        print("The email address is not in the database.")

