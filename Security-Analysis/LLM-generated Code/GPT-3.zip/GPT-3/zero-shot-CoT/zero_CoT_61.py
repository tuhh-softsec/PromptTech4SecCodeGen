import hashlib

with open('file.txt', 'rb') as f:
    buffer = f.read()

checksum = hashlib.md5(buffer).hexdigest()

if checksum == 0:
    print('Buffer is empty')

with open('output.txt', 'w') as f:
    f.write('Number of bytes read: {}\nChecksum: {}'.format(len(buffer), checksum))

