import sys

index = int(sys.argv[1])

if index < 0 or index >= len(sys.argv):
    print("Error: Invalid index!")
    sys.exit(1)

print(sys.argv[index])

