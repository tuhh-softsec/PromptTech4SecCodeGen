import flask
from flask import Flask, request

app = Flask(__name__)
app.config['PORT'] = 5000

def get_price(product_code):
    # code to get the price for the product code
    return price

@app.route('/price', methods=['GET'])
def calculate_price():
    product_code = request.args.get('product_code')
    quantity = request.args.get('quantity')
    price = get_price(product_code) * quantity
    return str(price)

if __name__ == '__main__':
    app.run(port=5000)

