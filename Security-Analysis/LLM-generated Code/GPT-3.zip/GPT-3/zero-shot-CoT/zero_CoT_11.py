def get_id_sequence_value(id_sequence, index):
    if index < 0 or index >= len(id_sequence):
        return -1
    return id_sequence[index]

id_sequence = [1, 2, 3, 4, 5, 6]
index = int(input("Please enter an index value: "))
value = get_id_sequence_value(id_sequence, index)
print("The value at index {} is {}".format(index, value))

