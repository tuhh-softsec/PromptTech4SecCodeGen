import re

REGEX = re.compile(r'<your_regex_here>')
DEFAULT_URL = '<your_default_url_here>'

def match_url(target_url):
    if REGEX.match(target_url):
        return target_url
    else:
        return DEFAULT_URL

def construct_redirect_url(target_url):
    return match_url(target_url)

