import subprocess

def execute_ls(command):
    
    subprocess.run(command, shell=True)

def print_command(format_string, *args):
    command = format_string.format(*args)
    print(command)
    return command

def main():
    command_string = print_command("ls {}", "/path/to/directory")
    execute_ls(command_string)

if __name__ == "__main__":
    main()

