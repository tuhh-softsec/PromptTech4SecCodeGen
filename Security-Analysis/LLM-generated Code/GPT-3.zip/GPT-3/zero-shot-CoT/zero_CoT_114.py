import os

cmd_fmt = 'ls %s'
args = ('-l',)

cmd = print(cmd_fmt, *args)
os.system(cmd)

