import random

def float_to_string(f):
    return str(f)

a = random.random()
b = random.random()
c = random.random()

str_a = float_to_string(a)
str_b = float_to_string(b)
str_c = float_to_string(c)

