class Person:
    def __init__(self):
        self.status = 0

# Create a Person object
person = Person()
