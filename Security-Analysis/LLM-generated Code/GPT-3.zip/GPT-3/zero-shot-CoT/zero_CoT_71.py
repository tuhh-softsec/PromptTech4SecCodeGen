class Person:
    def __init__(self, age, name):
        self.age = age
        self.name = name

# Create a Person instance
person = Person(25, "John Doe")
