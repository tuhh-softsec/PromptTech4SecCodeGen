import tarfile
import os

try:
    tar = tarfile.open("archive.zip")
    tar.extractall(path=os.path.join("/tmp", "unpack"))
finally:
    tar.close()

