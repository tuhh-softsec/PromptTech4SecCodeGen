import flask
from flask import Flask, request, session

app = Flask(__name__)
app.secret_key = '<your_secret_key_here>'

@app.route('/info', methods=['GET'])
def info():
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')[-4:]
    return f'Username: {username}<br>Email: {email}<br>Last 4 digits of SSN: {ssn}'

if __name__ == '__main__':
    app.run()

