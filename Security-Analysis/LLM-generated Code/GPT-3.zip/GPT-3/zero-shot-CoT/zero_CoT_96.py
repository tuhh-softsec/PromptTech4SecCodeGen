import bcrypt
import sqlite3

conn = sqlite3.connect('database.db')
cursor = conn.cursor()

username = input('Enter your username: ')
password = input('Enter your password: ')

hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
conn.commit()

conn.close()

