def http_hello_page(request, response):
    username = request.read()
    response_string = "Hello " + escape_html(username)
    response.write(response_string)
    response.send()

def escape_html(string):
    # Code to escape HTML goes here
    return escaped_string

