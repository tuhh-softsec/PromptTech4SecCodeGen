import hashlib
import sqlite3
from flask import request, redirect, session

# Get the username and password from the form
username = request.form.get('username')
password = request.form.get('password')

# Hash the password
hashed_password = hashlib.sha256(password.encode('utf-8')).hexdigest()

# Connect to the database
conn = sqlite3.connect('users.db')
c = conn.cursor()

# Check if the username and password match
c.execute("SELECT * FROM users WHERE username=? AND password=?", (username, hashed_password))
user = c.fetchone()

if user:
    # Log the user in and redirect to the dashboard page
    session['logged_in'] = True
    redirect('/dashboard')
else:
    # Redirect back to the login page
    redirect('/login')

