buffer = bytearray(1024)

def scan(format_string):
    # Read in a string from the standard input
    string = input()
    
    # Read in the string until it sees a newline character
    n = 0
    for c in string:
        if c == '\n':
            break
        if n == 1023:
            break
        buffer[n] = ord(c)
        n += 1
    
    # Read in the newline character, but don't store it in the buffer
    if string[-1] == '\n':
        n += 1
    
    # Return the number of characters read in
    return n

