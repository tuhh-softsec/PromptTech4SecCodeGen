from flask import Flask, request, redirect

app = Flask(__name__)

def check_mod(username, password):
    # Check if the username and password are correct
    if username == 'correct_username' and password == 'correct_password':
        return 'true'

@app.route('/check_mod')
def check_mod_route():
    username = request.args.get('username')
    password = request.args.get('password')
    return check_mod(username, password)

@app.before_request
def secure_check_mod():
    if request.path == '/check_mod':
        if not request.is_secure:
            return redirect(request.url.replace('http://', 'https://'))

