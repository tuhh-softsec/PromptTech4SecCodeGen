import re
from flask import request, redirect

regex = r"^[\w-]+\."
target = request.args.get('target')

if re.match(regex, target):
    redirect(target)
else:
    redirect('/')

