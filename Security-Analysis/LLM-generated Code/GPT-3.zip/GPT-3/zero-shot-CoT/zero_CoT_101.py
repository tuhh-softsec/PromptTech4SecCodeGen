import os

O_CREAT = os.O_CREAT
O_TRUNC = os.O_TRUNC
O_WRONLY = os.O_WRONLY
O_EXCL = os.O_EXCL

file = open("filename.txt", O_CREAT | O_TRUNC | O_WRONLY | O_EXCL)
file.open(mode="w", buffering=0, encoding=None, errors=None, newline=None, closefd=True, opener=None)

