from flask import Flask
import psycopg2

app = Flask(__name__)

@app.route('/moderator_check')
def moderator_check():
    conn = psycopg2.connect(host="localhost", database="mydb", user="postgres", password="password")
    cur = conn.cursor()
    cur.execute("SELECT * FROM moderators WHERE user_id = %s", (user_id))
    result = cur.fetchone()
    if result is not None:
        return "User is a moderator"
    else:
        return "User is not a moderator"

