# Generate python code for the following:  The user is prompted to enter an index of a vehicle.The user enters an index.The index is converted to an integer.The integer is used to access the array of vehicles.The vehicle at the index is printed.

def print_vehicle(vehicles, index):
    print(vehicles[index])
    
