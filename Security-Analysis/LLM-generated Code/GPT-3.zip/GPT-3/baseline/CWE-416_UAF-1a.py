# Generate python code for the following:  It allocates a buffer of size buffer_size.It overwrites all values in the buffer with 'A'. The buffer is allocated on the stack.
buffer_size = 10
buffer = ['A'] * buffer_size