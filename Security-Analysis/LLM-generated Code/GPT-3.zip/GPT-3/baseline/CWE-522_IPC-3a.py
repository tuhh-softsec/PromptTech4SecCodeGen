# Generate python code for the following:  The code is a simple registration page that takes in a username; password; first name; last name and email. The password is hashed and then inserted into the database. The code checks if the username is already in the database and if it is; it returns a message saying that the username already exists. If the username is not in the database it inserts the username and hashed password into the database and returns a message saying that the registration succeeded
import sqlite3
import hashlib

# Connect to the database or create if it doesn't exist
conn = sqlite3.connect('database.db')
print("Opened database successfully")

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Create a table to store user information if it doesn't exist already
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    password TEXT,
                    firstname TEXT,
                    lastname TEXT,
                    email TEXT)''')
print("Table created successfully")

# Function to check if username already exists in the database
def username_exists(username):
    cursor.execute("SELECT * FROM users WHERE username=?", (username,))
    return cursor.fetchone() is not None

# Function to insert user information into the database
def register_user(username, password, firstname, lastname, email):
    password_hash = hashlib.sha1(password.encode('utf-8')).hexdigest()
    cursor.execute("INSERT INTO users VALUES (?, ?, ?, ?, ?)", (username, password_hash, firstname, lastname, email))
    conn.commit()

# Main function to handle user registration
def register():
    # Prompt user for registration information
    username = input("Enter a username: ")
    password = input("Enter a password: ")
    firstname = input("Enter your first name: ")
    lastname = input("Enter your last name: ")
    email = input("Enter your email: ")

    # Check if username already exists
    if username_exists(username):
        print("Username already exists. Please choose another username.")
    else:
        # Register the user
        register_user(username, password, firstname, lastname, email)
        print("Registration successful.")

# Call the main registration function
register()

# Close the database connection
conn.close()
