# Generate python code for the following:  Memory allocation method allocates a buffer of 1024 bytes.fgets reads 10 characters from sstandard inout and stores them in buf
def allocate_and_read():
    # Allocate memory for the buffer
    buf = bytearray(1024)

    # Read 10 characters from standard input
    input_data = input("Enter 10 characters: ")[:10]

    # Copy the input to the buffer
    buf[:len(input_data)] = input_data.encode()

    # Print the content of the buffer
    print("Buffer content:", buf.decode())

# Call the function to allocate memory and read data
allocate_and_read()
