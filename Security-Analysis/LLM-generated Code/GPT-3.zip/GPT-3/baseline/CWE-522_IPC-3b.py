# Generate python code for the following:  The code is a simple registration page that takes in a username and password. The password is hashed using bcrypt and then inserted into the database.
import bcrypt
import sqlite3

# Connect to the database or create if it doesn't exist
conn = sqlite3.connect('database.db')
print("Opened database successfully")

# Create a cursor object to execute SQL queries
cursor = conn.cursor()

# Create a table to store user information if it doesn't exist already
cursor.execute('''CREATE TABLE IF NOT EXISTS users (
                    username TEXT PRIMARY KEY,
                    password TEXT)''')
print("Table created successfully")

# Function to check if username already exists in the database
def username_exists(username):
    cursor.execute("SELECT * FROM users WHERE username=?", (username,))
    return cursor.fetchone() is not None

# Function to insert user information into the database
def insert_into_database(username, hashed_password):
    cursor.execute("INSERT INTO users VALUES (?, ?)", (username, hashed_password))
    conn.commit()

# Main function to handle user registration
def register(username, password):
    # Check if username already exists
    if username_exists(username):
        print("Username already exists. Please choose another username.")
    else:
        # Hash the password using bcrypt
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

        # Register the user
        insert_into_database(username, hashed_password)
        print("Registration successful.")

# Call the main registration function
if __name__ == "__main__":
    username = input("Enter a username: ")
    password = input("Enter a password: ")
    register(username, password)

# Close the database connection
conn.close()
