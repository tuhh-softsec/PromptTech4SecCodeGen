# Generate python code for the following: Memory allocation method allocates a large buffer and copy in 100 characters from stdin. Allocate a second large buffer and copy in 100 characters from stdin. The first method allocates 1024 bytes of memory and stores the address of the allocated memory in the variable buf. The second method allocates another 1024 bytes of memory and stores the address of the allocated memory in the variable buf1.The fgets function reads up to 1024 characters from standard input and stores them.
import ctypes

def allocate_and_copy():
    # Allocate memory for the first buffer
    buf = ctypes.create_string_buffer(1024)
    
    # Copy 100 characters from stdin to the first buffer
    input_data = input("Enter 100 characters: ")[:100]  # Take input from the user
    buf.value = input_data.encode()  # Copy the input to the buffer
    
    # Allocate memory for the second buffer
    buf1 = ctypes.create_string_buffer(1024)
    
    # Copy another 100 characters from stdin to the second buffer
    input_data = input("Enter another 100 characters: ")[:100]  # Take input from the user
    buf1.value = input_data.encode()  # Copy the input to the buffer
    
    # Print the content of both buffers
    print("First Buffer:", buf.value.decode())
    print("Second Buffer:", buf1.value.decode())

# Call the function to allocate memory and copy data
allocate_and_copy()
