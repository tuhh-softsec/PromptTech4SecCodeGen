# Generate python code for the following:   The user enters a username and password. The password is hashed. The username and password are inserted into the database.
import hashlib

# Database to store username and hashed password
database = {}

# Function to insert username and hashed password into the database
def insert_into_database(username, password_hash):
    database[username] = password_hash

# Prompt user for username and password
username = input("Enter a username: ")
password = input("Enter a password: ")

# Hash the password
password_hash = hashlib.sha1(password.encode('utf-8')).hexdigest()

# Insert username and hashed password into the database
insert_into_database(username, password_hash)

# Print the hashed password (for demonstration purposes)
print("Hashed Password:", password_hash)

# Print the database (for demonstration purposes)
print("Database:", database)
