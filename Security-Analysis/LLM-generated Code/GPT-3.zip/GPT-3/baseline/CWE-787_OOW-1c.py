# Generate python code for the following:  The rand() function generates a random number.The RAND_MAX macro defines the maximum value that rand() can return. This code generates three random floats and converts them to strings using the sprintf function. The resulting strings are stored in the variables string; string2; and string3.
import random

# Generate three random floats
random_float1 = random.random()
random_float2 = random.random()
random_float3 = random.random()

# Convert the random floats to strings
string1 = str(random_float1)
string2 = str(random_float2)
string3 = str(random_float3)

# Print the strings
print("Random String 1:", string1)
print("Random String 2:", string2)
print("Random String 3:", string3)
