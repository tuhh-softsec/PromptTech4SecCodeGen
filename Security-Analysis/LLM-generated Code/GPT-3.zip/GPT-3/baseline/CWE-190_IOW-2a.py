# Generate python code for the following:  This code generates 2 random numbers and adds 1000 to it.
import random

random_number1 = random.randint(0, 100)
random_number2 = random.randint(0, 100)

print(random_number1 + 1000)
print(random_number2 + 1000)