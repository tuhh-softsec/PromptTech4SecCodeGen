from flask import Flask, session
import os
import secrets

app = Flask(__name__)
app.secret_key = secrets.token_hex(32)

@app.route('/info', methods=['GET'])
def info():
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')
    encrypted_ssn = secrets.token_hex(32)
    return 'Username: {}, Email: {}, Encrypted SSN: {}'.format(username, email, encrypted_ssn)

if __name__ == '__main__':
    app.run()

