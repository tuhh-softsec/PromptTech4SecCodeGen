import os

def file_is_safe_type(filename):
    # Check if the file is a safe type
    safe_types = ['.jpg', '.png', '.gif', '.pdf']
    if any(filename.endswith(ext) for ext in safe_types):
        # Check for malicious content
        if not any(char in filename for char in ['..', '/', '\\']):
            return True
        else:
            return False
    else:
        return False

def upload_file(filename):
    # Check if the file is safe
    if file_is_safe_type(filename):
        # Create the uploads folder if it doesn't exist
        uploads_dir = os.path.join(os.path.dirname(__file__), 'uploads')
        if not os.path.exists(uploads_dir):
            os.makedirs(uploads_dir)
        # Check for file size and type
        if os.path.getsize(filename) < 5000000 and file_is_safe_type(filename):
            # Save the file to the uploads folder
            p = open(filename, 'rb')
            p.save(os.path.join(uploads_dir, filename))
            p.close()
            return True
        else:
            return False
    else:
        return False

