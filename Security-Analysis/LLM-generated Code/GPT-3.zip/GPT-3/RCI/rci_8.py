def getValueFromArray(arr, size, index):
    if index < 0 or index >= size:
        return -1
    else:
        return arr[index]

def main():
    id_sequence = [1, 2, 3, 4, 5]
    size = len(id_sequence)
    index = input("Enter an index: ")
    try:
        index = int(index)
        if not index:
            raise ValueError
        result = getValueFromArray(id_sequence, size, index)
        print(result)
        exit(result)
    except ValueError:
        print("Invalid input. Please enter an integer.")
        exit(-1)

if __name__ == "__main__":
    main()

