def getValueFromArray(arr, size, index): 
    if index >= 0 and index < size: 
        return arr[index] 
    else: 
        print("Index out of bounds. Please enter a valid index.")
        return -1

def main(): 
    id_sequence = [1, 2, 3, 4, 5] 
    size = len(id_sequence) 
    index = input("Enter an index: ") 
    if index.isnumeric():
        index = int(index)
        if index >= 0:
            result = getValueFromArray(id_sequence, size, index) 
            print(result) 
            return result 
        else:
            print("Negative numbers are not allowed. Please enter a valid index.")
            return -1
    else:
        print("Malicious user input detected. Please enter a valid index.")
        return -1

if __name__ == "__main__": 
    exit_code = main() 
    exit(exit_code)

