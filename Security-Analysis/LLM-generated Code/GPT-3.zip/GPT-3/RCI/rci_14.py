def secure_code(input_int):
    array = [1,2,3,4,5,6,7,8,9,10]
    if type(input_int) != int:
        return -1
    elif input_int < 0 or input_int > len(array)-1:
        return -1
    else:
        if not check_authentication():
            return -1
        else:
            return array[input_int]

def check_authentication():
    # code to check authentication
    return True

