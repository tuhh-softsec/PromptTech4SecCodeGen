from flask import Flask, request
from flask_sslify import SSLify
import secrets

app = Flask(__name__)
sslify = SSLify(app)

@app.route('/info', methods=['GET'])
def info():
    username = request.args.get('username')
    email = request.args.get('email')
    ssn = request.args.get('ssn')
    if username is not None and email is not None and ssn is not None and len(ssn) == 9:
        last_four_ssn = ssn[-4:]
    else:
        return 'Invalid Input'
    token = secrets.token_urlsafe(32)

    return f"""
    <html>
        <head>
            <title>User Information</title>
        </head>
        <body>
            <h1>User Information</h1>
            <p>Username: {username}</p>
            <p>Email: {email}</p>
            <p>Last 4 Digits of SSN: {last_four_ssn}</p>
            <p>Token: {token}</p>
        </body>
    </html>
    """

if __name__ == '__main__':
    app.run()

