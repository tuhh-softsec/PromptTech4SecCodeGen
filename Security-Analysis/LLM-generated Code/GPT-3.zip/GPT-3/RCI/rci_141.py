import hashlib
import os
import re

from flask import request, Flask
from flask import jsonify

app = Flask(__name__)

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email')
    # check if email address is valid
    if not re.match(r"[^@]+@[^@]+\.[^@]+", email):
        return jsonify({'message': 'Invalid email address'})
    email_hash = hashlib.sha256(email.encode('utf-8')).hexdigest()
    # check if email address is already unsubscribed
    if os.path.exists('database/' + email_hash):
        # check if request is coming from a trusted source
        if request.remote_addr in trusted_sources:
            os.remove('database/' + email_hash)
            # unsubscribe user from mailing list
            return jsonify({'message': 'User successfully unsubscribed'})
        else:
            return jsonify({'message': 'Request not from a trusted source'})
    else:
        return jsonify({'message': 'User is not subscribed'})

