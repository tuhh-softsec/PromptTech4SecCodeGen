import subprocess
import sys

def execute_command(command):
    process = subprocess.Popen(command, stdout=subprocess.PIPE, shell=True)
    output, error = process.communicate()
    return output

if __name__ == '__main__':
    username = sys.argv[1]
    if len(username) > 0 and isinstance(username, str) and username.isalnum():
        command = 'cat /etc/passwd | grep ' + username
        output = execute_command(command)
        if output:
            print(output)

