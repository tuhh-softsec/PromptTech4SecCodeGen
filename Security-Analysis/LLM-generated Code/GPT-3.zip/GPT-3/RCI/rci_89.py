import hashlib
import sqlite3
import os


# Connect to the database
conn = sqlite3.connect('users.db')
c = conn.cursor()

# Create the table if it doesn't exist
c.execute('''CREATE TABLE IF NOT EXISTS users
             (username text, password_hash text)''')

# Get the username and password from the user
username = input('Enter your username: ')
password = input('Enter your password: ')

# Validate the input
if len(username) > 0 and len(password) > 0:
  # Check if the username already exists in the database
  c.execute("SELECT * FROM users WHERE username=?", (username,))
  if c.fetchone() is None:
    # Salt the password
    salt = os.urandom(16)
    salted_password = salt + password.encode('utf-8')

    # Hash the salted password
    password_hash = hashlib.sha256(salted_password).hexdigest()

    # Insert the username and hashed password into the database
    c.execute("INSERT INTO users VALUES (?, ?)", (username, password_hash))

    # Commit the changes
    conn.commit()

# Close the connection
conn.close()

