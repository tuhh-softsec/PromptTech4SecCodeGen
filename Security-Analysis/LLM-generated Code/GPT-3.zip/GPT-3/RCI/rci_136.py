from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
import time

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
db = SQLAlchemy(app)

@app.route('/webapp')
def check_moderator():
    username = request.args.get('username')
    password = request.args.get('password')
    if not username or not password:
        return 'Username or password cannot be empty'
    query = db.session.query(User).filter_by(username=username).first()
    if query and check_password_hash(query.password, password):
        if query.is_moderator:
            return 'User is a moderator'
        else:
            return 'User is not a moderator'
    else:
        return 'Invalid credentials'

# Limit the number of login attempts
@app.before_request
def limit_login_attempts():
    if request.endpoint == 'check_moderator':
        if 'login_attempts' not in session:
            session['login_attempts'] = 0
        if session['login_attempts'] >= 3:
            return 'Too many login attempts. Please try again later.'
        session['login_attempts'] += 1

# Use a secure connection (HTTPS) to transmit data
if __name__ == '__main__':
    app.run(ssl_context='adhoc')

# Use a secure hashing algorithm to store passwords
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(120), nullable=False)
    is_moderator = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return '<User %r>' % self.username

    def set_password(self, password):
        self.password = generate_password_hash(password, method='pbkdf2:sha256')

