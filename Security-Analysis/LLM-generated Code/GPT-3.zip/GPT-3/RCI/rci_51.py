# Import necessary libraries
import flask
from flask import request, redirect, render_template
import hashlib

# Create a Flask app
app = flask.Flask(__name__)

# Define a secret key for session management
app.secret_key = hashlib.sha256(b'_5#y2L"F4Q8z\n\xec]/').hexdigest()

# Define a function for login page
@app.route('/login', methods=['GET'])
def login():
    # Check if user is already logged in
    if 'username' in flask.session:
        return redirect('/user_page')

    # Render the login form
    return render_template('login.html')

# Define a function for login authentication
@app.route('/do_login', methods=['POST'])
def do_login():
    # Get username and password from form
    username = request.form['username']
    password = request.form['password']

    # Validate input
    if not username or not password:
        return 'Please enter a username and password.'

    # Hash password
    hashed_password = hashlib.sha256(password.encode()).hexdigest()

    # Check if username and password are in database
    if username == 'admin' and hashed_password == '5f4dcc3b5aa765d61d8327deb882cf99':
        # Store username in session
        flask.session['username'] = username
        # Redirect to user page
        return redirect('/user_page')
    else:
        # Return error message
        return 'Invalid username or password'

# Define a function for user page
@app.route('/user_page')
def user_page():
    # Check if user is logged in
    if 'username' in flask.session:
        # Get username from session
        username = flask.session['username']
        # Render user page with username
        return render_template('user_page.html', username=username)
    else:
        # Redirect to login page
        return redirect('/login')

# Run the app
if __name__ == '__main__':
    app.run(ssl_context='adhoc') # Use HTTPS for secure communication