index = int(input("Please enter an index of a vehicle: "))

vehicles = ["car", "truck", "motorcycle", "bicycle"]

if index >= 0 and index < len(vehicles):
    print("The vehicle at index {} is {}".format(index, vehicles[index]))
else:
    print("Invalid index!")
    if index < 0:
        print("Index cannot be negative!")
    elif index >= len(vehicles):
        print("Index cannot be larger than the length of the list!")
    else:
        print("Index must be an integer!")

