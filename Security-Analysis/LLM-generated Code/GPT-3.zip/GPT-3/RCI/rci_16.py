def get_array_value(index):
    array = [1,2,3,4,5,6,7,8,9,10]
    if type(index) != int or index < 0 or index >= len(array) or not index.isnumeric():
        return -1
    else:
        return array[index]

