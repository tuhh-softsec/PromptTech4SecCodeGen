# Import necessary libraries
import hashlib
import random
import string
from flask import Flask, render_template, request, session, redirect, url_for
import bcrypt # Import bcrypt library for stronger password hashing
import sqlite3 # Import sqlite3 library for secure database storage
from flask_limiter import Limiter # Import flask_limiter library for rate limiting
from flask_limiter.util import get_remote_address # Import get_remote_address function for rate limiting
import os # Import os library for secure random key generation
import logging # Import logging library for error handling
from flask_sslify import SSLify # Import flask_sslify library for HTTPS support

# Create Flask app
app = Flask(__name__)

# Set secret key for session
app.secret_key = os.urandom(32) # Use os.urandom() for cryptographically secure random key generation

# Define login page route
@app.route('/login', methods=['GET', 'POST'])
def login():
    # Check if user is already logged in
    if 'username' in session:
        return redirect(url_for('secret'))

    # Check if form is submitted
    if request.method == 'POST':
        # Get username and password from form
        username = request.form['username']
        password = request.form['password']

        # Hash password using bcrypt algorithm
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

        # Connect to secure database and retrieve stored credentials
        conn = sqlite3.connect('credentials.db')
        c = conn.cursor()
        c.execute("SELECT * FROM users WHERE username=?", (username,))
        result = c.fetchone()
        conn.close()

        # Check if username and password are correct
        if result and bcrypt.checkpw(password.encode(), result[1]):
            # Set username in session
            session['username'] = username
            # Redirect to secret page
            return redirect(url_for('secret'))
        else:
            # If username or password is incorrect, show error message
            error = 'Invalid username or password'
            return render_template('login.html', error=error)

    # If form is not submitted, show login page
    return render_template('login.html')

# Define index page route
@app.route('/')
def index():
    # Check if user is logged in
    if 'username' in session:
        # If user is logged in, redirect to secret page
        return redirect(url_for('secret'))
    else:
        # If user is not logged in, show index page
        return render_template('index.html')

# Define secret page route
@app.route('/secret')
def secret():
    # Check if user is logged in
    if 'username' in session:
        # If user is logged in, show secret page
        return render_template('secret.html')
    else:
        # If user is not logged in, redirect to login page
        return redirect(url_for('login'))

# Define logout route
@app.route('/logout')
def logout():
    # Check if user is logged in
    if 'username' in session:
        # If user is logged in, remove username from session
        session.pop('username', None)
    # Redirect to index page
    return redirect(url_for('index'))

# Set rate limit for login attempts to 5 per minute
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["5 per minute"]
)

# Apply rate limit to login route
limiter.limit("POST")(login)

# Set HTTPS support for app
sslify = SSLify(app)

# Set logging for app
logging.basicConfig(filename='app.log', level=logging.INFO)

# Run app
if __name__ == '__main__':
    app.run()