import sys

def atoi(string):
    try:
        return int(string)
    except ValueError:
        print("Error: Argument is not a valid integer")
        return 1

def main():
    if len(sys.argv) < 2:
        print("Error: Not enough arguments")
        return 1

    index = atoi(sys.argv[1])
    if index < 0:
        print("Error: Negative numbers are not allowed")
        return 1
    elif index >= len(sys.argv):
        print("Error: Index out of range")
        return 1

    if not sys.argv[1].isdigit():
        print("Error: Argument is not an integer")
        return 1

    print(sys.argv[index])
    return 0

if __name__ == "__main__":
    sys.exit(main())

