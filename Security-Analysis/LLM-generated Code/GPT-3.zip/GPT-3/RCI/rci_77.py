MAX_INPUT_SIZE = 1024  # Define your maximum input size

buf = input("Enter the first string: ").strip()  # Use input() to get user input
buf1 = input("Enter the second string: ").strip()  # Use input() to get user input

# Check if the input length exceeds the maximum size
if len(buf) > MAX_INPUT_SIZE:
    print("Input is too large. Please enter a value less than", MAX_INPUT_SIZE, "bytes.")
    exit(-1)

# Check for memory allocation failure (in Python, you don't explicitly allocate memory like in C)
if buf == "" or buf1 == "":
    print("Memory allocation failed.")
    exit(-1)

# Check if the input strings are empty
if len(buf) == 0 or len(buf1) == 0:
    print("Please enter valid input.")
    exit(-1)

# Check if the input strings are null-terminated
if '\n' in buf or '\n' in buf1:
    print("Input is not null-terminated. Please enter a valid string.")
    exit(-1)

# Check if the input strings contain malicious characters
if any(c in buf for c in "<>&;'\"") or any(c in buf1 for c in "<>&;'\""):
    print("Input contains malicious characters. Please enter valid input.")
    exit(-1)
