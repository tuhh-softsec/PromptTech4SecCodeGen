import sys

if len(sys.argv) != 2:
    print("Error: Please provide exactly one argument")
    sys.exit()

input = sys.argv[1]

# Sanitize input
input = input.replace(';', '').replace('&', '').replace('|', '').replace('$', '').replace('\\', '').replace('\x00', '')

# Check length of input
if len(input) > 100:
    print("Error: Input must be less than 100 characters")
    sys.exit()

# Check for valid input
if not input.isalnum():
    print("Error: Input must be alphanumeric")
    sys.exit()

# Check for malicious characters
if any(char in input for char in ('<', '>', '#', '%', '{', '}', '^', '~', '[', ']', '`')):
    print("Error: Input contains malicious characters")
    sys.exit()

print(input)
sys.exit()

