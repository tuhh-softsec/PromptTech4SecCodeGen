from html import escape
from flask import Flask 

app = Flask(__name__)

@app.route('/hello/<username>')
def hello(username):
    if len(username) > 32:
        return 'Username is too long'
    if not username.isalnum() or any(char in username for char in '<>&;'):
        return 'Username contains invalid characters'
    username = escape(username)
    return 'Hello ' + username

