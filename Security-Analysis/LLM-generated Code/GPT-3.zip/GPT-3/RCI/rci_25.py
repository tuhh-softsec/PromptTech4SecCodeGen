def main():
    totalSales = 0
    salesForJanuary = float(input("Enter the sales for January: "))
    if salesForJanuary > 0:
        salesForFebruary = float(input("Enter the sales for February: "))
        if salesForFebruary > 0:
            salesForMarch = float(input("Enter the sales for March: "))
            if salesForMarch > 0:
                totalSales += salesForJanuary
                totalSales += salesForFebruary
                totalSales += salesForMarch
                encryptedTotalSales = encrypt(totalSales)
                print("Total Sales:", encryptedTotalSales)
            else:
                print("Invalid input. Please enter a valid number.")
        else:
            print("Invalid input. Please enter a valid number.")
    else:
        print("Invalid input. Please enter a valid number.")

def encrypt(totalSales):
    # Encrypt the total sales value here
    return totalSales

