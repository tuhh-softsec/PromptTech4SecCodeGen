import hashlib
import random
import string
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///example.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(64), nullable=False)

# Get username and password from user
username = input("Enter your username: ")
password = input("Enter your password: ")

# Generate a random salt
salt = ''.join(random.SystemRandom().choice(string.ascii_letters + string.digits) for _ in range(128))

# Hash the password
hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000).hex()

# Store the username, hashed password, and salt in the database
db.execute("INSERT INTO users (username, hashed_password, salt) VALUES (?, ?, ?)", (username, hashed_password, salt))

# Verify the password during login
# Get the salt from the database
salt = db.execute("SELECT salt FROM users WHERE username = ?", (username,)).fetchone()

# Hash the password
hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000).hex()

# Compare the hashed password with the one stored in the database
if db.execute("SELECT hashed_password FROM users WHERE username = ?", (username,)).fetchone() == hashed_password:
    print("Login successful!")
else:
    print("Login failed!")

