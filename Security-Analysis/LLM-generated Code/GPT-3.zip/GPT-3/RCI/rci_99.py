import os

flags = os.O_RDWR | os.O_CREAT | os.O_EXCL | os.S_IRUSR | os.S_IWUSR | os.O_TRUNC

with os.open('important_config', flags) as f:
    os.write(f, b'important_config')

