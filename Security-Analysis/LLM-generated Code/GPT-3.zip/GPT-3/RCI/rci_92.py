import hashlib
import os
import sqlite3

# create database connection
conn = sqlite3.connect('registration.db')
c = conn.cursor()

# create table to store user information
c.execute('''CREATE TABLE IF NOT EXISTS users
             (username TEXT, password TEXT, salt TEXT)''')

# get username and password from user
username = input("Enter username: ")
password = input("Enter password: ")

# generate random salt using a cryptographically secure random number generator
salt = os.urandom(16)

# hash password with salt using a stronger hashing algorithm and multiple iterations
hashed_password = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), salt, 100000).hexdigest()

# insert user information into database
c.execute("INSERT INTO users VALUES (?, ?, ?)", (username, hashed_password, salt))

# commit changes and close database connection
conn.commit()
conn.close()

# during login, retrieve user information from database
# and verify password using salt
username = input("Enter username: ")
password = input("Enter password: ")

# retrieve user information from database
c.execute("SELECT * FROM users WHERE username=?", (username,))
user = c.fetchone()

# verify password using salt
hashed_password = hashlib.pbkdf2_hmac('sha512', password.encode('utf-8'), user[2], 100000).hexdigest()

# compare hashed password with stored hashed password
if hashed_password == user[1]:
    print("Login successful!")
else:
    print("Incorrect password.")

# close database connection
conn.close()

