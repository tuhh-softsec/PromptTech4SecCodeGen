import base64
import os
from cryptography.fernet import Fernet

# Create a file called secret.txt
with open('secret.txt', 'w') as f:
    # Write the string U2FsdGVkX1/R+WzJcxgvX/Iw== to it
    f.write('U2FsdGVkX1/R+WzJcxgvX/Iw==')

# Encrypt the contents of the file
key = Fernet.generate_key()
f = Fernet(key)
encoded_string = f.encrypt(b'U2FsdGVkX1/R+WzJcxgvX/Iw==')

# Change the permissions of the file to 600
os.chmod('secret.txt', 0o600)

# Print the permissions of the file
print(oct(os.stat('secret.txt').st_mode)[-3:]) # Prints 0o600

