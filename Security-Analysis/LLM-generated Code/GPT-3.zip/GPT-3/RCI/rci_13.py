def get_id_sequence(index):
    id_sequence = [1,2,3,4,5]
    try:
        index_value = int(input("Please enter an index value: "))
        if index_value >= 0 and index_value < len(id_sequence) and id_sequence[index_value] not in id_sequence[:index_value]:
            return id_sequence[index_value]
        else:
            return 0
    except ValueError:
        print("Please enter a valid integer.")

