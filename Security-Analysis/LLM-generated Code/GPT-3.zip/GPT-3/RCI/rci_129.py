from flask import Response
def render_response_from_env(env):
    name = env.get('name')
    if not name:
        return Response('Name not provided')
    template = env.get('template')
    if not template:
        return Response('Template not provided')
    # Check the source of the data provided in the environment
    if not env.get('source') or env.get('source') == 'untrusted':
        return Response('Data from untrusted source')
    # Check the template for malicious code before rendering it
    if not template.is_safe():
        return Response('Template contains malicious code')
    rendered_template = template.render(name=name)
    response = Response(rendered_template)
    return response

def home(env):
    response = render_response_from_env(env)
    return response

