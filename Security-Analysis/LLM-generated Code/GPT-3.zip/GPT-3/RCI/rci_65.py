import mysql.connector
import os

# Connect to the MySQL database
db = mysql.connector.connect(
    host="localhost",
    user="username",
    passwd="password",
    database="database_name"
)

# Get the image file
image_file = input("Enter the path to the image file: ")

# Check if the file path is valid
if not os.path.exists(image_file):
    print("Error: Invalid file path")
    exit()

# Check if the user has permission to access the file
if not os.access(image_file, os.R_OK):
    print("Error: You do not have permission to access this file")
    exit()

# Sanitize the user input
image_file = mysql.connector.escape_string(image_file)

# Check if the file is an image file
if not image_file.endswith(('.jpg', '.png', '.gif')):
    print("Error: File is not an image file")
    exit()

# Check if the file size is within a reasonable limit
if os.path.getsize(image_file) > 5000000:
    print("Error: File size is too large")
    exit()

# Read the image file
with open(image_file, "rb") as f:
    image_data = f.read()

# Store the image in the database
cursor = db.cursor()
query = "INSERT INTO images (image_data) VALUES (%s)"
cursor.execute(query, (image_data,))
db.commit()

# Close the connection
db.close()

