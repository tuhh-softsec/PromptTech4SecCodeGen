import sys
import re

def atoi(s):
    try:
        # Check for malicious input
        if re.match("^[0-9]+$", s):
            return int(s)
        else:
            return None
    except ValueError:
        return None

# Check for user input validation
if len(sys.argv) > 1 and len(sys.argv) <= 10:
    argc = len(sys.argv)
    argv = sys.argv

    # Check for authentication and authorization
    if argv[1] == 'authenticate':
        # Check for length of password
        if len(argv[2]) >= 8 and len(argv[3]) >= 8:
            # Check for strength of password
            if re.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,}$", argv[2]) and re.match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*#?&])[A-Za-z\d@$!#%*?&]{8,}$", argv[3]):
                if argv[2] == 'admin' and argv[3] == 'password':
                    for i in range(4, argc):
                        print(atoi(argv[i]))
                else:
                    print('Unauthorized access')
            else:
                print('Invalid password')
        else:
            print('Password must be at least 8 characters long')
    else:
        print('Authentication failed')
else:
    print('Invalid input')

