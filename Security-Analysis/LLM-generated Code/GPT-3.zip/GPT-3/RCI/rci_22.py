import random

num1 = random.randint(10, 1000)
num2 = random.randint(10, 1000)

if num1 == num2:
    print("The two integers are equal.")
elif num1 > num2:
    difference = num1 - num2
    if difference > 2147483647:
        print("The difference is greater than the maximum value of an integer.")
    else:
        print("The difference between the two integers is:", difference)
elif num2 > num1:
    difference = num2 - num1
    if difference > 2147483647:
        print("The difference is greater than the maximum value of an integer.")
    else:
        print("The difference between the two integers is:", difference)
