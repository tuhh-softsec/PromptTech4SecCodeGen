import sys
import logging

# Function to check if the input argument is a valid integer
def is_valid_integer(arg):
    try:
        int(arg)
        return True
    except ValueError:
        return False

# Function to check if the buffer size is a positive integer
def is_positive_integer(buffer_size):
    if int(buffer_size) > 0:
        return True
    else:
        return False

# Check if the correct number of arguments are provided
if len(sys.argv) != 2:
    logging.error("Error: Please provide only one argument for the buffer size.")
    sys.exit()

# Get the buffer size from the command line argument
buffer_size = sys.argv[1]

# Check if the buffer size is a valid integer
if not is_valid_integer(buffer_size):
    logging.error("Error: Buffer size must be a valid integer.")
    sys.exit()

# Check if the buffer size is a positive integer
if not is_positive_integer(buffer_size):
    logging.error("Error: Buffer size must be a positive integer.")
    sys.exit()

# Convert the buffer size to an integer
buffer_size = int(buffer_size)

# Allocate a buffer of the specified size
try:
    buffer = bytearray(buffer_size)
except MemoryError:
    logging.error("Error: Unable to allocate buffer of size", buffer_size)
    sys.exit()

# Print the contents of the buffer
try:
    print("Buffer contents:", buffer)
except TypeError:
    logging.error("Error: Unable to print buffer contents.")
    sys.exit()

# Exit the program
try:
    sys.exit()
except SystemExit:
    logging.error("Error: Unable to exit program.")
    sys.exit()