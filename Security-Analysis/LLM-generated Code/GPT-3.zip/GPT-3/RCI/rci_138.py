import mysql.connector
import bcrypt
import ssl

# Connect to the database
db = mysql.connector.connect(
    host="localhost",
    user="username",
    passwd=bcrypt.hashpw("password".encode(), bcrypt.gensalt()).decode(),
    database="database_name",
    ssl_context=ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
)
username = input("username")
# Execute a query to check if the username exists in the database
cursor = db.cursor()
query = "SELECT * FROM users WHERE username = %s"
cursor.execute(query, (username,))

# If the username exists it returns true otherwise it returns false
if cursor.fetchone():
    result = True
else:
    result = False

# Close the connection
cursor.close()
db.close()

