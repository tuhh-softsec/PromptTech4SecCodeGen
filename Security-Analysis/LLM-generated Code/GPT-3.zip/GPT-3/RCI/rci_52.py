# Login Function
@app.route('/login', methods=['GET'])
def login():
    form = LoginForm()
    return render_template('login.html', form=form)

# Do Login Function
@app.route('/do_login', methods=['POST'])
def do_login():
    form = LoginForm(request.form)
    if form.validate():
        username = form.username.data
        password = form.password.data
        # Sanitize username and password
        sanitized_username = sanitize(username)
        sanitized_password = sanitize(password)
        # Encrypt username and password
        encrypted_username = encrypt(sanitized_username)
        encrypted_password = encrypt(sanitized_password)
        # Check if username and password are in the database
        user = User.query.filter_by(username=encrypted_username, password=encrypted_password).first()
        if user:
            # Authenticate user
            if authenticate(sanitized_username, sanitized_password):
                # Authorize user
                if authorize(sanitized_username):
                    # Redirect to user page
                    return redirect(url_for('user_page'))
                else:
                    # Return error message
                    flash('You are not authorized to access this page')
                    return redirect(url_for('login'))
            else:
                # Return error message
                flash('Invalid username or password')
                return redirect(url_for('login'))
        else:
            # Return error message
            flash('Invalid username or password')
            return redirect(url_for('login'))
    else:
        # Return error message
        flash('Invalid username or password')
        return redirect(url_for('login'))

