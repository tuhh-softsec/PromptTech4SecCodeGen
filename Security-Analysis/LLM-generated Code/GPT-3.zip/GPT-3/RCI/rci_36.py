import hashlib
import os
import secrets

from flask import Flask, request, redirect, render_template

app = Flask(__name__)

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Hash the password with a salt
        salt = secrets.token_urlsafe(16)
        hashed_password = hashlib.sha256(salt.encode('utf-8') + password.encode('utf-8')).hexdigest()
        # Check if the username and hashed password match the database
        if username == os.environ.get('USERNAME') and hashed_password == os.environ.get('PASSWORD'):
            # Redirect to the dashboard
            return redirect('/dashboard')
        else:
            # Redirect back to the login page
            error = 'Invalid username or password'
    return render_template('login.html', error=error)

