import os

f = open("/path/to/filename", os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_EXCL | os.O_NOFOLLOW, 0o400)

