# Import necessary libraries
import os
from flask import Flask, request, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename

# Define the allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

# Define the allowed content types
ALLOWED_CONTENT_TYPES = {'text/plain', 'application/pdf', 'image/png', 'image/jpeg', 'image/gif'}

# Create a Flask app
app = Flask(__name__)

# Set the uploads directory
UPLOAD_FOLDER = 'uploads'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to check if the file is of safe type
def file_is_safe_type(filename):
    # Check the file's content type
    content_type = request.headers['Content-Type']
    # Check if the content type is allowed
    if content_type not in ALLOWED_CONTENT_TYPES:
        return False
    # Check if the file's extension matches the content type
    if not filename.endswith(content_type):
        return False
    return True

# Function to handle file upload
@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # Check if the file is present in the request
        if 'file' not in request.files:
            return redirect(request.url)
        file = request.files['file']
        # Check if the file is empty
        if file.filename == '':
            return redirect(request.url)
        # Check if the file is of allowed type
        if file and allowed_file(file.filename):
            # Check if the file is of safe type
            if file_is_safe_type(file.filename):
                # Secure the filename
                filename = secure_filename(file.filename)
                # Check if the file already exists in the uploads directory
                if os.path.exists(os.path.join(app.config['UPLOAD_FOLDER'], filename)):
                    # File already exists, return an error message
                    return 'File already exists'
                # Save the file to the uploads directory
                file.save(os.path.join(app.config['UPLOAD_FOLDER'], filename))
                return redirect(url_for('uploaded_file', filename=filename))
            else:
                # File is not of safe type, return an error message
                return 'File is not of safe type'
        else:
            # File is not of allowed type, return an error message
            return 'File is not allowed'
    # Render the upload form if the request method is GET
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''

# Function to display the uploaded file
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'],
                               filename)

# Run the app
if __name__ == '__main__':
    app.run()

