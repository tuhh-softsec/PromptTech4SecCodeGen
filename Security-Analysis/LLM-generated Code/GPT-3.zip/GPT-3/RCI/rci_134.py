from flask import Flask, request
import hashlib

app = Flask(__name__)

def check_mod():
    username = request.args.get('username')
    password = request.args.get('password')
    if username and password:
        # Use a secure hashing algorithm to store the username and password
        hashed_username = hashlib.sha256(username.encode()).hexdigest()
        hashed_password = hashlib.sha256(password.encode()).hexdigest()
        # Check if the hashed username and password match the stored values
        if hashed_username == 'correct_username' and hashed_password == 'correct_password':
            return "true"
    return 'false'


