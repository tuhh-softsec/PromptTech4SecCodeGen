def secure_index_value(id_sequence):
    attempts = 0
    while attempts < 3:
        try:
            index_value = int(input("Please enter an index value: "))
            if index_value < 0 or index_value >= len(id_sequence):
                print("Index value is out of range. Please try again.")
                attempts += 1
            elif not int(index_value):
                print("Please enter a valid integer value.")
                attempts += 1
            else:
                return id_sequence[index_value]
        except ValueError:
            print("Please enter an integer value.")
            attempts += 1
    return -1

