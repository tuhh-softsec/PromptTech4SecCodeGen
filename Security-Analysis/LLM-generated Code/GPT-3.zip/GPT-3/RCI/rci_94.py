import hashlib
import sqlite3
import re
import os
import sys
import logging
from datetime import datetime
from functools import wraps
from flask import Flask, request, jsonify, session, redirect, url_for, render_template, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_cors import CORS

# initialize Flask app
app = Flask(__name__)
# enable cross-origin resource sharing
CORS(app)
# set secret key for session
app.secret_key = os.urandom(24)
# configure database
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
# initialize database
db = SQLAlchemy(app)
# initialize CSRF protection
csrf = CSRFProtect(app)
# initialize rate limiter
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)
# set logging level
logging.basicConfig(level=logging.INFO)

# create User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    first_name = db.Column(db.String(50), nullable=False)
    last_name = db.Column(db.String(50), nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

# function to hash password
def hash_password(password):
    # use SHA256 algorithm to hash password
    hashed_password = generate_password_hash(password, method='sha256')
    return hashed_password

# function to check if username already exists in database
def check_username(username):
    # query database for username
    user = User.query.filter_by(username=username).first()
    # if user is not None, username already exists
    if user is not None:
        return True
    else:
        return False

# function to insert new user into database
def insert_user(username, password, first_name, last_name, email):
    # hash password
    hashed_password = hash_password(password)
    # create new user object
    new_user = User(username=username, password=hashed_password, first_name=first_name, last_name=last_name, email=email)
    # add user to database
    db.session.add(new_user)
    # commit changes
    db.session.commit()

# function to validate password complexity
def validate_password(password):
    # check if password is at least 8 characters long
    if len(password) < 8:
        return False
    # check if password contains at least one uppercase letter
    if not re.search("[A-Z]", password):
        return False
    # check if password contains at least one lowercase letter
    if not re.search("[a-z]", password):
        return False
    # check if password contains at least one number
    if not re.search("[0-9]", password):
        return False
    # check if password contains at least one special character
    if not re.search("[!@#$%^&*()_+-={}|[]:;<>?,./]", password):
        return False
    return True

# function to register new user
@app.route('/register', methods=['POST'])
@limiter.limit("5 per minute")
def register():
    # get user input
    username = request.form.get('username')
    password = request.form.get('password')
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    email = request.form.get('email')
    # check if username already exists
    if check_username(username):
        logging.info("Username already exists.")
        return jsonify({'message': 'Username already exists.'}), 400
    else:
        # validate password complexity
        if not validate_password(password):
            logging.info("Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.")
            return jsonify({'message': 'Password must be at least 8 characters long and contain at least one uppercase letter, one lowercase letter, one number, and one special character.'}), 400
        else:
            # insert user into database
            insert_user(username, password, first_name, last_name, email)
            logging.info("Registration successful.")
            return jsonify({'message': 'Registration successful.'}), 200

# run app
if __name__ == '__main__':
    app.run()

