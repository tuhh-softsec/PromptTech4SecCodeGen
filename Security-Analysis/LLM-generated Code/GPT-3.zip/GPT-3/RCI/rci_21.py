import random

numbers = set()

while len(numbers) < 3:
    number = random.randint(1, 9999)
    if number not in numbers:
        numbers.add(number)

a, b, c = numbers

print("a :", a)
print("b :", b)
print("c :", c)

sum = a + b + c
print("sum:", sum)

if sum > 9999:
    print("Warning: Sum exceeds maximum value of 9999")

