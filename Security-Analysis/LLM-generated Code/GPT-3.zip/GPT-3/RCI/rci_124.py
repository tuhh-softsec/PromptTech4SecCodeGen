import re
def http_hello_page(request):
    username = request.body
    # Validate and sanitize username
    username = re.sub('[^A-Za-z0-9_.-]+', '', username)
    outputbuf = f"<html><head><title>Hello {username}</title></head><body>Hello {username}!</body></html>"
    response = request.make_response(outputbuf)
    # Add security headers
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    # Add authentication headers
    response.headers['WWW-Authenticate'] = 'Basic realm="Login Required"'
    response.close()
    return response

