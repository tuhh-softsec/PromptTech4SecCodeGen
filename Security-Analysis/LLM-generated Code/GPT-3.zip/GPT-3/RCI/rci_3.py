import sys

# Get command line argument
arg = sys.argv[1]

# Check if argument is a valid integer
if arg.isdigit():
    # Convert argument to integer
    arg_int = int(arg)

    # Create array
    arr = [1, 2, 3, 4, 5]

    # Check if argument is within range of array
    if arg_int in range(len(arr)):
        # Check if argument is within safe range
        if arg_int < len(arr):
            print(arr[arg_int])
        else:
            print("Input out of range")
    else:
        print("Input out of range")
else:
    print("Invalid input")

