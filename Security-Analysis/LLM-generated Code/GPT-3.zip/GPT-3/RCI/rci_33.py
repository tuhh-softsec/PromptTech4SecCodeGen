import hashlib
import random
import time
from flask import request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(64), nullable=False)
    salt = db.Column(db.Integer, nullable=False)
    last_login_attempt = db.Column(db.Float, nullable=True)

def login(username, password):
    # Get the username and password from the form
    username = request.form.get('username')
    password = request.form.get('password')

    # Generate a random salt
    salt = random.randint(1, 1000)

    # Hash the password with the salt
    hashed_password = hashlib.sha256((password + str(salt)).encode('utf-8')).hexdigest()

    # Check if the username and hashed password exists in the database
    user = User.query.filter_by(username=username, password=hashed_password).first()

    # If the username and password exists in the database
    if user:
        # Redirect the user to the home page
        return redirect(url_for('home'))
    else:
        # Check for brute force attacks
        if User.query.filter_by(username=username).count() > 5:
            # Check the time since the last login attempt
            last_attempt = User.query.filter_by(username=username).order_by(User.last_login_attempt.desc()).first()
            if time.time() - last_attempt.last_login_attempt < 5:
                # Redirect the user to the login page
                return redirect(url_for('login'))

