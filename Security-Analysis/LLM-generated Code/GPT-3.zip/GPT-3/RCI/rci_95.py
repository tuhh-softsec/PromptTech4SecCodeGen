import hashlib
import sqlite3
import ssl
import random

# Connect to the database
conn = sqlite3.connect('registration.db')
c = conn.cursor()

# Get the user input
username = input('Username: ')
password = input('Password: ')
first_name = input('First Name: ')
last_name = input('Last Name: ')
email = input('Email: ')

# Sanitize the user input
username = username.replace("'", "''")
password = password.replace("'", "''")
first_name = first_name.replace("'", "''")
last_name = last_name.replace("'", "''")
email = email.replace("'", "''")

# Check for minimum password length
if len(password) < 8:
    print('Password must be at least 8 characters long!')
    exit()

# Check for valid email address
if not '@' in email:
    print('Please enter a valid email address!')
    exit()

# Generate a salt
salt = ''.join(random.choices('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789', k=16))

# Hash the password
hashed_password = hashlib.sha256((password + salt).encode()).hexdigest()

# Check if the username is already in the database
c.execute('SELECT * FROM users WHERE username=?', (username,))
user = c.fetchone()

if user:
    # Username already exists
    print('Username already exists!')
else:
    # Insert the username and hashed password into the database
    c.execute('INSERT INTO users (username, password, salt, first_name, last_name, email) VALUES (?, ?, ?, ?, ?, ?)', (username, hashed_password, salt, first_name, last_name, email))
    conn.commit()
    print('Registration successful!')

# Close the connection
conn.close()

# Secure the connection to the database with TLS/SSL
context = ssl.SSLContext(ssl.PROTOCOL_TLSv1_2)
context.load_cert_chain('server.crt', 'server.key')
conn = sqlite3.connect('registration.db', ssl=context)

