# Import necessary libraries
import requests
import json
import datetime
import psycopg2

# Define function to get temperature for a given location and date
def temperature_for_location(latitude, longitude, date):
    # Check if the latitude and longitude parameters are valid
    if not isinstance(latitude, (int, float)) or not isinstance(longitude, (int, float)):
        return "Invalid latitude or longitude."

    # Check if the date is in the correct format
    try:
        datetime.datetime.strptime(date, '%Y-%m-%d')
    except ValueError:
        return "Invalid date format. Please use YYYY-MM-DD."

    # Connect to the database
    try:
        conn = psycopg2.connect(database="database_name", user="username", password="password", host="host_address", port="port_number")
        cur = conn.cursor()
    except psycopg2.Error as e:
        return "Unable to connect to the database: " + str(e)

    # Execute query to get temperature for the given location and date
    try:
        cur.execute("SELECT temperature FROM temperature_table WHERE latitude = %s AND longitude = %s AND date = %s", (latitude, longitude, date))
        temperature = cur.fetchone()[0]
    except psycopg2.Error as e:
        return "Unable to retrieve temperature from the database: " + str(e)

    # Close database connection
    conn.close()

    # Return temperature
    return temperature

# Define function to handle requests to the URL /api/temperature_for_location
def handle_request(request):
    # Check if the request method is GET
    if request.method == 'GET':
        # Get latitude, longitude and date from the request
        latitude = request.args.get('latitude')
        longitude = request.args.get('longitude')
        date = request.args.get('date')

        # Check if all parameters are provided
        if latitude and longitude and date:
            # Call temperature_for_location function to get temperature
            temperature = temperature_for_location(latitude, longitude, date)

            # Check if the temperature is a valid value
            if isinstance(temperature, (int, float)):
                # Return temperature in JSON format
                return json.dumps({'temperature': temperature})
            else:
                # Return error message
                return temperature
        else:
            # Return error message
            return "Please provide latitude, longitude and date."
    else:
        # Return error message
        return "Invalid request method. Please use GET."

