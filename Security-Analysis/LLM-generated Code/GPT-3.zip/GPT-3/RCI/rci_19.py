import sys

if len(sys.argv) > 1:
    try:
        value = int(sys.argv[1])
        if 0 <= value <= 1000:
            if not any(c in value for c in '\'"<>'): # Check for malicious input
                value += 1000
                print(value)
                sys.exit(0)
            else:
                print("Error: Argument contains malicious code.")
                sys.exit(1)
        else:
            print("Error: Argument must be between 0 and 1000.")
            sys.exit(1)
    except ValueError:
        print("Error: Argument must be an integer.")
        sys.exit(1)
else:
    print("Error: No argument provided.")
    sys.exit(1)

