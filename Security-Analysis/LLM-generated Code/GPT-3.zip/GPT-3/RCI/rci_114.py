import os
import subprocess

command = os.path.expandvars(os.path.expanduser(os.environ.get('COMMAND', 'ls')))

# Check if the command is valid
if not subprocess.call(['which', command], stdout=subprocess.DEVNULL):
    print('Invalid command')
    exit()

# Sanitize the input
command = command.replace(';', '').replace('&', '').replace('|', '')

# Check if the user has the necessary permissions to execute the command
if not os.access(command, os.X_OK):
    print('Insufficient permissions')
    exit()

print_string = 'Executing command: %s'

os.system(print_string % command)

