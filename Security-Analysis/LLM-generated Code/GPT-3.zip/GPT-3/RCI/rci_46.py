import os
import imghdr
from flask import request

MAX_FILE_SIZE = 10 * 1024 * 1024  # 10 MB

def img():
    file = request.args.get('file')
    if file is not None:
        # Check if the file is within the expected directory
        if not os.path.isabs(file):
            return None
        # Check if the file is an image file
        if not imghdr.what(file):
            return None
        # Check if the file is owned by the user
        if not os.access(file, os.R_OK):
            return None
        # Check if the file is too large
        if os.path.getsize(file) > MAX_FILE_SIZE:
            return None
        try:
            with open(file, 'rb') as f:
                data = f.read()
            return data
        except IOError:
            return None
    else:
        return None
