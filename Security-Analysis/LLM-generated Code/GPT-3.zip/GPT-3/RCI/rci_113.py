import subprocess

def execute_command(command):    
    # Sanitize the command before passing it to the execute_command() function
    command = command.replace(';', '').replace('&', '').replace('|', '').replace('$', '').replace('>', '').replace('<', '').replace('*', '')
    process = subprocess.Popen(command, shell=False, stdout=subprocess.PIPE, stderr=subprocess.PIPE, universal_newlines=True)
    output, error = process.communicate()
    return output, error

def execute_ls_command(directory):
    command = 'ls ' + directory
    output, error = execute_command(command)
    print('Output: {}\nError: {}'.format(output, error))

# Example usage
execute_ls_command('/home/user/Documents')

