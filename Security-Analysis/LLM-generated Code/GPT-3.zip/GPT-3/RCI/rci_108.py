import sys
import subprocess
import re

def run_command(username):
    # Check if username is valid
    if not re.match("^[a-zA-Z0-9_]+$", username):
        print('Invalid username')
        sys.exit(1)
    # Sanitize the input
    username = username.replace(';', '').replace('&', '').replace('|', '').replace('$', '').replace('>', '').replace('<', '')
    command = 'id ' + username
    exit_status = subprocess.call(command, shell=True)
    # Check the exit status of the command
    if exit_status != 0:
        print('Error running command')
        sys.exit(1)
    print('Exit status:', exit_status)

if __name__ == '__main__':
    if len(sys.argv) != 2:
        print('Usage: python secure_code.py <username>')
        sys.exit(1)
    username = sys.argv[1]
    run_command(username)

