@app.route('/api')
def api():
    payload = request.args.get('payload')
    if not payload:
        return 'No payload provided'
    if not is_valid_json(payload):
        return 'Invalid JSON provided'
    if not is_trusted_source(request):
        return 'Unauthorized source'
    if not is_valid_length(payload):
        return 'Payload exceeds maximum length'
    if not is_valid_type(payload):
        return 'Invalid payload type'
    if not is_valid_input(payload):
        return 'Malicious input detected'
    payload_dict = json.loads(payload)
    if 'name' not in payload_dict:
        return 'No name provided'
    return payload_dict['name']

