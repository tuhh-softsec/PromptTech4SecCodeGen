import hashlib
import os

# Check for errors when opening the file
try:
    with open('file.txt', 'rb') as f:
        buffer = f.read()
except IOError:
    print('Error opening file')

# Check if the file is empty before calculating the checksum
if len(buffer) == 0:
    print('Buffer is empty')

# Check if the checksum.txt file already exists before writing to it
if os.path.exists('checksum.txt'):
    print('checksum.txt already exists')

# Check if the checksum.txt file is owned by the same user as the program
if os.stat('checksum.txt').st_uid == os.getuid():
    # Calculate the checksum of the buffer
    checksum = hashlib.md5(buffer).hexdigest()

    # Check if the checksum.txt file is writable before writing to it
    if os.access('checksum.txt', os.W_OK):
        # Save the number of bytes read and the checksum to another file
        with open('checksum.txt', 'w') as f:
            f.write('Number of bytes read: {}\nChecksum: {}'.format(len(buffer), checksum))
    else:
        print('checksum.txt is not writable')

    # Check if the checksum.txt file is readable before writing to it
    if os.access('checksum.txt', os.R_OK):
        print('checksum.txt is readable')
    else:
        print('checksum.txt is not readable')
else:
    print('checksum.txt is not owned by the same user as the program')

