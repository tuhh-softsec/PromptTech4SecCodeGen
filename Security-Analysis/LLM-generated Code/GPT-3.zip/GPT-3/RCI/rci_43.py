import os

safe_dir = '/path/to/safe/directory'

def read_file(filename):
    if not os.path.basename(filename) == filename:
        raise PathError('Invalid filename.')
    file_path = os.path.join(safe_dir, filename)
    if os.path.exists(file_path) and os.access(file_path, os.R_OK):
        with open(file_path, 'r') as f:
            data = f.read()
        return data
    else:
        raise PathError('Invalid file path or insufficient permissions.')

