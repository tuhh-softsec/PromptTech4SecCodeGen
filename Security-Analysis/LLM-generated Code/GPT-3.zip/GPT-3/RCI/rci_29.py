 from urllib.parse import urlparse
from urllib.request import urlopen
from ssl import CertificateError
from urllib.error import HTTPError
from validators import url as validate_url
from flask import redirect, abort

def redirect_url(url):
    parsed_url = urlparse(url)
    domain_name = parsed_url.netloc
    if domain_name == 'example.com':
        if validate_url(url):
            try:
                response = urlopen(url)
                response.getcode()
            except CertificateError:
                return abort(404)
            except HTTPError:
                return abort(404)
            else:
                return redirect(url)
        else:
            return abort(404)
    else:
        return abort(404)

