from flask import Flask, request

app = Flask(__name__)
@app.route('/', methods=['POST'])
def check_name():
    if request.is_json:
        payload = request.get_json()
        if 'name' in payload and payload['name'] is not None and payload['name'] != '':
            if request.authorization and request.authorization.username == 'valid_user' and request.authorization.password == 'valid_password':
                return payload['name']
            else:
                return 'Unauthorized access'
        else:
            return 'No valid name field found'
    else:
        return 'No valid JSON found'

