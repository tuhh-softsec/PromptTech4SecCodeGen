from flask import Flask, redirect, request, abort
import re
import ssl

app = Flask(__name__)

@app.route('/redirect_invalid_url', methods=['GET'])
def redirect_invalid_url():
    url = request.args.get('url')
    if re.match(r'^(http|https):\/\/example\.com', url):
        try:
            ssl_context = ssl.create_default_context()
            ssl_context.check_hostname = False
            ssl_context.verify_mode = ssl.CERT_REQUIRED
            ssl.match_hostname(ssl_context.get_server_certificate((url, 443)), url)
            return redirect(url)
        except ssl.CertificateError:
            abort(403)
    else:
        return 'Error: Invalid URL'

if __name__ == '__main__':
    app.run()

