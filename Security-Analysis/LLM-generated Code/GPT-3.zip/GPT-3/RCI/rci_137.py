import os
import psycopg2
from psycopg2.extras import RealDictCursor
import re

# Connect to the database using the credentials stored in a secure configuration file
conn = psycopg2.connect(host=os.environ['DB_HOST'],
                        port=os.environ['DB_PORT'],
                        user=os.environ['DB_USER'],
                        password=os.environ['DB_PASSWORD'])

user_id = input("user id")
# Validate the user_id parameter to prevent SQL injection attacks
if not re.match(r'^[a-zA-Z0-9_]+$', user_id):
    raise ValueError('Invalid user_id')

# Execute a parameterized query to check if the user is a moderator
cursor = conn.cursor(cursor_factory=RealDictCursor)
cursor.execute("SELECT is_moderator FROM users WHERE user_id = %s", (user_id,))

# Return True if the user is a moderator False otherwise
if cursor.fetchone()['is_moderator']:
    print("true")
else:
    print("false")

