import os
from os import path
import re
import base64

# Get the directory path
dir_path = path.dirname(path.realpath(__file__))

# Get the file path
file_path = path.join(dir_path, '/safe/file.txt')

# Open the file
with open(file_path, 'rb') as f:
    # Read the file
    data = f.read()

# Validate and sanitize the data
if data is not None and data != b'':
    data = data.strip()
    data = re.sub(b'<[^>]*>', b'', data)

# Encrypt the data
encrypted_data = base64.b64encode(data)

# Do something with the data
print(encrypted_data)

