import os

fd = os.open("config_file", os.O_RDWR | os.O_CREAT, 0o644)
os.write(fd, "important_config")
os.fsync(fd)
os.close(fd)

