import bcrypt
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///example.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(64), nullable=False)
# Get username and password from user
username = input("Please enter your username: ")
password = input("Please enter your password: ")

# Check if username already exists in the database
if db.execute("SELECT * FROM users WHERE username = ?", (username, )).fetchone():
    print("Username already exists. Please try again.")
    exit()

# Check if password meets security requirements
if len(password) < 8:
    print("Password must be at least 8 characters long. Please try again.")
    exit()

# Hash the password using bcrypt
hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

# Insert username and hashed password into database using a secure connection
db.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))

# Check if username meets security requirements
if not username.isalnum():
    print("Username must only contain alphanumeric characters. Please try again.")
    exit()

