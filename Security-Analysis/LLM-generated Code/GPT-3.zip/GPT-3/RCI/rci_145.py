@app.route('/buy_order', methods=['POST'])
def buy_order():
    # Check if the user is authenticated
    if not session.get('logged_in'):
        return redirect(url_for('login'))
    # Get the stock name and quantity from the form
    stock_name = request.form['stock_name']
    quantity = request.form['quantity']
    # Check if the user has enough funds to buy the stock
    if not has_enough_funds(stock_name, quantity):
        return redirect(url_for('insufficient_funds'))
    # Sanitize the user input to prevent SQL injection attacks
    stock_name = sanitize_input(stock_name)
    # Check if the stock name is valid
    if not is_valid_stock(stock_name):
        return redirect(url_for('invalid_stock'))
    # Check if the quantity of the stock is valid
    if not is_valid_quantity(quantity):
        return redirect(url_for('invalid_quantity'))
    # Connect to the database
    conn = sqlite3.connect('database.db')
    # Create a cursor
    c = conn.cursor()
    # Execute the query using parameterized queries
    c.execute("INSERT INTO stocks (stock_name, quantity) VALUES (?, ?)", (stock_name, quantity))
    # Commit the changes
    conn.commit()
    # Close the connection
    conn.close()
    # Redirect to the stock_view page
    return redirect(url_for('stock_view'))

