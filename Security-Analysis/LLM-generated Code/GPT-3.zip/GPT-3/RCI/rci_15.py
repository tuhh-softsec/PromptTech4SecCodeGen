def get_array_value(arr, index):
    if len(arr) == 0:
        return -1
    elif not isinstance(index, int) or index < 0:
        return -1
    elif index >= len(arr):
        return -1
    elif not isinstance(arr[index], int):
        return -1
    else:
        return arr[index]

