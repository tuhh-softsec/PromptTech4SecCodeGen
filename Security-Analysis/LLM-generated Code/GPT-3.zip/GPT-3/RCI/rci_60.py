import hashlib

# Prompt user for input file name
input_file = input("Enter input file name: ")

# Check if input file exists
try:
    with open(input_file, "rb") as f:
        # Read contents of file into buffer
        buffer = f.read()
except FileNotFoundError:
    print("Input file does not exist.")
    exit()

# Calculate checksum of buffer using SHA-512
checksum = hashlib.sha512(buffer).hexdigest()

# Check if buffer is empty
if checksum == "0":
    print("Buffer is empty.")
else:
    # Prompt user for output file name
    output_file = input("Enter output file name: ")

    # Open output file for writing
    try:
        with open(output_file, "w") as f:
            # Write number of bytes read and checksum to file
            f.write("Number of bytes read: " + str(len(buffer)) + "\n")
            f.write("Checksum: " + checksum)
    except IOError:
        print("Error writing to output file.")
        exit()

# Close input file
f.close()

