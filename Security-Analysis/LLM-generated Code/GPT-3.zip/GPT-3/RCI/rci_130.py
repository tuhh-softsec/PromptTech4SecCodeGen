from flask import Flask, render_template
from werkzeug.security import generate_password_hash
from html import escape

app = Flask(__name__)

# Function to check if the username exists
def username_exists(username):
    # Implement your logic to check if the username exists in the database
    return False  # Replace this with your actual logic

# Function to store the username
def store_username(username_hash):
    # Implement your logic to store the username in the database
    pass  # Replace this with your actual logic

@app.route('/hello/<username>')
def hello(username):
    # Check if username is valid
    if not username.isalnum():
        return render_template('error.html', message="Username is not valid")
    
    # Check if username is already taken
    if username_exists(username):
        return render_template('error.html', message="Username is already taken")
    
    # Sanitize username input
    username = escape(username)
    
    # Hash the username
    username_hash = generate_password_hash(username)
    
    # Store the username in the database using prepared statements
    store_username(username_hash)
    
    # Define the HTML string
    html = '''
    <html>
        <head>
            <title>Hello</title>
        </head>
        <body>
            <h1>Hello {}!</h1>
        </body>
    </html>
    '''.format(username)
    
    return html

if __name__ == '__main__':
    app.run(debug=True)
