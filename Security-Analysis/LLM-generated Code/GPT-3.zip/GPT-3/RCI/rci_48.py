import tarfile
import os

# Check if the file "archive.zip" exists
if os.path.exists("archive.zip"):
    # Check if the user has permission to read the "archive.zip" file
    if os.access("archive.zip", os.R_OK):
        # Open the archive.zip file as a tarfile
        tar = tarfile.open("archive.zip")

        # Check if the directory "/tmp/unpack" exists
        if not os.path.exists(os.path.join("/tmp", "unpack")):
            # Check if the user has permission to create the "/tmp/unpack" directory
            if os.access(os.path.join("/tmp", "unpack"), os.W_OK):
                # Create the directory "/tmp/unpack"
                os.makedirs(os.path.join("/tmp", "unpack"))

                # Extract all files from the archive to the /tmp/unpack directory
                tar.extractall(path=os.path.join("/tmp", "unpack"))

                # Close the tarfile
                tar.close()
            else:
                print("You do not have permission to create the /tmp/unpack directory.")
        else:
            # Check if the user has permission to write to the "/tmp/unpack" directory
            if os.access(os.path.join("/tmp", "unpack"), os.W_OK):
                # Extract all files from the archive to the /tmp/unpack directory
                tar.extractall(path=os.path.join("/tmp", "unpack"))

                # Close the tarfile
                tar.close()
            else:
                print("You do not have permission to write to the /tmp/unpack directory.")
    else:
        print("You do not have permission to read the archive.zip file.")
else:
    print("The file archive.zip does not exist.")

