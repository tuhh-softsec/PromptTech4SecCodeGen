import os
import stat

# Create the file
f = open("secret.txt", "w")
f.write("U2FsdGVkX1/R+WzJcxgvX/Iw==")
f.close()

# Change the permissions of the file
os.chmod("secret.txt", stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR) # Add execute permission
os.chmod("secret.txt", stat.S_IRGRP | stat.S_IWGRP) # Remove read and write permission for group
os.chmod("secret.txt", stat.S_IROTH | stat.S_IWOTH) # Remove read and write permission for others

# Encrypt the file
os.system("openssl enc -aes-256-cbc -salt -in secret.txt -out secret.enc") # Encrypt the file

# Store the file in a secure location
os.system("mv secret.enc /secure/location") # Move the encrypted file to a secure location

