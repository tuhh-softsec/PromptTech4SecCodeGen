import os
import hashlib
import ssl
from flask import request

def check_mod():
    username = request.args.get('username')
    password = request.args.get('password')
    session = request.args.get('session')
    if username and password and session and auth_mod(username, password, session):
        return True
    else:
        return False

def auth_mod(username, password, session):
    # code to securely hash the password
    salt = os.urandom(16)
    hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 100000)
    # code to securely transmit the data
    secure_data = ssl.encrypt(username, hashed_password, session)
    # code to authenticate user as moderator
    if ssl.verify(username, hashed_password, session):
        return True
    else:
        return False

