import random
import string
import os

# Generate 3 random floats
rand_floats = [random.uniform(0, 1) for _ in range(3)]

# Convert floats to strings
rand_strings = [str(float) for float in rand_floats]

# Concatenate strings into a single string
rand_string = ''.join(rand_strings)

# Write string to a file
with open(os.path.join(os.getcwd(), 'rand_string.txt'), 'w') as f:
    f.write(rand_string)

# Set file permissions to read-only
os.chmod(os.path.join(os.getcwd(), 'rand_string.txt'), 0o444)

