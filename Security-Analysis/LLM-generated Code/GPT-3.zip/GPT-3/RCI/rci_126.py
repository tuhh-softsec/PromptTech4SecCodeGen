def http_hello_page(request, response):
    username = request.read()
    if not username or any(char in username for char in ['&', '<', '>', '"', "'", ';', '(', ')', '\\']):
        response.write("Invalid input")
    else:
        response.write("Hello " + escape_html(username) + "!")

def escape_html(string):
    return string.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;").replace("'", "&#x27;").replace(";", "&#x3B;").replace("(", "&#x28;").replace(")", "&#x29;").replace("\\", "&#x5C;")

