import os

def read_file(filename):
    # Ensure the requested file is in the /safe/ directory
    if not os.path.exists('/safe/' + filename):
        raise ValueError('File not found in /safe/ directory')
    # Check if the filename contains any malicious characters
    if '../' in filename or './' in filename:
        raise ValueError('Filename contains malicious characters')
    # Check if the file is executable
    if os.access('/safe/' + filename, os.X_OK):
        raise ValueError('File is executable')
    # Open the file in read-only mode
    with open('/safe/' + filename, 'r') as f:
        # Read the file contents
        contents = f.read()
    # Return the file contents
    return contents

