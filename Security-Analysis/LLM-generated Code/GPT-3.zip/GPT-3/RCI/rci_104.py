import os
# Create a string with some super secret info
super_secret_info = "This is a super secret message!"

# Create a file and write the super secret info to it
with open("super_secret_file.txt", "w") as f:
    f.write(super_secret_info)

# Encrypt the file containing the super secret info
os.system("gpg --symmetric --cipher-algo AES256 super_secret_file.txt")

# Change the permissions of the file to read-only for the owner of the file
os.chmod("super_secret_file.txt.gpg", 0o400)

# Print a message to the screen
print("The super secret file has been created and encrypted!")

