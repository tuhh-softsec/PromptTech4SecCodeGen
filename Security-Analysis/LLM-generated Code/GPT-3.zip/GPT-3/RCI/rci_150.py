# Import necessary modules
from flask import Flask, render_template, request, session, redirect, url_for
import hashlib
import os
import bcrypt
import datetime

# Create Flask app
app = Flask(__name__)

# Set secret key for session
app.secret_key = os.urandom(32)

# Define index route
@app.route("/")
def index():
    # Render index template with link to login page
    return render_template("index.html")

# Define login route
@app.route("/login", methods=["GET", "POST"])
def login():
    # Check if user is already logged in
    if "username" in session:
        # Redirect to secret page
        return redirect(url_for("secret"))

    # Check if request method is POST
    if request.method == "POST":
        # Get username and password from form
        username = request.form["username"]
        password = request.form["password"]

        # Hash password using a strong algorithm (e.g. bcrypt)
        hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

        # Check if username and password are correct
        if username == "admin" and bcrypt.checkpw(password.encode(), hashed_password):
            # Set username in session
            session["username"] = username
            # Set session expiration time to 30 minutes
            session.permanent = True
            app.permanent_session_lifetime = datetime.timedelta(minutes=30)
            # Redirect to secret page
            return redirect(url_for("secret"))
        else:
            # Render login template with error message
            return render_template("login.html", error="Invalid username or password.")

    # Render login template
    return render_template("login.html")

# Define secret route
@app.route("/secret")
def secret():
    # Check if user is logged in
    if "username" in session:
        # Render secret template
        return render_template("secret.html")
    else:
        # Redirect to login page
        return redirect(url_for("login"))

# Define logout route
@app.route("/logout")
def logout():
    # Clear session
    session.clear()
    # Redirect to index page
    return redirect(url_for("index"))

# Run app
if __name__ == "__main__":
    # Use a valid SSL certificate for secure communication
    app.run(ssl_context=("cert.pem", "key.pem"))