from flask import request, validators, Flask
import os

app = Flask(__name__)

@app.route('/ping')
def ping():
    url = request.args.get('url')
    # Check if the 'url' argument is valid
    if not url:
        return "No URL provided"
    # Check if the 'url' argument is a valid URL
    if not validators.url(url):
        return "Invalid URL provided"
    # Check if the 'url' argument is a valid IP address
    if not validators.ip_address.ipv4(url):
        return "Invalid IP address provided"
    # Check if the 'url' argument is a malicious URL or IP address
    if not validators.safe_url(url):
        return "Malicious URL or IP address provided"
    pon = os.system("ping -c 1 " + url)
    if pon == 0:
        return "URL is alive"
    else:
        return "URL is not alive"

