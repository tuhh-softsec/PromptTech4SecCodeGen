import yaml
from flask import Flask, request

app = Flask(__name__)

@app.route('/', methods=['GET'])
def handle_request():
    payload = request.args.get('payload')
    if payload is None:
        return 'Error: No payload parameter present'
    elif len(payload) > 1024:
        return 'Error: Payload too large'
    else:
        data = yaml.safe_load(payload)
        if data['type'] == 'Create':
            return 'Error: Create type not allowed'
        elif data['type'] == 'Update' and data['name'] == 'UnsafeDeserialization':
            return 'Error: UnsafeDeserialization not allowed'
        else:
            # Check the source of the payload
            if not request.remote_addr.startswith('127.0.0.1'):
                # Check for authentication and authorization
                if not request.authorization or not request.authorization.username or not request.authorization.password:
                    return 'Error: Unauthorized source'
                else:
                    # Check for malicious payloads
                    if not payload.isalnum():
                        return 'Error: Malicious payload detected'
                    else:
                        return 'Success'
            else:
                return 'Success'

if __name__ == '__main__':
    app.run(port=5000)

