import hashlib
import random
import string
import bcrypt

username = input("Please enter your username: ")
password = input("Please enter your password: ")

# Generate a random salt
salt = ''.join(random.choice(string.ascii_letters + string.digits) for _ in range(16))

# Hash the password with the salt
hashed_password = hashlib.sha256((password + salt).encode()).hexdigest()

# Store the username, salt, and hashed password in a database securely
# using bcrypt
hashed_salt = bcrypt.hashpw(salt.encode(), bcrypt.gensalt())

# Store the username, hashed salt, and hashed password in a database
# ...

