# Check for uniqueness and length
while len(str_a) != 16 or len(str_b) != 16 or len(str_c) != 16 or str_a == str_b or str_a == str_c or str_b == str_c:
    str_a = secrets.token_hex(16)
    str_b = secrets.token_hex(16)
    str_c = secrets.token_hex(16)

