import subprocess
import shlex
import time

command = 'ls'

# Create the string to pass to the system function
command_string = shlex.quote(command)

# Sanitize the command string to prevent malicious code injection
command_string = command_string.replace(';', '').replace('&', '').replace('|', '')

# Set a timeout for the command
timeout = 10

# Execute the command
try:
    return_code = subprocess.call(command_string, shell=False, timeout=timeout)
    # Check the return code of the command
    if return_code != 0:
        raise Exception('Command failed with return code {}'.format(return_code))
except subprocess.TimeoutExpired:
    raise Exception('Command timed out after {} seconds'.format(timeout))

