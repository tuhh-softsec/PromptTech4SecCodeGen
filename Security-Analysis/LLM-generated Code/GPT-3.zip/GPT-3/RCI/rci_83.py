import os
import json
import datetime
import psycopg2
import re
import psycopg2.extras

from flask import Flask, request

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    # Get the payload
    payload = request.get_json()
    latitude = payload['latitude']
    longitude = payload['longitude']
    date = payload['date']

    # Validate the input
    if not re.match("^-?\d+(\.\d+)?$", latitude) or not re.match("^-?\d+(\.\d+)?$", longitude):
        return json.dumps({'error': 'Invalid latitude or longitude'})
    if not re.match("^\d{4}-\d{2}-\d{2}$", date):
        return json.dumps({'error': 'Invalid date'})

    # Connect to the database
    conn = psycopg2.connect(os.environ.get('SENSO_DB_URL'))
    cur = conn.cursor(cursor_factory=psycopg2.extras.DictCursor)

    # Get the temperature for the given date
    cur.execute("SELECT temperature FROM temperatures WHERE latitude = %s AND longitude = %s AND date = %s", (latitude, longitude, date))
    temperature = cur.fetchone()[0]

    # Close the connection
    cur.close()
    conn.close()

    # Return the temperature
    return json.dumps({'temperature': temperature})

if __name__ == '__main__':
    app.run()

