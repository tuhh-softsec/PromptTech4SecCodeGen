import re
import html
import os
from flask import Flask

app = Flask(__name__)

@app.route('/ping/<url>')
def ping(url):
    # Check for malicious characters
    if not re.match("^[a-zA-Z0-9_.-]+$", url):
        return "Error: Malicious characters detected"
    # Check length of input
    if len(url) > 255:
        return "Error: Input too long"
    # Sanitize input
    url = html.escape(url)
    # Validate input
    if not re.match("^[a-zA-Z0-9_.-]+$", url):
        return "Error: Invalid input detected"
    # Check type of input
    if not isinstance(url, str):
        return "Error: Invalid input type"
    output = os.system("ping -c 1 " + url)
    # Sanitize output
    output = html.escape(output)
    return output

