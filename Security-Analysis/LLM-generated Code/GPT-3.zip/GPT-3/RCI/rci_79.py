import sys
# Allocate a buffer of 1024 bytes
bu = bytearray(1024)

# Read up to 10 characters from standard input
n = sys.stdin.buffer.readinto(bu, 10)

# Check for buffer overflow
if n > 10:
  raise BufferError('Buffer overflow detected')

# Secure the buffer
bu[n:] = b'\x00' * (1024 - n)

# Clear the buffer after use
bu.clear()

