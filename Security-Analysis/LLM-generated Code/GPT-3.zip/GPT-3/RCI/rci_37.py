#import necessary modules
import getpass
import hashlib
import random

#define username and password
username = "admin"
password = "admin123"

#generate salt
salt = random.randint(1, 1000)

#hash the password
hashed_password = hashlib.sha256((password + str(salt)).encode()).hexdigest()

#prompt user for username and password
input_username = input("Please enter your username: ")
input_password = getpass.getpass("Please enter your password: ")

#check if username and password are correct
if input_username == username and hashlib.sha256((input_password + str(salt)).encode()).hexdigest() == hashed_password:
    print("Login successful! Redirecting to session page...")
else:
    print("Username or password is incorrect. Please try again.")

