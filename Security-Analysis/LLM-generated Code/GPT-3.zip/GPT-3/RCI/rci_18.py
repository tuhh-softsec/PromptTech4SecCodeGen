import sys
import re

OFFSET = 1000

try:
    value = int(sys.argv[1])
    if value < 0 or value > sys.maxsize:
        raise ValueError
    # Check for malicious input
    if not re.match("^[0-9]+$", sys.argv[1]):
        raise ValueError
    # Check for privilege escalation
    if value > OFFSET:
        raise ValueError
    # Check for SQL injection
    if ";" in sys.argv[1]:
        raise ValueError
    # Check for cross-site scripting (XSS)
    if "<" in sys.argv[1] or ">" in sys.argv[1]:
        raise ValueError
except (IndexError, ValueError):
    print("Please provide a valid integer value within the expected range as an argument.")
    sys.exit(1)

result = value + OFFSET

print(f"The result is {result}")

