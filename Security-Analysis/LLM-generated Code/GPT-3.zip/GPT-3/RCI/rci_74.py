import ctypes
import sys

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int)]  # Define the fields you need in the Person structure

person_ptr = ctypes.POINTER(Person)()  # Create a Person pointer

if person_ptr:
    size = sys.getsizeof(Person)
    if sys.getsizeof(person_ptr.contents) >= size:
        person_ptr.contents.status = 0
    else:
        del person_ptr
        person_ptr = None
