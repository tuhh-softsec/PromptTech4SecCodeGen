

from flask import Flask, session
from flask import request
import os
import secrets
import hashlib

app = Flask(__name__)
app.secret_key = secrets.token_hex(24)

@app.route('/info', methods=['GET'])
def info():
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')
    hashed_ssn = hashlib.pbkdf2_hmac('sha512', ssn.encode(), salt=None, iterations=100000).hex()[-4:]
    return f'Username: {username}<br>Email: {email}<br>Last 4 digits of hashed SSN: {hashed_ssn}'

