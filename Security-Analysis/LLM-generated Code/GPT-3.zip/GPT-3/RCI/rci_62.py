import os
import uuid
import mysql.connector

def upload_pdf(file):
    # Check the file type
    if not file.filename.endswith('.pdf'):
        return 'Invalid file type'
    # Check the file size
    if file.content_length > 1024 * 1024 * 5:
        return 'File size too large'
    # Generate a random filename
    filename = str(uuid.uuid4())
    # Get the file extension
    ext = os.path.splitext(file.filename)[1]
    # Create the filepath
    filepath = os.path.join('uploads', filename + ext)
    # Save the file
    file.save(filepath)
    # Connect to the database
    conn = mysql.connector.connect(host='localhost', user='user', password='password', database='database', ssl_ca='ca.pem', ssl_cert='client-cert.pem', ssl_key='client-key.pem')
    # Create a cursor
    cursor = conn.cursor()
    # Sanitize the input
    filepath = conn.escape(filepath)
    # Execute the query
    cursor.execute("INSERT INTO files (filepath) VALUES (%s)", (filepath,))
    # Commit the changes
    conn.commit()
    # Close the connection
    conn.close()

