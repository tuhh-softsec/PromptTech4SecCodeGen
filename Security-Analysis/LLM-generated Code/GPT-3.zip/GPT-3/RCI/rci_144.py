import sqlite3
conn = sqlite3.connect('database.db')
c = conn.cursor()

# Get user input
stock_name = input("Enter stock name: ")
stock_quantity = int(input("Enter stock quantity: "))

# Get username
username = input("Enter username: ")

# Validate username
c.execute("SELECT * FROM users WHERE username = ?", (username,))
if c.fetchone() is None:
    print("Username not found. Please try again.")
    exit()

# Check if user has enough funds
c.execute("SELECT funds FROM users WHERE username = ?", (username,))
funds = c.fetchone()[0]
if funds < stock_quantity:
    print("Insufficient funds. Please try again.")
    exit()

# Sanitize user input
stock_name = stock_name.replace("'", "''")

# Connect to database

# Insert buy order into database
c.execute("INSERT INTO orders (username, stock_name, stock_quantity) VALUES (?, ?, ?)", (username, stock_name, stock_quantity))
conn.commit()

# Redirect user to profile page
print("Redirecting to profile page...")

