import sys
import os
import random

# Check if the argument is valid
if len(sys.argv) != 2:
    print("Error: Invalid number of arguments")
    sys.exit(1)

# Sanitize the user input
try:
    buffer_size = int(sys.argv[1])
except ValueError:
    print("Error: Argument is not a valid integer")
    sys.exit(1)

# Check if the argument passed is within a valid range
if buffer_size < 0 or buffer_size > 1024:
    print("Error: Argument is not within a valid range")
    sys.exit(1)

# Allocate the buffer
buffer = bytearray(os.urandom(buffer_size))

# Print the contents of the buffer
print(buffer)

# Exit the program
sys.exit(0)

