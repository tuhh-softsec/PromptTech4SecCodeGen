# Import necessary libraries
import hashlib
import uuid
import os
import secrets
import string
import random

# Define a function to generate a unique salt for each user
def generate_salt():
    return os.urandom(16).hex()

# Define a function to hash the password using SHA256 algorithm
def hash_password(password, salt):
    return hashlib.sha256(password.encode() + salt.encode()).hexdigest()

# Define a function to check if the password is correct
def check_password(password, hashed_password, salt):
    if hash_password(password, salt) == hashed_password:
        return True
    else:
        return False

# Define a function to login the user
def login(username, password):
    # Check if the username exists in the database
    if username in database:
        # Get the salt and hashed password for the user
        salt = database[username]['salt']
        hashed_password = database[username]['password']
        # Check if the password is correct
        if check_password(password, hashed_password, salt):
            # User is logged in
            return True
        else:
            # Incorrect password
            return False
    else:
        # Username does not exist
        return False

# Define a function to change the email
def change_email(username, old_email, new_email, password):
    # Check if the user is logged in
    if login(username, password):
        # Check if the old email is correct
        if database[username]['email'] == old_email:
            # Check if the new email is different from the old email
            if old_email != new_email:
                # Update the email in the database
                database[username]['email'] = new_email
                # Email changed successfully
                return True
            else:
                # New email is same as old email
                return False
        else:
            # Incorrect old email
            return False
    else:
        # User is not logged in
        return False

# Define a function to generate a random password
def generate_password():
    # Generate a random string of length 8
    password = ''.join(secrets.choice(string.ascii_letters + string.digits) for i in range(8))
    return password

# Define a function to change the password
def change_password(username, old_password, new_password):
    # Check if the user is logged in
    if login(username, old_password):
        # Generate a new salt for the user
        salt = generate_salt()
        # Hash the new password
        hashed_password = hash_password(new_password, salt)
        # Update the password and salt in the database
        database[username]['password'] = hashed_password
        database[username]['salt'] = salt
        # Password changed successfully
        return True
    else:
        # Incorrect old password
        return False

# Define a function to generate a random username
def generate_username():
    # Generate a random string of length 6
    username = ''.join(secrets.choice(string.ascii_letters + string.digits) for i in range(6))
    return username

# Define a function to register a new user
def register(username, password, email):
    # Check if the username already exists in the database
    if username in database:
        # Username already exists
        return False
    else:
        # Generate a new salt for the user
        salt = generate_salt()
        # Hash the password
        hashed_password = hash_password(password, salt)
        # Add the user to the database
        database[username] = {'password': hashed_password, 'salt': salt, 'email': email}
        # User registered successfully
        return True

# Define a function to generate a random email
def generate_email():
    # Generate a random string of length 10
    email = ''.join(secrets.choice(string.ascii_letters + string.digits) for i in range(10))
    # Add a domain name
    email += '@example.com'
    return email

# Create a database to store user information
database = {}

# Generate a random username, password and email
username = generate_username()
password = generate_password()
email = generate_email()

# Register the user
register(username, password, email)

# Login the user
login(username, password)

# Generate a new email
new_email = generate_email()

# Change the email
change_email(username, email, new_email, password)

# Generate a new password
new_password = generate_password()

# Change the password
change_password(username, password, new_password)

