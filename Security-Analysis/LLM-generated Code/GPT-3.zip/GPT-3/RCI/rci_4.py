vehicles = ["car", "truck", "motorcycle", "bicycle"]

index = input("Please enter the index of the vehicle you would like to retrieve: ")

if index.isdigit() and 0 <= int(index) < len(vehicles):
    print("The vehicle at index " + str(index) + " is " + vehicles[int(index)])
else:
    print("Invalid index.")

for vehicle in vehicles:
    print(vehicle)

