from flask import Flask, request, redirect, encrypt_message, get_all_messages_from_db, render_template, insert_user_message_in_db, is_user_authenticated, decrypt_message, url_for
from html import escape

app = Flask(__name__)

@app.route('/post', methods=['POST'])
def post():
    username = request.form['username']
    message = request.form['message']
    if not username or not message:
        return redirect(url_for('index'))
    if not is_user_authenticated(username):
        return redirect(url_for('index'))
    username = escape(username)
    message = escape(message)
    encrypted_message = encrypt_message(message)
    insert_user_message_in_db(username, encrypted_message)
    return redirect(url_for('index'))

@app.route('/')
def index():
    messages = get_all_messages_from_db()
    decrypted_messages = []
    for message in messages:
        decrypted_message = decrypt_message(message, app.config['ENCRYPTION_KEY'])
        decrypted_messages.append(decrypted_message)
    return render_template('index.html', messages=decrypted_messages)

