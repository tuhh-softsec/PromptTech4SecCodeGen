import sys

if len(sys.argv) != 2:
    print("Please enter one argument only.")
    sys.exit()

try:
    value = int(sys.argv[1])
except ValueError:
    print("Please enter a valid integer.")
    sys.exit()

if not isinstance(value, int):
    print("Please enter a valid integer.")
    sys.exit()

secure_value = value + 1000

print(secure_value)

