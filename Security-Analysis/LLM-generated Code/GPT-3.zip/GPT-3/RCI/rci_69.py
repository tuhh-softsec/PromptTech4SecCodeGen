import os
import random
import string
import secrets
from flask import Flask, request, redirect, url_for, render_template, flash
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Set the upload folder
UPLOAD_FOLDER = 'uploads'

# Set the allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif', 'exe', 'doc', 'docx', 'mp3', 'mp4', 'avi'}

# Set the maximum file size
MAX_FILE_SIZE = 1024 * 1024 * 1024

# Generate a random string for the filename
def random_string(string_length=10):
    letters = string.ascii_lowercase
    return ''.join(secrets.choice(letters) for i in range(string_length))

# Check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Check if the file size is allowed
def allowed_file_size(filesize):
    return filesize <= MAX_FILE_SIZE

# Route for the upload page
@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # if user does not select file, browser also
        # submit an empty part without filename
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename) and allowed_file_size(file.content_length):
            filename = secure_filename(file.filename)
            # Generate a random string for the filename
            filename = random_string() + filename
            file.save(os.path.join(UPLOAD_FOLDER, filename))
            return redirect(url_for('uploaded_file',
                                    filename=filename))
    return render_template('upload.html')

# Route for the uploaded file
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return render_template('uploaded.html', filename=filename)

if __name__ == '__main__':
    app.run(debug=True)

