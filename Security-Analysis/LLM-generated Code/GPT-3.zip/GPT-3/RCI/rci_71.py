import ctypes
import sys

class Person(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.c_char_p),
        ("age", ctypes.c_int),
        ("height", ctypes.c_double)
    ]

def main():
    person_ptr = ctypes.POINTER(Person)()

    if person_ptr:
        if (sys.getsizeof(Person) <= ctypes.pythonapi._PyObject_Malloc_usable_size(person_ptr.contents) and
                ctypes.alignment(Person) == ctypes.alignment(person_ptr.contents) and
                ctypes.memset(ctypes.byref(person_ptr.contents), 0, sys.getsizeof(Person)) != 0):
            person_ptr.contents.name = b"John"
            person_ptr.contents.age = 25
            person_ptr.contents.height = 180
        else:
            print("Error allocating memory")
            ctypes.pythonapi.PyMem_Free(person_ptr)
    else:
        print("Error allocating memory")

if __name__ == "__main__":
    main()
