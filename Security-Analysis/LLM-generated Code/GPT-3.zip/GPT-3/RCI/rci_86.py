import yaml
from flask import Flask, request
from flask_jwt_extended import JWTManager, jwt_required
import secrets

app = Flask(__name__)

# Setup the Flask-JWT-Extended extension
app.config['JWT_SECRET_KEY'] = secrets.token_hex(16)  # Change this!
jwt = JWTManager(app)

@app.route('/calculate_price', methods=['GET'])
@jwt_required
def calculate_price():
    # Get the YAML payload from the query parameter
    payload = request.args.get('payload')
    # Parse the YAML payload
    data = yaml.safe_load(payload)
    # Validate the data
    if not validate_data(data):
        return 'Invalid data', 400
    # Extract the product_code and quantity
    product_code = data['product_code']
    quantity = data['quantity']
    # Sanitize the data to prevent injection attacks
    product_code = product_code.replace(';', '')
    quantity = int(quantity)
    # Calculate the total price
    price = get_price(product_code) * quantity
    # Return the total price as a string
    return str(price)

def validate_data(data):
    # Validate the data received from the query parameter
    if 'product_code' not in data or 'quantity' not in data:
        return False
    return True

def get_price(product_code):
    # Get the price of the product from the database
    return 10.00

if __name__ == '__main__':
    app.run()

