import os
import secrets

# Allocate two chunks of memory each of size 10
chunk1 = os.urandom(10)
chunk2 = os.urandom(10)

# Generate cryptographically secure token_bytes of length 10
token_bytes = secrets.token_bytes(10)

# Copy the contents of the token_bytes into the second chunk
if len(token_bytes) == 10 and token_bytes == chunk1:
    chunk2 = token_bytes

# Print the contents of the second chunk
print(chunk2)

