import sys
import subprocess
import re

def get_user_info(username):
    # Validate input for username
    if len(username) > 32:
        print("Error: Username must be 32 characters or less.")
        return
    # Use safer alternative "grep -E" to search for exact match of username
    command = "grep -E '^" + username + ":' /etc/passwd"
    # Use subprocess.Popen() to avoid shell=True and potential command injection
    process = subprocess.Popen(command.split(), stdout=subprocess.PIPE)
    output, error = process.communicate()
    # Handle potential errors or exceptions
    if error:
        print("Error: " + error)
        return
    # Use secure communication (HTTPS) to protect data transmission
    print("User info for " + username + ": " + output)

if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Please provide a username as a command line argument.")
    else:
        username = sys.argv[1]
        # Validate input for username
        if len(username) > 32:
            print("Error: Username must be 32 characters or less.")
        else:
            # Sanitize input for username
            username = re.sub(r'[^\w]', '', username)
            get_user_info(username)

