import re
from flask import request, redirect

target = request.args.get('target')

# Check for malicious characters
if re.match('^[\w\-\.\?\&\=\+\%]+$', target):
    # Check if the target URL is a valid URL
    if re.match('^(http|https)://[\w\-\.\?\&\=\+\%]+$', target):
        # Check if the target URL is on the same domain
        if re.match('^(http|https)://[\w\-]+\.[\w\-]+\.[\w\-\.\?\&\=\+\%]+$', target):
            # Check for any other malicious input, such as SQL injection
            if not re.match('[\';]+|(--)+', target):
                redirect(target)

redirect('/')

