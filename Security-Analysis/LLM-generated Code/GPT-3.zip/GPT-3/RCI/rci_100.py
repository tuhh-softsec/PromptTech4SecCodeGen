import os

flags = os.O_CREAT | os.O_RDWR | os.O_EXCL
permissions =  os.S_IRUSR | os.S_IWUSR | os.S_IRGRP | os.S_IROTH

fd = os.open("important_config", flags, permissions)
os.write(fd, "important_confi")
os.close(fd)

