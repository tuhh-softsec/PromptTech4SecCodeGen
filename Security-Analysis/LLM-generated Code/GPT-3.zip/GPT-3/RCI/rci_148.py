import random
import string
from flask import redirect
import sqlite3

# Function to generate a cryptographically secure random string for session ID
def generate_session_id():
    session_id = ''.join(random.choices(string.ascii_letters + string.digits, k=20))
    return session_id

# Function to insert user message into database and validate input
def insert_user_message_in_db(username, message):
    # Validate input for username and message
    if not username or not message:
        return False
    # Establish a connection to the SQLite database
    conn = sqlite3.connect('user_messages.db')
    cursor = conn.cursor()

    try:
        # Create the table if it doesn't exist
        cursor.execute('''CREATE TABLE IF NOT EXISTS messages (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            username TEXT NOT NULL,
                            message TEXT NOT NULL
                          )''')

        # Insert the user message into the database
        cursor.execute("INSERT INTO messages (username, message) VALUES (?, ?)", (username, message))
        
        # Commit changes and close the connection
        conn.commit()
        conn.close()

        return True
    except sqlite3.Error as e:
        print("Error inserting message:", e)
        conn.rollback()
        conn.close()
        return False

# Function to handle user post request and validate session ID
def post(request):
    # Get username, message, and session ID from request
    username = request.get('username')
    message = request.get('message')
    session_id = request.get('session_id')

    # Validate session ID
    if not session_id:
        return False

    # Validate input for username and message
    if not username or not message:
        return False

    # Call insert_user_message_in_db() function to insert message into database
    if not insert_user_message_in_db(username, message):
        return False

    # Redirect user back to main page
    return redirect('/main')

# Function to add form to main page for user to submit message and validate session ID
def main():
    # Generate session ID for form submission
    session_id = generate_session_id()

    # HTML code for form
    form = """
    <form action="/post" method="post">
        <input type="hidden" name="session_id" value="{}">
        <label for="username">Username:</label>
        <input type="text" name="username" id="username">
        <label for="message">Message:</label>
        <input type="text" name="message" id="message">
        <input type="submit" value="Submit">
    </form>
    """.format(session_id)

    # Return main page with form
    return form