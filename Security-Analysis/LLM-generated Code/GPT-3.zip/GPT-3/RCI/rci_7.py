import sys

if len(sys.argv) > 1:
    try:
        index = int(sys.argv[1])
        if index >= 0 and index < len(sys.argv) - 1:
            print(sys.argv[index + 1])
        else:
            print("Index out of range")
    except ValueError:
        print("Index must be an integer")
else:
    print("No index provided")

