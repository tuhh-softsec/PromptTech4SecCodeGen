import subprocess
from flask import Flask, request, validators, sanitize_input, is_trusted_source

app = Flask(__name__)


@app.route('/ping')
def ping():
    url = request.args.get('url')
    if url is None:
        return 'No URL provided'
    else:
        # Validate the URL
        if not validators.url(url):
            return 'Invalid URL provided'
        # Sanitize the input
        url = sanitize_input(url)
        # Check if the URL is from a trusted source
        if not is_trusted_source(url):
            return 'URL is not from a trusted source'
        # Run the ping command
        command = 'ping -c 1 ' + url
        output = subprocess.check_output(command, shell=True)
        return output

