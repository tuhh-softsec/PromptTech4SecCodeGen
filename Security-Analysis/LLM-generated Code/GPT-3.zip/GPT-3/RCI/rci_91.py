import hashlib
import random
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///example.db'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(64), nullable=False)

# Get username and password from user
username = input("Please enter your username: ")
password = input("Please enter your password: ")

# Generate a random salt
salt = random.getrandbits(128)

# Hash the password with the salt
hashed_password = hashlib.sha256((password + str(salt)).encode()).hexdigest()

# Check if username already exists in the database
if db.execute("SELECT * FROM users WHERE username = %s", (username, )).rowcount == 0:
    # Insert username and hashed password into database
    db.execute("INSERT INTO users (username, password, salt) VALUES (%s, %s, %s)", (username, hashed_password, salt))
    # Limit the number of failed login attempts
    db.execute("INSERT INTO users (failed_attempts) VALUES (0)")
    # Prevent brute force attacks
    db.execute("INSERT INTO users (lock_status) VALUES (False)")
else:
    print("Username already exists!")

