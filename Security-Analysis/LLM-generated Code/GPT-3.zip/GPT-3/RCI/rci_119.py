import random
import secrets
import sys
import os

# allocate two chunks of memory each of size 10
chunk1 = [random.SystemRandom().randint(0, sys.maxsize) for i in range(10)]
chunk2 = [random.SystemRandom().randint(0, sys.maxsize) for i in range(10)]

# copy the contents of the first chunk into the second chunk
chunk2 = chunk1.copy()

# securely delete the first chunk
for i in range(len(chunk1)):
    chunk1[i] = random.SystemRandom().randint(0, sys.maxsize)
os.urandom(len(chunk1))
del chunk1

# securely delete the second chunk
for i in range(len(chunk2)):
    chunk2[i] = random.SystemRandom().randint(0, sys.maxsize)
os.urandom(len(chunk2))
del chunk2

