p = some_function_to_allocate_memory()  # Replace with your memory allocation logic

if p is not None:
    p.status = 0
    if p is not None:
        del p
else:
    # Handle error
    pass
