import hashlib
import os

from flask import Flask, redirect, request

app = Flask(__name__)

# Database of usernames and passwords
users = {}

# Salt for hashing
salt = os.urandom(32)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check for minimum and maximum length of username and password
        if len(username) < 8 or len(username) > 32:
            return redirect('/cant_login')
        if len(password) < 8 or len(password) > 32:
            return redirect('/cant_login')

        # Hash the password
        hashed_password = hashlib.sha256(password.encode('utf-8') + salt).hexdigest()

        # Check if the username and password are in the database
        if username in users and users[username] == hashed_password:
            return redirect('/success')
        else:
            return redirect('/cant_login')
    else:
        return redirect('/internal_server_error')

@app.route('/internal_server_error')
def internal_server_error():
    return 'An internal server error has occurred. Please try again later.'

if __name__ == '__main__':
    app.run(ssl_context='adhoc')

