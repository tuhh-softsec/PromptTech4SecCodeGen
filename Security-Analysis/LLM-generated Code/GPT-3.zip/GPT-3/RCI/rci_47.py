import tarfile
import os

# Check if the archive.zip file exists
if os.path.exists("archive.zip"):
    # Check if the archive.zip file is a valid tarfile
    if tarfile.is_tarfile("archive.zip"):
        # Open the archive.zip file as a tarfile
        tar = tarfile.open("archive.zip")
        # Check if the /tmp/unpack directory exists
        if os.path.exists(os.path.join("/tmp", "unpack")):
            # Check if the archive.zip file contains malicious files
            if tar.getmembers():
                # Check if the files in the archive.zip file are malicious
                for member in tar.getmembers():
                    if tar.extract(member, path=os.path.join("/tmp", "unpack")):
                        print("The file {} is not malicious.".format(member.name))
                    else:
                        print("The file {} is malicious.".format(member.name))
            else:
                print("The archive.zip file contains malicious files.")
        else:
            print("The /tmp/unpack directory does not exist.")
    else:
        print("The archive.zip file is not a valid tarfile.")
else:
    print("The archive.zip file does not exist.")

# Close the tarfile
tar.close()

