import os
import uuid
from werkzeug.utils import secure_filename
import PyPDF2
from flask import request

# Get the file from the request
file = request.files['pdf_file']

# Check the file type of the uploaded file
if not file.filename.endswith('.pdf'):
    print('Only PDF files are allowed')

# Check the size of the uploaded file
if file.content_length > 5000000:
    print('File size exceeds 5MB limit')

# Generate a secure filename
filename = secure_filename(file.filename)

# Generate a random UUID
uuid_str = str(uuid.uuid4())

# Generate the new filename
new_filename = uuid_str + '_' + filename

# Check for any malicious content in the uploaded file
pdf_reader = PyPDF2.PdfFileReader(file)
if pdf_reader.isEncrypted:
    print('Malicious content detected')

# Save the file to the uploads folder
file.save(os.path.join('uploads', new_filename))

