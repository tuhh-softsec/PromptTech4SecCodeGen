import sys
import re

def scan():
    buffer = bytearray(1024)
    num_read = sys.stdin.buffer.readinto(buffer, 10)
    if num_read > 1023:
        raise ValueError("Input string too long")
    if num_read > 0 and buffer[num_read - 1] == ord('\n'):
        num_read -= 1
    input_string = buffer[:num_read].decode('utf-8')
    # Perform input validation
    if not re.match("^[a-zA-Z0-9_]+$", input_string):
        raise ValueError("Input contains invalid characters")
    # Check for malicious input
    if re.search("[;&|`$]", input_string):
        raise ValueError("Input contains malicious characters")
    return input_string

