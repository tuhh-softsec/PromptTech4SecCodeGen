#import necessary libraries
import getpass
import re

#define function to change email
def change_email():
    #prompt user for old email
    old_email = input("Please enter your old email: ")
    #check if email is valid
    if not re.match(r"[^@]+@[^@]+\.[^@]+", old_email):
        print("Invalid email address")
        return
    #prompt user for new email
    new_email = input("Please enter your new email: ")
    #check if email is valid
    if not re.match(r"[^@]+@[^@]+\.[^@]+", new_email):
        print("Invalid email address")
        return
    #check if new email is already in use
    if new_email == old_email:
        print("Email already in use")
        return
    #prompt user for confirm password
    confirm_password = getpass.getpass("Please enter your confirm password: ")
    #check if confirm password is correct
    if confirm_password != old_email:
        print("Incorrect confirm password")
        return
    #change email
    print("Email changed successfully")

#prompt user to login
username = input("Please enter your username: ")
password = getpass.getpass("Please enter your password: ")

#check if user is logged in
if username == "admin" and password == getpass.getpass("Please enter the admin password: "):
    #call change_email function
    change_email()
else:
    print("Incorrect username or password")

