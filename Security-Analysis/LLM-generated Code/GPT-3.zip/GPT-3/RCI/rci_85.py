import sqlite3

def temperature_for_location(request):
    # Get the latitude, longitude and date from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')
    
    # Validate the request parameters
    if not latitude or not longitude or not date:
        return None
    
    # Connect to the database
    try:
        conn = sqlite3.connect('database.db')
    except sqlite3.Error as e:
        print(e)
        return None
    c = conn.cursor()
    
    # Execute the query to get the temperature
    c.execute("SELECT temperature FROM temperatures WHERE latitude=? AND longitude=? AND date=?", (latitude, longitude, date))
    result = c.fetchone()
    
    # Check if the query returned any results
    if result is None:
        return None
    
    # Close the connection
    conn.close()
    
    # Return the temperature
    return result[0]

