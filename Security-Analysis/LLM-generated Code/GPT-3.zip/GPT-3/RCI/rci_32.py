import uuid
import hashlib

# Database of usernames and passwords
database = {
    'username1': 'password1',
    'username2': 'password2',
    'username3': 'password3'
}

# Login page
username = input('Username: ')
password = input('Password: ')

# Salt and hash the password
salt = uuid.uuid4().hex
hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt.encode('utf-8'), 100000)

# Check if username and password match
if username in database and database[username] == hashed_password:
    # Log the user in and redirect to dashboard page
    print('Login successful! Redirecting to dashboard page...')
else:
    # Redirect back to login page
    print('Login failed! Redirecting back to login page...')

