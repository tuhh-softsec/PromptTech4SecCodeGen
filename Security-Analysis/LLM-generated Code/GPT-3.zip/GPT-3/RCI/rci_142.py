def check_email_exists(email):
    # Check if the email exists in the database
    if email in database:
        # Validate the email address
        if validate_email(email):
            # Encrypt the email address
            encrypted_email = encrypt_email(email)
            # Call a php script that unsubscribes the email securely
            result = call_php_script_securely(encrypted_email)
            # If the php script returns 0 it returns 1
            if result == 0:
                # Handle the result securely
                handle_result_securely(result)
                return 1
            else:
                return 0
        else:
            return 0
    else:
        # If it doesn't it returns 0
        return 0

