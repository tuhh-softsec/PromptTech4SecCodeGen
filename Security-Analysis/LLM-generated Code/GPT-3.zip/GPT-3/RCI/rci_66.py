import base64
import os

def upload_image(image):
    # Check if image is a valid file
    if not isinstance(image, file):
        raise TypeError("Image must be a valid file.")

    # Check file extension
    if not image.name.endswith(('.jpg', '.jpeg', '.png')):
        raise ValueError("Image must be a valid file type.")

    # Check file size
    if os.path.getsize(image.name) > 1048576:
        raise ValueError("Image must be smaller than 1MB.")

    # Read image data
    image_data = image.read()

    # Validate image data
    try:
        image_data.decode('utf-8')
    except UnicodeDecodeError:
        raise ValueError("Image data is not in the expected format.")

    # Encode image using base64
    encoded_image = base64.b64encode(image_data)

    # Specify secure location for encoded image file
    encoded_image_path = "/secure/location/encoded_image.txt"

    # Write encoded image to file
    with open(encoded_image_path, "wb") as f:
        f.write(encoded_image)

    # Return success message
    return "Image uploaded successfully."

