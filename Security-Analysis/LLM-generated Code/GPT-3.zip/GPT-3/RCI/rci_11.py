id_sequence = [1,2,3,4,5]
def get_id_sequence_value(index):
  if index < 0 or index >= len(id_sequence):
    return -1
  elif type(index) != int:
    return -1
  else:
    return id_sequence[index]

def main():
  index = input("Please enter an index value: ")
  try:
    index = int(index)
    if index < 0:
      print("Please enter a positive integer.")
    elif index >= len(id_sequence):
      print("Please enter an index value within the range of the list.")
    else:
      value = get_id_sequence_value(index)
      print("The value at index {} is {}".format(index, value))
  except ValueError:
    print("Please enter a valid integer.")

if __name__ == "__main__":
  main()

