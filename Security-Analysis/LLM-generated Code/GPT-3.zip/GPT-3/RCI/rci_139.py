# Import necessary modules
import os
import random
import string
import webapp2
import sqlalchemy
import secrets
import cryptography

# Create a web app
app = webapp2.WSGIApplication([], debug=True)

# Define a function that returns a database connection
def get_db_connection():
    engine = sqlalchemy.create_engine('mysql+pymysql://{}:{}@{}/{}'.format(
        get_db_user(),
        get_db_password(),
        get_server_name(),
        get_db_name()
    ))
    return engine.connect()

# Define a function that returns the server name
def get_server_name():
    return os.environ.get('SERVER_NAME')

# Define a function that returns the database name
def get_db_name():
    return os.environ.get('DB_NAME')

# Define a function that returns the database user
def get_db_user():
    return os.environ.get('DB_USER')

# Define a function that returns the database password
def get_db_password():
    return secrets.token_urlsafe(20).encrypt(cryptography.fernet.Fernet.generate_key())

