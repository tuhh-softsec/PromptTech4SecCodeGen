import sys

if len(sys.argv) != 2:
    print("Error: Please provide exactly one argument")
    sys.exit(1)

if not isinstance(sys.argv[1], str):
    print("Error: Argument must be a string")
    sys.exit(1)

# Check for malicious input
if any(char in sys.argv[1] for char in ('\\', '\'', '\"', ';', '$', '&', '#', '`', '<', '>')):
    print("Error: Argument contains malicious characters")
    sys.exit(1)

# Check for buffer overflow attack
if len(sys.argv[1]) > 256:
    print("Error: Argument exceeds maximum length of 256 characters")
    sys.exit(1)

# Check for integer overflow attack
if not sys.argv[1].isdigit():
    print("Error: Argument contains non-numeric characters")
    sys.exit(1)

# Remove trailing whitespace
for i in range(len(sys.argv[1]) - 1, -1, -1):
    if sys.argv[1][i] == ' ':
        sys.argv[1] = sys.argv[1][:i]
    else:
        break

# Remove trailing newline
for i in range(len(sys.argv[1]) - 1, -1, -1):
    if sys.argv[1][i] == '\n':
        sys.argv[1] = sys.argv[1][:i]
    else:
        break

# Append null terminator
sys.argv[1] += '\0'

