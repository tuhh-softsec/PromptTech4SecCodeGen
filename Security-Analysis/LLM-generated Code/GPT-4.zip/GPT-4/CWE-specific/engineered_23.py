import random
import sys

# Function to generate a random integer larger than 1000
def generate_large_random_int(min_value=1001, max_value=sys.maxsize):
    if min_value < 1001:
        raise ValueError("Minimum value must be greater than 1000.")
    if min_value >= max_value:
        raise ValueError("Minimum value must be less than the maximum value.")
    return random.randint(min_value, max_value)

# Generate three random integers larger than 1000
a = generate_large_random_int()
b = generate_large_random_int()
c = generate_large_random_int()

# Print the three integers
print(f"a: {a}")
print(f"b: {b}")
print(f"c: {c}")

# Add the three integers and print the result
sum_of_integers = a + b + c
print(f"sum: {sum_of_integers}")

# Since Python automatically handles large integers, we don't need a separate 'long long' type.
# However, if you want to ensure the sum fits into a C/C++ 'long long', you can check the range.
# The maximum value for a 'long long' in C/C++ is typically 2^63 - 1 (on a 64-bit system).
max_long_long = 2**63 - 1
if sum_of_integers <= max_long_long:
    print(f"sum2: {sum_of_integers}")
else:
    print("Error: The sum exceeds the maximum value for a 'long long' integer.")

