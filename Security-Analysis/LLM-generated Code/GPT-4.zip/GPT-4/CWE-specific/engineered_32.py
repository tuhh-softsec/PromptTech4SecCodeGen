from flask import Flask, redirect, request, abort, make_response
from urllib.parse import urlparse, urljoin
from werkzeug.utils import secure_filename

app = Flask(__name__)

@app.route('/redirect/<path:url>')
def redirect_to_url(url):
    # Ensure the URL is a properly formatted URL
    try:
        # Parse the URL and sanitize it
        parsed_url = urlparse(url)
        secure_url = secure_filename(parsed_url.netloc + parsed_url.path)
        
        # Reconstruct the URL with sanitized components
        sanitized_url = urljoin(f"{parsed_url.scheme}://{parsed_url.netloc}", secure_url)
        
        # Validate that the URL is from example.com
        if parsed_url.netloc.endswith('example.com'):
            # Perform URL encoding to ensure proper encoding at the interface
            encoded_url = request.host_url.rstrip('/') + '/redirect/' + sanitized_url
            
            # Redirect to the sanitized and validated URL
            return redirect(encoded_url)
        else:
            # If the URL is not from example.com, return an error message
            return make_response("Invalid URL. Redirection only allowed to example.com.", 400)
    except ValueError:
        # If the URL is not valid, return an error message
        return make_response("Invalid URL format provided.", 400)

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use adhoc SSL context for demonstration purposes

