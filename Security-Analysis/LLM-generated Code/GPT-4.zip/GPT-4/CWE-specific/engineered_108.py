import subprocess
import re

def is_valid_username(username):
    # Define a strict allowlist pattern for the username (e.g., only alphanumeric characters and underscores)
    # Adjust the pattern as needed based on your system's username policy
    pattern = re.compile(r'^[a-zA-Z0-9_]+$')
    return pattern.match(username) is not None

def get_user_info(username):
    # Validate the username
    if not is_valid_username(username):
        raise ValueError("Invalid username. Only alphanumeric characters and underscores are allowed.")

    # Prepare the command using a list to avoid shell interpretation
    command = ['getent', 'passwd', username]

    # Execute the command securely without using a shell
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) as process:
        # Read the output and error streams
        output, error = process.communicate()

        # Check for errors
        if process.returncode != 0:
            raise RuntimeError(f"Command failed with error: {error.strip()}")

        # Return the output
        return output

# Example usage
username = input("Enter the username: ").strip()
try:
    user_info = get_user_info(username)
    # Store the output in a file
    with open('output.txt', 'w') as output_file:
        output_file.write(user_info)
    print("User information has been written to output.txt")
except ValueError as ve:
    print(f"Error: {ve}")
except RuntimeError as re:
    print(f"Error: {re}")

