from flask import Flask, request, redirect, render_template, flash, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired, Length

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Change this to a random secret key

# Dummy user data for demonstration purposes
# In a real application, you would use a database
users = {
    "user1": generate_password_hash("password123")
}

# Login form using WTForms for input validation
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=20)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=8, max=80)])

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        # Check if the username exists and the password is correct
        if username in users and check_password_hash(users[username], password):
            session['username'] = username
            return redirect('/session')
        else:
            # Do not reveal which part of the login is incorrect
            flash('Invalid username or password', 'error')

    return render_template('login.html', form=form)

@app.route('/session')
def session_page():
    if 'username' not in session:
        # Redirect to login if the user is not authenticated
        return redirect('/login')
    return 'Welcome to your session page, {}'.format(session['username'])

@app.errorhandler(404)
def page_not_found(e):
    return 'This page does not exist', 404

@app.errorhandler(500)
def internal_server_error(e):
    return 'Internal server error', 500

if __name__ == '__main__':
    app.run(debug=False)  # Do not use debug mode in production

