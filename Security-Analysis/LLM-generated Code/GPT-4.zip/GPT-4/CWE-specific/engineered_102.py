import os

# Define the file path
file_path = 'important_config'

# Define the flags for opening the file
flags = os.O_RDWR | os.O_CREAT  # Read and write, create if doesn't exist

# Define the mode for the file permissions (owner: read/write, group: read, others: read)
mode = (os.S_IRUSR | os.S_IWUSR | os.S_IRGRP | os.S_IROTH)

# Open the file securely with the specified flags and mode
file_descriptor = os.open(file_path, flags, mode)

# Convert the file descriptor to a file object
with os.fdopen(file_descriptor, 'r+') as file:
    # Write the string 'important_config' to the file
    file.write('important_config')

# The file is automatically closed when exiting the 'with' block

