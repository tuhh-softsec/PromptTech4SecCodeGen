from flask import Flask, send_from_directory, abort
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Define a list of allowed file extensions for images
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def is_safe_path(basedir, path, follow_symlinks=True):
    # Ensure the path is absolute and normalized
    abs_path = os.path.abspath(path)
    
    # Check if the path is within the basedir
    return os.path.commonprefix([abs_path, basedir]) == basedir

def allowed_file(filename):
    # Check if the file has an allowed extension
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/images/<filename>')
def get_image(filename):
    # Use the secure_filename function to sanitize the filename
    securefilename = secure_filename(filename)
    
    # Check if the filename is allowed
    if not allowed_file(securefilename):
        abort(404)  # Not found if the file extension is not allowed
    
    # Define the images directory
    images_dir = os.path.join(app.root_path, 'images')
    
    # Check if the path is safe
    if not is_safe_path(images_dir, securefilename):
        abort(403)  # Forbidden if the path seems unsafe
    
    # Check if the file exists
    if not os.path.isfile(os.path.join(images_dir, securefilename)):
        abort(404)  # Not found if the file does not exist
    
    # Send the file if it exists and is safe
    return send_from_directory(images_dir, securefilename)

if __name__ == '__main__':
    app.run()

