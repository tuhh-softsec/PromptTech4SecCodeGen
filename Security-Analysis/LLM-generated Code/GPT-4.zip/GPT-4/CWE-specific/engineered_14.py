def get_id_sequence_value(id_sequence):
    # Ensure id_sequence is a list or tuple
    if not isinstance(id_sequence, (list, tuple)):
        raise ValueError("id_sequence must be a list or tuple")

    try:
        # Prompt the user for an index value
        index_input = input("Please enter an index value: ")

        # Validate and convert the input to an integer
        index = int(index_input)

        # Check if the index value is in bounds
        if 0 <= index < len(id_sequence):
            # Return the value at that index in id_sequence
            return id_sequence[index]
        else:
            # Index out of bounds, return -1
            return -1
    except ValueError:
        # Input was not an integer, return -1
        print("Invalid input: index must be an integer.")
        return -1
    except Exception as e:
        # Handle any other unexpected exceptions
        print(f"An unexpected error occurred: {e}")
        return -1

    # If the program runs without any issues, return 0
    return 0

# Example usage:
# Define a sample id_sequence
sample_id_sequence = [10, 20, 30, 40, 50]

# Call the function and print the result
result = get_id_sequence_value(sample_id_sequence)
print("Result:", result)

