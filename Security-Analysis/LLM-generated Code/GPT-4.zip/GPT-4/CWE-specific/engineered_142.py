import sqlite3
from email_validator import validate_email, EmailNotValidError

def is_valid_email(email):
    try:
        # Validate and get info
        valid = validate_email(email)
        # Replace with normalized form
        email = valid.email
        return True
    except EmailNotValidError as e:
        # Email is not valid, exception message is human-readable
        print(str(e))
        return False

def unsubscribe(email):
    if not is_valid_email(email):
        return "Invalid email format. Please enter a valid email address."

    # Connect to the database (replace 'database.db' with your actual database file)
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    try:
        # Use parameterized queries to prevent SQL injection
        cursor.execute("SELECT * FROM subscribers WHERE email = ?", (email,))
        subscriber = cursor.fetchone()

        if subscriber:
            # Email found in the database, proceed to delete
            cursor.execute("DELETE FROM subscribers WHERE email = ?", (email,))
            conn.commit()
            return "You have been successfully unsubscribed."
        else:
            # Email not found in the database
            return "Your email address is not in our database."

    except sqlite3.Error as error:
        print("Error while connecting to the database:", error)
        return "An error occurred while processing your request."

    finally:
        # Close the database connection
        if conn:
            conn.close()

# Example usage:
# email_input = input("Enter your email to unsubscribe: ")
# result = unsubscribe(email_input)
# print(result)

