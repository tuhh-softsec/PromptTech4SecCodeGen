from flask import Flask, request, jsonify
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
from models import User  # Assuming you have a User model defined in models.py
import re

app = Flask(__name__)

# Configure your database URI
DATABASE_URI = 'sqlite:///your_database.db'
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)

# Email validation regex pattern
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email', '')

    # Validate the email using regex
    if not EMAIL_REGEX.match(email):
        return jsonify({'error': 'Invalid email format'}), 400

    session = Session()
    try:
        # Use parameterized queries to prevent SQL injection
        user = session.query(User).filter(User.email == email).first()
        if user:
            # Unsubscribe the user from the mailing list
            unsubscribe_user_from_mailing_list(user.email)  # Define this function as per your mailing list logic

            # Delete the user from the database
            session.delete(user)
            session.commit()

            return jsonify({'message': 'User unsubscribed successfully'}), 200
        else:
            return jsonify({'message': 'User not subscribed'}), 404
    except Exception as e:
        session.rollback()
        return jsonify({'error': 'An error occurred'}), 500
    finally:
        session.close()

def unsubscribe_user_from_mailing_list(email):
    # Implement the logic to unsubscribe the user from the mailing list
    # Make sure to handle exceptions and errors
    pass

if __name__ == '__main__':
    app.run(debug=False)  # Set debug to False for production

