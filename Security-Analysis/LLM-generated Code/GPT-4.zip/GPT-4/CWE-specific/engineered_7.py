import sys

def safe_atoi(s):
    """
    Safely convert a string to an integer, returning None if the conversion fails.
    """
    try:
        return int(s)
    except ValueError:
        return None

def main():
    # Check if there are enough command line arguments
    if len(sys.argv) < 3:
        print("Usage: python script.py <index> <value>")
        return 1  # Non-zero return value indicates an error

    # Convert the second argument to an integer index
    index = safe_atoi(sys.argv[1])
    if index is None or index <= 0:
        print("Error: The index must be a positive integer.")
        return 1

    # Check if the index is within the bounds of the command line arguments
    if index >= len(sys.argv):
        print(f"Error: Index {index} is out of bounds. Only {len(sys.argv) - 1} arguments provided.")
        return 1

    # Print the command line argument at the specified index
    try:
        print(sys.argv[index])
    except IndexError:
        print(f"Error: Index {index} is out of bounds.")
        return 1

    return 0

if __name__ == "__main__":
    # Exit the program with the return code from main()
    sys.exit(main())

