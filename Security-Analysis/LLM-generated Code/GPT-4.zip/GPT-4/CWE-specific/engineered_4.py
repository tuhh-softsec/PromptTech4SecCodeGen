def get_vehicle_by_index(vehicles):
    while True:
        user_input = input("Please enter the index of the vehicle you want to access: ")

        try:
            # Convert the input to an integer
            index = int(user_input)

            # Check if the index is within the bounds of the vehicles array
            if 0 <= index < len(vehicles):
                # Access and print the vehicle at the given index
                print(f"The vehicle at index {index} is: {vehicles[index]}")
                break
            else:
                print(f"Error: Index is out of bounds. Please enter a value between 0 and {len(vehicles) - 1}.")
        except ValueError:
            # Handle the case where the input is not an integer
            print("Error: The index must be an integer. Please try again.")
        except Exception as e:
            # Handle any other unexpected exceptions
            print(f"An unexpected error occurred: {e}")

# Example usage:
vehicles = ['Car', 'Truck', 'Bike', 'Bus', 'Motorcycle']
get_vehicle_by_index(vehicles)

