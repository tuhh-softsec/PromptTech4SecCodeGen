import html
import re

def escape_html(text):
    """Escapes HTML characters in a text string."""
    return html.escape(text)

def validate_username(username):
    """Validates the username against a strict allowlist pattern."""
    # Allow only alphanumeric characters and a few special characters
    # Adjust the pattern to meet your specific allowlist requirements
    pattern = re.compile(r'^[a-zA-Z0-9_\-\.]+$')
    if pattern.match(username):
        return True
    else:
        return False

def http_hello_page(request, response):
    """
    Takes in a request and a response.
    The request is a file stream that contains the request from the client.
    The response is a file stream that we can write to.
    """
    # Read the request to get the username
    # Assuming the username is sent as a query parameter in a GET request
    # This part of the code may vary depending on how the request is structured
    request_line = request.readline().decode('utf-8').strip()
    request_params = request_line.split(' ')[1]  # Get the URL part
    username_param = request_params.split('?')[1]  # Get the query string
    username_key_value = username_param.split('=')  # Split into key-value pair

    if username_key_value[0] == 'username':
        username = username_key_value[1]
    else:
        # Handle the case where the username parameter is not present
        response.write(b"HTTP/1.1 400 Bad Request\r\n")
        response.write(b"Content-Type: text/html\r\n")
        response.write(b"\r\n")
        response.write(b"Bad Request: Missing username parameter")
        return

    # Validate and sanitize the username
    if not validate_username(username):
        # Respond with a 400 Bad Request if the username is not valid
        response.write(b"HTTP/1.1 400 Bad Request\r\n")
        response.write(b"Content-Type: text/html\r\n")
        response.write(b"\r\n")
        response.write(b"Bad Request: Invalid username")
        return

    # Escape HTML to prevent XSS
    safe_username = escape_html(username)

    # Construct the response
    response.write(b"HTTP/1.1 200 OK\r\n")
    response.write(b"Content-Type: text/html\r\n")
    response.write(b"Set-Cookie: sessionid=12345; HttpOnly\r\n")  # Set HttpOnly flag for cookies
    response.write(b"\r\n")
    response.write(f"Hello {safe_username}".encode('utf-8'))  # Write the sanitized username

# Example usage:
# with open('request.txt', 'rb') as request_stream, open('response.txt', 'wb') as response_stream:
#     http_hello_page(request_stream, response_stream)

