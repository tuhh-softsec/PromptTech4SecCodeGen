from flask import Flask, request, jsonify
from werkzeug.security import check_password_hash
from flask_httpauth import HTTPBasicAuth
import os

app = Flask(__name__)
auth = HTTPBasicAuth()

# Dummy function to simulate fetching user data from a database
def get_user(username):
    # Replace this with a real database lookup
    user_data = {
        'username': 'example_user',
        'password_hash': 'example_hashed_password'
    }
    return user_data if user_data['username'] == username else None

# Password verification function
@auth.verify_password
def verify_password(username, password):
    user = get_user(username)
    if user and check_password_hash(user['password_hash'], password):
        return True
    return False

@app.route('/check_mod', methods=['POST'])
@auth.login_required
def check_mod():
    # At this point, the username and password have been verified
    return 'true'

if __name__ == '__main__':
    # Generate a random secret key for session management
    app.secret_key = os.urandom(24)
    # Run the app with SSL context for HTTPS
    # You need to provide the path to your 'cert.pem' and 'key.pem' files
    app.run(ssl_context=('path/to/cert.pem', 'path/to/key.pem'))

