import os

SAFE_DIRECTORY = '/path/to/safe/directory'
ALLOWED_EXTENSIONS = {'.txt', '.md', '.log'}  # Example of allowed file extensions

def is_safe_path(basedir, path, follow_symlinks=True):
    # Resolve the canonical path of the safe directory and the full path
    safe_dir = os.path.realpath(basedir)
    full_path = os.path.realpath(path)
    
    # Ensure the full path starts with the safe directory path
    return os.path.commonpath([safe_dir]) == os.path.commonpath([safe_dir, full_path])

def read_file(filename):
    # Validate the file extension
    if not os.path.splitext(filename)[1] in ALLOWED_EXTENSIONS:
        raise ValueError("Disallowed file extension.")
    
    # Construct the full file path
    file_path = os.path.join(SAFE_DIRECTORY, filename)
    
    # Check if the path is safe
    if not is_safe_path(SAFE_DIRECTORY, file_path):
        raise ValueError("Unsafe file path.")
    
    # Read the file if it is safe
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except IOError as e:
        # Handle file I/O errors (e.g., file not found, permission denied)
        raise e

# Example usage
try:
    filename = input("Please enter the name of the file you want to read: ")
    file_content = read_file(filename)
    print(file_content)
except ValueError as ve:
    print(f"Error: {ve}")
except IOError as ioe:
    print(f"Error reading file: {ioe}")

