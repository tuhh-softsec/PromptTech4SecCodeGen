import cgi
import html

def http_hello_page(request, response):
    # Define an allowlist of characters for the username
    allowlist = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-')

    # Read the username from the request
    # Assuming the username is passed as a query parameter or form data
    form = cgi.FieldStorage(fp=request, environ={'REQUEST_METHOD': 'POST'})
    username = form.getvalue('username', '')

    # Validate and sanitize the username
    sanitized_username = ''.join(filter(allowlist.__contains__, username))

    # Check if the username after sanitization is not empty
    if not sanitized_username:
        response.write("Invalid username.")
        return

    # Construct a response
    # Use html.escape to prevent XSS by escaping HTML special characters
    response_body = f"Hello {html.escape(sanitized_username)}"

    # Set the content type for the response
    response.write('Content-Type: text/html; charset=utf-8\r\n')

    # Set the HttpOnly flag on cookies to prevent access from JavaScript
    response.write('Set-Cookie: sessionid=your_session_id; HttpOnly\r\n')

    # Write additional security headers
    response.write('X-Content-Type-Options: nosniff\r\n')
    response.write('X-Frame-Options: DENY\r\n')
    response.write('Content-Security-Policy: default-src \'self\'\r\n')
    response.write('X-XSS-Protection: 1; mode=block\r\n')

    # End the header section
    response.write('\r\n')

    # Write the response body
    response.write(response_body)

# Example usage:
# Assuming `request_stream` and `response_stream` are file-like objects representing the request and response streams.
# http_hello_page(request_stream, response_stream)

