from flask import Flask, request, render_template, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from flask_bcrypt import Bcrypt
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'  # Replace with your actual secret key
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'  # Replace with your database URI
db = SQLAlchemy(app)
bcrypt = Bcrypt(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

# Create the database tables
db.create_all()

# Username and password validation patterns
USERNAME_PATTERN = re.compile(r"^[a-zA-Z0-9_]{3,20}$")  # Adjust the pattern as needed
PASSWORD_PATTERN = re.compile(r"^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d]{8,}$")  # Minimum eight characters, at least one letter and one number

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Validate username
        if not USERNAME_PATTERN.match(username):
            flash('Invalid username. Please use only letters, numbers, and underscores. Length: 3-20 characters.')
            return redirect(url_for('register'))

        # Validate password
        if not PASSWORD_PATTERN.match(password):
            flash('Invalid password. Minimum eight characters, at least one letter and one number.')
            return redirect(url_for('register'))

        # Check if the username already exists
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Username already exists. Please choose a different one.')
            return redirect(url_for('register'))

        # Hash the password
        password_hash = bcrypt.generate_password_hash(password).decode('utf-8')

        # Create a new user and insert it into the database
        new_user = User(username=username, password_hash=password_hash)
        db.session.add(new_user)
        db.session.commit()

        flash('Registration successful!')
        return redirect(url_for('login'))  # Redirect to the login page or home page after registration

    return render_template('register.html')  # Render the registration template

@app.route('/login')
def login():
    # Implement login functionality here
    pass

if __name__ == '__main__':
    app.run(debug=True)

