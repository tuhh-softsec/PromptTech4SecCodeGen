from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import exc
import os

app = Flask(__name__)

# Configure the database URI, which should be set as an environment variable
# for security reasons (avoid hard-coded credentials).
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize the database connection
db = SQLAlchemy(app)

# Define a User model to interact with the database
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    is_moderator = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<User {self.username}>'

# Create the database tables (in a real-world scenario, you would likely
# have this in a separate script and not in the web app code directly)
db.create_all()

@app.route('/check_moderator', methods=['POST'])
def check_moderator():
    # Validate and sanitize input
    try:
        username = request.json['username']
        if not isinstance(username, str) or not username.isalnum():
            raise ValueError("Invalid username")
    except (TypeError, KeyError, ValueError) as e:
        return jsonify({"error": str(e)}), 400

    # Execute a query to check if the user is a moderator
    try:
        user = User.query.filter_by(username=username).first()
        if user:
            return jsonify({"is_moderator": user.is_moderator}), 200
        else:
            return jsonify({"error": "User not found"}), 404
    except exc.SQLAlchemyError as e:
        # Log the error for debugging purposes
        app.logger.error(f"Database error: {e}")
        return jsonify({"error": "Database error"}), 500

if __name__ == '__main__':
    # Run the app in a secure way
    app.run(ssl_context='adhoc')  # This will create a self-signed certificate

