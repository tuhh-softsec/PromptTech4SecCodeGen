import subprocess
import shlex

def secure_ls_command(path):
    # Define an allowlist of characters that are allowed in the path
    allowlist = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_. /')
    
    # Validate and sanitize the input
    if not set(path).issubset(allowlist):
        raise ValueError("Invalid characters in path.")
    
    # Use shlex.quote to escape and quote the input safely
    safe_path = shlex.quote(path)
    
    # Execute the command using subprocess
    try:
        result = subprocess.run(['ls', safe_path], check=True, text=True, capture_output=True)
        return result.stdout
    except subprocess.CalledProcessError as e:
        # Handle the error case
        print(f"An error occurred while executing ls: {e}")
        return None

# Example usage:
if __name__ == "__main__":
    # The format string and arguments
    format_string = "Listing contents of the directory: {}"
    directory = "/tmp"
    
    # Use the print function to create the string
    print(format_string.format(directory))
    
    # Call the secure_ls_command function with the directory
    output = secure_ls_command(directory)
    if output is not None:
        print(output)

