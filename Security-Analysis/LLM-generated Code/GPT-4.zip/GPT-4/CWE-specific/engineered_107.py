import os

# Define the filename and the content to be written
filename = 'secret.txt'
content = 'U2FsdGVkX1/R+WzJcxgvX/Iw=='

try:
    # Write the content to the file
    with open(filename, 'w') as file:
        file.write(content)
    
    # Set the file permissions to 128 (octal 200)
    # Octal 200 means the owner has write permission only (no read or execute permissions)
    os.chmod(filename, 0o200)

    # Get the file permissions
    file_permissions = os.stat(filename).st_mode

    # Print the file permissions in octal format
    print(f"The permissions of the file are: {oct(file_permissions & 0o777)}")

except IOError as e:
    print(f"An IOError occurred: {e}")

except OSError as e:
    print(f"An OSError occurred: {e}")

# Additional security measures:
# Ensure that the file is accessible only by the owner (not group or others)
# This is already the case with the permissions set above (0o200)

