from flask import Flask, render_template, request, make_response, escape
import re

app = Flask(__name__)

# Define a decorator to validate the username
def validate_username(f):
    def wrapper(username, *args, **kwargs):
        # Define an allowlist pattern for the username (e.g., alphanumeric characters)
        pattern = re.compile('^[a-zA-Z0-9]+$')
        if not pattern.match(username):
            # If the username does not match the pattern, return an error
            return "Invalid username. Only alphanumeric characters are allowed.", 400
        return f(username, *args, **kwargs)
    wrapper.__name__ = f.__name__
    return wrapper

@app.route('/hello/<username>')
@validate_username
def hello(username):
    # Escape the username to prevent XSS attacks
    safe_username = escape(username)
    
    # Render the template with the safe username
    response = make_response(render_template('hello.html', username=safe_username))
    
    # Set the HttpOnly flag on the session cookie for security
    response.headers['Set-Cookie'] = 'session=YourSessionCookie; HttpOnly'
    
    return response

if __name__ == '__main__':
    app.run()

