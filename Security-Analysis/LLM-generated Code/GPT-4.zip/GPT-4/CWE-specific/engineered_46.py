from flask import Flask, send_file, abort
import os
from werkzeug.utils import secure_filename

app = Flask(__name__)

# Define a list of allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/img/<name>')
def img(name):
    # Use the secure_filename function to sanitize the filename
    secure_name = secure_filename(name)
    
    # Validate the file extension
    if not allowed_file(secure_name):
        abort(404)  # Not found if the file is not allowed
    
    # Define the path to the images directory
    images_dir = os.path.join(app.root_path, 'images')
    
    # Construct the full file path
    file_path = os.path.join(images_dir, secure_name)
    
    # Canonicalize the path and check if it's within the images directory
    if not os.path.realpath(file_path).startswith(images_dir):
        abort(403)  # Forbidden if the path seems malicious
    
    # Check if the file exists
    if not os.path.isfile(file_path):
        abort(404)  # Not found if the file does not exist
    
    # Send the file back to the client
    return send_file(file_path)

if __name__ == '__main__':
    app.run()

