from flask import Flask, request, redirect, render_template
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
from sqlite3 import Error

app = Flask(__name__)

DATABASE = 'path_to_your_database.db'

def create_connection(db_file):
    """ create a database connection to the SQLite database """
    conn = None
    try:
        conn = sqlite3.connect(db_file)
    except Error as e:
        print(e)
    return conn

def validate_user(username, password):
    """ Validate the username and password against the database """
    conn = create_connection(DATABASE)
    try:
        with conn:
            cur = conn.cursor()
            cur.execute("SELECT password FROM users WHERE username=?", (username,))
            user = cur.fetchone()
            if user and check_password_hash(user[0], password):
                return True
            else:
                return False
    except Error as e:
        # Log the error for debugging purposes
        # Ensure that the log file is secured and not accessible by unauthorized users
        print("An error occurred:", e)
        return None
    finally:
        if conn:
            conn.close()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Input validation
        if not username or not password:
            return redirect('/cant_login')

        # Validate credentials
        valid = validate_user(username, password)
        if valid is True:
            return redirect('/success')
        elif valid is False:
            return redirect('/cant_login')
        else:
            return redirect('/internal_server_error')

    return render_template('login.html')

@app.route('/success')
def success():
    return 'Logged in successfully!'

@app.route('/cant_login')
def cant_login():
    return 'Could not log in. Please check your username and password.'

@app.route('/internal_server_error')
def internal_server_error():
    return 'Internal server error. Please try again later.', 500

if __name__ == '__main__':
    app.run(debug=False)  # Never deploy a Flask app with debug=True in a production environment

