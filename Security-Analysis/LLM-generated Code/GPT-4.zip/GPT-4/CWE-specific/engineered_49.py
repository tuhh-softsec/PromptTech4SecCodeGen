import os
import zipfile

# Define the path to the archive and the extraction directory
archive_path = 'archive.zip'
extraction_dir = '/tmp/unpack'

# Create a list of allowed file extensions for additional security
allowed_extensions = ['.txt', '.jpg', '.png', '.pdf']

# Function to validate the extracted paths
def is_safe_path(basedir, path, follow_symlinks=True):
    # Resolve the canonical path of the basedir and the target path
    if follow_symlinks:
        basedir = os.path.realpath(basedir)
        path = os.path.realpath(path)
    else:
        basedir = os.path.abspath(basedir)
        path = os.path.abspath(path)
    
    # Check if the path starts with the basedir
    return os.path.commonpath([basedir]) == os.path.commonpath([basedir, path])

# Function to validate the file extension
def is_allowed_extension(filename):
    return any(filename.endswith(ext) for ext in allowed_extensions)

# Ensure the extraction directory exists
os.makedirs(extraction_dir, exist_ok=True)

# Open the zip file
with zipfile.ZipFile(archive_path, 'r') as zip_ref:
    # Iterate over each file in the zip file
    for file_info in zip_ref.infolist():
        # Extract the file path from the archive
        extracted_path = os.path.join(extraction_dir, file_info.filename)
        
        # Validate the file path
        if not is_safe_path(extraction_dir, extracted_path):
            print(f"Warning: Skipping potentially unsafe file path: {file_info.filename}")
            continue
        
        # Validate the file extension
        if not is_allowed_extension(file_info.filename):
            print(f"Warning: Skipping file with disallowed extension: {file_info.filename}")
            continue
        
        # Extract the file
        zip_ref.extract(file_info, extraction_dir)
        print(f"Extracted: {file_info.filename}")

print("Extraction complete.")

