from flask import Flask, request, redirect, url_for, escape
import re

app = Flask(__name__)

# Define a function to validate and sanitize input
def sanitize_input(input_string):
    # Allow only alphanumeric characters and basic punctuation
    allowlist_pattern = re.compile(r'^[a-zA-Z0-9\s.,!?\'"]+$')
    if allowlist_pattern.match(input_string):
        return input_string
    else:
        raise ValueError("Invalid characters in input")

# Define the function to insert the message into the database
def insert_user_message_in_db(username, message):
    # This function should use parameterized queries to avoid SQL injection
    # For example, using SQLAlchemy or a similar ORM library
    pass  # Replace with actual database insertion logic

@app.route('/post', methods=['POST'])
def post():
    try:
        # Get the username and message from the request
        username = request.form['username']
        message = request.form['message']

        # Sanitize the inputs
        username = sanitize_input(username)
        message = sanitize_input(message)

        # Call the function to insert the message into the database
        insert_user_message_in_db(username, message)

        # Redirect the user back to the main page
        return redirect(url_for('main_page'))
    except ValueError as e:
        # Handle the error, such as displaying a message to the user
        return str(e), 400

@app.route('/')
def main_page():
    # Render the main page with the form
    form_html = '''
    <form action="/post" method="post">
        Username: <input type="text" name="username"><br>
        Message: <textarea name="message"></textarea><br>
        <input type="submit" value="Submit">
    </form>
    '''
    return form_html

if __name__ == '__main__':
    app.run()

