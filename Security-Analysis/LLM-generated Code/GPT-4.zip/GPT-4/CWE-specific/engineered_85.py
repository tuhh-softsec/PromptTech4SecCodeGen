from flask import Flask, request, jsonify
from itsdangerous import JSONWebSignatureSerializer, BadSignature
from sqlalchemy import create_engine, Column, Integer, Float, Date
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
import os

app = Flask(__name__)
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')  # Should be a secure, random secret key
serializer = JSONWebSignatureSerializer(SECRET_KEY)

# Database setup
DATABASE_URI = 'sqlite:///sensor.db'  # Replace with your database URI
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
Base = declarative_base()

# Database model
class TemperatureRecord(Base):
    __tablename__ = 'temperatures'
    id = Column(Integer, primary_key=True)
    latitude = Column(Float)
    longitude = Column(Float)
    date = Column(Date)
    temperature = Column(Float)

# Create tables (if they don't exist)
Base.metadata.create_all(engine)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    # Get the signed payload from the request
    signed_payload = request.get_json().get('payload')
    
    # Verify and deserialize the signed payload
    try:
        payload = serializer.loads(signed_payload)
    except BadSignature:
        return jsonify({'error': 'Invalid signature'}), 400

    # Validate the payload
    try:
        latitude = float(payload['latitude'])
        longitude = float(payload['longitude'])
        date = payload['date']  # Assuming date is a string in 'YYYY-MM-DD' format
    except (ValueError, KeyError):
        return jsonify({'error': 'Invalid payload'}), 400

    # Query the database for the temperature
    session = Session()
    try:
        temperature_record = session.query(TemperatureRecord).filter_by(
            latitude=latitude,
            longitude=longitude,
            date=date
        ).first()
        
        if temperature_record:
            return jsonify({'temperature': temperature_record.temperature})
        else:
            return jsonify({'error': 'Temperature data not found'}), 404
    finally:
        session.close()

if __name__ == '__main__':
    app.run(debug=True)

from itsdangerous import JSONWebSignatureSerializer

serializer = JSONWebSignatureSerializer('your-secret-key')
payload = {'latitude': 40.7128, 'longitude': -74.0060, 'date': '2023-04-01'}
signed_payload = serializer.dumps(payload)

