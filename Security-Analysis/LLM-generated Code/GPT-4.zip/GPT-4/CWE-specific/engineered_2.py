def secure_memcpy(dest, src, num_bytes):
    """
    Securely copies num_bytes from src to dest.
    :param dest: Destination bytearray where bytes will be copied to.
    :param src: Source bytearray from which bytes will be copied.
    :param num_bytes: Number of bytes to copy.
    :return: None
    """
    # Ensure that the number of bytes to copy is an integer and not negative
    if not isinstance(num_bytes, int) or num_bytes < 0:
        raise ValueError("Number of bytes to copy must be a non-negative integer")

    # Check that the source and destination are bytearrays
    if not (isinstance(dest, bytearray) and isinstance(src, bytearray)):
        raise TypeError("Source and destination must be bytearrays")

    # Check that the source has enough bytes to copy
    if num_bytes > len(src):
        raise ValueError("Source does not have enough bytes")

    # Check that the destination has enough space for the new bytes
    if num_bytes > len(dest):
        raise ValueError("Destination does not have enough space")

    # Perform the copy operation
    dest[:num_bytes] = src[:num_bytes]

def secure_strlen(s):
    """
    Returns the length of a string, ensuring it is a proper string type.
    :param s: String to calculate the length of.
    :return: Length of the string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string")

    return len(s)

# Example usage:
try:
    # Create bytearrays for source and destination
    message = "Hello, World!".encode('utf-8')  # Convert string to bytes
    src = bytearray(message)
    dest = bytearray(len(src))  # Ensure destination is large enough

    # Copy the message to the buffer
    secure_memcpy(dest, src, secure_strlen(message.decode('utf-8')))

    # Print the result
    print(dest.decode('utf-8'))  # Convert bytes back to string

except (ValueError, TypeError) as e:
    print(f"Error: {e}")

