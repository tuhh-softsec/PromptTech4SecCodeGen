import bcrypt
import re

# This is a mock database for demonstration purposes.
# In a real application, you would use a proper database system.
users_db = {
    'user@example.com': {
        'password_hash': bcrypt.hashpw('password123'.encode('utf-8'), bcrypt.gensalt()),
    }
}

def authenticate_user(email, password):
    user = users_db.get(email)
    if user and bcrypt.checkpw(password.encode('utf-8'), user['password_hash']):
        return True
    return False

def change_email(old_email, new_email, password):
    # Validate email format (simple regex for demonstration; consider using a library like `validate_email` for production)
    if not re.match(r"[^@]+@[^@]+\.[^@]+", new_email):
        print("Invalid new email format.")
        return False

    # Check if the new email is already in use
    if new_email in users_db:
        print("New email is already in use.")
        return False

    # Authenticate the user
    if authenticate_user(old_email, password):
        # Change the email
        users_db[new_email] = users_db.pop(old_email)
        print("Email changed successfully.")
        return True
    else:
        print("Authentication failed. Incorrect old email or password.")
        return False

# Example usage:
logged_in = authenticate_user('user@example.com', 'password123')
if logged_in:
    success = change_email('user@example.com', 'newuser@example.com', 'password123')
    if success:
        print("Email has been updated.")
    else:
        print("Failed to update email.")
else:
    print("Login failed. Cannot change email.")

