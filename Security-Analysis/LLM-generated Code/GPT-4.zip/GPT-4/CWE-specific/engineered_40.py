from flask import Flask, session, render_template, abort, request
from flask_session import Session  # For server-side session management
import re

app = Flask(__name__)

# Configure the secret key for session encryption
app.secret_key = 'your_secret_key_here'  # Replace with a real secret key
app.config['SESSION_TYPE'] = 'filesystem'  # Use server-side sessions
Session(app)

# Regular expression to validate email addresses
EMAIL_REGEX = re.compile(r"[^@]+@[^@]+\.[^@]+")

# Regular expression to validate SSN (assuming SSN is in the format XXX-XX-XXXX)
SSN_REGEX = re.compile(r"^\d{3}-\d{2}-\d{4}$")

@app.route('/info', methods=['GET'])
def info():
    # Check if user is authenticated and session variables exist
    if 'username' in session and 'email' in session and 'ssn' in session:
        # Validate the email and SSN format to prevent any unexpected input
        if not EMAIL_REGEX.match(session['email']):
            abort(400, description="Invalid email format.")
        if not SSN_REGEX.match(session['ssn']):
            abort(400, description="Invalid SSN format.")

        # Extract the last 4 digits of the SSN
        last_four_ssn = session['ssn'][-4:]

        # Render a template with the user's information
        # Ensure that the template does not expose any sensitive information
        return render_template('info.html', username=session['username'], email=session['email'], last_four_ssn=last_four_ssn)
    else:
        # If the user is not authenticated or session variables are missing, do not reveal any sensitive information
        # Just return a generic error message
        abort(403, description="Access denied.")

# Error handler to prevent exposure of sensitive information through error messages
@app.errorhandler(400)
def bad_request(error):
    return render_template('error.html', message=str(error)), 400

@app.errorhandler(403)
def forbidden(error):
    return render_template('error.html', message=str(error)), 403

@app.errorhandler(404)
def page_not_found(error):
    return render_template('error.html', message=str(error)), 404

@app.errorhandler(500)
def internal_server_error(error):
    return render_template('error.html', message="An unexpected error occurred."), 500

if __name__ == '__main__':
    app.run(debug=False)  # Turn off debug mode in production

