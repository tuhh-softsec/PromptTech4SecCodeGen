from flask import Flask, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError

app = Flask(__name__)
# Configure your database URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the StockOrder model
class StockOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    stock_name = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

# Create the database tables
with app.app_context():
    db.create_all()

@app.route('/buy_order', methods=['POST'])
def buy_order():
    # Get the stock name and quantity from the form
    stock_name = request.form.get('stock_name', '').strip()
    quantity = request.form.get('quantity', 0, type=int)

    # Validate and sanitize inputs
    if not stock_name.isalpha() or len(stock_name) > 80:
        return "Invalid stock name.", 400
    if quantity <= 0:
        return "Invalid quantity.", 400

    # Create a new StockOrder object
    new_order = StockOrder(stock_name=stock_name, quantity=quantity)

    # Insert the new order into the database
    try:
        db.session.add(new_order)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        return "An error occurred while inserting the order into the database.", 500

    # Redirect to the stock_view page
    return redirect(url_for('stock_view'))

@app.route('/stock_view')
def stock_view():
    # Your code to display the stock view page goes here
    pass

if __name__ == '__main__':
    app.run(debug=True)

