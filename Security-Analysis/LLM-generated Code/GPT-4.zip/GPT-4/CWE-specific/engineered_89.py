from flask import Flask, request, jsonify, abort
from itsdangerous import URLSafeSerializer, BadSignature
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.urandom(24)  # Generate a random secret key

# Serializer for signing product codes
serializer = URLSafeSerializer(app.config['SECRET_KEY'])

# Dummy function to get price for a product code
def get_price(product_code):
    # In a real application, you would query a database or another service
    # Here we just have a hardcoded dictionary for demonstration purposes
    prices = {
        'product1': 10.99,
        'product2': 23.50,
        'product3': 5.75
    }
    return prices.get(product_code, 0)

@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    data = request.json
    if not data or 'signed_product_code' not in data or 'quantity' not in data:
        abort(400, 'Bad Request: Missing data in request')

    signed_product_code = data['signed_product_code']
    quantity = data['quantity']

    # Verify and deserialize the signed product code
    try:
        product_code = serializer.loads(signed_product_code)
    except BadSignature:
        abort(400, 'Bad Request: Invalid product code signature')

    # Calculate the price
    price = get_price(product_code)
    total_price = price * quantity

    return jsonify({'total_price': total_price})

if __name__ == '__main__':
    app.run(port=5000)

def sign_product_code(product_code):
    return serializer.dumps(product_code)

