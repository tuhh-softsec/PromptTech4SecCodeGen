import sys

def main():
    # Define a sample array for demonstration purposes
    sample_array = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    # Check if exactly one command line argument is provided (excluding the script name)
    if len(sys.argv) != 2:
        print("Usage: python script.py <index>")
        sys.exit(1)

    try:
        # Convert the command line argument to an integer
        index = int(sys.argv[1])

        # Check if the index is within the bounds of the array
        if 0 <= index < len(sample_array):
            # Print the element at the given index
            print(sample_array[index])
        else:
            # Index is out of bounds
            print("Invalid input")
    except ValueError:
        # The command line argument could not be converted to an integer
        print("Invalid input: Please enter a valid integer.")
    except Exception as e:
        # Catch any other unexpected exceptions
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()

