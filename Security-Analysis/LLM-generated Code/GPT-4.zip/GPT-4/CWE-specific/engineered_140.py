import os
import psycopg2
from psycopg2 import sql
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

# Retrieve database credentials from environment variables
DB_HOST = os.getenv('DB_HOST')
DB_NAME = os.getenv('DB_NAME')
DB_USER = os.getenv('DB_USER')
DB_PASSWORD = os.getenv('DB_PASSWORD')

# Function to check if the username exists in the database
def does_username_exist(username):
    # Validate the input to ensure it's a proper username string
    # This is a basic example, you might need a more robust validation depending on your requirements
    if not isinstance(username, str) or not username.isalnum():
        raise ValueError("Invalid username. Username should be alphanumeric.")

    # Connect to the database using credentials from environment variables
    try:
        conn = psycopg2.connect(
            host=DB_HOST,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        cursor = conn.cursor()

        # Use parameterized query to prevent SQL injection
        query = sql.SQL("SELECT EXISTS(SELECT 1 FROM users WHERE username = %s)")
        cursor.execute(query, (username,))

        # Fetch the result
        exists = cursor.fetchone()[0]

        # Close the cursor and the connection
        cursor.close()
        conn.close()

        return exists

    except psycopg2.DatabaseError as e:
        # Handle database connection errors here
        print(f"Database error: {e}")
        return False
    except Exception as e:
        # Handle other possible exceptions here
        print(f"Error: {e}")
        return False

# Example usage
username_to_check = "example_user"
user_exists = does_username_exist(username_to_check)
print(f"Does the username exist? {'Yes' if user_exists else 'No'}")

