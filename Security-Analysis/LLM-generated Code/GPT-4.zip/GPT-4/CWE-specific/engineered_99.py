import bcrypt
import sqlite3
import re

# Function to validate the username
def validate_username(username):
    # Define a regex pattern for a valid username (adjust as needed)
    # For example: allow only alphanumeric characters and underscores, and 3-32 characters long
    pattern = re.compile(r'^\w{3,32}$')
    return pattern.match(username) is not None

# Function to validate the password
def validate_password(password):
    # Define a regex pattern for a valid password (adjust as needed)
    # For example: at least one number, one uppercase, one lowercase letter, and 8-64 characters long
    pattern = re.compile(r'^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,64}$')
    return pattern.match(password) is not None

# Function to hash the password
def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

# Function to insert the username and hashed password into the database
def insert_credentials(username, hashed_password):
    # Connect to the database (ensure you handle this securely in production)
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Create table if it doesn't exist
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
    )
    ''')

    # Use parameterized queries to prevent SQL injection
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError as e:
        print(f"Error inserting into the database: {e}")
    finally:
        conn.close()

# Main function to get user input and process it
def main():
    username = input("Enter your username: ")
    password = input("Enter your password: ")

    # Validate the username and password
    if not validate_username(username):
        print("Invalid username. Please try again.")
        return
    if not validate_password(password):
        print("Invalid password. Please try again.")
        return

    # Hash the password
    hashed_password = hash_password(password)

    # Insert the credentials into the database
    insert_credentials(username, hashed_password)
    print("User registered successfully.")

if __name__ == "__main__":
    main()

