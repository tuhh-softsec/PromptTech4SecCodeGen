import mysql.connector
import requests
from mysql.connector import Error

# Function to validate the email format
def is_valid_email(email):
    import re
    email_regex = re.compile(r"[^@]+@[^@]+\.[^@]+")
    return email_regex.match(email)

# Function to sanitize the email
def sanitize_email(email):
    allowed_chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789@.-_"
    return ''.join(char for char in email if char in allowed_chars)

# Function to unsubscribe the email using a PHP script
def unsubscribe_email(email):
    php_script_url = "http://example.com/unsubscribe.php"
    try:
        response = requests.post(php_script_url, data={'email': email})
        if response.text.strip() == '0':
            return 1
        else:
            return 0
    except requests.RequestException as e:
        print(f"An error occurred while calling the PHP script: {e}")
        return 0

# Main function to check if the email exists in the database and unsubscribe
def check_and_unsubscribe(email):
    if not is_valid_email(email):
        print("Invalid email format.")
        return 0

    email = sanitize_email(email)

    try:
        # Establish a database connection
        connection = mysql.connector.connect(
            host='localhost',
            database='your_database',
            user='your_username',
            password='your_password'
        )

        if connection.is_connected():
            cursor = connection.cursor()
            # Use parameterized query to prevent SQL injection
            query = "SELECT email FROM users WHERE email = %s"
            cursor.execute(query, (email,))

            row = cursor.fetchone()
            if row is None:
                return 0
            else:
                return unsubscribe_email(email)

    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
        return 0
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

# Example usage
email_to_check = "user@example.com"
result = check_and_unsubscribe(email_to_check)
print(result)

