import base64
import os
from flask import request, abort
from werkzeug.utils import secure_filename
from PIL import Image
from io import BytesIO
from sqlalchemy import create_engine, Table, Column, Integer, String, MetaData

# Configure your database connection here
DATABASE_URI = 'sqlite:///images.db'
engine = create_engine(DATABASE_URI)
metadata = MetaData()
images_table = Table('images', metadata,
                     Column('id', Integer, primary_key=True),
                     Column('image_name', String),
                     Column('image_data', String))
metadata.create_all(engine)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
ALLOWED_MIME_TYPES = {'image/png', 'image/jpeg', 'image/gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_image():
    # Check if the post request has the file part
    if 'file' not in request.files:
        abort(400, description="No file part in the request")

    file = request.files['file']

    # If the user does not select a file, the browser submits an
    # empty file without a filename.
    if file.filename == '':
        abort(400, description="No selected file")

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        content_type = file.content_type

        if content_type not in ALLOWED_MIME_TYPES:
            abort(400, description="Invalid file type")

        try:
            # Read the image, convert it to base64
            image = Image.open(file)
            buffered = BytesIO()
            image.save(buffered, format=image.format)
            image_base64 = base64.b64encode(buffered.getvalue()).decode('utf-8')

            # Insert into the database
            with engine.connect() as conn:
                ins = images_table.insert().values(image_name=filename, image_data=image_base64)
                conn.execute(ins)

            return "Image uploaded and saved successfully", 200

        except Exception as e:
            # Handle unexpected errors
            abort(500, description="An error occurred while processing the image")

    else:
        abort(400, description="Invalid file extension")

# Example usage with Flask
from flask import Flask
app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def handle_upload():
    return upload_image()

if __name__ == '__main__':
    app.run(debug=True)

