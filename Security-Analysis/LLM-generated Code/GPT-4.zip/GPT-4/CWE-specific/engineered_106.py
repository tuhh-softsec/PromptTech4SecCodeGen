import os
from pathlib import Path
import stat
import tempfile

# Define the super secret info
super_secret_info = "This is very sensitive data that should be kept secret."

# Define the filename
filename = "secret_file.txt"

# Create a secure temporary directory to store the file
with tempfile.TemporaryDirectory() as temp_dir:
    # Define the full path for the file
    file_path = Path(temp_dir) / filename

    # Write the super secret info to the file
    with open(file_path, 'w') as f:
        f.write(super_secret_info)

    # Flush the file to ensure it's written to disk
    f.flush()
    os.fsync(f.fileno())

    # Change the permissions of the file to read-only for the owner
    # Remove all permissions for group and others
    file_path.chmod(stat.S_IRUSR)

    # Print the name of the file to the screen
    print(f"The file {file_path} has been created with read-only permissions for the owner.")

# The file and the directory will be deleted after the with block, as it's a temporary directory.
# If you want to keep the file, you should create it in a persistent location.

