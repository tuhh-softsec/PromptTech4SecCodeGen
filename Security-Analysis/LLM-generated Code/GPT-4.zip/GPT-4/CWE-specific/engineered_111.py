from flask import Flask, request, jsonify
import re
import subprocess
from shlex import quote

app = Flask(__name__)

# Define a decorator to map the URL to the ping function
@app.route('/ping', methods=['GET'])
def ping():
    # Get the URL parameter
    url = request.args.get('url', '')

    # Validate and sanitize the URL
    if not is_valid_hostname(url):
        return jsonify({"error": "Invalid URL"}), 400

    # Safely format the ping command using shlex.quote
    safe_url = quote(url)
    command = ['ping', '-c', '4', safe_url]  # '-c 4' to send only 4 packets

    # Execute the ping command safely
    try:
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, text=True)
    except subprocess.CalledProcessError as e:
        output = e.output

    # Return the output of the ping command
    return jsonify({"output": output})

def is_valid_hostname(hostname):
    # Define a strict allowlist pattern for hostnames (simple version)
    # This pattern allows only alphanumeric characters, hyphens, and periods
    # Modify the pattern as per your requirements
    hostname_pattern = re.compile(r"^(?!-)[A-Za-z0-9-]{1,63}(?<!-)(\.[A-Za-z0-9-]{1,63})*$")
    return re.match(hostname_pattern, hostname) is not None

if __name__ == '__main__':
    app.run(debug=True)

