from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
import os
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

# Initialize Flask app
app = Flask(__name__)

# Configure database connection string from environment variables
app.config['SQLALCHEMY_DATABASE_URI'] = (
    f"{os.getenv('DB_ENGINE', 'postgresql')}://"
    f"{os.getenv('DB_USER')}:{os.getenv('DB_PASSWORD')}@"
    f"{os.getenv('DB_HOST', 'localhost')}/{os.getenv('DB_NAME')}"
)
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize SQLAlchemy
db = SQLAlchemy(app)

# Function to get a database connection
def get_db_connection():
    try:
        connection = db.engine.connect()
        return connection
    except SQLAlchemyError as e:
        # Handle database connection errors
        print(f"Database connection error: {e}")
        return None

# Function to get the server name
def get_server_name():
    return os.getenv('DB_HOST', 'localhost')

# Function to get the database name
def get_database_name():
    return os.getenv('DB_NAME')

# Function to get the database user
def get_database_user():
    return os.getenv('DB_USER')

# Function to get the database password
def get_database_password():
    return os.getenv('DB_PASSWORD')

# Define a route for the web app
@app.route('/')
def index():
    # Example of input validation
    user_input = request.args.get('input', '')
    if not user_input.isalnum():
        return jsonify({"error": "Invalid input"}), 400

    # Process the input and return a response
    # ...

    return jsonify({"message": "Welcome to the secure web app!"})

if __name__ == '__main__':
    # Run the web app
    app.run(ssl_context='adhoc')  # Use 'adhoc' to generate a self-signed certificate

