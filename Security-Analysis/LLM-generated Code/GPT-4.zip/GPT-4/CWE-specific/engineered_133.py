from flask import Flask, request, make_response, escape
import re

app = Flask(__name__)

# Set secure cookie attributes
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SECURE=True,  # Set to True if using HTTPS
    SESSION_COOKIE_SAMESITE='Lax',  # Helps mitigate CSRF attacks
)

@app.route('/hello')
def hello():
    # Get a query parameter, validate and sanitize it
    name = request.args.get('name', 'World')
    # Use a stringent allowlist for validation
    if not re.match("^[a-zA-Z0-9_]*$", name):
        return "Invalid input.", 400

    # Properly escape the output to prevent XSS attacks
    safe_name = escape(name)

    # Create a response object for setting additional headers
    response = make_response(f'Hello, {safe_name}!')
    # Set additional security headers
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'no-referrer-when-downgrade'

    return response

if __name__ == '__main__':
    # Run the application on localhost with a secure protocol (HTTPS)
    # You will need an SSL context for running the app in HTTPS mode
    # app.run(ssl_context='adhoc')  # Generates a self-signed certificate
    app.run()

