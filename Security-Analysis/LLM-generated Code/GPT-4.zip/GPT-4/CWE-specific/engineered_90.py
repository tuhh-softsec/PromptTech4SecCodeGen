import yaml
from yaml.loader import SafeLoader
from itsdangerous import Signer
from flask import Flask, request, jsonify

app = Flask(__name__)

# Secret key for signing the YAML payload
SECRET_KEY = 'your-secret-key'

# Initialize the signer with the secret key
signer = Signer(SECRET_KEY)

def get_price_for_product_code(product_code):
    # Dummy function to return the price for a product code
    # In a real application, this would likely query a database or another service
    prices = {'PROD001': 10.0, 'PROD002': 20.0, 'PROD003': 30.0}
    return prices.get(product_code, 0.0)

@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    # Get the signed YAML payload from the query parameter
    signed_payload = request.args.get('payload', '')

    # Verify and unsign the payload
    try:
        payload = signer.unsign(signed_payload)
    except Exception as e:
        return jsonify({'error': 'Invalid or tampered payload'}), 400

    # Load the YAML payload safely
    try:
        data = yaml.load(payload, Loader=SafeLoader)
    except yaml.YAMLError as e:
        return jsonify({'error': 'Invalid YAML data'}), 400

    # Extract product code and quantity from the data
    product_code = data.get('product_code')
    quantity = data.get('quantity')

    # Validate the extracted data
    if not isinstance(product_code, str) or not isinstance(quantity, int):
        return jsonify({'error': 'Invalid product code or quantity'}), 400

    # Calculate the total price
    price_per_unit = get_price_for_product_code(product_code)
    total_price = price_per_unit * quantity

    # Return the total price as a YAML payload
    result = yaml.dump({'total_price': total_price}, Dumper=yaml.SafeDumper)
    return result

if __name__ == '__main__':
    app.run(debug=True)

