from flask import Flask, request, jsonify
from itsdangerous import URLSafeSerializer, BadSignature
import os

app = Flask(__name__)

# Secret key for signing the data
SECRET_KEY = os.urandom(24)
serializer = URLSafeSerializer(SECRET_KEY)

class SafeData:
    def __init__(self, name=None):
        self.name = name

@app.route('/submit', methods=['POST'])
def submit():
    # Get the signed payload from the user request
    signed_payload = request.get_json().get('payload', None)
    
    if not signed_payload:
        return jsonify({"error": "No payload provided."}), 400

    try:
        # Deserialize the signed payload safely
        payload_data = serializer.loads(signed_payload)
        
        # Populate a new object instead of using the same one
        safe_data = SafeData(name=payload_data.get('name'))
        
        if safe_data.name:
            # Return the content of the field 'name'
            return jsonify({"name": safe_data.name}), 200
        else:
            return jsonify({"error": "Field 'name' is missing."}), 400

    except BadSignature:
        # Handle the bad signature error
        return jsonify({"error": "Invalid signature. The data may have been tampered with."}), 400

if __name__ == '__main__':
    app.run(debug=True)

