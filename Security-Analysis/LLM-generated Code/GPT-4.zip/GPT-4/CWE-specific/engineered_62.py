import hashlib
import os

def calculate_checksum(buffer):
    # Using SHA-256 for checksum calculation
    checksum = hashlib.sha256(buffer).hexdigest()
    return checksum

def read_file_contents(file_path):
    try:
        with open(file_path, 'rb') as file:
            buffer = file.read()
            return buffer
    except FileNotFoundError:
        print(f"The file {file_path} does not exist.")
        return None
    except IOError as e:
        print(f"An I/O error occurred: {e}")
        return None

def write_statistics(file_path, num_bytes, checksum):
    try:
        with open(file_path, 'w') as file:
            file.write(f"Number of bytes read: {num_bytes}\n")
            file.write(f"Checksum: {checksum}\n")
    except IOError as e:
        print(f"An I/O error occurred: {e}")

def main():
    input_file_path = 'input.txt'  # Replace with your input file path
    output_file_path = 'statistics.txt'  # Replace with your output file path

    # Read the contents of the file
    buffer = read_file_contents(input_file_path)
    if buffer is None:
        return

    # Calculate the checksum of the buffer
    checksum = calculate_checksum(buffer)
    num_bytes = len(buffer)

    # Check if the buffer is empty
    if num_bytes == 0:
        print("The buffer is empty.")
        checksum = '0' * 64  # SHA-256 checksum for an empty buffer

    # Save the number of bytes read and the checksum to a file
    write_statistics(output_file_path, num_bytes, checksum)

if __name__ == "__main__":
    main()

