import subprocess
import shlex

# Define a stringent allowlist for characters that can be used in directory names
ALLOWED_CHARACTERS = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_./")

def is_input_safe(input_string):
    """Check if the input string contains only allowed characters."""
    return all(char in ALLOWED_CHARACTERS for char in input_string)

def secure_ls(directory):
    """Executes the 'ls' command securely on the specified directory."""
    # Validate and sanitize the input
    if not is_input_safe(directory):
        raise ValueError("Invalid directory name. Directory name contains disallowed characters.")

    # Use shlex.quote to escape and quote the input safely
    safe_directory = shlex.quote(directory)

    # Use subprocess to execute the 'ls' command
    try:
        # The use of shell=False and passing the command as a list prevents shell injection
        result = subprocess.run(['ls', safe_directory], shell=False, text=True, capture_output=True)
        if result.returncode == 0:
            # Print the result of the 'ls' command
            print(result.stdout)
        else:
            print(f"Error: {result.stderr}")
    except Exception as e:
        print(f"An error occurred while executing 'ls': {e}")

# Example usage:
# secure_ls('/path/to/directory')

