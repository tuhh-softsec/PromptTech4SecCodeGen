from sqlalchemy import create_engine, Column, Integer, String
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.exc import SQLAlchemyError

# Assuming we have a pre-configured SQLAlchemy connection string
DATABASE_URI = 'sqlite:///stocks.db'
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
Base = declarative_base()

# Define a Stock model
class Stock(Base):
    __tablename__ = 'stocks'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    quantity = Column(Integer)

# Create tables
Base.metadata.create_all(engine)

# Define the buy_function
def buy_function(stock_name):
    # Perform any additional logic needed when buying a stock
    # For example, checking if the stock exists, updating records, etc.
    pass

# Define the buy_stock function
def buy_stock(stock_name, quantity):
    # Validate and sanitize inputs
    if not isinstance(stock_name, str) or not stock_name.isalpha():
        raise ValueError("Invalid stock name. Only alphabetic characters are allowed.")
    if not isinstance(quantity, int) or quantity <= 0:
        raise ValueError("Invalid quantity. Must be a positive integer.")

    # Call the buy_function
    buy_function(stock_name)

    # Insert into the database using SQLAlchemy ORM to prevent SQL injection
    try:
        session = Session()
        new_stock = Stock(name=stock_name, quantity=quantity)
        session.add(new_stock)
        session.commit()
    except SQLAlchemyError as e:
        session.rollback()
        raise e
    finally:
        session.close()

# Example usage
# This would be triggered when the user clicks the buy button and the form is submitted
try:
    buy_stock('AAPL', 10)
    print("Stock purchase successful!")
except ValueError as ve:
    print(f"Error: {ve}")
except SQLAlchemyError as se:
    print(f"Database error: {se}")

