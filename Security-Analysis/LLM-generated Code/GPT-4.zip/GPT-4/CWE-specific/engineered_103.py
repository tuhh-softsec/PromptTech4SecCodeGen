import os

# Define the file path and the flags for opening the file
file_path = 'example.txt'
flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY

# Use a restrictive umask to ensure that file permissions are set securely
old_umask = os.umask(0o077)  # Only the file owner can read and write

try:
    # Open the file securely with the specified flags and permissions
    # 0o600 permission means that only the owner can read and write the file
    file_descriptor = os.open(file_path, flags, 0o600)
    
    # Now you can write to the file using the file descriptor
    # For example, to write a string to the file:
    os.write(file_descriptor, b"Hello, secure world!")
    
finally:
    # Restore the original umask
    os.umask(old_umask)
    
    # Close the file descriptor
    os.close(file_descriptor)

flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_EXCL

