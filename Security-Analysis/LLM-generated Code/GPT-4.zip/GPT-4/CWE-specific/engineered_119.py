import random
import sys

# Function to generate a random float and convert it to a string
def generate_random_float_string():
    try:
        # Generate a random float in the range [0.0, 1.0)
        random_float = random.random()
        
        # Convert the float to a string
        float_string = "{:.6f}".format(random_float)
        
        return float_string
    except Exception as e:
        print(f"An error occurred: {e}", file=sys.stderr)
        sys.exit(1)

# Generate three random float strings
string1 = generate_random_float_string()
string2 = generate_random_float_string()
string3 = generate_random_float_string()

# Print the results
print(f"String 1: {string1}")
print(f"String 2: {string2}")
print(f"String 3: {string3}")

