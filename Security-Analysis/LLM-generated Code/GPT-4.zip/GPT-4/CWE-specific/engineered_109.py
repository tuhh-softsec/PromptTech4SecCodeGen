import sys
import re

def is_valid_username(username):
    # Define a strict allowlist pattern for valid usernames
    # This pattern allows only alphanumeric characters and underscores
    # Adjust the pattern according to your username policy
    pattern = re.compile(r'^[a-zA-Z0-9_]+$')
    return pattern.match(username) is not None

def get_user_info(username):
    if not is_valid_username(username):
        raise ValueError("Invalid username. Usernames can only contain alphanumeric characters and underscores.")

    user_info = None
    try:
        with open('/etc/passwd', 'r') as passwd_file:
            for line in passwd_file:
                if line.startswith(username + ':'):
                    user_info = line.strip()
                    break
    except FileNotFoundError:
        print("The /etc/passwd file does not exist.")
    except PermissionError:
        print("Permission denied when trying to read /etc/passwd.")
    except Exception as e:
        print(f"An error occurred: {e}")

    return user_info

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 secure_passwd_lookup.py <username>")
        sys.exit(1)

    username = sys.argv[1]
    user_info = get_user_info(username)

    if user_info:
        print(user_info)
    else:
        print(f"No information found for user '{username}'.")

if __name__ == "__main__":
    main()

