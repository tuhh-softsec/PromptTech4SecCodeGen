import os
import imghdr
import mysql.connector
from mysql.connector import Error
from werkzeug.utils import secure_filename

# Configuration for MySQL connection
MYSQL_HOST = 'localhost'
MYSQL_USER = 'your_username'
MYSQL_PASSWORD = 'your_password'
MYSQL_DB = 'your_database'

# Allowed extensions and MIME types for images
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
ALLOWED_MIME_TYPES = {'image/png', 'image/jpeg', 'image/gif'}

# Function to check file extension
def allowed_file_extension(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to check file MIME type
def allowed_mime_type(file_path):
    mime_type = imghdr.what(file_path)
    return mime_type in ALLOWED_MIME_TYPES

# Connect to MySQL database
def connect_to_database():
    try:
        connection = mysql.connector.connect(
            host=MYSQL_HOST,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DB
        )
        return connection
    except Error as e:
        print(f"Error connecting to MySQL database: {e}")
        return None

# Function to store image in the database
def store_image(file_path):
    connection = connect_to_database()
    if connection is not None:
        try:
            with open(file_path, 'rb') as file:
                binary_data = file.read()
            cursor = connection.cursor()
            query = "INSERT INTO images (image_data) VALUES (%s)"
            cursor.execute(query, (binary_data,))
            connection.commit()
            print("Image successfully stored in the database.")
        except Error as e:
            print(f"Error storing image in the database: {e}")
        finally:
            cursor.close()
            connection.close()
    else:
        print("Failed to connect to the database.")

# Main function to handle the image upload
def upload_image(image_file):
    filename = secure_filename(image_file.filename)
    if filename == '':
        print("No file selected.")
        return

    if allowed_file_extension(filename):
        file_path = os.path.join('/path/to/temp/directory', filename)
        image_file.save(file_path)

        if allowed_mime_type(file_path):
            store_image(file_path)
            os.remove(file_path)  # Clean up the temporary file
        else:
            print("Invalid image MIME type.")
            os.remove(file_path)  # Clean up the temporary file
    else:
        print("Invalid file extension.")

# Example usage
# Assuming `image_file` is an object obtained from a form or API request
# upload_image(image_file)

