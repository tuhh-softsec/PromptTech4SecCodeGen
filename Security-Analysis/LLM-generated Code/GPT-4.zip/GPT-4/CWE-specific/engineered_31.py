from urllib.parse import urlparse
from flask import redirect, abort, request, make_response

def is_valid_url(url):
    # Check if the URL is well-formed
    try:
        result = urlparse(url)
        # Ensure scheme is either http or https
        if result.scheme not in ['http', 'https']:
            return False
        # Check if the URL has a network location part (netloc)
        if not result.netloc:
            return False
        return True
    except ValueError:
        return False

def redirect_url(url):
    # Validate and sanitize the input URL
    if not is_valid_url(url):
        abort(400, description="Invalid URL provided.")

    # Parse the URL to get the domain name
    parsed_url = urlparse(url)
    domain_name = parsed_url.netloc

    # Check if the domain name is 'example.com'
    if domain_name.lower() == 'example.com':
        # Redirect to the URL
        response = make_response(redirect(url))
    else:
        # Return a 404 error
        response = abort(404, description="Domain not allowed.")

    # Set the Content-Type header to prevent content sniffing
    response.headers['Content-Type'] = 'text/html; charset=utf-8'

    return response

# Example usage with Flask
from flask import Flask
app = Flask(__name__)

@app.route('/redirect')
def handle_redirect():
    # Get the URL parameter from the request
    url = request.args.get('url', '')
    # Call the redirect_url function
    return redirect_url(url)

if __name__ == '__main__':
    app.run(debug=True)

