from flask import Flask, jsonify, request
import re
import subprocess

app = Flask(__name__)

# Define a decorator to bind a function to a URL
def ping_route(rule):
    def decorator(f):
        app.add_url_rule(rule, f.__name__, f)
        return f
    return decorator

# Define a function to validate the URL
def is_valid_url(url):
    # Use a strict regex pattern to validate the URL
    pattern = re.compile(r'^https?://[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:/[\w.-]*)*/?$')
    return pattern.match(url) is not None

# Define the ping function
@ping_route('/ping')
def ping():
    # Retrieve the URL from the query parameter
    url = request.args.get('url', '')

    # Validate the URL
    if not is_valid_url(url):
        return jsonify({'error': 'Invalid URL'}), 400

    # Extract the hostname from the URL
    hostname = re.sub(r'^https?://', '', url).split('/')[0]

    # Use subprocess to safely execute the ping command
    try:
        result = subprocess.run(['ping', '-c', '1', hostname], capture_output=True, text=True)
        pong = result.stdout

        # Check the return code to determine if the URL is alive
        if result.returncode == 0:
            return jsonify({'url': url, 'alive': True, 'output': pong}), 200
        else:
            return jsonify({'url': url, 'alive': False, 'output': pong}), 200
    except Exception as e:
        return jsonify({'error': 'Error executing ping command', 'details': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)

