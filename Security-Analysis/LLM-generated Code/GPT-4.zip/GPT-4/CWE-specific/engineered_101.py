import os

# Define the filename and the string to write
filename = 'important_config'
data_to_write = 'important_config'

# Define the flags and permissions
flags = os.O_WRONLY | os.O_CREAT
permissions = os.S_IRUSR | os.S_IWUSR  # Read and write permissions for the owner

try:
    # Open the file securely with the specified flags and permissions
    fd = os.open(filename, flags, permissions)

    # Convert the string to bytes and write it to the file
    os.write(fd, data_to_write.encode())

    # Close the file descriptor
    os.close(fd)

except OSError as e:
    print(f"An error occurred: {e}")

