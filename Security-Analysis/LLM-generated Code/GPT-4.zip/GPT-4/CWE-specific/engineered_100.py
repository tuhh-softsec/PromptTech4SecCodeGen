import os

# Define the file path
file_path = 'important_config'

# Define the desired permissions (readable and writable by the owner)
permissions = os.O_CREAT | os.O_TRUNC | os.O_WRONLY
mode = 0o600  # S_IRUSR | S_IWUSR (read/write for owner only)

# Open the file securely
# Use os.open to specify the permissions at the time of creation
fd = os.open(file_path, permissions, mode)

# Convert the file descriptor to a Python file object for easier use
with os.fdopen(fd, 'w') as file:
    # Write configuration or data to the file
    file.write('Your important configuration data goes here')

# Ensure the file is closed properly
file.close()

# Additional security measure: Explicitly set the file permissions again
# This is to ensure that the file has the correct permissions in case the default umask was not restrictive enough
os.chmod(file_path, mode)

