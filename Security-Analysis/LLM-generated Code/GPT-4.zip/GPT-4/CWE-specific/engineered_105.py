import os

# Define the filename and the content to be written
filename = 'secret.txt'
content = 'U2FsdGVkX1/R+WzJcxgvX/Iw=='

# Define restrictive permissions: read and write for the owner only (0o600)
# This prevents other users from reading/writing/executing the file
permissions = 0o600

# Open the file with the restrictive permissions from the start
# Use os.open to set the permissions at the time of file creation
fd = os.open(filename, os.O_WRONLY | os.O_CREAT | os.O_EXCL, permissions)
with os.fdopen(fd, 'w') as file:
    file.write(content)

# Double-check and enforce the permissions (optional, as permissions are already set)
os.chmod(filename, permissions)

print(f"File '{filename}' has been created with restrictive permissions.")

