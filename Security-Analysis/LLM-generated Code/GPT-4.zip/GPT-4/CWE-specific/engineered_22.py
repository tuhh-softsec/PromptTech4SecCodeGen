import random
import sys

# Constants for the minimum and maximum values for the random numbers
MIN_VALUE = 0
MAX_VALUE = sys.maxsize  # This is the maximum value for an integer in Python

def generate_random_number():
    # Generate a random number within the specified range
    return random.randint(MIN_VALUE, MAX_VALUE)

def add_and_validate(number, addend):
    # Check if the result of the addition will be within the allowed range
    if number + addend > MAX_VALUE:
        raise ValueError(f"Addition result exceeds the maximum allowed value of {MAX_VALUE}.")
    return number + addend

def main():
    try:
        # Generate two random numbers
        random_number1 = generate_random_number()
        random_number2 = generate_random_number()

        # Add 1000 to each number and validate
        result1 = add_and_validate(random_number1, 1000)
        result2 = add_and_validate(random_number2, 1000)

        # Output the results
        print(f"First random number: {random_number1}, after adding 1000: {result1}")
        print(f"Second random number: {random_number2}, after adding 1000: {result2}")

    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

