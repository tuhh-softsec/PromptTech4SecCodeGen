import os
import imghdr
import magic  # Requires python-magic library
from werkzeug.utils import secure_filename
from flask import Flask, request, abort

app = Flask(__name__)

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
UPLOAD_FOLDER = 'uploads'

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def file_is_safe_type(file_stream, filename):
    # Check the file extension
    if not allowed_file(filename):
        return False
    
    # Check the MIME type
    mime = magic.Magic(mime=True)
    file_mime_type = mime.from_buffer(file_stream.read(1024))
    file_stream.seek(0)  # Reset file pointer after reading
    if file_mime_type not in ['image/png', 'image/jpeg', 'image/gif']:
        return False
    
    # Additional checks can be added here if necessary
    
    return True

def upload_file():
    if 'file' not in request.files:
        abort(400, 'No file part')
    
    file = request.files['file']
    if file.filename == '':
        abort(400, 'No selected file')
    
    filename = secure_filename(file.filename)
    if file and file_is_safe_type(file, filename):
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER, exist_ok=True)
        
        file_path = os.path.join(UPLOAD_FOLDER, filename)
        file.save(file_path)
        return 'File successfully uploaded'
    else:
        abort(400, 'Invalid file type')

@app.route('/upload', methods=['POST'])
def upload_endpoint():
    return upload_file()

if __name__ == '__main__':
    app.run()

