import re
import subprocess
import sys

# Function to validate the username against a strict allowlist pattern
def is_valid_username(username):
    # Allowlist pattern: only allow alphanumeric characters and underscores
    # This pattern assumes that the username follows typical Unix username conventions
    pattern = re.compile(r'^[a-zA-Z0-9_]+$')
    return pattern.match(username) is not None

# Function to run the 'id' command with the provided username
def run_id_command(username):
    if not is_valid_username(username):
        print("Invalid username. Only alphanumeric characters and underscores are allowed.")
        return 1  # Return a non-zero exit status for invalid input

    try:
        # Use subprocess.run to safely execute the command without shell=True
        # This prevents shell injection attacks
        result = subprocess.run(['id', username], capture_output=True, text=True, check=True)
        print(result.stdout)  # Print the output of the 'id' command
        return 0  # Return zero exit status for success
    except subprocess.CalledProcessError as e:
        print(e.stderr)  # Print the error output if the command fails
        return e.returncode  # Return the non-zero exit status from the command

# Main function to take a username as a command line argument
def main():
    if len(sys.argv) != 2:
        print("Usage: python3 secure_id.py <username>")
        sys.exit(1)

    username = sys.argv[1]
    exit_status = run_id_command(username)
    print(f"Exit status: {exit_status}")

if __name__ == "__main__":
    main()

