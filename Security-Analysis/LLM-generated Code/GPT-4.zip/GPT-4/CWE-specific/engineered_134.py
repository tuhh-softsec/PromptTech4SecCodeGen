from flask import Flask, escape, request, make_response

app = Flask(__name__)

# Define a decorator to map the URL to the hello function
def route(rule):
    def decorator(f):
        app.add_url_rule(rule, f.__name__, f)
        return f
    return decorator

# Define the hello function with input validation and escaping
@route('/hello/<username>')
def hello(username):
    # Use a stringent allowlist to validate the username
    if not username.isalnum():
        return "Invalid username. Only alphanumeric characters are allowed.", 400

    # Escape the username to prevent XSS attacks
    safe_username = escape(username)

    # Return the response with the escaped username
    response = make_response(f"Hello, {safe_username}!")
    
    # Set the HttpOnly flag on the session cookie for security
    response.set_cookie('session', 'value', httponly=True)
    
    return response

if __name__ == '__main__':
    app.run()

