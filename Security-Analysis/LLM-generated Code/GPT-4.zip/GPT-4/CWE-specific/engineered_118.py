import os
import random
import io

# Function to generate a random float and convert it to a string
def generate_random_float_str():
    # Generate a random float in the range [0.0, 1.0)
    random_float = random.random()
    # Convert the float to a string with a fixed precision to avoid floating-point representation issues
    return f"{random_float:.6f}"

# Function to concatenate float strings and write to a file
def write_floats_to_file(filename):
    # Ensure the filename is a valid string and not too long
    if not isinstance(filename, str) or len(filename) > 255:
        raise ValueError("Invalid filename")

    # Generate 3 random float strings
    float_strs = [generate_random_float_str() for _ in range(3)]
    
    # Concatenate the float strings into a single string
    concatenated_str = ''.join(float_strs)
    
    # Check if the concatenated string is not too long for the buffer
    # Assuming a reasonable buffer size limit (e.g., 1024 characters)
    if len(concatenated_str) > 1024:
        raise ValueError("Concatenated string is too long for the buffer")

    # Write the concatenated string to a file using a secure method
    try:
        with open(filename, 'w', encoding='utf-8') as file:
            file.write(concatenated_str)
    except IOError as e:
        # Handle file I/O errors (e.g., permission issues, disk full)
        print(f"An error occurred while writing to the file: {e}")
        raise

# Example usage
if __name__ == "__main__":
    try:
        # Define a secure filename (avoiding directory traversal attacks)
        secure_filename = "random_floats.txt"
        write_floats_to_file(secure_filename)
        print(f"Successfully wrote random floats to {secure_filename}")
    except ValueError as e:
        print(f"Error: {e}")

