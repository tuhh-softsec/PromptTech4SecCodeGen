from flask import Flask, request, jsonify
import re
import subprocess
import shlex

app = Flask(__name__)

# Define a decorator to bind a function to a URL
def route(url):
    def decorator(func):
        app.add_url_rule(url, view_func=func)
        return func
    return decorator

# Allowlist for hostname validation (only alphanumeric characters, hyphens, and periods)
ALLOWED_HOSTNAME_CHARS = re.compile(r'^[a-zA-Z0-9.-]+$')

def is_valid_hostname(hostname):
    """Validate the hostname against the allowlist."""
    return ALLOWED_HOSTNAME_CHARS.match(hostname) is not None

def sanitize_hostname(hostname):
    """Sanitize the hostname to prevent command injection."""
    if not is_valid_hostname(hostname):
        raise ValueError("Invalid hostname")
    return hostname

@route('/ping')
def ping():
    # Retrieve the URL parameter
    url = request.args.get('url', '')

    try:
        # Sanitize the URL to ensure it's a valid hostname
        sanitized_url = sanitize_hostname(url)

        # Prepare the ping command using shlex to ensure proper quoting
        command = shlex.split(f'ping -c 4 {sanitized_url}')

        # Execute the ping command safely
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)

        # Encode the output to ensure safe display in the browser
        output = result.stdout.replace('<', '&lt;').replace('>', '&gt;')

        # Return the sanitized output to the browser
        return jsonify({'output': output})

    except ValueError as e:
        # Return an error message if the input validation fails
        return jsonify({'error': str(e)}), 400

    except subprocess.CalledProcessError as e:
        # Return an error message if the ping command fails
        return jsonify({'error': 'Ping command failed'}), 500

if __name__ == '__main__':
    app.run(debug=True)

