import os
import hashlib
import re
from typing import Tuple

# Assuming we have a function to connect to the database
from database import save_user_credentials

# Constants for password hashing
HASH_NAME = 'sha256'
SALT_SIZE = 16
ITERATIONS = 100000

def generate_salt() -> bytes:
    return os.urandom(SALT_SIZE)

def hash_password(password: str, salt: bytes) -> bytes:
    password_hash = hashlib.pbkdf2_hmac(
        HASH_NAME,
        password.encode('utf-8'),
        salt,
        ITERATIONS
    )
    return password_hash

def validate_username(username: str) -> bool:
    # Username must be between 3 and 20 characters and can only contain alphanumeric characters and underscores
    return re.match(r'^\w{3,20}$', username) is not None

def validate_password(password: str) -> bool:
    # Password must be at least 8 characters long and contain a mix of upper and lower case letters, numbers, and symbols
    if len(password) < 8:
        return False
    if not re.search(r'[A-Z]', password):
        return False
    if not re.search(r'[a-z]', password):
        return False
    if not re.search(r'[0-9]', password):
        return False
    if not re.search(r'[\W_]', password):
        return False
    return True

def register_user(username: str, password: str) -> Tuple[bool, str]:
    # Validate username
    if not validate_username(username):
        return False, "Invalid username."

    # Validate password
    if not validate_password(password):
        return False, "Invalid password."

    # Generate salt and hash the password
    salt = generate_salt()
    password_hash = hash_password(password, salt)

    # Store the salt and hashed password in the database
    # Here we concatenate the salt and password_hash to store them together
    # You might want to store them separately depending on your database schema
    credentials = salt + password_hash
    save_user_credentials(username, credentials)

    return True, "User registered successfully."

# Example usage
username = input("Enter your username: ")
password = input("Enter your password: ")

success, message = register_user(username, password)
if success:
    print(message)
else:
    print("Registration failed:", message)

