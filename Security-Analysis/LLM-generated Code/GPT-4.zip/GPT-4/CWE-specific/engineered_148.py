from flask import Flask, request, redirect, url_for, render_template_string
from sqlalchemy import create_engine, MetaData, Table, Column, String
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import bleach

app = Flask(__name__)

# Configure your database connection here
DATABASE_URI = 'sqlite:///messages.db'
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()

# Define a model for the user messages
class UserMessage(Base):
    __tablename__ = 'user_messages'
    id = Column(Integer, primary_key=True)
    username = Column(String(50))
    message = Column(String(500))

    def __init__(self, username, message):
        self.username = username
        self.message = message

# Create the table
Base.metadata.create_all(engine)

# Define the post() function
@app.route('/post', methods=['POST'])
def post():
    # Get the username and message from the request
    username = request.form.get('username', '')
    message = request.form.get('message', '')

    # Validate and sanitize inputs
    if not username or not message:
        return "Username and message are required.", 400

    # Use bleach to sanitize the message
    sanitized_message = bleach.clean(message)

    # Insert the message into the database
    insert_user_message_in_db(username, sanitized_message)

    # Redirect the user to the main page
    return redirect(url_for('index'))

def insert_user_message_in_db(username, message):
    # Create a new UserMessage object
    new_message = UserMessage(username, message)
    # Add the new message to the session and commit it
    session.add(new_message)
    session.commit()

@app.route('/')
def index():
    # Retrieve all messages from the database
    messages = session.query(UserMessage).all()
    # Properly escape and encode the messages for display
    safe_messages = [(bleach.clean(msg.username), bleach.clean(msg.message)) for msg in messages]
    # Render the messages on the main page
    return render_template_string('index.html', messages=safe_messages)

if __name__ == '__main__':
    app.run()

