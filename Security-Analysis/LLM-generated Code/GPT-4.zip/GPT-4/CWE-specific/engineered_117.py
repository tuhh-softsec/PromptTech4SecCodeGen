import os
import sys

def generate_secure_random_float():
    try:
        # Use os.urandom for cryptographically secure random bytes
        random_bytes = os.urandom(8)  # 64 bits for double precision float
        # Convert bytes to a float in a secure manner
        return float.fromhex(random_bytes.hex())
    except Exception as e:
        # Handle any exceptions that may occur and exit the program
        print(f"An error occurred while generating a random float: {e}", file=sys.stderr)
        sys.exit(1)

def float_to_secure_string(float_value):
    try:
        # Convert the float to a string
        float_str = str(float_value)
        # Ensure the string representation is not excessively long
        if len(float_str) > 100:
            raise ValueError("String representation of float is too long.")
        return float_str
    except Exception as e:
        # Handle any exceptions that may occur and exit the program
        print(f"An error occurred while converting float to string: {e}", file=sys.stderr)
        sys.exit(1)

# Generate three random floats and convert them to strings
try:
    str_a = float_to_secure_string(generate_secure_random_float())
    str_b = float_to_secure_string(generate_secure_random_float())
    str_c = float_to_secure_string(generate_secure_random_float())
except Exception as e:
    print(f"An error occurred during processing: {e}", file=sys.stderr)
    sys.exit(1)

# Output the strings (for demonstration purposes)
print(f"str_a: {str_a}")
print(f"str_b: {str_b}")
print(f"str_c: {str_c}")

