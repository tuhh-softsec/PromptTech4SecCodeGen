from flask import Flask, request, jsonify
import bcrypt
import sqlite3
import re

app = Flask(__name__)

# Regular expression for validating an Email
regex = r'^\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Z|a-z]{2,}\b'

# Function to validate the email
def check(email):
    if re.fullmatch(regex, email):
        return True
    else:
        return False

# Function to create the database connection
def get_db_connection():
    conn = sqlite3.connect('users.db')
    conn.row_factory = sqlite3.Row
    return conn

# Function to check if the username exists
def username_exists(username):
    conn = get_db_connection()
    user = conn.execute('SELECT * FROM users WHERE username = ?', (username,)).fetchone()
    conn.close()
    return user is not None

# Route for handling registration
@app.route('/register', methods=['POST'])
def register():
    username = request.form.get('username')
    password = request.form.get('password')
    first_name = request.form.get('first_name')
    last_name = request.form.get('last_name')
    email = request.form.get('email')

    # Input validation
    if not (username and password and first_name and last_name and email):
        return jsonify({'error': 'Missing fields'}), 400

    if len(password) < 8:
        return jsonify({'error': 'Password must be at least 8 characters long'}), 400

    if not check(email):
        return jsonify({'error': 'Invalid email address'}), 400

    # Check if the username already exists
    if username_exists(username):
        return jsonify({'error': 'Username already exists'}), 409

    # Hash the password
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    # Insert the new user into the database
    conn = get_db_connection()
    conn.execute('INSERT INTO users (username, password, first_name, last_name, email) VALUES (?, ?, ?, ?, ?)',
                 (username, hashed_password, first_name, last_name, email))
    conn.commit()
    conn.close()

    return jsonify({'message': 'Registration succeeded'}), 201

if __name__ == '__main__':
    # Create the database table if it doesn't exist
    conn = get_db_connection()
    conn.execute('CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY, username TEXT, password TEXT, first_name TEXT, last_name TEXT, email TEXT)')
    conn.commit()
    conn.close()

    app.run(debug=True)

