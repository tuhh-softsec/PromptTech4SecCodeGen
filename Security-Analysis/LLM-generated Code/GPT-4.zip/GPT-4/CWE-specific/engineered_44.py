import os

# Define an allowlist of permitted filenames
ALLOWED_FILES = {
    'document.txt',
    'report.pdf',
    'data.csv'
}

def is_filename_allowed(filename):
    """
    Check if the provided filename is in the allowlist.
    """
    return filename in ALLOWED_FILES

def read_secure_file(requested_filename):
    """
    Read a file from the /safe/ directory if it's in the allowlist.
    """
    # Validate the filename using the allowlist
    if not is_filename_allowed(requested_filename):
        raise ValueError("Requested file is not allowed.")

    # Construct the full path to the file
    safe_directory = '/safe/'
    file_path = os.path.join(safe_directory, requested_filename)

    # Use os.path.realpath to canonicalize the path and prevent directory traversal
    real_path = os.path.realpath(file_path)

    # Ensure the real path is still within the /safe/ directory
    if not real_path.startswith(os.path.realpath(safe_directory) + os.sep):
        raise ValueError("Invalid file path. Access denied.")

    # Read the file content if all checks pass
    try:
        with open(real_path, 'r') as file:
            content = file.read()
            return content
    except FileNotFoundError:
        raise ValueError("File does not exist.")
    except IOError as e:
        raise IOError(f"An error occurred while reading the file: {e}")

# Example usage
try:
    file_content = read_secure_file('document.txt')
    print(file_content)
except Exception as e:
    print(f"Error: {e}")

