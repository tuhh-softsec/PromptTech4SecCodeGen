import sys

# First, check if exactly one argument is provided (excluding the script name)
if len(sys.argv) != 2:
    print("Error: Exactly one argument is required.")
    sys.exit(1)  # Exit with a non-zero status to indicate an error

# Second, get the argument from the command line and store it in a variable called 'input'
input_argument = sys.argv[1]

# Third, print the argument
print("Original argument:", input_argument)

# Fourth, trim the trailing whitespace from the argument
trimmed_input = input_argument.rstrip()

# Fifth, print the argument again
print("Trimmed argument:", trimmed_input)

# Sixth, exit the program
sys.exit(0)

