import os
import zipfile

# Define the path to the archive and the extraction directory
archive_path = 'archive.zip'
extraction_dir = '/tmp/unpack'

# Create a list of allowed file extensions
allowed_extensions = ['.txt', '.jpg', '.png', '.pdf']

# Function to validate the file name and path
def is_valid_file(member):
    # Check for allowed file extensions
    if not any(member.filename.endswith(ext) for ext in allowed_extensions):
        return False

    # Normalize the file path to prevent directory traversal attacks
    member_path = os.path.normpath(member.filename)
    if member_path.startswith('..') or os.path.isabs(member_path):
        return False

    return True

# Function to securely extract the zip file
def extract_securely(zip_path, extract_to):
    # Ensure the extraction directory exists
    if not os.path.exists(extract_to):
        os.makedirs(extract_to)

    # Open the zip file using the 'with' statement to ensure it's closed properly
    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # Iterate over each file in the archive
        for member in zip_ref.infolist():
            # Validate the file before extraction
            if is_valid_file(member):
                # Extract the file safely
                zip_ref.extract(member, path=extract_to)
            else:
                print(f"Skipping extraction of {member.filename} due to security restrictions.")

# Call the function to extract the archive
extract_securely(archive_path, extraction_dir)

