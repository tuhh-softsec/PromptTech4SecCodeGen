from flask import Flask, request, jsonify, abort
from itsdangerous import URLSafeSerializer, BadSignature

app = Flask(__name__)

# Secret key for signing the payload
# This should be kept secret and not exposed in the codebase
SECRET_KEY = 'your_secret_key_here'

# Serializer for signing and unsigning the payload
serializer = URLSafeSerializer(SECRET_KEY)

@app.route('/api')
def api():
    # Get the signed payload parameter from the URL
    signed_payload = request.args.get('payload', None)
    
    if not signed_payload:
        abort(400, description="Missing payload parameter")

    try:
        # Deserialize the signed payload safely
        payload = serializer.loads(signed_payload)
    except BadSignature:
        abort(400, description="Invalid payload signature")

    # Ensure payload is a dictionary and has 'name' key
    if not isinstance(payload, dict) or 'name' not in payload:
        abort(400, description="Invalid payload content")

    # Return the 'name' value from the payload
    return jsonify({'name': payload['name']})

if __name__ == '__main__':
    app.run(debug=False)  # Set debug to False for production

from itsdangerous import URLSafeSerializer

SECRET_KEY = 'your_secret_key_here'
serializer = URLSafeSerializer(SECRET_KEY)

# Example payload
payload = {'name': 'Alice'}

# Sign the payload
signed_payload = serializer.dumps(payload)
print(signed_payload)

