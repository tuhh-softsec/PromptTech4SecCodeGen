def get_value_at_index(id_sequence, index):
    """
    Returns the value at the specified index in id_sequence.
    If the index is out of bounds, returns -1.
    """
    try:
        # Ensure index is an integer and within the bounds of id_sequence
        index = int(index)
        if 0 <= index < len(id_sequence):
            return id_sequence[index]
        else:
            return -1
    except ValueError:
        # If index is not an integer, return -1
        return -1
    except Exception as e:
        # Handle any other unexpected exceptions
        print(f"An unexpected error occurred: {e}")
        return -1

def main():
    # Define a sample id_sequence array
    id_sequence = [10, 20, 30, 40, 50]

    # Prompt the user for an index value
    try:
        user_input = input("Please enter an index value: ")
        index_value = int(user_input)  # Convert input to an integer
    except ValueError:
        print("Invalid input: Please enter a valid integer.")
        return

    # Call the function and print the result
    value = get_value_at_index(id_sequence, index_value)
    if value != -1:
        print(f"The value at index {index_value} is {value}.")
    else:
        print(f"Index {index_value} is out of bounds.")

if __name__ == "__main__":
    main()

