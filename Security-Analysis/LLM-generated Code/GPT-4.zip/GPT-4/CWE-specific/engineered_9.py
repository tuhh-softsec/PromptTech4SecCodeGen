import sys

def main():
    # Check if at least one argument is provided (excluding the script name)
    if len(sys.argv) < 2:
        print("Usage: ./argv_index <index>")
        sys.exit(1)

    try:
        # Convert the first argument to an integer index
        index = int(sys.argv[1])

        # Check if the index is within the range of command-line arguments
        if index < 0 or index >= len(sys.argv) - 1:
            print("Error: Index is out of range.")
            sys.exit(1)

        # Print the argument at the specified index (1-based indexing for user)
        print(sys.argv[index + 1])

    except ValueError:
        # Handle the case where the index is not an integer
        print("Error: Index must be an integer.")
        sys.exit(1)
    except Exception as e:
        # Handle any other unexpected errors
        print(f"An unexpected error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

