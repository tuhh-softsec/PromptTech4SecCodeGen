import bcrypt
import sqlite3
import re

# Establish a database connection (replace with your actual database connection code)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create users table if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
)
''')
conn.commit()

# Function to validate the username
def validate_username(username):
    # Define a regex pattern for a valid username (adjust as needed)
    pattern = re.compile("^[a-zA-Z0-9_]{3,20}$")
    return pattern.match(username)

# Function to validate the password
def validate_password(password):
    # Define a regex pattern for a valid password (adjust as needed)
    pattern = re.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)[a-zA-Z\d]{8,}$")
    return pattern.match(password)

# Function to hash the password
def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Function to insert the username and hashed password into the database
def insert_user(username, hashed_password):
    try:
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError as e:
        print(f"Error inserting user: {e}")

# Main function to get user input and perform the operations
def main():
    username = input("Enter your username: ")
    password = input("Enter your password: ")

    # Validate the username and password
    if not validate_username(username):
        print("Invalid username. It must be 3-20 characters long and can contain letters, numbers, and underscores.")
        return
    if not validate_password(password):
        print("Invalid password. It must be at least 8 characters long, contain a mix of upper and lower case letters, and include numbers.")
        return

    # Hash the password
    hashed_password = hash_password(password)

    # Insert the username and hashed password into the database
    insert_user(username, hashed_password)
    print("User created successfully.")

if __name__ == "__main__":
    main()

# Close the database connection
conn.close()

