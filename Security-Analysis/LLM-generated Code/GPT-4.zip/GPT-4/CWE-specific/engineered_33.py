from flask import Flask, request, redirect, abort, url_for
from urllib.parse import urlparse, urljoin
from werkzeug.utils import secure_filename

app = Flask(__name__)

def is_safe_url(target):
    """
    Check if the target URL is safe for redirects.
    """
    ref_url = urlparse(request.host_url)
    test_url = urlparse(urljoin(request.host_url, target))
    return test_url.scheme in ('http', 'https') and \
           ref_url.netloc == test_url.netloc

def is_example_domain(url):
    """
    Check if the URL's domain is 'example.com'.
    """
    parsed_url = urlparse(url)
    return parsed_url.netloc.endswith('example.com')

@app.route('/redirect')
def redirect_to_url():
    # Get the URL parameter and ensure it is a string
    url = request.args.get('url', '')
    
    # Validate and sanitize the URL
    if not url or not is_example_domain(url) or not is_safe_url(url):
        # If the URL is not valid or not safe, return an error message
        return "Invalid URL. Only redirects to 'example.com' are allowed.", 400
    
    # Redirect to the sanitized and validated URL
    return redirect(secure_filename(url))

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use adhoc SSL for demonstration purposes

