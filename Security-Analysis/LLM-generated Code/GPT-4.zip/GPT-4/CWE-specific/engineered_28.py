import re
from urllib.parse import urlparse, urljoin
from flask import redirect, request, abort, Flask

app = Flask(__name__)

# Precompile the regular expression for performance
# Example pattern: match URLs like "https://example.com/page"
VALID_URL_PATTERN = re.compile(r'^https://example\.com/[\w/-]*$')

# Default URL to redirect to if the target URL does not match
DEFAULT_URL = "https://example.com/default"

def is_valid_url(url):
    """Validate and sanitize the input URL."""
    # Parse the URL to ensure it's well-formed
    parsed_url = urlparse(url)
    
    # Check the scheme and netloc to prevent open redirects
    if parsed_url.scheme not in ('http', 'https') or not parsed_url.netloc:
        return False
    
    # Check if the URL matches the precompiled regular expression
    return VALID_URL_PATTERN.match(url) is not None

def get_redirect_target():
    """Get the target URL from the request and validate it."""
    # Get the target URL from the request arguments
    target_url = request.args.get('url', '')
    
    # Validate and sanitize the target URL
    if not is_valid_url(target_url):
        return DEFAULT_URL
    
    return target_url

def redirect_to_target():
    """Redirect to the validated target URL or the default URL."""
    target_url = get_redirect_target()
    
    # Ensure the target URL is properly encoded to prevent injection attacks
    safe_target_url = urljoin(request.host_url, target_url)
    
    # Redirect to the safe target URL
    return redirect(safe_target_url)

# Example usage in a Flask route
@app.route('/redirect')
def redirect_view():
    try:
        return redirect_to_target()
    except Exception as e:
        # Log the exception for debugging purposes
        print(f"An error occurred during redirection: {e}")
        # Abort with a 400 Bad Request if something goes wrong
        abort(400)

# Run the Flask app
if __name__ == '__main__':
    app.run()

