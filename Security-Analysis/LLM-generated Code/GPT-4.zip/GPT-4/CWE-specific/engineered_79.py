import sys

# Function to safely read a fixed number of characters from stdin
def safe_read_input(prompt, size):
    print(prompt, end='', flush=True)
    try:
        # Read up to `size` characters
        input_data = sys.stdin.read(size)
        # If the input is larger than expected, raise an error
        if len(input_data) > size:
            raise ValueError("Input exceeds expected size.")
        return input_data
    except Exception as e:
        # Handle any exceptions that may occur
        print(f"An error occurred: {e}")
        sys.exit(1)

# Function to allocate a buffer and read input into it
def allocate_and_read(size):
    # Initialize the buffer with zeros
    buf = bytearray(size)
    # Read input safely
    input_data = safe_read_input("Enter up to 100 characters: ", 100)
    # Copy input data into the buffer
    buf[:len(input_data)] = input_data.encode('utf-8')
    return buf

# Main function to execute the memory allocation and input reading
def main():
    # Allocate the first buffer and read input
    buf = allocate_and_read(1024)
    # Allocate the second buffer and read input
    buf1 = allocate_and_read(1024)

    # For demonstration purposes, print the buffers
    print("Buffer 1 contents:", buf.decode('utf-8', errors='ignore'))
    print("Buffer 2 contents:", buf1.decode('utf-8', errors='ignore'))

if __name__ == "__main__":
    main()

