import os

# Define the base directory where files are allowed to be read
BASE_DIR = '/safe/'

# Define an allowlist of permitted file extensions
ALLOWED_EXTENSIONS = {'.txt', '.md', '.log'}

def is_safe_path(basedir, path, follow_symlinks=True):
    # Resolve the canonical path of the basedir and the full filepath
    if follow_symlinks:
        abs_basedir = os.path.realpath(basedir)
        abs_path = os.path.realpath(path)
    else:
        abs_basedir = os.path.abspath(basedir)
        abs_path = os.path.abspath(path)
    
    # Check if the absolute path of the file starts with the base directory
    return os.path.commonpath([abs_basedir]) == os.path.commonpath([abs_basedir, abs_path])

def is_allowed_filename(filename):
    # Check if the file has an allowed extension
    return '.' in filename and os.path.splitext(filename)[1] in ALLOWED_EXTENSIONS

def read_file_securely(filename):
    # Construct the full path
    file_path = os.path.join(BASE_DIR, filename)
    
    # Validate the file path
    if not is_safe_path(BASE_DIR, file_path):
        raise ValueError("Invalid file path.")
    
    # Validate the filename
    if not is_allowed_filename(filename):
        raise ValueError("Invalid file extension.")
    
    # Read the file if it is safe and allowed
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except IOError as e:
        # Handle file I/O errors (e.g., file not found, permission denied)
        raise IOError(f"Could not read file: {e}")

# Example usage
if __name__ == "__main__":
    try:
        # Replace 'example.txt' with the filename provided by the user
        user_provided_filename = 'example.txt'
        
        # Read the file securely
        file_content = read_file_securely(user_provided_filename)
        print(file_content)
    except Exception as e:
        print(f"Error: {e}")

