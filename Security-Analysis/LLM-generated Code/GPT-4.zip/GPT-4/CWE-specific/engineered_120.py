import copy

# Function to securely copy contents from one buffer to another
def secure_copy(source, destination):
    # Check if the destination buffer is large enough
    if len(destination) < len(source):
        raise ValueError("Destination buffer is not large enough to hold the source data.")
    
    # Copy contents from source to destination using slicing
    destination[:len(source)] = source

# Function to print the contents of a buffer
def print_buffer(buffer):
    print("Buffer contents:", buffer)

# Allocate two chunks of memory each of size 10
chunk1 = bytearray(10)
chunk2 = bytearray(10)

# Initialize chunk1 with some data
chunk1[:] = b'1234567890'

try:
    # Securely copy contents of the first chunk into the second chunk
    secure_copy(chunk1, chunk2)
    
    # Print the contents of the second chunk
    print_buffer(chunk2)
except ValueError as e:
    print("Error:", e)

