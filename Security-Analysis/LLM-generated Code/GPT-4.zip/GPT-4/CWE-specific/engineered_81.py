import sys

def safe_input(prompt="Input: ", max_length=10):
    # Initialize the buffer with None to ensure it's empty
    buf = None

    try:
        # Prompt the user for input
        print(prompt, end='')

        # Read input from the user safely with exception handling
        buf = sys.stdin.readline(max_length + 1)  # Read max_length + 1 to check for overflow

        # Check if the input is longer than max_length
        if len(buf) > max_length:
            raise ValueError("Input exceeded maximum length")

        # Strip any additional newline or carriage return characters
        buf = buf.rstrip('\n\r')

    except Exception as e:
        # Handle any potential exceptions that could arise
        print(f"An error occurred: {e}")
        sys.exit(1)

    # Ensure that the buffer is not None or empty
    if buf is None or len(buf) == 0:
        print("No input received")
        sys.exit(1)

    # Return the safely obtained input
    return buf

# Use the safe_input function to read 10 characters securely
buffer = safe_input()
print(f"Received input: {buffer}")

