from flask import Flask, request, make_response, render_template_string
import re

app = Flask(__name__)

# Define a strict allowlist for the 'name' parameter to prevent injection attacks
ALLOWLIST_PATTERN = re.compile(r'^[a-zA-Z0-9\s]+$')

def sanitize_input(input_string):
    """Sanitize the input to allow only characters in the allowlist."""
    if not ALLOWLIST_PATTERN.match(input_string):
        raise ValueError("Invalid input detected.")
    return input_string

def render_response_from_env(environment):
    """Render a response from the environment with proper validation and sanitization."""
    # Get the 'name' parameter from the request, with proper validation and sanitization
    name = request.args.get('name', '')
    try:
        sanitized_name = sanitize_input(name)
    except ValueError as e:
        return str(e), 400  # Return a 400 Bad Request response if validation fails

    # Get the template from the environment
    template = environment.get_template('template.html')

    # Render the template with the sanitized 'name' parameter
    rendered_template = template.render(name=sanitized_name)

    # Create a response with the rendered template
    response = make_response(rendered_template)

    # Set the HttpOnly flag on the session cookie for security
    response.set_cookie('session', value='session_value', httponly=True)

    return response

@app.route('/')
def home():
    """Home function that calls render_response_from_env and returns the response."""
    # Assuming 'env' is a Jinja2 environment that has been set up elsewhere
    env = app.jinja_env
    response = render_response_from_env(env)
    return response

if __name__ == '__main__':
    app.run()

