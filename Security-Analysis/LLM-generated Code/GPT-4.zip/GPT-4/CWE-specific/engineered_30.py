from flask import Flask, request, redirect
import re

app = Flask(__name__)

# Regular expression pattern to match the required format
# Starts with one or more alphanumeric characters or hyphens followed by a period
pattern = re.compile(r'^[\w-]+\.')

@app.route('/redirect')
def redirect_to_target():
    # Get the target query parameter
    target = request.args.get('target', '')

    # Ensure the target is a string to prevent type-related issues
    if not isinstance(target, str):
        return redirect('/')

    # Validate the target against the regular expression
    if pattern.match(target):
        # Sanitize the target to prevent Open Redirects and other vulnerabilities
        # Here we only allow redirects to the same domain or subdomains
        # Adjust the domain as per your requirements
        allowed_domain = 'example.com'
        if allowed_domain in target:
            # Redirect to the target if it's valid and safe
            return redirect(target)
        else:
            # Redirect to the root of the site if the domain is not allowed
            return redirect('/')
    else:
        # Redirect to the root of the site if the target does not match the pattern
        return redirect('/')

if __name__ == '__main__':
    app.run()

