import subprocess
import shlex

# Define a stringent allowlist for characters that can be used in arguments
ALLOWED_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_. /')

def is_input_safe(input_string):
    """Check if the input string contains only allowed characters."""
    return all(char in ALLOWED_CHARS for char in input_string)

def execute_ls_command(directory):
    """Execute the 'ls' command securely on the specified directory."""
    # Validate and sanitize the input
    if not is_input_safe(directory):
        raise ValueError("Invalid characters in directory name.")

    # Use shlex.quote to escape and quote the input safely
    safe_directory = shlex.quote(directory)

    # Use subprocess to execute the command safely
    try:
        # The command is a list where each argument is a separate item
        command = ['ls', safe_directory]
        result = subprocess.run(command, check=True, text=True, capture_output=True)
        
        # Print the result of the command
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        # Handle errors in the subprocess
        print(f"An error occurred while executing 'ls': {e}", file=sys.stderr)
    except Exception as e:
        # Handle other exceptions
        print(f"An unexpected error occurred: {e}", file=sys.stderr)

# Example usage:
# Replace 'some_directory' with the directory you want to list
try:
    execute_ls_command('some_directory')
except ValueError as e:
    print(f"Error: {e}")

