def get_array_value_at_index(array, index):
    """
    Returns the value at the specified index in the array if the index is valid.
    If the index is out of bounds or invalid, returns -1.
    
    :param array: List of values.
    :param index: Integer representing the index in the array.
    :return: Value at the given index or -1 if the index is invalid.
    """
    # Ensure the index is an integer
    if not isinstance(index, int):
        return -1

    # Check for valid index range
    if 0 <= index < len(array):
        return array[index]
    else:
        return -1

# Example usage:
if __name__ == "__main__":
    # Define a sample array
    sample_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

    # Get input from the user in a secure manner
    try:
        user_input = int(input("Enter an integer index to retrieve the value from the array: "))
    except ValueError:
        print("Invalid input: Please enter a valid integer.")
    else:
        # Get the value at the user-specified index
        result = get_array_value_at_index(sample_array, user_input)
        print(f"The value at index {user_input} is: {result}" if result != -1 else "Invalid index: -1")

