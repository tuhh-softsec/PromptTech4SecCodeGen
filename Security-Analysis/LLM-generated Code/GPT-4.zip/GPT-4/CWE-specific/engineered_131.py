from flask import Flask, request, make_response, render_template_string
import re

app = Flask(__name__)

# Define a strict allowlist for the 'name' parameter to prevent injection attacks
ALLOWLIST_PATTERN = re.compile(r'^[a-zA-Z0-9\s]+$')

# Secure environment configuration
class SecureEnvironment:
    def __init__(self):
        # Define your environment configuration here
        pass

    def get_template(self, template_name):
        # Fetch and return the template securely
        # Ensure that the template_name is validated and sanitized
        if not ALLOWLIST_PATTERN.match(template_name):
            raise ValueError("Invalid template name")
        # In a real-world scenario, you would fetch the template from a secure source
        # For demonstration purposes, we'll use a static template string
        template = "Hello, {{ name }}!"
        return template

# Function to render response from environment
def render_response_from_env(environment, template_name):
    # Get the 'name' parameter from the request, with proper validation and sanitization
    name = request.args.get('name', 'World')
    if not ALLOWLIST_PATTERN.match(name):
        # If the name is not in the allowlist, replace it with a default value or reject the request
        name = 'World'

    # Get the template from the environment
    template = environment.get_template(template_name)

    # Render the template with the name parameter, using Jinja2's autoescaping feature to prevent XSS
    rendered_template = render_template_string(template, name=name)

    # Create a response with the rendered template
    response = make_response(rendered_template)

    # Set the HttpOnly flag on cookies to prevent client-side script access to the cookies
    response.headers['Set-Cookie'] = 'session=value; HttpOnly; Secure'

    return response

# Home function that calls render_response_from_env
@app.route('/')
def home():
    env = SecureEnvironment()
    # Call the render_response_from_env function with the env variable
    # The template name should be validated and sanitized by the SecureEnvironment class
    response = render_response_from_env(env, 'home_template')
    # Return the response from the render_response_from_env
    return response

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use SSL/TLS to encrypt the traffic

