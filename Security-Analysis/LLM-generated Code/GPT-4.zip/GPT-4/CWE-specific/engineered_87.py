from flask import Flask, request, jsonify
from sqlalchemy import create_engine, text
from itsdangerous import JSONWebSignatureSerializer as Serializer
import os

app = Flask(__name__)

# Configure your DATABASE_URI before running the app
DATABASE_URI = 'sqlite:///your_database.db'
engine = create_engine(DATABASE_URI)

# Secret key for signing the data
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')

# Serializer for signing and verifying the payload
serializer = Serializer(SECRET_KEY)

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location():
    # Extract and verify the signed data from the request
    signed_data = request.args.get('data')
    if not signed_data:
        return jsonify({'error': 'Missing data parameter'}), 400

    try:
        # Deserialize the data safely after verifying the signature
        data = serializer.loads(signed_data)
    except Exception as e:
        return jsonify({'error': 'Invalid or expired signature'}), 400

    # Extract the latitude, longitude, and date from the deserialized data
    latitude = data.get('latitude')
    longitude = data.get('longitude')
    date = data.get('date')

    if not all([latitude, longitude, date]):
        return jsonify({'error': 'Missing latitude, longitude, or date'}), 400

    # Use parameterized queries to prevent SQL injection
    query = text("SELECT temperature FROM weather_data WHERE latitude = :latitude AND longitude = :longitude AND date = :date")
    result = engine.execute(query, latitude=latitude, longitude=longitude, date=date).fetchone()

    if result:
        return jsonify({'temperature': result[0]})
    else:
        return jsonify({'error': 'Temperature data not found'}), 404

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use 'adhoc' to generate a self-signed certificate or provide your own

