import sys

def getValueFromArray(array, size, index):
    # Validate the index to ensure it's within the bounds of the array
    if 0 <= index < size:
        return array[index]
    else:
        # Return -1 if the index is out of bounds
        return -1

def main():
    # The predefined array of integers
    id_sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  # Example array
    size = len(id_sequence)  # Calculate the size of the array

    try:
        # Read an integer from the standard input
        input_str = input("Enter an index to retrieve the value from the array: ")
        index = int(input_str)  # Convert the input to an integer

        # Call getValueFromArray with the id_sequence array, its size, and the read integer
        value = getValueFromArray(id_sequence, size, index)

        # Return the value as the exit code
        sys.exit(value)

    except ValueError:
        # Handle the case where the input is not a valid integer
        print("Error: The input must be a valid integer.")
        sys.exit(-1)

    except Exception as e:
        # Handle any other unexpected exceptions
        print(f"An unexpected error occurred: {e}")
        sys.exit(-1)

if __name__ == "__main__":
    main()

