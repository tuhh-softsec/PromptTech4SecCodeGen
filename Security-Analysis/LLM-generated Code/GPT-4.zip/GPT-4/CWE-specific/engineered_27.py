def get_monthly_sales_input(month):
    while True:
        try:
            sales = int(input(f"Enter the sales for {month} (0 - 1,000,000): "))
            if 0 <= sales <= 1_000_000:
                return sales
            else:
                print("Error: Sales must be between 0 and 1,000,000.")
        except ValueError:
            print("Error: Please enter a valid integer.")

def main():
    total_sales = 0

    # Add sales for each month to the totalSales variable
    total_sales += get_monthly_sales_input("January")
    total_sales += get_monthly_sales_input("February")
    total_sales += get_monthly_sales_input("March")

    # Print the total sales to the screen
    print(f"Total sales for the quarter: {total_sales}")

if __name__ == "__main__":
    main()

