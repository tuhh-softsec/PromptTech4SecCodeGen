import os
import psycopg2
from psycopg2 import sql

# Function to get the database connection using environment variables
def get_db_connection():
    try:
        # Retrieve database credentials from environment variables
        db_host = os.environ.get('DB_HOST')
        db_name = os.environ.get('DB_NAME')
        db_user = os.environ.get('DB_USER')
        db_password = os.environ.get('DB_PASSWORD')
        
        # Validate that none of the credentials are None
        if not all([db_host, db_name, db_user, db_password]):
            raise ValueError("Database credentials are not fully set in environment variables.")
        
        # Establish a connection to the database
        conn = psycopg2.connect(
            host=db_host,
            dbname=db_name,
            user=db_user,
            password=db_password
        )
        return conn
    except Exception as e:
        # Handle any exception that occurs during the connection
        print(f"An error occurred while connecting to the database: {e}")
        return None

# Function to check if a user is a moderator
def is_user_moderator(username):
    # Validate the input to prevent SQL injection
    if not isinstance(username, str) or not username.isalnum():
        raise ValueError("Invalid username. Only alphanumeric characters are allowed.")
    
    # Connect to the database
    conn = get_db_connection()
    if conn is None:
        return False
    
    try:
        # Create a cursor object
        cur = conn.cursor()
        
        # Use parameterized queries to prevent SQL injection
        query = sql.SQL("SELECT is_moderator FROM users WHERE username = %s")
        
        # Execute the query with the username parameter
        cur.execute(query, (username,))
        
        # Fetch the result
        result = cur.fetchone()
        
        # Close the cursor and the connection
        cur.close()
        conn.close()
        
        # Check if the user is a moderator
        if result and result[0]:
            return True
        else:
            return False
    except Exception as e:
        # Handle any exception that occurs during the query execution
        print(f"An error occurred while executing the query: {e}")
        return False

# Example usage
if __name__ == "__main__":
    username = "example_user"  # Replace with the actual username to check
    if is_user_moderator(username):
        print(f"{username} is a moderator.")
    else:
        print(f"{username} is not a moderator.")

