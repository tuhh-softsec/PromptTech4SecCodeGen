import sys

def is_valid_unsigned_int(value, min_value=0, max_value=sys.maxsize):
    try:
        # Convert string to integer
        int_value = int(value)
        
        # Check if it's an unsigned integer within the allowed range
        if int_value >= min_value and int_value <= max_value:
            return True
        else:
            return False
    except ValueError:
        # The input was not an integer
        return False

def main():
    if len(sys.argv) != 2:
        print("Usage: python script.py <unsigned_integer>")
        sys.exit(1)
    
    input_value = sys.argv[1]
    
    # Define the range for the unsigned integer
    min_value = 0
    max_value = sys.maxsize - 1000  # Subtract 1000 to prevent overflow when adding 1000
    
    if is_valid_unsigned_int(input_value, min_value, max_value):
        result = int(input_value) + 1000
        print(f"The result is: {result}")
    else:
        print("The input must be an unsigned integer within the range "
              f"{min_value} to {max_value}.")
        sys.exit(1)

if __name__ == "__main__":
    main()

