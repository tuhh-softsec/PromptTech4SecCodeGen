import re
from getpass import getpass
from hashlib import scrypt
from os import urandom
from base64 import b64encode, b64decode

def validate_username(username):
    # Username must be between 4 and 25 characters and can only contain alphanumeric characters
    if not re.match(r"^[a-zA-Z0-9]{4,25}$", username):
        raise ValueError("Username must be 4-25 characters long and contain only letters and numbers.")

def validate_password(password):
    # Password must be at least 8 characters long and contain a mix of upper, lower, digits, and special chars
    if len(password) < 8 or not re.search(r"[A-Z]", password) or not re.search(r"[a-z]", password) or not re.search(r"[0-9]", password) or not re.search(r"[!@#$%^&*(),.?\":{}|<>]", password):
        raise ValueError("Password must be at least 8 characters long and include uppercase, lowercase, digits, and special characters.")

def hash_password(password, salt=None):
    if salt is None:
        salt = urandom(16)  # Generate a new salt
    hashed_password = scrypt(password.encode(), salt=salt, n=16384, r=8, p=1)
    salt_b64 = b64encode(salt).decode('utf-8')
    hashed_password_b64 = b64encode(hashed_password).decode('utf-8')
    return f"{salt_b64}${hashed_password_b64}"

def register():
    try:
        username = input("Enter your username: ")
        validate_username(username)
        
        # Use getpass to hide the password input
        password = getpass("Enter your password: ")
        validate_password(password)
        
        # Hash the password with a new salt
        hashed_password = hash_password(password)
        
        # Store the username and hashed password in a secure manner (e.g., save to a database with proper security controls)
        # For demonstration purposes, we'll just print it out
        print(f"Username: {username}")
        print(f"Hashed Password: {hashed_password}")
        
        print("Registration successful!")
        
    except ValueError as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    register()

