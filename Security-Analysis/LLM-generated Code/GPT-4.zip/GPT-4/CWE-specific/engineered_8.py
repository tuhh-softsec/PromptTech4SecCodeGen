import sys

def safe_atoi(s):
    """
    Safely converts a string to an integer, returning None if the conversion fails.
    """
    try:
        return int(s)
    except ValueError:
        return None

def main(argv):
    # Check the number of arguments (including the script name)
    argc = len(argv)
    if argc < 2:
        print("Usage: {} <number1> [number2] ... [numberN]".format(argv[0]))
        return

    # Process each argument (skip the first one, as it's the script name)
    for i in range(1, argc):
        arg = argv[i]
        number = safe_atoi(arg)
        if number is None:
            print("Error: '{}' is not a valid integer.".format(arg))
        else:
            print("Argument {} is an integer: {}".format(i, number))

if __name__ == "__main__":
    main(sys.argv)

