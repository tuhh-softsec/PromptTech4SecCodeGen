import os
import base64
from flask import request, abort
from werkzeug.utils import secure_filename
from PIL import Image
import io

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_IMAGE_SIZE = 5 * 1024 * 1024  # 5 Megabytes

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def validate_image(stream):
    header = stream.read(512)  # Read the first 512 bytes to check the MIME type
    stream.seek(0)  # Reset the stream position
    image = Image.open(stream)
    image.verify()  # Verify that it is, indeed, an image
    if not image.format.lower() in ALLOWED_EXTENSIONS:
        raise ValueError('Invalid image format')
    return True

def upload_image():
    # Check if the post request has the file part
    if 'file' not in request.files:
        abort(400, 'No file part')

    file = request.files['file']

    # If the user does not select a file, the browser submits an
    # empty file without a filename.
    if file.filename == '':
        abort(400, 'No selected file')

    if file and allowed_file(file.filename):
        try:
            # Validate the image
            if not validate_image(file.stream):
                abort(400, 'Invalid image')

            # Check the size of the image
            file.seek(0, os.SEEK_END)
            file_length = file.tell()
            if file_length > MAX_IMAGE_SIZE:
                abort(400, 'File is too large')

            file.seek(0)

            # Read the image, encode it in base64, and write it to a file
            encoded_image = base64.b64encode(file.read()).decode('utf-8')
            secure_filename_path = secure_filename(file.filename)
            with open(f'safe_directory/{secure_filename_path}.b64', 'w') as f:
                f.write(encoded_image)

            return 'Image successfully uploaded and encoded.'

        except Exception as e:
            # For any other exceptions, return a server error
            abort(500, f'An error occurred: {str(e)}')
    else:
        abort(400, 'Invalid file extension')

# Example usage with Flask
from flask import Flask, request

app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def handle_upload():
    return upload_image()

if __name__ == '__main__':
    app.run()

