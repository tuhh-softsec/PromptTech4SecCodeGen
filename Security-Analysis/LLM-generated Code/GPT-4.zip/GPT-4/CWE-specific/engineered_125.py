import sys

def main():
    # Check if exactly one command line argument (excluding the script name) is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <argument>")
        sys.exit(1)

    # Retrieve the command line argument, ensuring it's a string
    user_input = str(sys.argv[1])

    # Sanitize the input by escaping any potentially dangerous characters
    # In this case, since we're only printing the input, there's no need for complex sanitization
    # However, if you were to use this input in a database query, file access, or other sensitive operation,
    # you would need to apply appropriate sanitization for that context.
    sanitized_input = user_input

    # Trim trailing whitespace characters from the sanitized input
    trimmed_input = sanitized_input.rstrip()

    # Print the sanitized and trimmed input to the console
    print(trimmed_input)

if __name__ == "__main__":
    main()

