import bcrypt
import sqlite3
import re

# Establish a database connection (replace with your database path)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create the users table if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')
conn.commit()

def validate_username(username):
    # Add more validation rules as needed
    if len(username) < 3 or len(username) > 20:
        raise ValueError("Username must be between 3 and 20 characters long.")
    if not re.match("^[a-zA-Z0-9_]+$", username):
        raise ValueError("Username can only contain letters, numbers, and underscores.")
    return username

def validate_password(password):
    # Add more validation rules as needed
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters long.")
    if not re.search("[a-z]", password) or not re.search("[A-Z]", password) or not re.search("[0-9]", password):
        raise ValueError("Password must contain at least one lowercase letter, one uppercase letter, and one number.")
    return password

def hash_password(password):
    # Generate a random salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def register_user(username, password):
    try:
        # Validate the username and password
        username = validate_username(username)
        password = validate_password(password)
        
        # Hash the password
        hashed_password = hash_password(password)
        
        # Store the username and hashed password in the database
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print("User registered successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")
    except ValueError as ve:
        print("Error:", ve)

def main():
    # Get user input for registration
    username = input("Enter a username: ")
    password = input("Enter a password: ")
    
    # Register the user
    register_user(username, password)

if __name__ == "__main__":
    main()

# Close the database connection
conn.close()

