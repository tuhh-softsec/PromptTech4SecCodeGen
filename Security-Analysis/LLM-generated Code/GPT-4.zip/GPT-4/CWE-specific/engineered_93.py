import sqlite3
import bcrypt

# Establish a database connection
# Note: In a production environment, use a more secure database system and connection method
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user credentials if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
)
''')
conn.commit()

def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

def insert_user(username, password):
    # Hash the user's password
    password_hash = hash_password(password)

    try:
        # Insert the new user into the database using parameterized queries
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")
    except sqlite3.Error as e:
        print("An error occurred:", e)

def validate_input(username, password):
    # Implement input validation
    if not username or not password:
        return False
    if len(username) < 3 or len(password) < 8:
        return False
    if ' ' in username or ' ' in password:
        return False
    # Add any other validation rules as necessary
    return True

# Main program
def main():
    username = input("Enter a username: ")
    password = input("Enter a password: ")

    if validate_input(username, password):
        insert_user(username, password)
    else:
        print("Invalid input. Make sure the username is at least 3 characters long and the password is at least 8 characters long without spaces.")

if __name__ == "__main__":
    main()

# Close the database connection
conn.close()

