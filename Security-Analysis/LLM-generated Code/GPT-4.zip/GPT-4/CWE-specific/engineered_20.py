import sys

# Define the offset as a constant
OFFSET = 1000

# Define the minimum and maximum values for the unsigned integer
MIN_VALUE = 0
MAX_VALUE = 4294967295  # This is the maximum value for a 32-bit unsigned integer

def main():
    # Check if an argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <unsigned_integer>")
        sys.exit(1)

    try:
        # Read the value from the command line and convert it to an integer
        input_value = int(sys.argv[1])

        # Check if the input is an unsigned integer within the allowed range
        if input_value < MIN_VALUE or input_value > MAX_VALUE:
            raise ValueError("The input must be an unsigned integer within the range {} to {}.".format(MIN_VALUE, MAX_VALUE))

        # Add the offset to the input value
        result = input_value + OFFSET

        # Check if the result is within the allowed range for unsigned integers
        if result > MAX_VALUE:
            raise OverflowError("The result exceeds the maximum allowed value for an unsigned integer.")

        # Output the result
        print("The result is:", result)

    except ValueError as ve:
        print("Error:", ve)
        sys.exit(1)
    except OverflowError as oe:
        print("Error:", oe)
        sys.exit(1)

if __name__ == "__main__":
    main()

