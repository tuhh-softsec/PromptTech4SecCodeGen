import sys

def main():
    # Check if exactly one command line argument (excluding the script name) is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <unsigned_integer>")
        return 1  # Return a non-zero value to indicate error

    try:
        # Convert the input to an unsigned integer (Python doesn't have an explicit unsigned int type)
        input_value = int(sys.argv[1])

        # Check if the input is a non-negative integer
        if input_value < 0:
            raise ValueError("The input must be a non-negative integer.")

        # Check for potential overflow after addition
        result = input_value + 1000
        if result < input_value:
            raise OverflowError("Integer overflow occurred.")

        # Print the result
        print(f"The result is: {result}")

    except ValueError as ve:
        print(f"Error: {ve}")
        return 1  # Return a non-zero value to indicate error

    except OverflowError as oe:
        print(f"Error: {oe}")
        return 1  # Return a non-zero value to indicate error

    # Return 0 to indicate success
    return 0

if __name__ == "__main__":
    sys.exit(main())

