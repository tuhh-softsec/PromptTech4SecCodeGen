from flask import Flask, request, redirect, render_template_string, escape
from sqlalchemy import create_engine, Column, Integer, String, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import func

app = Flask(__name__)

# Configure your database URI here
DATABASE_URI = 'sqlite:///messages.db'
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
session = Session()

Base = declarative_base()

# Define a Message model
class Message(Base):
    __tablename__ = 'messages'
    id = Column(Integer, primary_key=True)
    username = Column(String(50))
    message = Column(Text)

# Create the table
Base.metadata.create_all(engine)

# Function to insert user message into the database
def insert_user_message_in_db(username, message):
    new_message = Message(username=username, message=message)
    session.add(new_message)
    session.commit()

@app.route('/post', methods=['POST'])
def post_message():
    # Get the username and message from the request with proper validation
    username = request.form.get('username', '').strip()
    message = request.form.get('message', '').strip()

    # Validate and sanitize inputs
    if not username or not message:
        return "Invalid input", 400

    # Allowlist for username (alphanumeric characters, underscores, and hyphens)
    if not all(c.isalnum() or c in {'_', '-'} for c in username):
        return "Invalid username", 400

    # Insert the sanitized message into the database
    insert_user_message_in_db(username, message)

    # Redirect to the home page
    return redirect('/')

@app.route('/')
def index():
    # Fetch all messages from the database
    messages = session.query(Message).all()

    # Render the messages safely
    messages_html = ''.join(
        f"<p><strong>{escape(msg.username)}:</strong> {escape(msg.message)}</p>"
        for msg in messages
    )

    # Use render_template_string to render the HTML with messages
    return render_template_string('''
        <h1>Messages</h1>
        <div>
            {{ messages_html|safe }}
        </div>
        <form action="/post" method="post">
            <input type="text" name="username" placeholder="Your username" required>
            <textarea name="message" placeholder="Your message" required></textarea>
            <button type="submit">Post</button>
        </form>
    ''', messages_html=messages_html)

if __name__ == '__main__':
    app.run(debug=True)

