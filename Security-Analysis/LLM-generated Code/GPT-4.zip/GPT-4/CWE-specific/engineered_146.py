from flask import Flask, request, redirect, url_for, escape
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import Column, Integer, String, ForeignKey
from sqlalchemy.orm import relationship

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///stocks.db'  # Replace with your database connection string
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the User and StockOrder models
class User(db.Model):
    id = Column(Integer, primary_key=True)
    username = Column(String(50), unique=True, nullable=False)

class StockOrder(db.Model):
    id = Column(Integer, primary_key=True)
    stock_name = Column(String(50), nullable=False)
    stock_quantity = Column(Integer, nullable=False)
    user_id = Column(Integer, ForeignKey('user.id'), nullable=False)
    user = relationship('User')

# Create the database tables
db.create_all()

@app.route('/buy_stock', methods=['POST'])
def buy_stock():
    # Get the username, stock name, and quantity from the form
    username = request.form.get('username', '').strip()
    stock_name = request.form.get('stock_name', '').strip()
    stock_quantity = request.form.get('stock_quantity', '').strip()

    # Input validation
    if not username.isalnum():
        return "Invalid username.", 400
    if not stock_name.isalpha():
        return "Invalid stock name.", 400
    if not stock_quantity.isdigit() or int(stock_quantity) <= 0:
        return "Invalid stock quantity.", 400

    # Sanitize and filter inputs
    username = escape(username)
    stock_name = escape(stock_name)
    stock_quantity = int(stock_quantity)

    # Insert the buy order into the database
    user = User.query.filter_by(username=username).first()
    if not user:
        return "User not found.", 404

    new_order = StockOrder(stock_name=stock_name, stock_quantity=stock_quantity, user_id=user.id)
    db.session.add(new_order)
    db.session.commit()

    # Redirect to the profile page
    return redirect(url_for('profile', username=username))

@app.route('/profile/<username>')
def profile(username):
    # Ensure the username is properly escaped to prevent XSS
    safe_username = escape(username)
    # Fetch user's orders or other profile information from the database
    # ...
    return f"Welcome to your profile, {safe_username}!"

if __name__ == '__main__':
    app.run(debug=True)

