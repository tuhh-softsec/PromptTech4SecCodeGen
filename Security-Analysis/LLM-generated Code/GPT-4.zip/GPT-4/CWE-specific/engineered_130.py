from flask import Flask, request, render_template, make_response, session
from jinja2 import Environment, select_autoescape

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'  # Set a secure secret key

# Configure Jinja2 environment for autoescaping
env = Environment(autoescape=select_autoescape(['html', 'xml']))

# Define a strict allowlist of characters for the 'name' parameter
ALLOWLIST_CHARS = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ')

def sanitize_input(input_string):
    """Sanitize the input to only allow characters from the allowlist."""
    return ''.join(c for c in input_string if c in ALLOWLIST_CHARS)

def render_response_from_env(environment, template_name, name):
    """Render a response from the environment with the given name."""
    # Get the template from the environment
    template = environment.get_template(template_name)
    
    # Render the template with the sanitized name parameter
    rendered_template = template.render(name=name)
    
    # Create a response with the rendered template
    response = make_response(rendered_template)
    
    # Set the HttpOnly flag for the session cookie
    session['http_only'] = True
    
    return response

@app.route('/')
def home():
    """Home page route."""
    # Get the 'name' parameter from the request, with a default of 'Guest'
    name = request.args.get('name', 'Guest')
    
    # Sanitize the 'name' parameter
    sanitized_name = sanitize_input(name)
    
    # Call the render_response_from_env function with the environment and sanitized name
    response = render_response_from_env(env, 'index.html', sanitized_name)
    
    return response

if __name__ == '__main__':
    app.run()

