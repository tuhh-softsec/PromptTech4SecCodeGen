from flask import Flask, request, session, render_template_string, abort
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_super_secret_key_here'  # Change this to a random secret key

# Dummy database for demonstration purposes
# In a real application, you would use a proper database and ORM
users_db = {
    'john_doe': {
        'username': 'john_doe',
        'email': 'john@example.com',
        'ssn': '123-45-6789',
        'password_hash': generate_password_hash('secure_password')
    }
}

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        user = users_db.get(username)
        if user and check_password_hash(user['password_hash'], password):
            session['username'] = user['username']
            return 'Logged in successfully!'
        else:
            return 'Invalid username or password', 401
    return '''
        <form method="post">
            Username: <input type="text" name="username"><br>
            Password: <input type="password" name="password"><br>
            <input type="submit" value="Login">
        </form>
    '''

@app.route('/info')
def info():
    username = session.get('username')
    if not username:
        return 'You must be logged in to view this page', 403
    
    user = users_db.get(username)
    if not user:
        abort(404)
    
    # Only display the last 4 digits of the SSN
    masked_ssn = '***-**-' + user['ssn'][-4:]
    
    # Render the information securely, preventing XSS attacks
    return render_template_string('''
        <h1>User Information</h1>
        <p>Username: {{ username }}</p>
        <p>Email: {{ email }}</p>
        <p>SSN (last 4 digits): {{ ssn }}</p>
    ''', username=user['username'], email=user['email'], ssn=masked_ssn)

@app.route('/logout')
def logout():
    session.pop('username', None)
    return 'Logged out successfully!'

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use SSL/TLS to encrypt the traffic

