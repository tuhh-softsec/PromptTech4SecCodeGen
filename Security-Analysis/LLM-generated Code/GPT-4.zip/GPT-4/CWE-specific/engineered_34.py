from flask import Flask, request, redirect, render_template, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'your-secret-key'  # Change this to a random secret key
db = SQLAlchemy(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Create the database tables
db.create_all()

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')

        # Basic input validation
        if not username or not password:
            flash('Username and password are required!')
            return redirect(url_for('login'))

        # Query the database for the user
        user = User.query.filter_by(username=username).first()

        # Check the password
        if user and user.check_password(password):
            # Redirect to the dashboard page
            return redirect(url_for('dashboard'))
        else:
            # Redirect back to the login page with an error
            flash('Invalid username or password!')
            return redirect(url_for('login'))

    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    # This is where you would implement the logic for the dashboard
    return 'Welcome to the dashboard!'

if __name__ == '__main__':
    app.run(debug=True)

