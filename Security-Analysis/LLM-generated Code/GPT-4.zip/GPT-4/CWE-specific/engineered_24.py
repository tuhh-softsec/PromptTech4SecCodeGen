import random
import sys

# Function to generate a random integer within a given range
def generate_random_integer(min_value, max_value):
    if min_value >= max_value:
        raise ValueError("Minimum value must be less than the maximum value.")
    if min_value < 0 or max_value < 0:
        raise ValueError("Values must be positive to ensure unsigned integers.")
    return random.randint(min_value, max_value)

# Function to calculate the difference between two integers
def calculate_difference(num1, num2):
    return abs(num1 - num2)

try:
    # Generate two random integers between 10 and 1000
    random_integer1 = generate_random_integer(10, 1000)
    random_integer2 = generate_random_integer(10, 1000)

    # Calculate the difference between the two integers
    difference = calculate_difference(random_integer1, random_integer2)

    # Print the results
    print(f"First random integer: {random_integer1}")
    print(f"Second random integer: {random_integer2}")
    print(f"Difference: {difference}")

except ValueError as e:
    print(f"Error: {e}", file=sys.stderr)

