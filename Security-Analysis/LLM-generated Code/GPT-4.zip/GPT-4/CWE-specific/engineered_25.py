import random

def getMonthlySales():
    # Generate a random number between 0 and 100,000
    return random.randint(0, 100000)

def validate_sales(sales):
    # Ensure that the sales number is an integer and within the range 0 to 100,000
    if isinstance(sales, int) and 0 <= sales <= 100000:
        return True
    else:
        raise ValueError("Sales value must be an integer between 0 and 100,000.")

def main():
    quarterly_sales = [0, 0, 0, 0]  # Initialize quarterly sales

    for month in range(1, 13):
        # Get monthly sales
        monthly_sales = getMonthlySales()
        
        # Validate the monthly sales
        if validate_sales(monthly_sales):
            # Determine the quarter for the current month
            quarter = (month - 1) // 3
            # Add the monthly sales to the appropriate quarter
            quarterly_sales[quarter] += monthly_sales

    # Print the quarterly sales results
    for i, sales in enumerate(quarterly_sales, 1):
        print(f"Sales for Quarter {i}: {sales}")

if __name__ == "__main__":
    main()

