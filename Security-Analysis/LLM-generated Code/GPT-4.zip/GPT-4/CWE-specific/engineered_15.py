def get_id_sequence_value(id_sequence):
    # Ensure id_sequence is a list or tuple
    if not isinstance(id_sequence, (list, tuple)):
        raise ValueError("id_sequence must be a list or tuple")

    try:
        # Prompt the user for an index value
        index_input = input("Please enter an index value: ")

        # Validate the input to ensure it is an integer
        index = int(index_input)

        # Check if the index value is within bounds of the id_sequence
        if 0 <= index < len(id_sequence):
            # Return the value at the index in id_sequence
            return id_sequence[index]
        else:
            # Index out of bounds, return 0
            return 0
    except ValueError:
        # Handle the case where the input is not an integer
        print("Invalid input: index value must be an integer.")
        return 0
    except Exception as e:
        # Handle any other unexpected exceptions
        print(f"An unexpected error occurred: {e}")
        return 0

# Example usage:
# Define a sequence of IDs
id_sequence = [101, 202, 303, 404, 505]

# Call the function and print the result
value = get_id_sequence_value(id_sequence)
print(f"The value at the given index is: {value}")

