def get_vehicle_by_index(vehicles, index):
    try:
        # Convert index to an integer
        index = int(index)
    except ValueError:
        # Handle non-integer input
        print("Invalid input: Index must be an integer.")
        return None

    # Check if the index is within the bounds of the vehicles array
    if 0 <= index < len(vehicles):
        return vehicles[index]
    else:
        print("Invalid index: Index is out of range.")
        return None

def main():
    # Array of vehicles
    vehicles = ["Car", "Truck", "Bike", "Bus", "Motorcycle", "Scooter"]

    # Prompt the user for the index of a vehicle
    index = input("Enter the index of the vehicle you want to retrieve: ")

    # Retrieve and print the vehicle at the given index
    vehicle = get_vehicle_by_index(vehicles, index)
    if vehicle is not None:
        print(f"The vehicle at index {index} is a {vehicle}.")

    # Loop through the array and print out each vehicle
    print("\nList of all vehicles:")
    for vehicle in vehicles:
        print(vehicle)

if __name__ == "__main__":
    main()

