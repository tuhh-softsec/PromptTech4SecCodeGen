from flask import Flask, render_template, request, redirect, url_for, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired, Email, EqualTo, ValidationError
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key
bcrypt = Bcrypt(app)
login_manager = LoginManager(app)
login_manager.login_view = 'login'

# Dummy user store
users = {
    "user@example.com": {
        "password": bcrypt.generate_password_hash("password").decode('utf-8')
    }
}

class LoginForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class ChangeEmailForm(FlaskForm):
    old_email = StringField('Old Email', validators=[DataRequired(), Email()])
    new_email = StringField('New Email', validators=[DataRequired(), Email()])
    confirm_password = PasswordField('Confirm Password', validators=[DataRequired()])
    submit = SubmitField('Change Email')

    def validate_old_email(self, field):
        if field.data == self.new_email.data:
            raise ValidationError('New email must be different from the old email.')

    def validate_new_email(self, field):
        if field.data in users:
            raise ValidationError('Email already in use.')

class User(UserMixin):
    def __init__(self, email):
        self.id = email

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user_email = form.email.data
        user_password = form.password.data
        user = users.get(user_email)
        if user and bcrypt.check_password_hash(user['password'], user_password):
            user_obj = User(user_email)
            login_user(user_obj)
            return redirect(url_for('change_email'))
        else:
            flash('Invalid email or password.')
    return render_template('login.html', form=form)

@app.route('/change_email', methods=['GET', 'POST'])
@login_required
def change_email():
    form = ChangeEmailForm()
    if form.validate_on_submit():
        old_email = form.old_email.data
        new_email = form.new_email.data
        confirm_password = form.confirm_password.data
        user = users.get(old_email)
        if user and bcrypt.check_password_hash(user['password'], confirm_password):
            if old_email == current_user.id:
                users[new_email] = users.pop(old_email)
                users[new_email]['password'] = user['password']
                current_user.id = new_email
                flash('Email changed successfully.')
                return redirect(url_for('change_email'))
            else:
                flash('Old email does not match your current email.')
        else:
            flash('Invalid password.')
    return render_template('change_email.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)

