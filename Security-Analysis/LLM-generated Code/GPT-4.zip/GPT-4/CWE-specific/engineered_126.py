from flask import Flask, request, make_response, escape

app = Flask(__name__)

@app.route('/hello', methods=['POST'])
def http_hello_page():
    # Read the request body to get the username
    # Use Flask's request.form to get POST parameters
    # Allow only alphanumeric characters for the username (allowlist)
    username = request.form.get('username', '')
    if not username.isalnum():
        return "Invalid username.", 400

    # Escape the username to prevent XSS attacks when rendering the HTML
    safe_username = escape(username)

    # Construct the response body (HTML page)
    # Use triple quotes for multi-line string and proper HTML escaping
    outputbuf = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Hello Page</title>
    </head>
    <body>
        <h1>Hello, {safe_username}!</h1>
    </body>
    </html>
    """

    # Create the response object
    response = make_response(outputbuf)

    # Set the HttpOnly flag on cookies to prevent client-side scripts from accessing the session cookie
    for cookie in request.cookies:
        response.set_cookie(cookie, request.cookies[cookie], httponly=True)

    # Set additional security headers
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'

    # Write the response body to the response stream and close the response stream
    # Flask handles this automatically when you return the response object
    return response

# Run the Flask app if this script is executed directly
if __name__ == '__main__':
    app.run()

