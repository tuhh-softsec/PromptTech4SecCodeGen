def secure_memcpy(dest, src, num_bytes):
    """
    Securely copies num_bytes from src to dest.
    
    :param dest: Destination bytearray where bytes will be copied to.
    :param src: Source bytearray from which bytes will be copied.
    :param num_bytes: Number of bytes to copy.
    :return: None
    """
    # Check if the number of bytes to copy is an integer and non-negative
    if not isinstance(num_bytes, int) or num_bytes < 0:
        raise ValueError("Number of bytes to copy must be a non-negative integer.")
    
    # Check if the source and destination are bytearrays
    if not (isinstance(dest, bytearray) and isinstance(src, bytearray)):
        raise TypeError("Source and destination must be bytearrays.")
    
    # Check if the source has enough bytes to copy
    if len(src) < num_bytes:
        raise ValueError("Source does not have enough bytes to copy.")
    
    # Check if the destination has enough space to accommodate the new bytes
    if len(dest) < num_bytes:
        raise ValueError("Destination does not have enough space for the new bytes.")
    
    # Perform the copy operation
    dest[:num_bytes] = src[:num_bytes]

def secure_strlen(s):
    """
    Returns the length of a string, not including the null terminator.
    
    :param s: The string to measure.
    :return: The length of the string.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")
    
    return len(s)

# Example usage:
try:
    dest_buffer = bytearray(100)  # Destination buffer with 100 bytes
    src_buffer = bytearray(b"Hello, World!")  # Source buffer with a string
    num_bytes_to_copy = secure_strlen("Hello, World!") + 1  # +1 to include the null terminator
    
    secure_memcpy(dest_buffer, src_buffer, num_bytes_to_copy)
    print("Copy successful!")
except Exception as e:
    print(f"Error: {e}")

