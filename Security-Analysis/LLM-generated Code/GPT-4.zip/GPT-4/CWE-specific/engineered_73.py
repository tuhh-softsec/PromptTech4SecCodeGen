from distutils.core import setup, Extension

module = Extension('person_module', sources=['person_module.c'])

setup(name='PersonModule',
      version='1.0',
      description='Python interface for the person struct',
      ext_modules=[module])

