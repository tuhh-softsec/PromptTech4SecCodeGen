from flask import Flask, request, redirect, url_for
import re

app = Flask(__name__)

# Regular expression to match URLs containing 'example.com'
# This regex assumes that 'example.com' should be a domain or subdomain part of the URL
# Adjust the regex as needed for more specific cases
URL_REGEX = re.compile(r'https?://(?:www\.)?example\.com(/.*)?', re.IGNORECASE)

@app.route('/redirect')
def redirect_to_target():
    # Retrieve the target parameter from the query string
    target = request.args.get('target', '')

    # Validate the target URL
    if URL_REGEX.match(target):
        # The target is a valid URL containing 'example.com', proceed with the redirect
        # Use Flask's redirect function which ensures proper encoding of the URL
        return redirect(target)
    else:
        # The target does not match the regular expression, redirect to the root
        # Use url_for to avoid open redirects by ensuring that the redirect stays within the same application
        return redirect(url_for('index'))

@app.route('/')
def index():
    # The root route of the web application
    return 'Welcome to the web application!'

if __name__ == '__main__':
    # Run the app in a secure manner
    # Consider using a production-ready server like Gunicorn and running over HTTPS
    app.run(ssl_context='adhoc')  # 'adhoc' generates a self-signed certificate, not for production

