from flask import Flask, request, jsonify
from itsdangerous import URLSafeSerializer
import yaml
from yaml.loader import SafeLoader

app = Flask(__name__)

# Secret key for signing payloads
SECRET_KEY = 'your-secret-key'
# Serializer for signing and unsigning data
serializer = URLSafeSerializer(SECRET_KEY)

# Prices for different product codes
PRODUCT_PRICES = {
    'product1': 10.0,
    'product2': 20.0,
    'product3': 30.0,
}

@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    # Get the signed YAML payload from the query parameter
    signed_payload = request.args.get('payload', '')

    try:
        # Unsign the payload to verify its authenticity
        payload = serializer.loads(signed_payload)
        
        # Load the YAML content safely
        data = yaml.load(payload, Loader=SafeLoader)
        
        # Extract product_code and quantity
        product_code = data.get('product_code')
        quantity = data.get('quantity')
        
        # Validate product_code and quantity
        if product_code not in PRODUCT_PRICES or not isinstance(quantity, int):
            return jsonify({'error': 'Invalid product code or quantity'}), 400
        
        # Calculate the total price
        total_price = PRODUCT_PRICES[product_code] * quantity
        
        # Return the total price as a string
        return jsonify({'total_price': str(total_price)})
    
    except Exception as e:
        # Handle exceptions such as signature errors or YAML parsing errors
        return jsonify({'error': 'Invalid or tampered payload'}), 400

if __name__ == '__main__':
    app.run(debug=True)

from itsdangerous import URLSafeSerializer

# Secret key must match the one used by the server
SECRET_KEY = 'your-secret-key'
serializer = URLSafeSerializer(SECRET_KEY)

# Example payload
payload = """
product_code: product1
quantity: 3
"""

# Sign the payload
signed_payload = serializer.dumps(payload)

# The signed_payload can now be sent as a query parameter to the server
print(signed_payload)

