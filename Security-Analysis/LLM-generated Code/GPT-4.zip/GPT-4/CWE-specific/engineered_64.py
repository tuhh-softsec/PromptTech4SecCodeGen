import os
import mysql.connector
from flask import Flask, request, abort, send_from_directory
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'pdf'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Configure your MySQL connection details
db_config = {
    'user': 'your_username',
    'password': 'your_password',
    'host': 'localhost',
    'database': 'your_database',
    'raise_on_warnings': True
}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def save_file_to_database(filepath):
    try:
        conn = mysql.connector.connect(**db_config)
        cursor = conn.cursor()
        cursor.execute("INSERT INTO files (filepath) VALUES (%s)", (filepath,))
        conn.commit()
    except mysql.connector.Error as err:
        print(f"Error: {err}")
        abort(500)  # Internal Server Error
    finally:
        cursor.close()
        conn.close()

@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        abort(400)  # Bad Request

    file = request.files['file']
    if file.filename == '':
        abort(400)  # Bad Request

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        save_file_to_database(filepath)
        return "File uploaded and saved to database successfully.", 200
    else:
        abort(400)  # Bad Request

@app.route('/download_pdf/<filename>')
def download_pdf(filename):
    if not allowed_file(filename):
        abort(404)  # Not Found

    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

if __name__ == '__main__':
    if not os.path.exists(app.config['UPLOAD_FOLDER']):
        os.makedirs(app.config['UPLOAD_FOLDER'])
    app.run(debug=True)

