import ctypes

# Define the Person structure
class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int),
                ("name", ctypes.c_char_p)]

# Simulate memory allocation with error checking
def allocate_memory(size):
    # Allocate memory and check if the allocation was successful
    block = ctypes.create_string_buffer(size)
    if not block:
        raise MemoryError("Failed to allocate memory.")
    return block

# Initialize a new Person with default values
def create_person():
    # Allocate memory for a new Person
    person_memory = allocate_memory(ctypes.sizeof(Person))
    person = ctypes.cast(person_memory, ctypes.POINTER(Person))

    # Check if the memory allocation was successful
    if not person:
        raise MemoryError("Failed to allocate memory for Person.")

    # Initialize the Person structure
    person.contents.status = 0
    person.contents.name = b"John"

    return person

# Main function to demonstrate usage
def main():
    try:
        new_person = create_person()
        print(f"Person status: {new_person.contents.status}")
        print(f"Person name: {new_person.contents.name.decode()}")
    except MemoryError as e:
        print(str(e))

if __name__ == "__main__":
    main()

