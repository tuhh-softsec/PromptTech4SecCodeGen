import os
import tarfile

# Define a list of allowed filenames for strict allowlisting
ALLOWED_FILENAMES = ['allowed_file_1.txt', 'allowed_file_2.txt', 'allowed_document.pdf']

def is_filename_allowed(filename):
    # Canonicalize the path to prevent directory traversal attacks
    canonicalized_path = os.path.realpath(filename)
    # Check if the canonicalized filename is in the allowlist
    return os.path.basename(canonicalized_path) in ALLOWED_FILENAMES

def extract_tarfile_safe(tar_path, extract_path):
    # Validate the tar_path
    if not is_filename_allowed(tar_path):
        raise ValueError("The tar file path is not allowed")

    # Ensure the extract_path is a canonical absolute path to prevent directory traversal
    extract_path = os.path.realpath(extract_path)

    # Open the tar file safely using the with statement
    with tarfile.open(tar_path, 'r:*') as tar:
        # Iterate over the members of the tar file
        for member in tar.getmembers():
            # Validate each member's name
            if not is_filename_allowed(member.name):
                print(f"Skipping extraction of {member.name} as it's not in the allowlist.")
                continue

            # Extract the member safely
            tar.extract(member, path=extract_path)
            print(f"Extracted {member.name} to {extract_path}")

def create_tarfile_safe(files_to_archive, tar_path):
    # Validate the tar_path
    if not is_filename_allowed(tar_path):
        raise ValueError("The tar file path is not allowed")

    # Open the tar file safely using the with statement
    with tarfile.open(tar_path, 'w:gz') as tar:
        for file in files_to_archive:
            # Validate each file's name
            if not is_filename_allowed(file):
                print(f"Skipping adding {file} to the archive as it's not in the allowlist.")
                continue

            # Add the file to the tar archive
            tar.add(file)
            print(f"Added {file} to the archive {tar_path}")

# Example usage
try:
    # Extract files from a tar archive
    extract_tarfile_safe('example.tar.gz', '/path/to/extract')

    # Create a new tar archive with gzip compression
    create_tarfile_safe(['allowed_file_1.txt', 'allowed_file_2.txt'], 'archive.tar.gz')
except ValueError as e:
    print(e)

