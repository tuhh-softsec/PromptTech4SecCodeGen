def get_value_at_index(array, index):
    """
    Returns the value at the specified index in the array if the index is within bounds.
    Otherwise, returns -1.
    
    :param array: List of values.
    :param index: Integer index to access the value in the array.
    :return: Value at the specified index or -1 if the index is out of bounds.
    """
    try:
        # Ensure the index is an integer
        index = int(index)
    except ValueError:
        # If the index is not an integer, return -1
        return -1

    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        return array[index]
    else:
        # If the index is out of bounds, return -1
        return -1

# Example usage:
if __name__ == "__main__":
    # Define a sample array
    sample_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

    # Get input from the user in a secure manner
    try:
        user_input = input("Enter an integer index to retrieve the value from the array: ")
        result = get_value_at_index(sample_array, user_input)
        print(f"The value at index {user_input} is: {result}")
    except Exception as e:
        # Catch any unexpected exceptions and handle them
        print(f"An error occurred: {e}")

