from flask import Flask, request, jsonify
from itsdangerous import TimestampSigner, BadSignature
from sqlalchemy import create_engine, MetaData, Table, select, and_
from sqlalchemy.orm import sessionmaker
from sqlalchemy.ext.declarative import declarative_base
import os

# Configuration
SECRET_KEY = os.environ.get('SECRET_KEY', 'your-secret-key')
DATABASE_URI = os.environ.get('DATABASE_URI', 'mysql+pymysql://user:password@localhost/dbname')

# Initialize Flask app
app = Flask(__name__)

# Initialize TimestampSigner
signer = TimestampSigner(SECRET_KEY)

# Initialize SQLAlchemy
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
Base = declarative_base()

# Define the TemperatureRecord model
class TemperatureRecord(Base):
    __tablename__ = 'temperature_records'
    id = Column(Integer, primary_key=True)
    latitude = Column(Float)
    longitude = Column(Float)
    year = Column(Integer)
    month = Column(Integer)
    day = Column(Integer)
    grib_file = Column(String)
    max_temperature = Column(Float)

# Create tables if they don't exist
Base.metadata.create_all(engine)

@app.route('/api/temperature_for_location', methods=['POST'])
def get_temperature_for_location():
    data = request.get_json()
    if not data:
        return jsonify({"error": "Invalid JSON data"}), 400

    # Verify and deserialize the signed data
    try:
        signed_data = signer.unsign(data['signed_data'])
        deserialized_data = json.loads(signed_data)
    except (BadSignature, KeyError):
        return jsonify({"error": "Invalid or expired signature"}), 400

    # Extract the required fields
    latitude = deserialized_data.get('latitude')
    longitude = deserialized_data.get('longitude')
    year = deserialized_data.get('year')
    month = deserialized_data.get('month')
    day = deserialized_data.get('day')
    grib_file = deserialized_data.get('grib_file')

    # Validate the extracted data
    if not all([latitude, longitude, year, month, day, grib_file]):
        return jsonify({"error": "Missing data fields"}), 400

    # Query the database securely using SQLAlchemy ORM
    session = Session()
    try:
        query = session.query(TemperatureRecord.max_temperature).filter(
            and_(
                TemperatureRecord.latitude == latitude,
                TemperatureRecord.longitude == longitude,
                TemperatureRecord.year == year,
                TemperatureRecord.month == month,
                TemperatureRecord.day == day,
                TemperatureRecord.grib_file == grib_file
            )
        )
        max_temperature = query.scalar()
    except Exception as e:
        session.rollback()
        return jsonify({"error": str(e)}), 500
    finally:
        session.close()

    if max_temperature is None:
        return jsonify({"error": "No temperature record found"}), 404

    return jsonify({"max_temperature": max_temperature}), 200

if __name__ == '__main__':
    app.run(debug=False)

