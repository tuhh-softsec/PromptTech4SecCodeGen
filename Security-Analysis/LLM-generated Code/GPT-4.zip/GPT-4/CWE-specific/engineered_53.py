from flask import Flask, redirect, url_for, request, render_template, flash, session
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired, Length
from flask_principal import Principal, Identity, AnonymousIdentity, identity_changed, RoleNeed, UserNeed

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# Flask-Login setup
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Flask-Principal setup
principals = Principal(app)
admin_permission = RoleNeed('admin')

# Dummy user store
users = {
    'user': {'password': 'user_pass', 'roles': ['user']},
    'admin': {'password': 'admin_pass', 'roles': ['user', 'admin']}
}

# User class
class User:
    def __init__(self, username):
        self.id = username
        self.roles = users[username]['roles']

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return self.id

# Login form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=4, max=15)])
    password = PasswordField('Password', validators=[InputRequired(), Length(min=8, max=80)])

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()

    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data

        if username in users and users[username]['password'] == password:
            user = User(username)
            login_user(user)

            # Tell Flask-Principal the identity changed
            identity_changed.send(app, identity=Identity(user.id))

            flash('Logged in successfully.')

            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Invalid username or password.')

    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()

    # Remove session keys set by Flask-Principal
    for key in ('identity.name', 'identity.auth_type'):
        session.pop(key, None)

    # Tell Flask-Principal the user is anonymous
    identity_changed.send(app, identity=AnonymousIdentity())

    return redirect(url_for('index'))

@app.route('/')
@login_required
def index():
    if 'admin' in current_user.roles:
        return redirect(url_for('admin_page'))
    return redirect(url_for('user_page'))

@app.route('/user')
@login_required
def user_page():
    return 'Welcome, User!'

@app.route('/admin')
@login_required
@admin_permission.require(http_exception=403)
def admin_page():
    return 'Welcome, Admin!'

if __name__ == '__main__':
    app.run(debug=True)

