import os
from flask import Flask, send_file, request, abort

app = Flask(__name__)

# Define the base directory where images are stored
IMAGE_DIR = os.path.abspath("path/to/your/images")

# Define an allowlist of allowed file extensions
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}

def is_safe_path(basedir, path, follow_symlinks=True):
    # Check if the path is safe to open
    if follow_symlinks:
        return os.path.realpath(path).startswith(basedir)
    else:
        return os.path.abspath(path).startswith(basedir)

def allowed_file(filename):
    # Check if the file extension is allowed
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/img')
def img():
    # Get the filename from the query parameter
    filename = request.args.get('file')

    # Validate the filename
    if not filename or not allowed_file(filename):
        abort(404)  # Not found

    # Construct the full file path
    file_path = os.path.join(IMAGE_DIR, filename)

    # Check if the path is safe
    if not is_safe_path(IMAGE_DIR, file_path):
        abort(403)  # Forbidden

    # Check if the file exists
    if not os.path.isfile(file_path):
        abort(404)  # Not found

    # Serve the file
    return send_file(file_path)

if __name__ == '__main__':
    app.run()

