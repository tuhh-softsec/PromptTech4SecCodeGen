from flask import Flask, request, jsonify
from itsdangerous import URLSafeSerializer
import yaml

app = Flask(__name__)

# Secret key for signing payloads. This should be kept secret and secure.
SECRET_KEY = 'your-secret-key'
serializer = URLSafeSerializer(SECRET_KEY)

# A simple class to represent the expected data structure.
class CreateObject:
    def __init__(self, data):
        # Initialize your object with the data you expect.
        # Make sure to validate the data to prevent security issues.
        self.data = data

@app.route('/', methods=['POST'])
def process_request():
    payload = request.args.get('payload')

    if not payload:
        return jsonify({'error': 'Missing payload parameter'}), 400

    try:
        # Verify and deserialize the signed payload
        payload_data = serializer.loads(payload)
    except Exception as e:
        return jsonify({'error': 'Invalid or tampered payload'}), 400

    try:
        # Parse the YAML safely
        parsed_data = yaml.safe_load(payload_data)
    except yaml.YAMLError as e:
        return jsonify({'error': 'Invalid YAML data'}), 400

    # Check if the type is 'Create'
    if parsed_data.get('type') != 'Create':
        return jsonify({'error': 'Type must be Create'}), 400

    # Populate a new object with the deserialized data
    create_object = CreateObject(parsed_data)

    # Process the create_object as needed
    # ...

    return jsonify({'message': 'Payload processed successfully'}), 200

if __name__ == '__main__':
    app.run(port=5000)

