from flask import Flask, session, jsonify, abort
from flask_session import Session  # for server-side sessions
import os

app = Flask(__name__)

# Configure the secret key for session management and use server-side sessions
app.config['SECRET_KEY'] = os.urandom(24)  # Generate a random secret key
app.config['SESSION_TYPE'] = 'filesystem'  # Use filesystem-based sessions
Session(app)

@app.route('/info', methods=['GET'])
def info():
    # Check if the user is authenticated and the required data is in the session
    if 'authenticated' not in session or not session['authenticated']:
        abort(403)  # Forbidden access if the user is not authenticated

    # Validate that the session contains the required information
    required_keys = ['username', 'email', 'ssn']
    if not all(key in session for key in required_keys):
        abort(400)  # Bad request if the session does not contain the required keys

    # Retrieve the user's information from the session, ensuring no sensitive data is exposed
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')

    # Return the user's information in a safe manner
    return jsonify({
        'username': username,
        'email': email,
        'ssn': ssn
    })

# Error handler for 403 Forbidden
@app.errorhandler(403)
def forbidden(e):
    return jsonify(error=str(e)), 403

# Error handler for 400 Bad Request
@app.errorhandler(400)
def bad_request(e):
    return jsonify(error=str(e)), 400

# Error handler for 500 Internal Server Error
@app.errorhandler(500)
def internal_server_error(e):
    # Log the error for internal tracking without exposing sensitive details
    app.logger.error('Server Error: %s', str(e))
    return jsonify(error='An internal error occurred. Please try again later.'), 500

if __name__ == '__main__':
    app.run(debug=False)  # Never deploy a production app with debug=True

