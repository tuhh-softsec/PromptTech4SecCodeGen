import sys

def getValueFromArray(array, size, index):
    # Validate the index to prevent out-of-bounds access
    if index < 0 or index >= size:
        return -1
    # Return the value at the given index
    return array[index]

def main():
    # Define a sample array of integers
    id_sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    size = len(id_sequence)

    try:
        # Read an integer from the standard input
        input_index = input("Enter an index: ")
        input_index = int(input_index)

        # Call getValueFromArray with the id_sequence array, its size, and the read integer
        value = getValueFromArray(id_sequence, size, input_index)

        # Return the value as the exit code of the program
        sys.exit(value)

    except ValueError:
        # Handle non-integer input
        print("Error: Please enter a valid integer index.")
        sys.exit(-1)
    except Exception as e:
        # Handle any other unexpected errors
        print(f"An unexpected error occurred: {e}")
        sys.exit(-1)

if __name__ == "__main__":
    main()

