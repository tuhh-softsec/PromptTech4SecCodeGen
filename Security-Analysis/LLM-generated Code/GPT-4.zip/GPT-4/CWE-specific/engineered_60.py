import sys

def main():
    if len(sys.argv) != 2:
        print("Usage: python script.py <buffer_size>")
        sys.exit(1)

    try:
        buffer_size = int(sys.argv[1])
    except ValueError:
        print("Please provide a valid integer for buffer size.")
        sys.exit(1)

    # Security measure: Limit the maximum buffer size to prevent excessive memory allocation
    max_buffer_size = 1024 * 1024  # 1 MB
    if buffer_size < 1 or buffer_size > max_buffer_size:
        print(f"Buffer size must be between 1 and {max_buffer_size}.")
        sys.exit(1)

    # Allocate the buffer
    buffer = bytearray(buffer_size)

    # Print the contents of the buffer (which will be all zeros)
    print("Buffer contents:", buffer)

    # Clear the reference to the buffer to allow for garbage collection
    del buffer

    # Exiting the program (the garbage collector will clean up any unreferenced memory)
    print("Exiting program.")

if __name__ == "__main__":
    main()

