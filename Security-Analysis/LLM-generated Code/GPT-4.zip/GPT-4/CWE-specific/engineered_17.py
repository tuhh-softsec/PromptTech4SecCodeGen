def get_value_at_index(array, input_string):
    try:
        # Validate the input to ensure it is an integer
        index = int(input_string)
    except ValueError:
        # If the input is not an integer, return -1
        print("Invalid input: Please enter a valid integer.")
        return -1

    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        # If the index is valid, return the value at that index
        return array[index]
    else:
        # If the index is out of bounds, return -1
        return -1

# Example usage:
if __name__ == "__main__":
    # Define a sample array
    sample_array = [10, 20, 30, 40, 50]

    # Get user input securely
    user_input = input("Enter the index of the element you want to retrieve: ")

    # Call the function with the user input
    value = get_value_at_index(sample_array, user_input)

    # Output the result
    if value != -1:
        print(f"The value at index {user_input} is {value}.")
    else:
        print("Index out of bounds or invalid input.")

