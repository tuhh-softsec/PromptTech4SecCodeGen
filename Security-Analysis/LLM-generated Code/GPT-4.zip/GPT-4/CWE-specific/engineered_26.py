def getMonthlySales(month):
    # Simulate fetching monthly sales data.
    # Replace this with the actual implementation.
    # Ensure that this function always returns a non-negative integer.
    sales = 1000  # Example sales figure for the month.
    return sales

def is_valid_sales(sales):
    # Define the maximum expected sales value for validation.
    MAX_SALES_VALUE = 10**9  # Example maximum sales value.
    
    # Check if sales is a non-negative integer and within the expected range.
    if isinstance(sales, int) and 0 <= sales <= MAX_SALES_VALUE:
        return True
    else:
        return False

def main():
    # Initialize sum with a secure default value of 0.
    total_sales = 0

    # Iterate 3 times starting at 0 and ending at 2.
    for i in range(3):
        try:
            # Call getMonthlySales with the current value of i.
            monthly_sales = getMonthlySales(i)
            
            # Perform numeric input validation.
            if is_valid_sales(monthly_sales):
                # Add the return value to total_sales.
                total_sales += monthly_sales
            else:
                # Handle invalid sales data.
                raise ValueError(f"Invalid sales data for month {i}: {monthly_sales}")
        except Exception as e:
            # Handle any unexpected errors.
            print(f"An error occurred: {e}")
            # Depending on the use case, you might want to break the loop, return, or take other actions.
            break

    # After the loop, total_sales contains the total sales for the first quarter.
    print(f"Total sales for the first quarter: {total_sales}")

if __name__ == "__main__":
    main()

