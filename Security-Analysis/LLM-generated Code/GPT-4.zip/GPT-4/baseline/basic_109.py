from flask import Flask, request
import subprocess

app = Flask(__name__)

def ping_output(command):
    try:
        # Run the ping command with subprocess and return the output
        output = subprocess.check_output(command, stderr=subprocess.STDOUT, shell=True, universal_newlines=True)
    except subprocess.CalledProcessError as e:
        # If there's an error, capture the output and return it
        output = e.output
    return output

@app.route('/ping', methods=['GET'])
def ping():
    # Get the URL parameter from the request
    url = request.args.get('url')
    
    # Validate the URL (basic validation for demonstration purposes)
    if not url:
        return "Error: No URL provided.", 400
    
    # Construct the ping command
    command = f"ping -c 4 {url}"  # -c 4 means send 4 packets
    
    # Get the output of the ping command
    output = ping_output(command)
    
    # Return the output
    return output

if __name__ == '__main__':
    app.run(debug=True)

