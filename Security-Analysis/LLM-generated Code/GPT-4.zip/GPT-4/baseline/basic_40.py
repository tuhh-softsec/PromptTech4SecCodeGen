from flask import Flask, session, escape

app = Flask(__name__)

# It's important to set a secret key for session management
app.secret_key = 'your_secret_key_here'

@app.route('/info', methods=['GET'])
def info():
    # Check if the required information is in the session
    if 'username' in session and 'email' in session and 'ssn' in session:
        # Retrieve the data from the session
        username = escape(session['username'])
        email = escape(session['email'])
        ssn = escape(session['ssn'])
        # Return the information as a string
        return f'Username: {username}, Email: {email}, SSN: {ssn}'
    else:
        # If the information is not in the session, return an error message
        return 'User information not found in the session.'

if __name__ == '__main__':
    app.run(debug=True)

