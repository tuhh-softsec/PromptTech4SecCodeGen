def getValueFromArray(array, size, index):
    # Check if the index is within the bounds of the array
    if 0 <= index < size:
        return array[index]
    else:
        return -1

def main():
    # Define the id_sequence array
    id_sequence = [1, 2, 3, 4, 5]  # Example array, replace with actual values
    size = len(id_sequence)
    
    # Read an integer from the standard input
    try:
        input_index = int(input("Enter an index: "))
    except ValueError:
        print("Invalid input. Please enter an integer.")
        return -1
    
    # Call getValueFromArray with the id_sequence array, its size, and the read integer
    value = getValueFromArray(id_sequence, size, input_index)
    
    # Return the value as the exit code
    return value

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)

