import os
import hashlib

# Function to hash the password with a salt
def hash_password(password, salt):
    # Create a new hasher using SHA256 (you can choose another algorithm if you prefer)
    hasher = hashlib.sha256()
    # Update the hasher with the salt and the password
    hasher.update(salt + password.encode('utf-8'))
    # Return the hex digest of the hash
    return hasher.hexdigest()

# Function to register a new user
def register_user(username, password):
    # Generate a salt
    salt = os.urandom(16)
    
    # Hash the password with the salt
    hashed_password = hash_password(password, salt)
    
    # Store the username, salt, and hashed password in the database
    # For this example, we'll just print them out
    # In a real application, you would save these to your database
    print(f"Username: {username}")
    print(f"Salt: {salt.hex()}")
    print(f"Hashed Password: {hashed_password}")
    
    # Here you would insert the username, salt, and hashed password into your database
    # For example:
    # db.execute("INSERT INTO users (username, salt, hashed_password) VALUES (?, ?, ?)",
    #            (username, salt, hashed_password))
    # db.commit()

# Example usage
if __name__ == "__main__":
    # Prompt the user for a username and password
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    # Register the user
    register_user(username, password)

