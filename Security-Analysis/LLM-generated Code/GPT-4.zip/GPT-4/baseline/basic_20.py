import sys  # This imports the sys module, which is part of the standard library

# Now you can use the print function, which is a built-in function in Python
print("Hello, World!")

