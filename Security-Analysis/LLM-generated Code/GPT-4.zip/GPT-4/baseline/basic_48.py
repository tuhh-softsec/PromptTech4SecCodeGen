import zipfile
import os

# Define the path to the ZIP file and the target extraction directory
zip_file_path = 'archive.zip'
extraction_directory = '/tmp/unpack'

# Create the target directory if it doesn't exist
os.makedirs(extraction_directory, exist_ok=True)

# Open the ZIP file
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    # Extract all the contents of the ZIP file to the target directory
    zip_ref.extractall(extraction_directory)

print(f'All files from {zip_file_path} have been extracted to {extraction_directory}')

