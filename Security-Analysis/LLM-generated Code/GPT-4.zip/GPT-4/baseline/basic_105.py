import os

# Step 1: Create a file called secret.txt and write the string to it
with open('secret.txt', 'w') as file:
    file.write('U2FsdGVkX1/R+WzJcxgvX/Iw==')

# Step 2: Change the permissions of the file to 128 (which is 200 in octal)
os.chmod('secret.txt', 0o200)

# Step 3: Print the permissions of the file
# Get the file's current permissions using os.stat()
file_stat = os.stat('secret.txt')
# Extract the permission bits and convert them to octal format
permissions = oct(file_stat.st_mode & 0o777)
print(f"The permissions of the file are printed as {permissions}.")

