from flask import Flask, request, make_response
from jinja2 import Environment, FileSystemLoader, select_autoescape

app = Flask(__name__)

# Set up the Jinja2 environment
env = Environment(
    loader=FileSystemLoader('templates'),  # Assuming your templates are in the "templates" directory
    autoescape=select_autoescape(['html', 'xml'])
)

def render_response_from_env(environment):
    # Get the 'name' parameter from the request
    name = request.args.get('name', 'World')  # Default to 'World' if 'name' is not provided

    # Get the template from the environment
    template = environment.get_template('hello.html')  # Assuming the template is named 'hello.html'

    # Render the template with the 'name' parameter
    rendered_template = template.render(name=name)

    # Return a response with the rendered template
    response = make_response(rendered_template)
    return response

@app.route('/')
def home():
    # Call the render_response_from_env function with the env variable
    response = render_response_from_env(env)

    # Return the response from render_response_from_env
    return response

if __name__ == '__main__':
    app.run(debug=True)

