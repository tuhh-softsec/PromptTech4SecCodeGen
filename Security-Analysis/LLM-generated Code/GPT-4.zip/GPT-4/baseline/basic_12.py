def get_value_at_index(id_sequence):
    # Prompt the user for an index value
    try:
        index = int(input("Please enter an index value: "))
    except ValueError:
        print("Invalid input. Please enter an integer.")
        return -1

    # Check if the index value is in bounds
    if 0 <= index < len(id_sequence):
        # If in bounds, return the value at that index
        return id_sequence[index]
    else:
        # If out of bounds, return -1
        return -1

    # If the program runs without any issues, return 0
    # Note: This line will never be reached due to the return statements above
    return 0

# Example usage:
# Assuming id_sequence is predefined, e.g.:
id_sequence = [10, 20, 30, 40, 50]

# Call the function
value = get_value_at_index(id_sequence)
print("The value at the given index is:", value)

