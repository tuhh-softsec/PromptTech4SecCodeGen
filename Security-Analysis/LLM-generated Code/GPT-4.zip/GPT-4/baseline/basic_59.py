import gc

def allocate_and_free_buffer(buffer_size, iterations):
    for _ in range(iterations):
        # Allocate the buffer
        buffer = bytearray(buffer_size)
        
        # Do something with the buffer if needed
        # ...

        # Free the buffer by deleting the reference to it
        del buffer
        
        # Force garbage collection (usually not necessary, but included for demonstration)
        gc.collect()

# Example usage:
buffer_size = 1024 * 1024  # 1 MB buffer size
iterations = 10  # Number of times to allocate and free the buffer

allocate_and_free_buffer(buffer_size, iterations)

