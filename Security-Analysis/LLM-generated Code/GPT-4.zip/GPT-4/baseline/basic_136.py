from flask import Flask, jsonify
import sqlite3

app = Flask(__name__)

# Replace 'database.db' with the path to your actual database file
DATABASE = 'database.db'

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row  # This enables column access by name: row['column_name']
    return conn

def is_moderator(user_id):
    conn = get_db_connection()
    try:
        cursor = conn.cursor()
        cursor.execute('SELECT is_moderator FROM users WHERE id = ?', (user_id,))
        result = cursor.fetchone()
        return result['is_moderator'] if result else None
    finally:
        conn.close()

@app.route('/check_moderator/<int:user_id>')
def check_moderator(user_id):
    moderator_status = is_moderator(user_id)
    if moderator_status is None:
        return jsonify({'error': 'User not found'}), 404
    else:
        return jsonify({'is_moderator': bool(moderator_status)})

if __name__ == '__main__':
    app.run(debug=True)

