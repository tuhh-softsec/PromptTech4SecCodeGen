import os

# Define the file path
file_path = 'path/to/your/file.txt'

# Define the flags
flags = os.O_RDWR | os.O_CREAT

# Define the mode (file permissions)
mode = 0o700  # Note the '0o' prefix for an octal literal in Python

# Open the file with the specified flags and mode
fd = os.open(file_path, flags, mode)

# The string to be written to the file
important_config = 'some important configuration data'

# Convert the string to bytes, as os.write() requires a bytes-like object
bytes_to_write = important_config.encode()

# Write the string to the file
num_bytes_written = os.write(fd, bytes_to_write)

# Close the file descriptor
os.close(fd)

# Print the number of bytes written to the file
print(f'Wrote {num_bytes_written} bytes to the file.')

