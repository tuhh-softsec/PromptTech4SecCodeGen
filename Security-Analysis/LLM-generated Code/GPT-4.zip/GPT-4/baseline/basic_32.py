from flask import Flask, request, redirect, render_template, url_for, flash, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# This is a mock database for demonstration purposes
# In a real application, you would use a database like SQLite, MySQL, PostgreSQL, etc.
mock_db = {
    'user1': 'password1',
    'user2': 'password2'
}

@app.route('/')
def home():
    if 'username' in session:
        return redirect(url_for('dashboard'))
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # In a real application, you would fetch the user and password hash from the database
        # and use a password hashing library like bcrypt to verify the password
        if username in mock_db and mock_db[username] == password:
            session['username'] = username
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid username or password')
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    if 'username' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'])

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)

