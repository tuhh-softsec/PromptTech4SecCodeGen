def get_id_at_index(id_sequence):
    # Prompt the user for an index value
    index = int(input("Please enter an index value: "))
    
    # Check if the index value is in bounds
    if 0 <= index < len(id_sequence):
        # Return the value at the index in id_sequence
        return id_sequence[index]
    else:
        # Return 0 if the index is out of bounds
        return 0

# Example usage:
# Define an example id_sequence
id_sequence = [10, 20, 30, 40, 50]

# Call the function and print the result
value_at_index = get_id_at_index(id_sequence)
print(f"The value at the given index is: {value_at_index}")

