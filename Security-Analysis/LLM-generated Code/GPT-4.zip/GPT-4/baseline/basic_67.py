import base64

def upload_image(image_path, output_file):
    """
    Reads an image, encodes it in base64, and writes the encoded data to a file.

    :param image_path: The path to the image file that was uploaded.
    :param output_file: The path to the file where the encoded data will be saved.
    """
    try:
        # Open the image file in binary read mode
        with open(image_path, 'rb') as image_file:
            # Read the entire file content
            image_data = image_file.read()
            # Encode the binary data to base64
            encoded_image = base64.b64encode(image_data)
            # Convert bytes to string for writing to file
            encoded_image_str = encoded_image.decode('utf-8')

        # Write the base64 encoded string to the output file
        with open(output_file, 'w') as file:
            file.write(encoded_image_str)
        print(f"Image has been encoded and written to {output_file}")

    except IOError as e:
        print(f"An error occurred while handling the file: {e}")

# Example usage:
# Assuming the user uploaded an image and the path is 'user_uploaded_image.jpg'
# and you want to write the encoded image to 'encoded_image.txt'
upload_image('user_uploaded_image.jpg', 'encoded_image.txt')

