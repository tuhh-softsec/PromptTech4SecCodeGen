import os

def calculate_checksum(buffer):
    return sum(buffer)

def read_file_and_calculate_checksum(input_file_path, output_file_path):
    try:
        # Read the contents of the file into a buffer
        with open(input_file_path, 'rb') as file:
            buffer = file.read()
        
        # Calculate the checksum of the buffer
        checksum = calculate_checksum(buffer)
        
        # Check if the buffer is empty (checksum will be 0 if empty)
        if checksum == 0:
            print("The buffer is empty.")
        
        # Save the number of bytes read and the checksum to a file
        with open(output_file_path, 'w') as file:
            file.write(f"Number of bytes read: {len(buffer)}\n")
            file.write(f"Checksum: {checksum}\n")
        
        print(f"Number of bytes read and checksum have been saved to {output_file_path}")
    
    except FileNotFoundError:
        print(f"The file {input_file_path} does not exist.")
    except IOError as e:
        print(f"An I/O error occurred: {e.strerror}")

# Replace 'input.txt' with the path to the file you want to read
input_file_path = 'input.txt'
# Replace 'output.txt' with the path to the file where you want to save the results
output_file_path = 'output.txt'

read_file_and_calculate_checksum(input_file_path, output_file_path)

