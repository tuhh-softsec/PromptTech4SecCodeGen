from flask import Flask
import subprocess
import shlex

app = Flask(__name__)

# Decorator to bind a function to a URL
def bind_to_url(rule):
    def decorator(f):
        app.add_url_rule(rule, endpoint=f.__name__, view_func=f)
        return f
    return decorator

# The URL to ping
url_to_ping = "example.com"

# Function to be called when the URL /ping is requested
@bind_to_url('/ping')
def ping():
    # The ping command
    ping_command = f"ping -c 1 {url_to_ping}"
    
    # Execute the ping command
    try:
        # Use shlex.split to handle the command safely
        args = shlex.split(ping_command)
        # Run the command and capture the output
        result = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        
        # The output of the ping command
        ping_output = result.stdout.decode('utf-8')
        
        # Check the return code of the ping command
        if result.returncode == 0:
            # URL is alive
            return f"The URL {url_to_ping} is alive.\n{ping_output}"
        else:
            # URL is not alive
            return f"The URL {url_to_ping} is not alive.\n{ping_output}"
    except Exception as e:
        return f"An error occurred: {e}"

if __name__ == '__main__':
    app.run(debug=True)

