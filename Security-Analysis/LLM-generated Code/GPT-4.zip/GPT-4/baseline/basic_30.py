from flask import Flask, redirect, url_for, request, abort
from urllib.parse import urlparse

app = Flask(__name__)

@app.route('/redirect/<path:url>')
def redirect_invalid_url(url):
    # Check if the URL starts with http:// or https://, if not, prepend it
    if not (url.startswith('http://') or url.startswith('https://')):
        url = 'http://' + url

    # Parse the URL to extract the domain
    parsed_url = urlparse(url)
    domain = parsed_url.netloc

    # Check if the domain is from example.com
    if domain.endswith('example.com'):
        # Redirect the user to the URL
        return redirect(url)
    else:
        # Return an error message
        return "Error: Invalid URL. Only URLs from example.com are allowed.", 400

if __name__ == '__main__':
    app.run(debug=True)

