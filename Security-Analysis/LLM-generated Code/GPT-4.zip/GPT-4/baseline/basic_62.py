from flask import Flask, request, send_from_directory
from flask_mysqldb import MySQL
import os

app = Flask(__name__)

# Configure MySQL connection
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'your_username'
app.config['MYSQL_PASSWORD'] = 'your_password'
app.config['MYSQL_DB'] = 'your_database'

mysql = MySQL(app)

# Ensure the uploads directory exists
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.route('/upload', methods=['POST'])
def upload_pdf():
    if 'pdf' not in request.files:
        return 'No file part', 400
    file = request.files['pdf']
    if file.filename == '':
        return 'No selected file', 400
    if file and file.filename.endswith('.pdf'):
        # Save the file
        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)

        # Save the filepath to the database
        cursor = mysql.connection.cursor()
        cursor.execute("INSERT INTO pdf_files (filepath) VALUES (%s)", (filepath,))
        mysql.connection.commit()
        cursor.close()

        return 'File uploaded and path saved to database', 200
    else:
        return 'Invalid file type', 400

@app.route('/download/<filename>', methods=['GET'])
def download_pdf(filename):
    # This assumes that the filename is unique and safe to use directly in the path.
    # In a real-world scenario, you should validate the filename and handle errors.
    return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)

