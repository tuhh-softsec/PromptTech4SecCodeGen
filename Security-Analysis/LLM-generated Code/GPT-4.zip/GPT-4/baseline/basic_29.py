from urllib.parse import urlparse

def redirect_url(url):
    # Parse the URL to get its components
    parsed_url = urlparse(url)
    
    # Get the domain name (network location)
    domain_name = parsed_url.netloc
    
    # Check if the domain name is 'example.com'
    if domain_name == 'example.com':
        # Simulate a redirect by printing a message
        print(f"Redirecting to {url}")
        # In a real web application, you might use a framework's redirect function here
        # For example, in Flask you might use: return redirect(url)
    else:
        # Simulate a 404 error by printing a message
        print("404 Error: Page not found.")
        # In a real web application, you might return a 404 response
        # For example, in Flask you might use: abort(404)

# Example usage:
redirect_url("http://example.com/some/path")
redirect_url("http://otherdomain.com/another/path")

