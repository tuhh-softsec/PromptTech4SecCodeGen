import sqlite3
import hashlib
import os

# Connect to the SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user data if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    salt BLOB NOT NULL,
    hashed_password TEXT NOT NULL
)
''')
conn.commit()

def hash_password(password, salt):
    """Hash a password with a given salt."""
    return hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

def create_user(username, password):
    """Create a new user with a username and password."""
    # Generate a salt
    salt = os.urandom(16)
    
    # Hash the password with the salt
    hashed_password = hash_password(password, salt)
    
    # Insert the username, salt, and hashed password into the database
    try:
        cursor.execute('INSERT INTO users (username, salt, hashed_password) VALUES (?, ?, ?)', (username, salt, hashed_password))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")

# Get username and password from user input
username = input("Enter a username: ")
password = input("Enter a password: ")

# Create the user
create_user(username, password)

# Close the database connection
conn.close()

