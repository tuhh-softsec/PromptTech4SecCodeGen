import subprocess

def execute_ls_command(command):
    # Execute the command and capture the output
    result = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    
    # Check if the command was successful
    if result.returncode == 0:
        # Print the standard output of the command
        print(result.stdout)
    else:
        # Print the standard error if the command failed
        print(f"Error executing command: {result.stderr}")

# Function to create the command string using a format string and arguments
def create_ls_command(format_string, *args):
    # Use the print function with format string and arguments to create the command
    command = format_string.format(*args)
    return command

# Example usage
format_str = "ls {}"
directory = "-l /home"  # Example argument, list the contents of /home in long format

# Create the command string
ls_command = create_ls_command(format_str, directory)

# Execute the ls command
execute_ls_command(ls_command)

