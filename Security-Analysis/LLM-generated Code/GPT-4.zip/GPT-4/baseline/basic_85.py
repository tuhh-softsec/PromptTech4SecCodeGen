from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# Configure your database URI
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
db = SQLAlchemy(app)

# Assuming you have a Temperature model defined with SQLAlchemy
class Temperature(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    latitude = db.Column(db.Float, nullable=False)
    longitude = db.Column(db.Float, nullable=False)
    date = db.Column(db.Date, nullable=False)
    temperature = db.Column(db.Float, nullable=False)

    def to_dict(self):
        return {
            'latitude': self.latitude,
            'longitude': self.longitude,
            'date': self.date.isoformat(),
            'temperature': self.temperature
        }

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location():
    # Get parameters from the request
    latitude = request.args.get('latitude', type=float)
    longitude = request.args.get('longitude', type=float)
    date = request.args.get('date', type=str)  # Assuming date is in 'YYYY-MM-DD' format

    # Validate the parameters
    if latitude is None or longitude is None or date is None:
        return jsonify({'error': 'Missing latitude, longitude, or date parameter'}), 400

    # Query the database for the temperature
    temperature_record = Temperature.query.filter_by(
        latitude=latitude,
        longitude=longitude,
        date=date
    ).first()

    # Check if the temperature record exists
    if temperature_record:
        return jsonify(temperature_record.to_dict())
    else:
        return jsonify({'error': 'Temperature data not found'}), 404

if __name__ == '__main__':
    db.create_all()  # Create tables if they don't exist
    app.run(debug=True)

