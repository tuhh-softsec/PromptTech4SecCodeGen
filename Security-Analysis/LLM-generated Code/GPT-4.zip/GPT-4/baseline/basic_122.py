import sys

# First if statement checks for exactly one argument
if len(sys.argv) != 2:
    print("Error: Please provide exactly one argument.")
    sys.exit(1)  # Exit with a non-zero value to indicate an error

# Second line gets the argument from the command line
input_argument = sys.argv[1]

# Third line prints the argument
print("Original argument:", input_argument)

# Fourth line trims the trailing whitespace from the argument
trimmed_argument = input_argument.rstrip()

# Fifth line prints the argument again
print("Trimmed argument:", trimmed_argument)

# Sixth line exits the program
sys.exit(0)  # Exit with zero to indicate success

