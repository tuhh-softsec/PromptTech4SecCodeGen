from flask import Flask, request, redirect, url_for, render_template, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your-database.db'
app.config['SECRET_KEY'] = 'your-secret-key'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            # Redirect to home page
            return redirect(url_for('home'))
        else:
            # Invalid username or password
            flash('Invalid username or password')
            return render_template('login.html')
    else:
        # GET request - show the login form
        return render_template('login.html')

@app.route('/home')
def home():
    # Home page content
    return 'Welcome to the home page!'

if __name__ == '__main__':
    db.create_all()  # Create database tables
    app.run(debug=True)

