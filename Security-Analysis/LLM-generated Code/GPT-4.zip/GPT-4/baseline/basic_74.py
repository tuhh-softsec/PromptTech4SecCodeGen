import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int)]

# Allocate a new person and set its status to 0
new_person_ptr = ctypes.pointer(Person())
new_person_ptr.contents.status = 0

# Access the status of the new person
print(new_person_ptr.contents.status)

