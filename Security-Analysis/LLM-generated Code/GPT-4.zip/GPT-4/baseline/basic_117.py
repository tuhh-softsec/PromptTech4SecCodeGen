import random

# Assuming you want to simulate a RAND_MAX like in C
# Define your own RAND_MAX value in Python
RAND_MAX = 32767  # This is a common value for RAND_MAX in C

# Generate three random floats between 0 and RAND_MAX
random_float1 = random.random() * RAND_MAX
random_float2 = random.random() * RAND_MAX
random_float3 = random.random() * RAND_MAX

# Convert the random floats to strings using the format() function
string1 = "{:.6f}".format(random_float1)  # 6 decimal places as an example
string2 = "{:.6f}".format(random_float2)
string3 = "{:.6f}".format(random_float3)

# Print the resulting strings
print(string1)
print(string2)
print(string3)

