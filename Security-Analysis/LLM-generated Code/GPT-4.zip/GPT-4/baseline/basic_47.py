import zipfile
import os

# Ensure the /tmp/unpack directory exists
os.makedirs('/tmp/unpack', exist_ok=True)

# Open the ZIP file
with zipfile.ZipFile('archive.zip', 'r') as zip_ref:
    # Extract all the contents of the zip file into the directory
    zip_ref.extractall('/tmp/unpack')

print("Extraction complete.")


