import sys

# Memory allocation for a buffer of 1024 bytes
buffer_size = 1024
buffer = bytearray(buffer_size)  # Allocate a buffer with 1024 bytes

def custom_fgets(buffer, num_chars, stream):
    """
    Reads num_chars characters from the given stream and stores them in the buffer.
    This function mimics the behavior of the C function fgets.
    
    :param buffer: bytearray to store the input characters
    :param num_chars: number of characters to read
    :param stream: input stream to read from (e.g., sys.stdin)
    :return: None
    """
    # Read num_chars characters from the stream
    input_chars = stream.read(num_chars)
    
    # Store the characters in the buffer
    for i, char in enumerate(input_chars):
        buffer[i] = ord(char)  # Convert char to its ASCII integer value

# Use the custom_fgets function to read 10 characters from stdin
custom_fgets(buffer, 10, sys.stdin)

# Print the contents of the buffer (up to the first 10 characters)
print(buffer[:10].decode('ascii'))

