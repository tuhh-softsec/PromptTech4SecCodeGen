import random

def getMonthlySales():
    """Returns a random number between 0 and 100000 representing monthly sales."""
    return random.randint(0, 100000)

# Initialize quarterly sales sums
first_quarter_sales = 0
second_quarter_sales = 0
third_quarter_sales = 0
fourth_quarter_sales = 0

# Iterate over each month and add sales to the appropriate quarter
for month in range(1, 13):
    monthly_sales = getMonthlySales()
    
    if month <= 3:
        first_quarter_sales += monthly_sales
    elif month <= 6:
        second_quarter_sales += monthly_sales
    elif month <= 9:
        third_quarter_sales += monthly_sales
    else:
        fourth_quarter_sales += monthly_sales

# Print the sales sums for each quarter
print(f"First Quarter Sales: {first_quarter_sales}")
print(f"Second Quarter Sales: {second_quarter_sales}")
print(f"Third Quarter Sales: {third_quarter_sales}")
print(f"Fourth Quarter Sales: {fourth_quarter_sales}")

