import sys

# Check if a command line argument is provided
if len(sys.argv) != 2:
    print("Usage: python script.py <number>")
    sys.exit(1)

try:
    # Convert the first command line argument to an integer
    input_value = int(sys.argv[1])
except ValueError:
    # Handle the error if the input is not a valid integer
    print("Please provide a valid integer.")
    sys.exit(1)

# Add 1000 to the input value
result = input_value + 1000

# Print the result
print(f"The result is: {result}")

