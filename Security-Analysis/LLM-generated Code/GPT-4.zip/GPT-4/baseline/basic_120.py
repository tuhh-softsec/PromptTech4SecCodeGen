import array
import copy

# Allocate two chunks of memory each of size 10
# We'll use a list to simulate a chunk of memory for simplicity
chunk1 = array.array('b', [0]*10)  # Create an array of 10 bytes initialized to 0
chunk2 = array.array('b', [0]*10)  # Create another array of 10 bytes initialized to 0

# Copy the contents of the first chunk into the second chunk
chunk2 = copy.deepcopy(chunk1)

# Free the first chunk
# In Python, you don't explicitly free memory, but you can delete the reference to the object
del chunk1

# Free the second chunk
del chunk2

# At this point, both chunks are eligible for garbage collection

