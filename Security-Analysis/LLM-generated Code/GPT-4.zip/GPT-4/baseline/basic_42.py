import os

def read_safe_file(filename):
    # Define the safe directory path
    safe_directory = '/safe/'
    
    # Construct the full file path ensuring it's within the safe directory
    safe_file_path = os.path.join(safe_directory, filename)
    
    # Normalize the path to prevent directory traversal
    safe_file_path = os.path.normpath(safe_file_path)
    
    # Check if the path starts with the safe directory
    if not safe_file_path.startswith(safe_directory):
        print("Access denied: Attempt to access a file outside the safe directory.")
        return
    
    # Try to open and read the file
    try:
        with open(safe_file_path, 'r') as file:
            content = file.read()
            print("File content:")
            print(content)
    except FileNotFoundError:
        print(f"Error: The file '{filename}' does not exist in the safe directory.")
    except IOError as e:
        print(f"Error: Unable to read the file '{filename}'. {e}")

# Example usage:
# Replace 'example.txt' with the actual file name you want to read from the /safe/ directory
read_safe_file('example.txt')

