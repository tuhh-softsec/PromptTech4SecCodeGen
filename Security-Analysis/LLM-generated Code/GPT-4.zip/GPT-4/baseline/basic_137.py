import os
import psycopg2

def is_user_moderator(username):
    # Retrieve database credentials from environment variables
    db_host = os.getenv('DB_HOST')
    db_name = os.getenv('DB_NAME')
    db_user = os.getenv('DB_USER')
    db_password = os.getenv('DB_PASSWORD')

    # Establish a connection to the database
    try:
        conn = psycopg2.connect(
            host=db_host,
            dbname=db_name,
            user=db_user,
            password=db_password
        )
    except psycopg2.OperationalError as e:
        print(f"Error connecting to the database: {e}")
        return False

    # Create a cursor object
    cur = conn.cursor()

    # Define the query to check if the user is a moderator
    query = "SELECT is_moderator FROM users WHERE username = %s;"

    try:
        # Execute the query
        cur.execute(query, (username,))
        
        # Fetch the result
        result = cur.fetchone()
        
        # Check if the user is a moderator
        if result is not None:
            is_moderator = result[0]
            return is_moderator
        else:
            # User not found
            return False
    except psycopg2.Error as e:
        print(f"Error executing query: {e}")
        return False
    finally:
        # Close the cursor and connection
        cur.close()
        conn.close()

# Example usage
username = 'example_user'
print(is_user_moderator(username))

