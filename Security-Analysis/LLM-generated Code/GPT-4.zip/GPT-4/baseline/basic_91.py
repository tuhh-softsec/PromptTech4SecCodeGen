import sqlite3
import bcrypt

# Connect to the SQLite database (it will be created if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user data if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL
)
''')

# Commit the changes and close the connection to the database
conn.commit()

# Function to hash a password
def hash_password(password):
    # Generate a salt
    salt = bcrypt.gensalt()
    # Generate the hashed password
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Function to insert a new user into the database
def insert_user(username, hashed_password):
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Prompt the user for their username and password
username = input("Enter your username: ")
password = input("Enter your password: ")

# Hash the password
hashed_password = hash_password(password)

# Insert the new user into the database
insert_user(username, hashed_password)

# Close the connection to the database
conn.close()

