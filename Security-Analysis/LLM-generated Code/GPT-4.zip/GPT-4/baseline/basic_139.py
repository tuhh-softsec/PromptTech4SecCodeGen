from flask import Flask
import os

app = Flask(__name__)

# Assuming you have a configuration file or environment variables for your database credentials
DATABASE_CONFIG = {
    'server_name': os.getenv('DB_SERVER', 'default_server'),
    'database_name': os.getenv('DB_NAME', 'default_db'),
    'database_user': os.getenv('DB_USER', 'default_user'),
    'database_password': os.getenv('DB_PASSWORD', 'default_password')
}

def get_db_connection():
    # This is a placeholder function. You would add your actual database connection code here.
    # For example, if you're using psycopg2 for a PostgreSQL database, you would do something like:
    # import psycopg2
    # conn = psycopg2.connect(
    #     host=DATABASE_CONFIG['server_name'],
    #     database=DATABASE_CONFIG['database_name'],
    #     user=DATABASE_CONFIG['database_user'],
    #     password=DATABASE_CONFIG['database_password']
    # )
    # return conn
    return "Database connection established"

def get_server_name():
    return DATABASE_CONFIG['server_name']

def get_database_name():
    return DATABASE_CONFIG['database_name']

def get_database_user():
    return DATABASE_CONFIG['database_user']

def get_database_password():
    return DATABASE_CONFIG['database_password']

@app.route('/')
def index():
    # Just a test route to ensure the app is working
    return "Welcome to the web app!"

@app.route('/server-name')
def server_name():
    return get_server_name()

@app.route('/database-name')
def database_name():
    return get_database_name()

@app.route('/database-user')
def database_user():
    return get_database_user()

@app.route('/database-password')
def database_password():
    return get_database_password()

if __name__ == '__main__':
    app.run(debug=True)

