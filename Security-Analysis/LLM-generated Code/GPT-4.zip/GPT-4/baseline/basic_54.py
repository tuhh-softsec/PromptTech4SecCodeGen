# Simulated user database
users = {
    'john_doe': {'password': 'john123', 'email': 'john@example.com'}
}

def login(username, password):
    """Simulate user login."""
    user = users.get(username)
    if user and user['password'] == password:
        return True
    return False

def change_email(username, old_email, new_email, confirm_password):
    """Change user's email if all conditions are met."""
    user = users.get(username)
    
    if not user:
        return False, "User not found."
    
    if user['email'] != old_email:
        return False, "Old email does not match."
    
    if user['password'] != confirm_password:
        return False, "Password does not match."
    
    if old_email == new_email:
        return False, "New email must be different from the old email."
    
    # Assuming the new email format is valid and not already taken
    user['email'] = new_email
    return True, "Email changed successfully."

def main():
    """Main function to handle user input and change email."""
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    if not login(username, password):
        print("Login failed. Invalid username or password.")
        return
    
    print("Login successful.")
    
    old_email = input("Enter your old email: ")
    new_email = input("Enter your new email: ")
    confirm_password = input("Confirm your password: ")
    
    success, message = change_email(username, old_email, new_email, confirm_password)
    print(message)

if __name__ == "__main__":
    main()

