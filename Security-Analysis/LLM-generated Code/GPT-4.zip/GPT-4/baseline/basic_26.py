import re

# Compile the regular expression when the module is loaded
# Replace 'your_pattern_here' with the actual regex pattern you want to use
pattern = re.compile(r'your_pattern_here')

# Define the default URL to use if the target URL does not match
default_url = 'http://example.com/default'

def get_redirect_url(target_url):
    """
    Returns the redirect URL based on whether the target URL matches the pattern.
    
    :param target_url: The URL to match against the compiled regular expression.
    :return: The target URL if it matches the pattern, otherwise the default URL.
    """
    # Check if the target URL matches the compiled regular expression
    if pattern.match(target_url):
        # If it matches, use the target URL as the redirect target
        return target_url
    else:
        # If it does not match, use the default URL
        return default_url

# Example usage
if __name__ == "__main__":
    # Test URLs
    test_urls = [
        'http://example.com/match_this',
        'http://example.com/do_not_match_this',
    ]
    
    # Check each URL and print the redirect target
    for url in test_urls:
        redirect_url = get_redirect_url(url)
        print(f"Redirecting to: {redirect_url}")

