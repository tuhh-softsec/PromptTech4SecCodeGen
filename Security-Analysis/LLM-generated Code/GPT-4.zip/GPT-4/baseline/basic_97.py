import sqlite3
import bcrypt

# Connect to the SQLite database (or create it if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store usernames and hashed passwords if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL
)
''')

# Commit the changes to the database
conn.commit()

# Function to hash a password
def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Function to insert a new user into the database
def insert_user(username, password):
    try:
        # Hash the user's password
        hashed_password = hash_password(password)

        # Insert the new user into the database
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")
    except Exception as e:
        print(f"An error occurred: {e}")

# Prompt the user for a username and password
input_username = input("Enter a username: ")
input_password = input("Enter a password: ")

# Insert the new user into the database
insert_user(input_username, input_password)

# Close the database connection
conn.close()

