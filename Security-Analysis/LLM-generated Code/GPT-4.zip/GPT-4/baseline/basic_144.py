from flask import Flask, request, redirect, url_for, render_template
import sqlite3

app = Flask(__name__)

# Ensure you have a database named 'stock_orders.db' with a table 'buy_orders'
# The table 'buy_orders' should have columns 'username', 'stock_name', and 'stock_quantity'

DATABASE = 'stock_orders.db'

def insert_buy_order(username, stock_name, stock_quantity):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("INSERT INTO buy_orders (username, stock_name, stock_quantity) VALUES (?, ?, ?)",
                   (username, stock_name, stock_quantity))
    conn.commit()
    conn.close()

@app.route('/buy_stock', methods=['GET', 'POST'])
def buy_stock():
    if request.method == 'POST':
        # Assuming the form data will have 'stock_name', 'stock_quantity', and 'username'
        stock_name = request.form['stock_name']
        stock_quantity = request.form['stock_quantity']
        username = request.form['username']
        
        # Insert the buy order into the database
        insert_buy_order(username, stock_name, stock_quantity)
        
        # Redirect the user to their profile page
        return redirect(url_for('profile', username=username))
    else:
        # Render the buy stock form page (assuming you have a template called 'buy_stock_form.html')
        return render_template('buy_stock_form.html')

@app.route('/profile/<username>')
def profile(username):
    # Render the user's profile page (assuming you have a template called 'profile.html')
    return render_template('profile.html', username=username)

if __name__ == '__main__':
    app.run(debug=True)

