import mysql.connector
import requests

# Replace with your database connection details
db_config = {
    'user': 'your_username',
    'password': 'your_password',
    'host': 'your_host',
    'database': 'your_database',
    'raise_on_warnings': True
}

# Replace with the URL of your PHP script
php_script_url = 'http://yourdomain.com/unsubscribe.php'

def check_email_and_unsubscribe(email):
    # Connect to the database
    try:
        cnx = mysql.connector.connect(**db_config)
        cursor = cnx.cursor()
        
        # Check if the email exists in the database
        query = "SELECT COUNT(*) FROM your_table WHERE email = %s"
        cursor.execute(query, (email,))
        (email_count,) = cursor.fetchone()
        
        if email_count == 0:
            # Email does not exist in the database
            return 0
        else:
            # Email exists, call the PHP script to unsubscribe
            response = requests.post(php_script_url, data={'email': email})
            
            if response.text.strip() == '0':
                # PHP script returned 0, unsubscribe successful
                return 1
            else:
                # PHP script did not return 0, unsubscribe failed
                return 0
    except mysql.connector.Error as err:
        print(f"Database error: {err}")
        return 0
    finally:
        if 'cnx' in locals() and cnx.is_connected():
            cnx.close()

# Example usage
email_to_check = 'example@example.com'
result = check_email_and_unsubscribe(email_to_check)
print(result)

