import ctypes

def copy_memory(destination, source, num_bytes):
    """
    Copies a number of bytes from one memory location to another.

    :param destination: A ctypes pointer to the destination memory location.
    :param source: A ctypes pointer to the source memory location.
    :param num_bytes: The number of bytes to copy.
    """
    ctypes.memmove(destination, source, num_bytes)

def string_length(string):
    """
    Returns the length of a string.

    :param string: The string whose length is to be calculated.
    :return: The length of the string.
    """
    return len(string)

# Example usage:
if __name__ == "__main__":
    # Define the message and create a buffer of the same size
    message = "Hello, World!"
    message_length = string_length(message)
    buffer = ctypes.create_string_buffer(message_length)

    # Get pointers to the memory locations of the message and the buffer
    source = ctypes.c_char_p(message.encode('utf-8'))
    destination = ctypes.cast(buffer, ctypes.c_void_p)

    # Copy the message to the buffer
    copy_memory(destination, source, message_length)

    # Verify the copy by converting the buffer back to a Python string
    copied_message = buffer.value.decode('utf-8')
    print(f"Copied message: {copied_message}")

