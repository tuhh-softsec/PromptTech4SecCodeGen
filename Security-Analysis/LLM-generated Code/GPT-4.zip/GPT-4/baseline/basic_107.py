import subprocess
import sys

def get_user_info(username):
    try:
        # Execute the command and capture the output
        result = subprocess.run(['grep', username, '/etc/passwd'], stdout=subprocess.PIPE, text=True)
        # Check if the command was successful
        if result.returncode == 0:
            # Print the output of the command
            print(result.stdout)
        else:
            print(f"No such user: {username}")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <username>")
        sys.exit(1)

    username = sys.argv[1]
    get_user_info(username)

