import os

# Define the file name
file_name = 'important_config'

# Define the permissions: readable and writable by the owner
permissions = os.S_IRUSR | os.S_IWUSR

# Define the flags: create the file if it does not exist, truncate it to zero length, and open it for writing only
flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY

# Open the file with the specified flags and permissions
file_descriptor = os.open(file_name, flags, permissions)

# You can now write to the file using os.write() if needed, for example:
# os.write(file_descriptor, b'Your content here')

# Close the file descriptor when done
os.close(file_descriptor)

