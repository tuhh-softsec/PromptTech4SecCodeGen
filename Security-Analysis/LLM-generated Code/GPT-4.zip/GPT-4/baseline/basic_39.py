from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/info')
def info():
    # For demonstration purposes, we'll use static data.
    # In a real application, you would retrieve this information from a database or another data source.
    user_info = {
        'username': 'johndoe',
        'email': 'johndoe@example.com',
        'ssn': '123-45-6789'
    }

    # Extract the last 4 digits of the SSN
    last_four_ssn = user_info['ssn'].split('-')[-1]

    # Render a template with the user information
    return render_template('info.html', username=user_info['username'], email=user_info['email'], last_four_ssn=last_four_ssn)

if __name__ == '__main__':
    app.run(debug=True)

