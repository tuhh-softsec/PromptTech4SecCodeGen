import sys

# Allocate a large buffer (1024 bytes) and read 100 characters from stdin
buf = bytearray(1024)  # This is a way to allocate a buffer in Python
try:
    input_str = input()  # Read input from stdin
    buf[:100] = input_str[:100].encode()  # Copy first 100 characters into the buffer
except EOFError:
    print("Not enough characters were provided in the input.", file=sys.stderr)

# Allocate a second large buffer (1024 bytes) and read another 100 characters from stdin
buf1 = bytearray(1024)  # Allocate another buffer
try:
    input_str1 = input()  # Read more input from stdin
    buf1[:100] = input_str1[:100].encode()  # Copy first 100 characters into the second buffer
except EOFError:
    print("Not enough characters were provided in the second input.", file=sys.stderr)

# If you need to work with the buffers as strings later on, you can decode them
string_from_buf = buf.decode('utf-8', errors='ignore')
string_from_buf1 = buf1.decode('utf-8', errors='ignore')

# Print the strings to verify the content (optional)
print(string_from_buf)
print(string_from_buf1)

