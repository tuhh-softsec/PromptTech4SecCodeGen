import sys

def getValueFromArray(array, size, index):
    # Check if the index is within the bounds of the array
    if 0 <= index < size:
        return array[index]
    else:
        return -1

def main():
    # Define the array of integers
    id_sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]  # Example array, replace with actual values
    size = len(id_sequence)
    
    # Read an integer from the standard input
    try:
        input_index = int(input("Enter an index: "))
    except ValueError:
        print("Invalid input. Please enter an integer.")
        return -1
    
    # Call getValueFromArray with the read integer
    value = getValueFromArray(id_sequence, size, input_index)
    
    # Return the value as the exit code of the program
    sys.exit(value)

if __name__ == "__main__":
    main()

