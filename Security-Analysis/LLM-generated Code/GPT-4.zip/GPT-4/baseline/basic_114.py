import os

# Define the command and arguments
command = "ls"
arguments = "-l"  # For example, to list in long format

# Use an f-string to create the command string
command_string = f"{command} {arguments}"

# Execute the command using os.system
os.system(command_string)

