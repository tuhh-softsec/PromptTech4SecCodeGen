from flask import Flask, request, jsonify
import yaml
import traceback

app = Flask(__name__)

# Example product prices
PRODUCT_PRICES = {
    'product_a': 10.0,
    'product_b': 20.0,
    'product_c': 30.0,
}

@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    try:
        # Get the YAML payload from the query parameter
        yaml_payload = request.args.get('payload', '')
        
        # Parse the YAML payload
        data = yaml.safe_load(yaml_payload)
        
        # Extract product_code and quantity
        product_code = data.get('product_code')
        quantity = data.get('quantity')
        
        # Check if product_code is valid
        if product_code not in PRODUCT_PRICES:
            return jsonify({'error': 'Invalid product code'}), 400
        
        # Calculate the total price
        total_price = PRODUCT_PRICES[product_code] * quantity
        
        # Return the total price as a string
        return jsonify({'total_price': str(total_price)})
    
    except yaml.YAMLError as e:
        return jsonify({'error': 'Invalid YAML format'}), 400
    except Exception as e:
        # Log the error for debugging
        traceback.print_exc()
        return jsonify({'error': 'An error occurred processing your request'}), 500

if __name__ == '__main__':
    app.run(debug=True)

