# Define the array id_sequence
id_sequence = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# Function to get the value at a given index in id_sequence
def get_value_at_index(index):
    # Check if the index is within the bounds of the array
    if 0 <= index < len(id_sequence):
        return id_sequence[index]
    else:
        # Return -1 if the index is out of bounds
        return -1

# Main function to prompt the user and call the get_value_at_index function
def main():
    # Prompt the user for an index value
    try:
        index = int(input("Enter an index value: "))
        # Call the function and print the result
        value = get_value_at_index(index)
        print(f"The value at index {index} is: {value}")
    except ValueError:
        print("Please enter a valid integer index.")

# Call the main function
if __name__ == "__main__":
    main()

