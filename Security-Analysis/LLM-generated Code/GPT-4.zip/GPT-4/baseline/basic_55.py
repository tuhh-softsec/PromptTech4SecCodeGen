# Simulated user database
users = {
    'user@example.com': {
        'password': 'userpassword',
        'logged_in': False
    }
}

def login(email, password):
    user = users.get(email)
    if user and user['password'] == password:
        user['logged_in'] = True
        print("Login successful.")
        return True
    else:
        print("Login failed. Incorrect email or password.")
        return False

def change_email(old_email, new_email, confirm_password):
    user = users.get(old_email)
    if user:
        if user['logged_in']:
            if user['password'] == confirm_password:
                # Simulate email change in the database
                users[new_email] = users.pop(old_email)
                users[new_email]['password'] = confirm_password
                print("Email changed successfully to", new_email)
            else:
                print("Password confirmation failed. Email not changed.")
        else:
            print("You must be logged in to change your email.")
    else:
        print("The old email does not exist.")

# Main program
def main():
    print("Welcome to the Email Change Page")
    email = input("Enter your email: ")
    password = input("Enter your password: ")

    if login(email, password):
        new_email = input("Enter your new email: ")
        confirm_password = input("Confirm your password: ")
        change_email(email, new_email, confirm_password)

if __name__ == "__main__":
    main()

