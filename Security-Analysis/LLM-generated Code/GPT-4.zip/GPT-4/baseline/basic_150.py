from flask import Flask, request, redirect, url_for, render_template, session, abort

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# Dummy data for user authentication
users = {
    'admin': 'password123'
}

@app.route('/')
def index():
    return '<h1>Welcome!</h1><a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            return '<h1>Invalid username or password</h1>'
    return '''
        <form method="post">
            Username: <input type="text" name="username"><br>
            Password: <input type="password" name="password"><br>
            <input type="submit" value="Login">
        </form>
    '''

@app.route('/secret')
def secret():
    if 'username' in session:
        return '<h1>Secret settings</h1>'
    else:
        return abort(401)  # Unauthorized access

if __name__ == '__main__':
    app.run(debug=True)

