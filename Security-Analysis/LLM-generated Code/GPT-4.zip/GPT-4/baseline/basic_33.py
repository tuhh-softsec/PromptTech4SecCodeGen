from flask import Flask, render_template, request, redirect, url_for
import sqlite3

app = Flask(__name__)

# Assuming you have a database named 'users.db' with a table 'user_accounts'
# The 'user_accounts' table has 'username' and 'password' columns

DATABASE = 'users.db'

def check_login(username, password):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM user_accounts WHERE username=? AND password=?", (username, password))
    account = cursor.fetchone()
    conn.close()
    return account

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if check_login(username, password):
            return redirect(url_for('home'))
        else:
            return redirect(url_for('login'))
    return render_template('login.html')

@app.route('/home')
def home():
    return 'Welcome to the home page!'

if __name__ == '__main__':
    app.run(debug=True)

