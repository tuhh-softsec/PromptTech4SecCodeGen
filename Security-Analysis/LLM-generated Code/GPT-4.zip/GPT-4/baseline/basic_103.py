import os

# Define the filename and the content to write
filename = 'secret.txt'
content = 'U2FsdGVkX1/R+WzJcxgvX/Iw=='

# Write the content to the file
with open(filename, 'w') as file:
    file.write(content)

# Change the file permissions to be restrictive (read and write for owner only)
os.chmod(filename, 0o600)  # Octal permission 600 means read/write for owner, no permissions for group and others

