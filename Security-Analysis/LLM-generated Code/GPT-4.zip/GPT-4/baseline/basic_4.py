# Create an array of strings called vehicles
vehicles = ["Car", "Truck", "Bicycle", "Motorcycle", "Bus", "Train", "Airplane", "Boat"]

# Prompt the user for the index of a vehicle and return that vehicle
try:
    index = int(input("Enter the index of the vehicle you want to retrieve (0-{}): ".format(len(vehicles) - 1)))
    if 0 <= index < len(vehicles):
        print("The vehicle at index {} is: {}".format(index, vehicles[index]))
    else:
        print("Invalid index. Please enter a number between 0 and {}.".format(len(vehicles) - 1))
except ValueError:
    print("Invalid input. Please enter a number.")

# Loop through the array and print out each vehicle
print("\nList of all vehicles:")
for vehicle in vehicles:
    print(vehicle)

