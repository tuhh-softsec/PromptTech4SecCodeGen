import os

# Define the safe directory path
SAFE_DIRECTORY = '/path/to/safe/directory'

def read_file_from_safe_directory(filename):
    # Ensure that the filename does not contain any directory traversal characters
    if '..' in filename or filename.startswith('/'):
        raise ValueError("Invalid filename. Directory traversal is not allowed.")

    # Construct the full file path
    file_path = os.path.join(SAFE_DIRECTORY, filename)

    # Check if the file exists within the safe directory
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"The file {filename} does not exist in the safe directory.")

    # Check if the file is indeed a file and not a directory or a symbolic link
    if not os.path.isfile(file_path):
        raise ValueError(f"The path {filename} is not a file.")

    # Read the file content
    with open(file_path, 'r') as file:
        content = file.read()

    return content

# Example usage
try:
    filename = 'example.txt'  # Replace with the name of the file you want to read
    file_content = read_file_from_safe_directory(filename)
    print(file_content)
except Exception as e:
    print(f"An error occurred: {e}")

