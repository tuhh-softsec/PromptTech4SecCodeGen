def get_value_at_index():
    # Define your array here
    array = [10, 20, 30, 40, 50]  # Example array

    # Get input from the user
    try:
        index = int(input("Enter an index: "))
    except ValueError:
        print("Please enter a valid integer.")
        return -1

    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        return array[index]
    else:
        return -1

# Example usage
value = get_value_at_index()
if value != -1:
    print(f"The value at the given index is: {value}")
else:
    print("Index out of bounds.")

