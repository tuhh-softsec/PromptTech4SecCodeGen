from flask import Flask, request, jsonify
# Assuming these are the correct credentials
CORRECT_USERNAME = "correct_user"
CORRECT_PASSWORD = "correct_pass"

def check_mod(username, password):
    """
    Check if the provided username and password are correct.

    :param username: The username to check.
    :param password: The password to check.
    :return: 'true' if credentials are correct, 'false' otherwise.
    """
    if username == CORRECT_USERNAME and password == CORRECT_PASSWORD:
        return 'true'
    else:
        return 'false'

# Example usage:
# This would typically be triggered by a button click in a web application
# and the username and password would be obtained from a form.
# For demonstration purposes, we're calling the function directly with test values.
username_from_form = "user_input"
password_from_form = "user_password"

# Call the check_mod function with the form data
login_result = check_mod(username_from_form, password_from_form)
print(login_result)  # Output will be 'true' or 'false' based on the credentials



app = Flask(__name__)

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    result = check_mod(username, password)
    return jsonify({'success': result == 'true'})

if __name__ == '__main__':
    app.run(debug=True)

