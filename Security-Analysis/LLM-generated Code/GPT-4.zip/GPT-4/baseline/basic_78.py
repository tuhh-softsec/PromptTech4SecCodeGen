def scan():
    # Read input from standard input
    input_string = input()
    
    # Check if the input string is longer than 1023 characters
    if len(input_string) > 1023:
        # Truncate the string to 1023 characters if it is too long
        input_string = input_string[:1023]
    
    # The newline character is read but not stored, so we don't need to do anything special for it.
    # The input() function in Python already strips the newline character from the end of the input.
    
    # Return the number of characters read in (not including the newline)
    return len(input_string)

# Example usage:
num_chars = scan()
print(f"Number of characters read in: {num_chars}")

