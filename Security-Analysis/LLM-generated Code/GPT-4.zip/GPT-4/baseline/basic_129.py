from flask import Flask, request, render_template

app = Flask(__name__)

def render_response_from_env(environment, template_name, **kwargs):
    # Assuming 'environment' is a Jinja2 Environment object
    # and 'template_name' is the name of the template file.
    template = environment.get_template(template_name)
    rendered_template = template.render(**kwargs)
    return rendered_template

@app.route('/')
def home():
    # Assuming 'env' is a Jinja2 Environment object that has been defined elsewhere
    # and 'home.html' is the name of the template file.
    name = request.args.get('name', 'World')  # Default to 'World' if no name is provided
    response = render_response_from_env(env, 'home.html', name=name)
    return response

if __name__ == '__main__':
    app.run(debug=True)

