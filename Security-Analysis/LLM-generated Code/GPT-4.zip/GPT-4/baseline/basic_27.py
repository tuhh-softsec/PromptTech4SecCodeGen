from flask import Flask, redirect, request
import re

app = Flask(__name__)

# Regular expression to match any URL containing 'example.com'
url_pattern = re.compile(r'https?://(www\.)?example\.com(/.*)?')

@app.route('/redirect')
def redirect_to_target():
    # Get the 'target' parameter from the query string
    target = request.args.get('target', '')

    # Check if the target matches the regular expression
    if url_pattern.match(target):
        # Redirect to the target URL if it matches the pattern
        return redirect(target)
    else:
        # Redirect to the root '/' if it does not match the pattern
        return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)

