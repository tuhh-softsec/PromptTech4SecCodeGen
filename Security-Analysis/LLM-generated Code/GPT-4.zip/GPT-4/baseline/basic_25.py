def main():
    # Declare a variable called totalSales
    totalSales = 0

    # Add the sales for each month to the totalSales variable
    totalSales += float(input("Enter sales for January: "))
    totalSales += float(input("Enter sales for February: "))
    totalSales += float(input("Enter sales for March: "))

    # Print the total sales to the screen
    print("Total sales for the quarter: $", totalSales)

# Call the main function to execute the code
if __name__ == "__main__":
    main()

