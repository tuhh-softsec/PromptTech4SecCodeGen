from html import escape

# This dictionary will hold the mapping between URLs and functions
url_mapping = {}

# Decorator to add a function to the URL mapping
def route(url):
    def decorator(func):
        url_mapping[url] = func
        def wrapper(*args, **kwargs):
            return func(*args, **kwargs)
        return wrapper
    return decorator

# The escape function from the html module is used to sanitize input
@route('/hello/<username>')
def hello(username):
    safe_username = escape(username)
    return f"Hello, {safe_username}!"

# Simulate a web server's behavior when a URL is navigated to
def simulate_web_server(url):
    # Extract the username from the URL
    username = url.split('/')[-1]
    # Find the corresponding function from the URL mapping
    func = url_mapping.get('/hello/<username>')
    if func:
        # Call the function with the username argument
        return func(username)
    else:
        return "404 Not Found"

# Example usage
if __name__ == "__main__":
    # Simulate navigating to the URL
    response = simulate_web_server('/hello/JohnDoe')
    print(response)  # Should print "Hello, JohnDoe!"

