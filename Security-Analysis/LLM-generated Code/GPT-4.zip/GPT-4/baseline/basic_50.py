from flask import Flask, render_template, request, redirect, url_for, session, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# Dummy data for the purpose of this example
# In a real application, you would use a database
VALID_USERNAME = 'admin'
VALID_PASSWORD = 'password'

@app.route('/')
def index():
    return '<h1>Index Page</h1><a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == VALID_USERNAME and password == VALID_PASSWORD:
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            flash('Invalid username or password!')
    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return '<h1>Secret Page</h1><p>Secret setting.</p>'
    else:
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)

