from flask import Flask, request, jsonify

app = Flask(__name__)

# Define a function to get the price for a product code
def get_price(product_code):
    # For demonstration purposes, we'll use a simple dictionary
    # to represent a database of product prices.
    product_prices = {
        'P001': 10.99,
        'P002': 23.50,
        'P003': 5.75,
        # Add more product codes and prices as needed
    }
    return product_prices.get(product_code, 0)  # Return 0 if product code not found

# Define a route to calculate the price for a product code and quantity
@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    # Get product code and quantity from the request's query parameters
    product_code = request.args.get('product_code', '')
    quantity = request.args.get('quantity', 0, type=int)

    # Get the unit price for the product code
    unit_price = get_price(product_code)

    # Calculate the total price
    total_price = unit_price * quantity

    # Return the result as JSON
    return jsonify({
        'product_code': product_code,
        'quantity': quantity,
        'unit_price': unit_price,
        'total_price': total_price
    })

if __name__ == '__main__':
    # Run the app on port 5000
    app.run(port=5000)

