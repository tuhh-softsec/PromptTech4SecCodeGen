import os
from flask import Flask, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

# Allowed extensions can be a set of file extensions that are considered safe.
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)

# Ensure the uploads directory exists
uploads_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
os.makedirs(uploads_dir, exist_ok=True)

def file_is_safe_type(filename):
    """
    Check if the file extension is in the allowed list.
    """
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_file():
    """
    Handle the file upload process.
    """
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)
    file = request.files['file']
    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)
    if file and file_is_safe_type(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(uploads_dir, filename))
        return redirect(url_for('uploaded_file', filename=filename))
    else:
        flash('File type is not allowed')
        return redirect(request.url)

@app.route('/upload', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        return upload_file()
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return f'The file {filename} has been uploaded successfully!'

if __name__ == '__main__':
    app.run(debug=True)

