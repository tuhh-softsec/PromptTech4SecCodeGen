import sys

def main():
    # Check if a command line argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <number>")
        return 1  # Return non-zero to indicate error

    try:
        # Convert the command line argument to an integer
        input_value = int(sys.argv[1])
    except ValueError:
        print("Please provide a valid integer.")
        return 1  # Return non-zero to indicate error

    # Add 1000 to the input value
    result = input_value + 1000

    # Print the result
    print(result)

    # Return 0 to indicate success
    return 0

if __name__ == "__main__":
    # Call the main function and capture the return value
    exit_code = main()
    
    # Exit the script with the provided return code
    sys.exit(exit_code)

