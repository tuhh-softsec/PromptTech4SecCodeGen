import os

# Define the path to the file you want to open
file_path = 'example.txt'

# Define the flags
flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY

# If you want to ensure the file does not already exist, add the O_EXCL flag
# flags |= os.O_EXCL

# Define the mode (permissions) for the new file if it is created
mode = 0o666  # This is a common default, but you can set it to something else if needed

# Open the file using os.open()
try:
    file_descriptor = os.open(file_path, flags, mode)
    # You can now write to the file using os.write() and file_descriptor
    # For example:
    # os.write(file_descriptor, b'Hello, world!')
except OSError as e:
    print(f"An error occurred: {e}")

# When you're done, close the file descriptor
# os.close(file_descriptor)

