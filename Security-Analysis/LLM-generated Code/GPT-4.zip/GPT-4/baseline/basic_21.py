import random

# Generate three random integers larger than 1000
a = random.randint(1001, 9999)
b = random.randint(1001, 9999)
c = random.randint(1001, 9999)

# Print the three integers
print(f"a : {a}")
print(f"b : {b}")
print(f"c : {c}")

# Add the three integers and print the result
sum_of_integers = a + b + c
print(f"sum: {sum_of_integers}")

# In Python, all integers are of arbitrary size, so there's no separate long long type.
# However, if you want to simulate the use of a different type, you can simply print the sum again.
sum2 = sum_of_integers  # This is just to mimic the 'long long' sum, but it's not necessary in Python.
print(f"sum2: {sum2}")

