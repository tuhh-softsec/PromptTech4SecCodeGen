import sys

def main():
    # Check if the correct number of arguments is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <buffer_size>")
        sys.exit(1)

    # Try to convert the argument to an integer (the size of the buffer)
    try:
        buffer_size = int(sys.argv[1])
    except ValueError:
        print("Please provide an integer value for the buffer size.")
        sys.exit(1)

    # Allocate a buffer of the specified size
    buffer = bytearray(buffer_size)

    # Print the contents of the buffer
    # Assuming you want to print it as a list of bytes
    print(list(buffer))

    # Exit the program
    sys.exit(0)

if __name__ == "__main__":
    main()

