from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/getname', methods=['POST'])
def get_name():
    data = request.get_json()  # Get JSON payload from the user request
    if not data:
        return jsonify({"error": "No JSON payload provided"}), 400

    name = data.get('name')  # Check for the 'name' field in the payload
    if name:
        return jsonify({"name": name}), 200  # Return the content of the 'name' field
    else:
        return jsonify({"error": "Field 'name' is missing"}), 400  # 'name' field not found

if __name__ == '__main__':
    app.run(debug=True)

