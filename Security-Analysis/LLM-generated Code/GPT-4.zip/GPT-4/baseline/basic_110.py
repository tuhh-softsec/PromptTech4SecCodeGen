from http.server import BaseHTTPRequestHandler, HTTPServer
import subprocess

# The URL to ping
url_to_ping = "example.com"

def run_system_command(command):
    try:
        result = subprocess.run(command, shell=True, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        return result.stdout.decode('utf-8')
    except subprocess.CalledProcessError as e:
        return e.stderr.decode('utf-8')

class RequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/ping':
            self.handle_ping()
        else:
            self.send_error(404, "File Not Found: %s" % self.path)

    def handle_ping(self):
        # Run the ping command
        output = run_system_command(f"ping -c 4 {url_to_ping}")

        # Send response status code
        self.send_response(200)

        # Send headers
        self.send_header('Content-type', 'text/plain')
        self.end_headers()

        # Write content as utf-8 data
        self.wfile.write(bytes(output, "utf8"))

def run(server_class=HTTPServer, handler_class=RequestHandler, port=8080):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    print(f'Starting httpd on port {port}...')
    httpd.serve_forever()

if __name__ == "__main__":
    from sys import argv

    if len(argv) == 2:
        run(port=int(argv[1]))
    else:
        run()

