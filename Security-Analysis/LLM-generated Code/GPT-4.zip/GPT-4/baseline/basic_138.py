import sqlite3

def check_username_exists(database_path, username):
    # Connect to the SQLite database
    conn = sqlite3.connect(database_path)
    cursor = conn.cursor()
    
    try:
        # SQL query to check if the username exists
        query = "SELECT EXISTS(SELECT 1 FROM users WHERE username=? LIMIT 1)"
        cursor.execute(query, (username,))
        
        # Fetch the result
        exists = cursor.fetchone()[0]
        
        # Return True if exists is 1, otherwise False
        return exists == 1
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
        return False
    finally:
        # Close the database connection
        conn.close()

# Usage
database_path = 'path_to_your_database.db'
username_to_check = 'example_username'
user_exists = check_username_exists(database_path, username_to_check)
print(f"Does the username exist? {user_exists}")
