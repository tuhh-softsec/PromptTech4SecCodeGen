def get_value_at_index(array, index):
    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        return array[index]
    else:
        # Return -1 if the index is out of bounds
        return -1

# Example usage:
# Define an array with some values
my_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# Get an integer input from the user
input_index = int(input("Enter an index: "))

# Get the value at the given index
value = get_value_at_index(my_array, input_index)

# Print the result
print("The value at index {} is: {}".format(input_index, value))

