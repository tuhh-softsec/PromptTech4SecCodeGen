import sys

def atoi(s):
    try:
        return int(s)
    except ValueError:
        print("Error: Cannot convert string to integer.")
        sys.exit(1)

def main():
    # Check if there are enough command line arguments
    if len(sys.argv) < 3:
        print("Usage: python script.py <index> <other arguments...>")
        sys.exit(1)
    
    # Get the index from the second command line argument
    index = atoi(sys.argv[1])
    
    # Check if the index is within the range of command line arguments
    if index >= len(sys.argv) or index < 0:
        print("Error: Index out of range.")
        sys.exit(1)
    
    # Print the command line argument at the specified index
    print(sys.argv[index])
    
    # Exit the program with a return code of 0
    sys.exit(0)

if __name__ == "__main__":
    main()

