import ctypes

def copy_memory(destination, source, num_bytes):
    """
    Copies num_bytes from source to destination using ctypes.memmove.
    
    :param destination: A ctypes object or an integer representing the address of the destination buffer
    :param source: A ctypes object or an integer representing the address of the source buffer
    :param num_bytes: The number of bytes to copy
    """
    # Ensure that the source and destination are ctypes objects with a buffer interface
    if not isinstance(destination, ctypes._CData) and not isinstance(source, ctypes._CData):
        raise TypeError("Source and destination must be ctypes objects with a buffer interface.")
    
    # Perform the memory copy
    ctypes.memmove(destination, source, num_bytes)

# Example usage:
def main():
    # Define the source string and the number of bytes to copy
    source_string = b"Hello."
    num_bytes_to_copy = len(source_string)  # Using len() to get the number of bytes in the string
    
    # Create a buffer for the destination with the same size as the source
    destination_buffer = ctypes.create_string_buffer(num_bytes_to_copy)
    
    # Copy the string to the buffer
    copy_memory(destination_buffer, source_string, num_bytes_to_copy)
    
    # Print the contents of the destination buffer to verify the copy
    print(destination_buffer.value)

if __name__ == "__main__":
    main()

