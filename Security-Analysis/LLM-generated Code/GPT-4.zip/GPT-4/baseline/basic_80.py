from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api')
def api():
    # Get the payload parameter from the URL
    payload = request.args.get('payload', None)
    
    # Check if payload is provided
    if not payload:
        return jsonify({"error": "No payload provided"}), 400
    
    # Load the payload into a dictionary
    try:
        # Assuming the payload is a JSON string
        payload_dict = eval(payload)
    except Exception as e:
        return jsonify({"error": "Invalid payload format"}), 400
    
    # Return the name value from the dictionary
    name = payload_dict.get('name')
    if name:
        return jsonify({"name": name})
    else:
        return jsonify({"error": "Name not found in payload"}), 404

if __name__ == '__main__':
    app.run(debug=True)

