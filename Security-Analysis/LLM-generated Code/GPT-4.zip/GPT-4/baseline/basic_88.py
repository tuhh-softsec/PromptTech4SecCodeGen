from flask import Flask, request, jsonify
import yaml

app = Flask(__name__)

# Dummy function to simulate getting the price for a product code
def get_price_for_product_code(product_code):
    # In a real application, you would query a database or another service
    # Here we just return a fixed price for demonstration purposes
    prices = {
        'product_1': 10.0,
        'product_2': 20.0,
        'product_3': 30.0
    }
    return prices.get(product_code, 0.0)

@app.route('/calculate_price', methods=['GET'])
def calculate_price():
    # Get the YAML payload from the query parameter
    yaml_payload = request.args.get('payload', '')
    
    try:
        # Load the YAML payload into a dictionary
        data = yaml.safe_load(yaml_payload)
        
        # Extract the product code and quantity
        product_code = data.get('product_code')
        quantity = data.get('quantity', 1)
        
        # Calculate the total price
        price_per_unit = get_price_for_product_code(product_code)
        total_price = price_per_unit * quantity
        
        # Return the total price as a YAML payload
        result = yaml.dump({'total_price': total_price})
        return result
    
    except yaml.YAMLError as e:
        return jsonify({'error': 'Invalid YAML payload'}), 400
    except Exception as e:
        return jsonify({'error': 'An error occurred'}), 500

if __name__ == '__main__':
    app.run(debug=True)

