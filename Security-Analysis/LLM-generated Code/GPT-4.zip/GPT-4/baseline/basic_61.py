import os

def calculate_checksum(buffer):
    return sum(buffer)

def read_file_and_calculate_checksum(input_filename, output_filename):
    try:
        # Read the contents of the input file
        with open(input_filename, 'rb') as file:
            buffer = file.read()
        
        # Calculate the checksum of the buffer
        checksum = calculate_checksum(buffer)
        
        # Check if the buffer is empty
        if checksum == 0:
            print("The buffer is empty.")
        
        # Get the number of bytes read
        num_bytes_read = len(buffer)
        
        # Save the number of bytes read and the checksum to the output file
        with open(output_filename, 'w') as file:
            file.write(f"Number of bytes read: {num_bytes_read}\n")
            file.write(f"Checksum: {checksum}\n")
            
        print(f"Number of bytes read and checksum have been saved to {output_filename}")
        
    except IOError as e:
        print(f"An error occurred: {e}")

# Replace 'input.txt' with the path to the file you want to read
# Replace 'output.txt' with the path to the file where you want to save the results
read_file_and_calculate_checksum('input.txt', 'output.txt')

