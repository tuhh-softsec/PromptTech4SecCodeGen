from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

DATABASE = 'Senso.db'

def get_temperature_from_db(lat, lon, date):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    # Assuming the table is named 'temperature_data' and has 'latitude', 'longitude', 'date', and 'temperature' columns
    query = "SELECT temperature FROM temperature_data WHERE latitude=? AND longitude=? AND date=?"
    cursor.execute(query, (lat, lon, date))
    result = cursor.fetchone()
    conn.close()
    return result[0] if result else None

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    payload = request.json
    lat = payload.get('latitude')
    lon = payload.get('longitude')
    date = payload.get('date')

    if not (lat and lon and date):
        return jsonify({'error': 'Missing latitude, longitude, or date in payload'}), 400

    temperature = get_temperature_from_db(lat, lon, date)

    if temperature is not None:
        return jsonify({'temperature': temperature})
    else:
        return jsonify({'error': 'Temperature data not found for the provided location and date'}), 404

if __name__ == '__main__':
    app.run(debug=True)

