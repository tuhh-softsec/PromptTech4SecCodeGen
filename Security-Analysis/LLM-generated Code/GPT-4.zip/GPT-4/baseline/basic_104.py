import os

# Step 1: Create a string with some super secret info
super_secret_info = "This is some very secret information that nobody should see!"

# Step 2: Create a file and write the super secret info to it
file_name = "secret_file.txt"
with open(file_name, 'w') as file:
    file.write(super_secret_info)

# Step 3: Change the permissions of the file to read-only for the owner
# Read-only permission in octal is '0o400' (owner can read, no permissions for group and others)
os.chmod(file_name, 0o400)

# Step 4: Print the name of the file to the screen
print(f"The name of the file is: {file_name}")

