from flask import Flask, redirect, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# Dummy user data for demonstration purposes
users = {
    'user1': {'password': 'password1', 'is_admin': False},
    'admin': {'password': 'adminpass', 'is_admin': True}
}

@app.route('/')
def home():
    if 'username' not in session:
        # User is not logged in, redirect to login page
        return redirect('/login')
    elif session.get('is_admin'):
        # User is logged in and is an admin, redirect to admin page
        return redirect('/admin')
    else:
        # User is logged in but not an admin, redirect to user page
        return redirect('/user')

@app.route('/login')
def login():
    # Here you would have your login logic
    # For demonstration, we'll just log in a user directly
    username = 'user1'  # You would get this from a form
    user = users.get(username)
    if user:
        session['username'] = username
        session['is_admin'] = user['is_admin']
    return 'Login page (user would log in here)'

@app.route('/user')
def user_page():
    if 'username' not in session:
        return redirect('/login')
    return 'User page'

@app.route('/admin')
def admin_page():
    if 'username' not in session or not session.get('is_admin'):
        return redirect('/')
    return 'Admin page'

if __name__ == '__main__':
    app.run(debug=True)

