import bcrypt
import sqlite3

# Connect to the SQLite database (it will be created if it doesn't exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user data if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL
)
''')
conn.commit()

def hash_password(password):
    # Generate a random salt
    salt = bcrypt.gensalt()
    # Hash the password with the salt
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def register_user(username, password):
    hashed_password = hash_password(password)
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print("User registered successfully!")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")

def verify_password(stored_password, provided_password):
    # Check if the provided password matches the stored password
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_password)

# Example usage
if __name__ == "__main__":
    # Register a new user
    username = input("Enter a username: ")
    password = input("Enter a password: ")
    register_user(username, password)

    # Verify the password for the user (login simulation)
    username_to_verify = input("Enter your username to login: ")
    password_to_verify = input("Enter your password to login: ")

    cursor.execute('SELECT password FROM users WHERE username = ?', (username_to_verify,))
    result = cursor.fetchone()

    if result:
        stored_password = result[0]
        if verify_password(stored_password, password_to_verify):
            print("Login successful!")
        else:
            print("Login failed: Incorrect password.")
    else:
        print("Login failed: Username not found.")

    # Close the database connection
    conn.close()

