import subprocess

# Define the directory you want to list, for example, the current directory
directory_to_list = "."

# Create the command string using a format string
command = "ls {}".format(directory_to_list)

# Alternatively, you can use f-string for more concise syntax (Python 3.6+)
# command = f"ls {directory_to_list}"

# Execute the command using the subprocess.run() function
subprocess.run(command, shell=True)

