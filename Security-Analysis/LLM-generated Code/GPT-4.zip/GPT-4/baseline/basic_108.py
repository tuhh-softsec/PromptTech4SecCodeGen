import subprocess
import sys

def run_id_command(username):
    try:
        # Run the 'id' command for the given username
        result = subprocess.run(['id', username], check=True, text=True, capture_output=True)
        # If the command was successful, print the output
        print(result.stdout)
        # Return the exit status (0 for success)
        return result.returncode
    except subprocess.CalledProcessError as e:
        # If the command failed, print the error message
        print(e.stderr, file=sys.stderr)
        # Return the non-zero exit status
        return e.returncode

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <username>", file=sys.stderr)
        sys.exit(1)

    username = sys.argv[1]
    exit_status = run_id_command(username)
    print(f"Exit status of the command: {exit_status}")

