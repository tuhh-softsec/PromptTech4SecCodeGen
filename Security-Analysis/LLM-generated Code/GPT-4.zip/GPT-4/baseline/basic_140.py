from flask import Flask, request, render_template_string
import sqlite3

app = Flask(__name__)

# HTML template for the unsubscribe form
UNSUBSCRIBE_FORM = '''
<!DOCTYPE html>
<html>
<head>
    <title>Unsubscribe</title>
</head>
<body>
    <h2>Unsubscribe from our mailing list</h2>
    <form method="post">
        Email: <input type="email" name="email" required>
        <input type="submit" value="Unsubscribe">
    </form>
    {{ message|safe }}
</body>
</html>
'''

# Function to unsubscribe an email
def unsubscribe(email):
    # Connect to the database
    conn = sqlite3.connect('your_database.db')
    cursor = conn.cursor()
    
    # Check if the email is in the database
    cursor.execute("SELECT * FROM subscribers WHERE email = ?", (email,))
    if cursor.fetchone():
        # Email is in the database, remove it
        cursor.execute("DELETE FROM subscribers WHERE email = ?", (email,))
        conn.commit()
        message = "You have been successfully unsubscribed."
    else:
        # Email is not in the database
        message = "Your email address is not in our database."
    
    # Close the database connection
    cursor.close()
    conn.close()
    
    return message

@app.route('/unsubscribe', methods=['GET', 'POST'])
def unsubscribe_form():
    message = ''
    if request.method == 'POST':
        email = request.form['email']
        message = unsubscribe(email)
    return render_template_string(UNSUBSCRIBE_FORM, message=message)

if __name__ == '__main__':
    app.run(debug=True)

