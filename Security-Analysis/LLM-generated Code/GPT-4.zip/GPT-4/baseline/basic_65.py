import mysql.connector
from mysql.connector import Error
from PIL import Image
import io

# Database configuration
db_config = {
    'host': 'localhost',
    'user': 'your_username',
    'password': 'your_password',
    'database': 'your_database'
}

# Connect to the database
try:
    connection = mysql.connector.connect(**db_config)
    if connection.is_connected():
        print("Successfully connected to the database")
except Error as e:
    print(f"Error while connecting to MySQL: {e}")
    exit(1)

# Function to convert image to binary data
def convert_image_to_binary(filename):
    with open(filename, 'rb') as file:
        binary_data = file.read()
    return binary_data

# Function to insert image into the database
def insert_image_to_db(image_path):
    try:
        cursor = connection.cursor()
        binary_data = convert_image_to_binary(image_path)
        sql_insert_blob_query = """ INSERT INTO images_table (image_data) VALUES (%s)"""
        cursor.execute(sql_insert_blob_query, (binary_data,))
        connection.commit()
        print("Image has been inserted into the database")
    except mysql.connector.Error as error:
        print(f"Failed to insert image into MySQL table: {error}")
    finally:
        if connection.is_connected():
            cursor.close()

# Replace 'your_image.jpg' with the path to the image you want to store
image_path = 'your_image.jpg'
insert_image_to_db(image_path)

# Close the database connection
if connection.is_connected():
    connection.close()
    print("MySQL connection is closed")

