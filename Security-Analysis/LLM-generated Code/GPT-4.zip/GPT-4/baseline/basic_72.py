import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int)]

# Allocate a new Person instance and set the status field to 0
new_person = Person()
new_person.status = 0

# Access the status field
print(new_person.status)  # Output: 0

