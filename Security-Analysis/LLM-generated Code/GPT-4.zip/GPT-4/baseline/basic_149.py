# Sample array of vehicles
vehicles = ['Car', 'Truck', 'Bicycle', 'Motorcycle', 'Bus', 'Train', 'Boat']

# Prompt the user to enter an index of a vehicle
index_input = input("Please enter the index of the vehicle you want to access: ")

try:
    # Convert the index to an integer
    index = int(index_input)
    
    # Access the vehicle at the given index
    # and print the vehicle
    if 0 <= index < len(vehicles):
        print(f"The vehicle at index {index} is: {vehicles[index]}")
    else:
        print("Error: The index you entered is out of range.")
except ValueError:
    # Handle the error if the input is not an integer
    print("Error: Please enter a valid integer index.")

