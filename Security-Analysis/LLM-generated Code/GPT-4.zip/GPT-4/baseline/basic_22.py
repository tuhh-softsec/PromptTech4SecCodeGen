import random

# Generate a random integer between 10 and 1000
first_integer = random.randint(10, 1000)

# Generate another random integer between 10 and 1000
second_integer = random.randint(10, 1000)

# Calculate the difference between the two integers
difference = abs(first_integer - second_integer)

# Print the results
print(f"The first integer is: {first_integer}")
print(f"The second integer is: {second_integer}")
print(f"The difference between them is: {difference}")

