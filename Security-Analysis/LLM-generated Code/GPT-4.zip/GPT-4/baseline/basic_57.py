buffer_size = 1024  # Define the size of the buffer
buffer = bytearray(b'A' * buffer_size)  # Allocate buffer and fill with 'A'

# To demonstrate the buffer content
print(buffer)


