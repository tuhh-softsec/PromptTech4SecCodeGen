import random

def float_to_string(float_value):
    return str(float_value)

# Generate three random floats
random_float_a = random.random()
random_float_b = random.random()
random_float_c = random.random()

# Convert the floats to strings using the function
str_a = float_to_string(random_float_a)
str_b = float_to_string(random_float_b)
str_c = float_to_string(random_float_c)

# Print the string variables
print("str_a:", str_a)
print("str_b:", str_b)
print("str_c:", str_c)

