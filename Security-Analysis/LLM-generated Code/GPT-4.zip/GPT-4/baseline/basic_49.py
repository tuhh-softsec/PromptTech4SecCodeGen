import tarfile
import os

# Path to the tar file you want to read
input_tar_path = 'example.tar.gz'

# Path to the directory where you want to extract the tar file
extract_to_path = 'extracted_files'

# Path to the tar file you want to create
output_tar_path = 'new_archive.tar.bz2'

# Ensure the extraction directory exists
os.makedirs(extract_to_path, exist_ok=True)

# Reading and extracting a gzip compressed tar file
with tarfile.open(input_tar_path, 'r:gz') as tar:
    tar.extractall(path=extract_to_path)
    print(f"Extracted contents of {input_tar_path} to {extract_to_path}")

# Creating a new tar file with bz2 compression and adding files to it
with tarfile.open(output_tar_path, 'w:bz2') as tar:
    # Assuming you want to add the extracted files to the new tar file
    for root, dirs, files in os.walk(extract_to_path):
        for file in files:
            full_path = os.path.join(root, file)
            tar.add(full_path, arcname=os.path.relpath(full_path, extract_to_path))
    print(f"Created a new bz2 compressed tar file: {output_tar_path}")

