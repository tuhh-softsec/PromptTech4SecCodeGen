import bcrypt

def get_user_input():
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    return username, password

def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def register_user(username, hashed_password):
    # Here you would store the username and hashed password in a database or file
    # For demonstration purposes, we'll just print them
    print(f"Username: {username}")
    print(f"Hashed Password: {hashed_password}")

def main():
    username, password = get_user_input()
    hashed_password = hash_password(password)
    register_user(username, hashed_password)

if __name__ == "__main__":
    main()

