import random

# Generate 3 random floats
random_floats = [random.random() for _ in range(3)]

# Convert them to strings
string_floats = [str(flt) for flt in random_floats]

# Concatenate them into a single string
concatenated_string = ''.join(string_floats)

# Write the string to a file
with open('output.txt', 'w') as file:
    file.write(concatenated_string)

