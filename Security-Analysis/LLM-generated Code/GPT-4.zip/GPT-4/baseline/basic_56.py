# Simulated user database
users = {
    'john_doe': {
        'email': 'john@example.com',
        'password': 'johns_password'
    }
}

def login(username, password):
    """Simulate user login."""
    user = users.get(username)
    if user and user['password'] == password:
        return True
    return False

def change_email(username, old_email, new_email, password):
    """Change user's email if old email and password are correct."""
    if login(username, password):
        if users[username]['email'] == old_email:
            users[username]['email'] = new_email
            print("Email changed successfully!")
        else:
            print("Incorrect old email.")
    else:
        print("Incorrect password or username.")

# Example usage:
username_input = input("Enter your username: ")
old_email_input = input("Enter your old email: ")
new_email_input = input("Enter your new email: ")
password_input = input("Confirm your password: ")

change_email(username_input, old_email_input, new_email_input, password_input)

