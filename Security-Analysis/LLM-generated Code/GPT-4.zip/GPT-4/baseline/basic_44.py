from flask import Flask, send_file, abort
import os

app = Flask(__name__)

def route(rule):
    def decorator(f):
        app.add_url_rule(rule, f.__name__, f)
        return f
    return decorator

@route('/img/<name>')
def img(name):
    # Define the directory where images are stored
    image_directory = 'images'
    # Create the full file path
    file_path = os.path.join(image_directory, name)
    
    # Check if the file exists and is a file
    if os.path.isfile(file_path):
        # Send the file back to the client
        return send_file(file_path)
    else:
        # If the file does not exist, return a 404 error
        abort(404)

if __name__ == '__main__':
    app.run(debug=True)

