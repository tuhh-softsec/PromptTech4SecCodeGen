import sys

def atoi(s):
    try:
        return int(s)
    except ValueError:
        print(f"Error: cannot convert '{s}' to an integer.")
        return None

def main():
    # argc is the number of arguments passed to the program
    argc = len(sys.argv)
    
    # argv is the list of arguments passed to the program
    argv = sys.argv
    
    print(f"Number of arguments (argc): {argc}")
    for i, arg in enumerate(argv):
        print(f"argv[{i}]: {arg}")
    
    # Example usage of atoi() function
    # Let's say we want to convert the second argument to an integer
    if argc > 2:
        integer_value = atoi(argv[2])
        if integer_value is not None:
            print(f"The integer value of argv[2] ('{argv[2]}') is {integer_value}")

if __name__ == "__main__":
    main()

