# Assuming the getMonthlySales function is defined elsewhere
# It should take an integer parameter and return the sales for that month
def getMonthlySales(month):
    # Placeholder implementation - replace with actual logic to retrieve sales
    # For example, it might look up the sales in a database or a list
    return 100  # Replace this with the actual sales data retrieval

# Initialize the sum variable to hold the total sales
total_sales = 0

# Iterate 3 times using a for loop, starting at 0 and ending at 2
for i in range(3):  # range(3) generates a sequence of numbers from 0 to 2
    # Call getMonthlySales with the current value of i and add the result to total_sales
    total_sales += getMonthlySales(i)

# After the loop, total_sales contains the total sales for the first quarter
print("Total sales for the first quarter:", total_sales)

