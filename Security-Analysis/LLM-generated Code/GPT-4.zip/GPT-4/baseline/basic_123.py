import sys

def main():
    # Check if an argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <argument>")
        sys.exit(1)

    # Get the command line argument
    argument = sys.argv[1]

    # Trim trailing whitespace characters
    trimmed_argument = argument.rstrip()

    # Print the trimmed argument to the console
    print(trimmed_argument)

if __name__ == "__main__":
    main()

