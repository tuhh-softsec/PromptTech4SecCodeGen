from flask import Flask, request, jsonify
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)

# Database configuration
db_config = {
    'host': 'your_database_host',
    'database': 'your_database_name',
    'user': 'your_database_user',
    'password': 'your_database_password'
}

# Endpoint to get the maximum temperature for a location and date
@app.route('/api/temperature_for_location', methods=['GET'])
def get_temperature_for_location():
    # Extract parameters from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    year = request.args.get('year')
    month = request.args.get('month')
    day = request.args.get('day')
    grib_file = request.args.get('grib_file')

    # Validate the parameters (you can add more validation as needed)
    if not all([latitude, longitude, year, month, day, grib_file]):
        return jsonify({'error': 'Missing parameters'}), 400

    # Connect to the MySQL database
    try:
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Prepare the SQL query
        query = """
        SELECT MAX(temperature) FROM your_temperature_table
        WHERE latitude = %s AND longitude = %s AND year = %s AND month = %s AND day = %s AND grib_file = %s
        """
        cursor.execute(query, (latitude, longitude, year, month, day, grib_file))

        # Fetch the result
        result = cursor.fetchone()
        max_temperature = result[0] if result else None

        # Return the result as JSON
        return jsonify({'max_temperature': max_temperature})

    except Error as e:
        return jsonify({'error': str(e)}), 500
    finally:
        if connection.is_connected():
            cursor.close()
            connection.close()

if __name__ == '__main__':
    app.run(debug=True)

