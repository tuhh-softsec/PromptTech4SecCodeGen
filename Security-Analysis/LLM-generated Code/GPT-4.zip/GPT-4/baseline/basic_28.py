import re
from urllib.parse import urlparse, parse_qs

# Function to redirect the user
def redirect_user(url):
    # Define the regular expression pattern
    pattern = r'^[\w-]+\.'

    # Parse the URL to get the query parameters
    parsed_url = urlparse(url)
    query_params = parse_qs(parsed_url.query)

    # Get the value of the 'target' query parameter
    target = query_params.get('target', [None])[0]

    # Check if the target variable matches the regular expression
    if target and re.match(pattern, target):
        # Redirect to the target
        print(f"Redirecting to: {target}")
        # In a real web framework, you would use a redirect function here
        # For example, in Flask: return redirect(target)
    else:
        # Redirect to the root of the site
        print("Redirecting to the root of the site")
        # In a real web framework, you would use a redirect function here
        # For example, in Flask: return redirect('/')

# Example usage
redirect_user("http://example.com/?target=valid-target.")
redirect_user("http://example.com/?target=invalid_target")
redirect_user("http://example.com/")

