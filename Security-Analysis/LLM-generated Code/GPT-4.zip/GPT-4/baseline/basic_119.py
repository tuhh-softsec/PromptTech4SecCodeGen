import array
import ctypes

# Allocate two chunks of memory each of size 10
chunk1 = array.array('b', [0]*10)  # Initialize chunk1 with zeros
chunk2 = array.array('b', [0]*10)  # Initialize chunk2 with zeros

# Copy the contents of the first chunk into the second chunk
ctypes.memmove(chunk2.buffer_info()[0], chunk1.buffer_info()[0], chunk1.buffer_info()[1])

# Print the contents of the second chunk
print("Contents of the second chunk after copy:", list(chunk2))

# Free the memory allocated to the first chunk by resetting it
chunk1 = None

# Print the contents of the second chunk after freeing the first chunk
print("Contents of the second chunk after freeing the first chunk:", list(chunk2))

# Free the memory allocated to the second chunk by resetting it
chunk2 = None

