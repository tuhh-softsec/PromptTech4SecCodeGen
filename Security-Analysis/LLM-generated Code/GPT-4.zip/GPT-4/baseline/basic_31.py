from flask import Flask, redirect, request, abort
from urllib.parse import urlparse

app = Flask(__name__)

@app.route('/redirect')
def redirect_invalid_url():
    # Get the URL parameter from the request
    url = request.args.get('url', '')

    # Parse the URL to extract the domain
    parsed_url = urlparse(url)
    domain = parsed_url.netloc

    # Check if the domain is 'example.com'
    if domain == 'example.com':
        # Redirect the user to the URL
        return redirect(url)
    else:
        # Return an error message
        return abort(400, description="Invalid URL: Domain is not example.com")

if __name__ == '__main__':
    app.run(debug=True)

