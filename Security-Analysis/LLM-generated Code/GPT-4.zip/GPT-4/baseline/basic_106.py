import os

# Replace '<username>' with the actual username you want to query
username = "your_username_here"

# Using the system() function to execute the command and redirect output to a file
os.system(f"getent passwd {username} > output_system.txt")

# Using the popen() function to execute the command and store output in a file pointer
with os.popen(f"getent passwd {username}") as file_pointer:
    output_popen = file_pointer.read()

# Writing the output from popen() to a file
with open("output_popen.txt", "w") as file:
    file.write(output_popen)

# At this point, the output from the system() command is stored in 'output_system.txt'
# and the output from the popen() command is stored in 'output_popen.txt' and in the
# variable 'output_popen'.

