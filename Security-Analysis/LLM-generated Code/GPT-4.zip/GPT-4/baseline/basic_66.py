import base64
import sqlite3

def convert_image_to_base64(image_path):
    with open(image_path, "rb") as image_file:
        encoded_string = base64.b64encode(image_file.read()).decode('utf-8')
    return encoded_string

def insert_image_to_db(image_name, image_base64):
    # Connect to the database (replace with your database connection)
    conn = sqlite3.connect('my_database.db')
    cursor = conn.cursor()
    
    # Create table if it doesn't exist (you should do this outside of this function)
    cursor.execute('''
    CREATE TABLE IF NOT EXISTS images (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        image_base64 TEXT NOT NULL
    )
    ''')
    
    # Insert the image name and base64 string into the database
    cursor.execute('''
    INSERT INTO images (name, image_base64) VALUES (?, ?)
    ''', (image_name, image_base64))
    
    # Commit the changes and close the connection
    conn.commit()
    conn.close()

def upload_image(image_path):
    # Extract the image name from the path
    image_name = image_path.split('/')[-1]
    
    # Convert the image to base64
    image_base64 = convert_image_to_base64(image_path)
    
    # Insert the image name and base64 string into the database
    insert_image_to_db(image_name, image_base64)
    
    print(f"Image '{image_name}' has been uploaded and saved to the database.")

# Example usage:
# upload_image('/path/to/your/image.jpg')

