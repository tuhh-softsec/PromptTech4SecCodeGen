import sys

# Check if exactly one argument is provided
if len(sys.argv) == 2:
    argument = sys.argv[1]
    
    # Check if the argument is a string
    if isinstance(argument, str):
        # Trim trailing whitespace from the string
        argument = argument.rstrip()
        
        # Trim newlines from the string
        argument = argument.replace('\n', '')
        
        # Null-terminate the string
        argument += '\0'
        
        print(f"Processed string: {argument}")
    else:
        print("The argument provided is not a string.")
else:
    print("Please provide exactly one argument.")

