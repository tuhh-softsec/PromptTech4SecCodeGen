from flask import Flask, send_from_directory, abort
import os

app = Flask(__name__)

def route(url):
    def decorator(func):
        app.add_url_rule(url, func.__name__, func)
        return func
    return decorator

@route('/images/<filename>')
def send_image(filename):
    image_directory = os.path.join(app.root_path, 'images')
    if os.path.isfile(os.path.join(image_directory, filename)):
        return send_from_directory(image_directory, filename)
    else:
        abort(404)  # File not found

if __name__ == '__main__':
    app.run(debug=True)

