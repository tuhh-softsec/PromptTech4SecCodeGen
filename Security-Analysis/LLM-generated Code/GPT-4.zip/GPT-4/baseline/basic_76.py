class Person:
    def __init__(self):
        self.status = None

def allocate_person():
    # Simulate memory allocation by creating a new Person instance
    new_person = Person()
    # Set the status to 0
    new_person.status = 0
    # Return a reference to the new person object
    return new_person

# Allocate a new person and set the status
person_pointer = allocate_person()

# Access the status of the person using the dot operator
print(person_pointer.status)  # Output: 0

