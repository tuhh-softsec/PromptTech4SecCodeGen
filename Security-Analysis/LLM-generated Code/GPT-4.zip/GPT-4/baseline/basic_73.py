class Person:
    def __init__(self):
        self.status = 0

# Allocate a new Person instance
new_person = Person()

# Set the status to 0 (although it's already set in the __init__ method)
new_person.status = 0

# Access the status of the new person
print(new_person.status)

