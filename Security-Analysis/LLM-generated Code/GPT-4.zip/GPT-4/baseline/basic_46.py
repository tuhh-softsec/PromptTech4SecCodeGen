from flask import Flask, send_file, request, abort
import os

app = Flask(__name__)

@app.route('/img')
def img():
    # Get the filename from the query parameter 'file'
    filename = request.args.get('file')
    
    # Check if the filename is not None and is not trying to access files outside the allowed directory
    if filename and not os.path.isabs(filename) and not filename.startswith(".."):
        # Define the path to the image directory
        image_directory = 'path/to/your/image/directory'
        # Create the full file path
        file_path = os.path.join(image_directory, filename)
        
        # Check if the file exists
        if os.path.isfile(file_path):
            # Open the file in read binary mode and return it
            return send_file(file_path, mimetype='image/jpeg')
        else:
            # If the file does not exist, return a 404 error
            abort(404, description="Image not found.")
    else:
        # If the filename is not provided or is invalid, return a 400 error
        abort(400, description="Invalid file name.")

if __name__ == '__main__':
    app.run(debug=True)

