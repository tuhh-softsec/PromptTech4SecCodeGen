import html

def escape_html(text):
    """Escapes HTML characters in a string."""
    return html.escape(text)

def http_hello_page(request, response):
    """
    Constructs a response that greets the user by username and writes it to the response stream.
    
    :param request: A file stream containing the client's request.
    :param response: A file stream to write the response to.
    """
    # Read the request stream to get the username
    # Assuming the username is sent in a simple format like "username=JohnDoe"
    request_content = request.read()
    username_key_value = request_content.decode().split('&')[0]  # Get the first key-value pair
    username = username_key_value.split('=')[1] if '=' in username_key_value else 'Guest'
    
    # Escape HTML to prevent HTML injection
    safe_username = escape_html(username)
    
    # Construct the response
    response_content = f"Hello {safe_username}!"
    
    # Write the HTTP headers
    response.write(b"HTTP/1.1 200 OK\r\n")
    response.write(b"Content-Type: text/plain\r\n")
    response.write(b"Connection: close\r\n")
    response.write(b"\r\n")
    
    # Write the response content
    response.write(response_content.encode())

# Example usage:
# with open('request.txt', 'rb') as request_stream, open('response.txt', 'wb') as response_stream:
#     http_hello_page(request_stream, response_stream)

