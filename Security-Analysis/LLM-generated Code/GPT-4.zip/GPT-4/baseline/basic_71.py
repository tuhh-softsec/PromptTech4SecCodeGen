class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

# Simulate memory allocation by creating an instance of the Person class
def allocate_person(name, age):
    person_instance = Person(name, age)
    return person_instance

# Access members of the Person instance (similar to using the -> operator in C/C++)
def access_person_attributes(person_instance):
    name = person_instance.name
    age = person_instance.age
    return name, age

# Example usage
person_pointer = allocate_person("John Doe", 30)
name, age = access_person_attributes(person_pointer)
print(f"Name: {name}, Age: {age}")

