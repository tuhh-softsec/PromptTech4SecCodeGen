def http_hello_page(request, response):
    # Read the username from the request file stream
    username = request.read().strip()
    
    # Construct the HTTP response
    http_response = f"""HTTP/1.1 200 OK
Content-Type: text/html

<html>
<head>
    <title>Hello Page</title>
</head>
<body>
    <h1>Hello {username}</h1>
</body>
</html>
"""
    
    # Write the response to the response file stream
    response.write(http_response)
    response.flush()

# Example usage:
# Assuming 'request_stream' is a file-like object that contains the username
# and 'response_stream' is a file-like object where the HTTP response will be written.
# http_hello_page(request_stream, response_stream)

