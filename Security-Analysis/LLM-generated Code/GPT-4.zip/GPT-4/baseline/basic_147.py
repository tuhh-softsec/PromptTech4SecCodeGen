from flask import Flask, request, redirect, render_template, url_for
import sqlite3

app = Flask(__name__)

# Assuming you have a function to insert messages into the database
def insert_user_message_in_db(username, message):
    # Here you would insert the message into the database
    # This is just a placeholder function
    pass

# Route to handle the form submission
@app.route('/post', methods=['POST'])
def post_message():
    username = request.form['username']
    message = request.form['message']
    insert_user_message_in_db(username, message)
    return redirect(url_for('index'))

# Route to display messages
@app.route('/')
def index():
    # Here you would retrieve messages from the database
    # For demonstration purposes, let's use a static list of messages
    messages = [
        {'username': 'Alice', 'message': 'Hello, World!'},
        {'username': 'Bob', 'message': 'Flask is awesome!'}
    ]
    return render_template('index.html', messages=messages)

if __name__ == '__main__':
    app.run(debug=True)

