def get_value_at_index(array, index):
    # Check if the index is -1 or out of the array bounds
    if index == -1 or index >= len(array):
        return -1
    # Return the value at the given index
    return array[index]

# Example usage:
# Define an array with some values
my_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

# Get user input and convert it to an integer
user_input = int(input("Enter an index: "))

# Call the function with the user input and print the result
result = get_value_at_index(my_array, user_input)
print(f"The value at index {user_input} is: {result}")

