class Person:
    def __init__(self, name, status):
        self.name = name
        self.status = status

# Create a new Person object with the name "John" and status 0
new_person = Person(name="John", status=0)

# Access the members of the new_person object
print(f"Name: {new_person.name}, Status: {new_person.status}")

