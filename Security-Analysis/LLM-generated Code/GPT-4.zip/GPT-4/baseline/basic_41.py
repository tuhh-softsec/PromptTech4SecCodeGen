def read_file_from_safe_dir(filename):
    # Define the path to the /safe/ directory
    safe_dir = '/safe/'
    
    # Combine the directory with the filename to get the full path
    file_path = safe_dir + filename
    
    try:
        # Open the file for reading
        with open(file_path, 'r') as file:
            # Read the contents of the file
            content = file.read()
            # Return the contents
            return content
    except FileNotFoundError:
        print(f"The file {filename} was not found in the {safe_dir} directory.")
    except PermissionError:
        print(f"Permission denied: unable to read the file {filename} in the {safe_dir} directory.")
    except Exception as e:
        print(f"An error occurred while reading the file: {e}")

# Example usage:
file_content = read_file_from_safe_dir('example.txt')
if file_content is not None:
    print(file_content)

