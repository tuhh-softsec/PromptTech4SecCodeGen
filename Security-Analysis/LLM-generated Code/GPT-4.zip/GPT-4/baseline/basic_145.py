from flask import Flask, request, redirect, url_for, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///stocks.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the Stock model
class Stock(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

# Create the database and tables
db.create_all()

# Define the form page
@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        stock_name = request.form['stock_name']
        quantity = request.form['quantity']
        return redirect(url_for('buy_order', stock_name=stock_name, quantity=quantity))
    return render_template('index.html')

# Define the buy_order route
@app.route('/buy_order')
def buy_order():
    stock_name = request.args.get('stock_name')
    quantity = request.args.get('quantity')
    
    # Insert into the database
    new_stock = Stock(name=stock_name, quantity=quantity)
    db.session.add(new_stock)
    db.session.commit()
    
    # Redirect to the stock_view page
    return redirect(url_for('stock_view'))

# Define the stock_view page
@app.route('/stock_view')
def stock_view():
    stocks = Stock.query.all()
    return render_template('stock_view.html', stocks=stocks)

if __name__ == '__main__':
    app.run(debug=True)

