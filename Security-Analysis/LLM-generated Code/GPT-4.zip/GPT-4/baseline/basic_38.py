from flask import Flask, session, render_template_string

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

@app.route('/info', methods=['GET'])
def info():
    # Ensure the session variables exist
    if 'username' in session and 'email' in session and 'ssn' in session:
        # Extract the last 4 digits of the SSN
        ssn_last_4 = session['ssn'][-4:]
        # Render a simple page with the information
        return render_template_string('''
            <!DOCTYPE html>
            <html>
            <head>
                <title>User Info</title>
            </head>
            <body>
                <h1>User Information</h1>
                <p>Username: {{ username }}</p>
                <p>Email: {{ email }}</p>
                <p>SSN (last 4 digits): {{ ssn_last_4 }}</p>
            </body>
            </html>
        ''', username=session['username'], email=session['email'], ssn_last_4=ssn_last_4)
    else:
        return "Session variables not set", 400

if __name__ == '__main__':
    app.run(debug=True)

