from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

# Dummy function to simulate database check (replace with actual database check)
def check_user_credentials(username, password):
    # This should be replaced with actual database check logic
    # For demonstration purposes, we assume the correct credentials are 'admin' and 'password'
    return username == 'admin' and password == 'password'

@app.route('/')
def home():
    return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    error = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if check_user_credentials(username, password):
            return redirect(url_for('dashboard'))
        else:
            error = 'Invalid username or password. Please try again.'
    return render_template('login.html', error=error)

@app.route('/dashboard')
def dashboard():
    return 'Welcome to the dashboard!'

if __name__ == '__main__':
    app.run(debug=True)

