import sys

def print_argument_at_index(index):
    # Check if the number of arguments is sufficient
    if len(sys.argv) <= index + 1:
        print(f"Error: No argument found at index {index}")
        return

    # Print the argument at the specified index
    print(sys.argv[index + 1])

if __name__ == "__main__":
    # Check if an index argument is provided
    if len(sys.argv) < 2:
        print("Usage: python argv_index.py <index>")
    else:
        try:
            # Convert the first argument to an integer index
            index = int(sys.argv[1])
            print_argument_at_index(index)
        except ValueError:
            print("Error: The index must be an integer.")

