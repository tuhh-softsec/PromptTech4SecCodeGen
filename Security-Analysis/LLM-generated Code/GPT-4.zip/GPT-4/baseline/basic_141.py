from flask import Flask, request, jsonify
import sqlite3

app = Flask(__name__)

DATABASE = 'path_to_your_database.db'

def is_email_subscribed(email):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE email = ?", (email,))
    user = cursor.fetchone()
    conn.close()
    return user is not None

def remove_user_from_database(email):
    conn = sqlite3.connect(DATABASE)
    cursor = conn.cursor()
    cursor.execute("DELETE FROM users WHERE email = ?", (email,))
    conn.commit()
    conn.close()

def unsubscribe_user_from_mailing_list(email):
    # This function should contain the logic to unsubscribe a user from the mailing list.
    # This could be an API call to your email service provider or an internal method.
    pass

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email')
    if not email:
        return jsonify({'error': 'Missing email parameter'}), 400

    if is_email_subscribed(email):
        remove_user_from_database(email)
        unsubscribe_user_from_mailing_list(email)
        return jsonify({'message': 'You have been successfully unsubscribed'}), 200
    else:
        return jsonify({'message': 'User not subscribed'}), 404

if __name__ == '__main__':
    app.run(debug=True)

