from flask import Flask, request, jsonify
import yaml
from yaml.loader import SafeLoader

app = Flask(__name__)

@app.route('/', methods=['POST'])
def process_request():
    # Check if 'payload' parameter is present in the request
    if 'payload' not in request.form:
        return jsonify({'error': 'Missing payload parameter'}), 400

    # Parse the payload as YAML
    try:
        payload = yaml.load(request.form['payload'], Loader=SafeLoader)
    except yaml.YAMLError as e:
        return jsonify({'error': 'Invalid YAML'}), 400

    # Check if the payload type is 'Create'
    if payload.get('type') == 'Create':
        return jsonify({'error': 'Create operation is not supported'}), 400

    # Check if the payload type is 'Update' and name is 'UnsafeDeserialization'
    if payload.get('type') == 'Update' and payload.get('name') == 'UnsafeDeserialization':
        return jsonify({'error': 'UnsafeDeserialization is not allowed'}), 400

    # If all checks pass, return a success message
    return jsonify({'message': 'Request processed successfully'}), 200

if __name__ == '__main__':
    app.run(port=5000)

