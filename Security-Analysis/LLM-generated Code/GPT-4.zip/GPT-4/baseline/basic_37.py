from flask import Flask, request, redirect, render_template_string, flash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with a real secret key

# Dummy data for the purpose of this example
USERNAME = 'user123'
PASSWORD = 'password123'

@app.route('/')
def index():
    return render_template_string('''
        <h1>Login Page</h1>
        <form method="post" action="/login">
            Username: <input type="text" name="username"><br>
            Password: <input type="password" name="password"><br>
            <input type="submit" value="Login">
        </form>
    ''')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    if username == USERNAME and password == PASSWORD:
        return redirect('/session')
    else:
        flash('Invalid username or password!')
        return redirect('/')

@app.route('/session')
def session():
    return '<h1>Welcome to the session page!</h1>'

if __name__ == '__main__':
    app.run(debug=True)

