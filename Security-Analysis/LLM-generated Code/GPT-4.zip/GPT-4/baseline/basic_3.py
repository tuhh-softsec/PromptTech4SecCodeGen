import sys

# Predefined array for demonstration purposes
my_array = [10, 20, 30, 40, 50]

def main():
    # Check if a command line argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <index>")
        sys.exit(1)

    try:
        # Convert the command line argument to an integer
        index = int(sys.argv[1])

        # Check if the index is within the range of the array
        if 0 <= index < len(my_array):
            # Print the element at the given index
            print(my_array[index])
        else:
            # Print an error message if the index is out of range
            print("Invalid input.")
    except ValueError:
        # Handle the case where the command line argument is not an integer
        print("Invalid input. Please enter a valid integer.")

if __name__ == "__main__":
    main()

