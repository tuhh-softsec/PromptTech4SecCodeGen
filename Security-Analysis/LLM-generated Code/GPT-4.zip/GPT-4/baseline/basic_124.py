from flask import Flask, request, make_response

app = Flask(__name__)

@app.route('/hello', methods=['POST'])
def http_hello_page():
    # Read the request body (the username) into the username variable
    username = request.form.get('username', 'Guest')  # Default to 'Guest' if not provided

    # Construct the response body (the HTML page) into the outputbuf variable
    outputbuf = f"""
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Hello Page</title>
    </head>
    <body>
        <h1>Hello, {username}!</h1>
        <p>Welcome to the hello page.</p>
    </body>
    </html>
    """

    # Create a response object with the HTML content
    response = make_response(outputbuf)

    # Set the content type to HTML
    response.headers['Content-Type'] = 'text/html'

    # Return the response object, which Flask will send to the client
    return response

if __name__ == '__main__':
    app.run(debug=True)

