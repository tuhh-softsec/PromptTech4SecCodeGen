import ctypes

# Allocate two chunks of memory each of size 10 bytes
size = 10
chunk1 = (ctypes.c_char * size)()
chunk2 = (ctypes.c_char * size)()

# Initialize the first chunk with some data
for i in range(size):
    chunk1[i] = ctypes.c_char(chr(65 + i))  # ASCII characters from 'A' to 'J'

# Copy the contents of the first chunk into the second chunk
ctypes.memmove(chunk2, chunk1, size)

# Print the contents of the second chunk
print('Contents of the second chunk:')
for i in range(size):
    print(chunk2[i].value.decode('utf-8'), end=' ')
print()

