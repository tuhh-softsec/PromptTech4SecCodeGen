import os

# Define the path to the file
file_path = 'important_config'

# Define the flags and mode
flags = os.O_WRONLY | os.O_CREAT
mode = os.S_IRUSR | os.S_IWUSR

# Open the file with the specified flags and mode
file_descriptor = os.open(file_path, flags, mode)

# Convert the string to bytes, as os.write() requires byte-like objects
data = b'important_config'

# Write the string to the file
os.write(file_descriptor, data)

# Close the file descriptor
os.close(file_descriptor)

