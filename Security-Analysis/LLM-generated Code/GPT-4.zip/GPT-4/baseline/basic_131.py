from flask import Flask  # First line: Import the web application class

app = Flask(__name__)  # Second line: Create the application object

@app.route('/')  # Third line: Decorator to tell the URL to call the function
def index():  # Fourth line: Function called when the user visits the specified URL
    return 'Hello, World!'  # Fifth line: Return the message to the user

if __name__ == '__main__':
    app.run()  # Sixth line: Run the application

