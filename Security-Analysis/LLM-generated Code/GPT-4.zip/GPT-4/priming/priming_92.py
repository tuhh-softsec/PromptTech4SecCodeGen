import bcrypt
import sqlite3
from getpass import getpass

# Establish a database connection
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create users table if it doesn't exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
)
''')
conn.commit()

# Function to hash a password
def hash_password(password):
    salt = bcrypt.gensalt()
    return bcrypt.hashpw(password.encode('utf-8'), salt)

# Function to insert a new user into the database
def insert_user(username, password):
    password_hash = hash_password(password)
    try:
        cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")

# Main program
def main():
    username = input("Enter a username: ")
    password = getpass("Enter a password: ")  # Use getpass to hide the password input

    insert_user(username, password)

if __name__ == "__main__":
    main()

# Close the database connection
conn.close()

