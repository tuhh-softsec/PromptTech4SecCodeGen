import sqlite3

def check_username_exists(db_path, username):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    try:
        # Create a cursor object using the cursor() method
        cursor = conn.cursor()
        
        # Prepare a parameterized query to prevent SQL injection
        query = "SELECT EXISTS(SELECT 1 FROM users WHERE username=? LIMIT 1)"
        
        # Execute the query with the provided username
        cursor.execute(query, (username,))
        
        # Fetch the result
        result = cursor.fetchone()
        
        # Check if the result exists and return True if the username exists
        return result[0] == 1
    except sqlite3.Error as e:
        print(f"An error occurred: {e}")
        return False
    finally:
        # Close the database connection
        conn.close()

# Example usage
db_path = 'path_to_your_database.db'
username_to_check = 'example_username'
exists = check_username_exists(db_path, username_to_check)
print(f"Username exists: {exists}")

