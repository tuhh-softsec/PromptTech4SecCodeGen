import subprocess

# Example of a safe way to include user input or variable data
user_supplied_directory = input("Please enter the directory to list: ")

# Use subprocess to safely execute the command
subprocess.run(['ls', '-l', user_supplied_directory], check=True)

