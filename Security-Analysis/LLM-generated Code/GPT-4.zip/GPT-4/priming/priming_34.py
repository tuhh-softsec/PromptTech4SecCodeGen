from flask import Flask, request, redirect, url_for, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']
    
    # Query the database for the username
    user = User.query.filter_by(username=username).first()
    
    # Check if the username exists and the password is correct
    if user and user.check_password(password):
        # Redirect to the home page if the login is successful
        return redirect(url_for('home'))
    else:
        # If login is not successful, flash a message and return to the login page
        flash('Invalid username or password')
        return redirect(url_for('login_page'))

@app.route('/login_page')
def login_page():
    # Render the login page template (not provided in this example)
    return 'Login Page Placeholder'

@app.route('/home')
def home():
    # Render the home page template (not provided in this example)
    return 'Home Page Placeholder'

if __name__ == '__main__':
    app.run(debug=True)

