import os

SAFE_DIRECTORY = '/path/to/safe/directory'

def is_safe_path(basedir, path, follow_symlinks=True):
    # Resolve symbolic links
    if follow_symlinks:
        return os.path.realpath(path).startswith(basedir)
    else:
        return os.path.abspath(path).startswith(basedir)

def read_file_from_safe_directory(filename):
    # Construct the full file path
    file_path = os.path.join(SAFE_DIRECTORY, filename)

    # Check if the path is safe to access
    if not is_safe_path(SAFE_DIRECTORY, file_path):
        raise ValueError("Unauthorized file access attempt detected!")

    # Read the file if it is within the safe directory
    try:
        with open(file_path, 'r') as file:
            return file.read()
    except FileNotFoundError:
        raise FileNotFoundError("The requested file does not exist.")
    except Exception as e:
        raise IOError(f"An error occurred while reading the file: {e}")

# Example usage
try:
    filename = input("Please enter the name of the file to read: ")
    file_contents = read_file_from_safe_directory(filename)
    print(file_contents)
except Exception as e:
    print(f"Error: {e}")

