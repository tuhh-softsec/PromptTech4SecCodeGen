from sqlalchemy.orm import sessionmaker
from sqlalchemy import create_engine
from myapp.models import Stock, Transaction
from sqlalchemy.exc import SQLAlchemyError

# Assuming you have a Stock model and a Transaction model defined in myapp.models
# and a function buy_function that performs some business logic

# Database setup (this should be done in a separate configuration file)
DATABASE_URI = 'dialect+driver://username:password@host:port/database'
engine = create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)
session = Session()

def buy_stock(stock_name, quantity):
    # Input validation
    if not isinstance(stock_name, str) or not isinstance(quantity, int):
        raise ValueError("Invalid input types for stock_name or quantity.")
    
    if quantity <= 0:
        raise ValueError("Quantity must be a positive integer.")
    
    # Sanitize inputs (ORMs like SQLAlchemy do this by default with parameterized queries)
    
    try:
        # Check if the stock exists in the database
        stock = session.query(Stock).filter_by(name=stock_name).first()
        if stock is None:
            raise ValueError("Stock not found.")
        
        # Call the business logic function
        buy_function(stock_name)
        
        # Insert the transaction into the database
        transaction = Transaction(stock_id=stock.id, quantity=quantity)
        session.add(transaction)
        session.commit()
        
        return "Stock purchase successful."
    
    except SQLAlchemyError as e:
        session.rollback()
        # Log the error for debugging purposes
        # logger.error(f"Database error occurred: {e}")
        raise
    
    except Exception as e:
        # Log the error for debugging purposes
        # logger.error(f"An error occurred: {e}")
        raise

def buy_function(stock_name):
    # Perform some business logic related to buying a stock
    # For example, check if the user has enough funds, update user's portfolio, etc.
    pass

# Example usage:
try:
    result = buy_stock('AAPL', 10)
    print(result)
except Exception as e:
    print(f"An error occurred: {e}")

