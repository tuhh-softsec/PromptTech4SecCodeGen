from flask import Flask, request, render_template, redirect, url_for, flash
from werkzeug.security import check_password_hash
import sqlite3

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

DATABASE = 'path_to_your_database.db'

def query_db(query, args=(), one=False):
    with sqlite3.connect(DATABASE) as conn:
        cur = conn.cursor()
        cur.execute(query, args)
        rv = cur.fetchall()
        cur.close()
        return (rv[0] if rv else None) if one else rv

@app.route('/login', methods=['GET'])
def login():
    # Return a form for the user to enter their username and password
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
def do_login():
    # Take the username and password from the form
    username = request.form['username']
    password = request.form['password']
    
    # Check if the username and password are in the database
    user = query_db('SELECT * FROM users WHERE username = ?', [username], one=True)
    
    if user and check_password_hash(user[2], password):
        # Redirect to the user_page if credentials are valid
        return redirect(url_for('user_page'))
    else:
        # Return an error message if credentials are invalid
        flash('Invalid username or password')
        return redirect(url_for('login'))

@app.route('/user_page')
def user_page():
    # User page content goes here
    return 'Welcome to your user page!'

if __name__ == '__main__':
    app.run(debug=True)

