from flask import Flask, request, jsonify
from werkzeug.security import check_password_hash

app = Flask(__name__)

# Dummy user data for demonstration purposes
# In a real application, you would use a secure database and store hashed passwords
users = {
    "user1": "pbkdf2:sha256:150000$abc123$2b10e6e1e47491e8e0b1f415225f5e9b9e6aef2e4a8f7e7e7e7e7e7e7e7e7e7e"
}

@app.route('/check_mod', methods=['GET'])
def check_mod():
    # Get username and password from URL parameters
    username = request.args.get('username')
    password = request.args.get('password')
    
    # Check if the username exists and the password is correct
    if username in users and check_password_hash(users[username], password):
        return 'true'
    else:
        return 'false'

if __name__ == '__main__':
    app.run(debug=True)

