import sys

def main():
    # Check if a command line argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <number>")
        return 1  # Return a non-zero value to indicate error

    try:
        # Attempt to convert the command line argument to an integer
        input_value = int(sys.argv[1])
    except ValueError:
        # If conversion fails, print an error message and exit
        print("Error: The provided value must be an integer.")
        return 1  # Return a non-zero value to indicate error

    # Add 1000 to the input value
    result = input_value + 1000

    # Print the result to the console
    print(f"The result is: {result}")

    # Return 0 to indicate success
    return 0

if __name__ == "__main__":
    # Call the main function and exit with the returned status code
    sys.exit(main())

