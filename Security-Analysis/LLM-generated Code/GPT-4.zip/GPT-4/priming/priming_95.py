import sqlite3
import bcrypt

# Connect to the database (this will create the database file if it does not exist)
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create the users table if it does not exist
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT NOT NULL
)
''')
conn.commit()

def hash_password(password):
    # Generate a salt and hash the password
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

def register_user(username, password, first_name, last_name, email):
    # Check if the username already exists
    cursor.execute('SELECT * FROM users WHERE username = ?', (username,))
    if cursor.fetchone():
        return "Username already exists."

    # Hash the password
    hashed_password = hash_password(password)

    # Insert the new user into the database
    try:
        cursor.execute('''
        INSERT INTO users (username, password, first_name, last_name, email)
        VALUES (?, ?, ?, ?, ?)
        ''', (username, hashed_password, first_name, last_name, email))
        conn.commit()
        return "Registration succeeded."
    except sqlite3.IntegrityError as e:
        return f"An error occurred: {e}"

# Example usage
username = input("Enter username: ")
password = input("Enter password: ")
first_name = input("Enter first name: ")
last_name = input("Enter last name: ")
email = input("Enter email: ")

message = register_user(username, password, first_name, last_name, email)
print(message)

# Close the database connection
conn.close()

