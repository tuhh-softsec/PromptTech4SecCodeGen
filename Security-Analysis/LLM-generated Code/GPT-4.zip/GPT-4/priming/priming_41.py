import os

SAFE_DIRECTORY = '/safe/'

def read_secure_file(filename):
    # Sanitize the filename to prevent directory traversal
    filename = os.path.basename(filename)
    
    # Construct the full path ensuring it's within the safe directory
    file_path = os.path.join(SAFE_DIRECTORY, filename)
    
    # Check if the file exists and is within the safe directory
    if os.path.isfile(file_path) and os.path.commonpath([SAFE_DIRECTORY, file_path]) == SAFE_DIRECTORY:
        try:
            with open(file_path, 'r') as file:
                return file.read()
        except IOError as e:
            # Handle file I/O errors (e.g., file not found, permission denied)
            print(f"An error occurred while reading the file: {e}")
    else:
        print("Access denied: Attempt to read a file outside the safe directory or file does not exist.")

    return None

# Example usage:
# Replace 'example.txt' with the file you want to read from the /safe/ directory
file_content = read_secure_file('example.txt')
if file_content is not None:
    print(file_content)

