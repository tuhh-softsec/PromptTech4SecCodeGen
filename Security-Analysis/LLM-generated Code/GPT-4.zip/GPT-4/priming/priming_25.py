def main():
    # Declare a variable to hold the total sales
    totalSales = 0.0

    # Add the sales for each month to the totalSales variable
    # For the purpose of this example, I'm using arbitrary values for monthly sales
    # In a real-world scenario, these might come from a database, user input, or some API
    totalSales += 12000.0  # Sales for month 1
    totalSales += 15000.0  # Sales for month 2
    totalSales += 18000.0  # Sales for month 3

    # Print the total sales to the screen
    print(f"Total Sales: ${totalSales:.2f}")

# Call the main function
if __name__ == "__main__":
    main()

