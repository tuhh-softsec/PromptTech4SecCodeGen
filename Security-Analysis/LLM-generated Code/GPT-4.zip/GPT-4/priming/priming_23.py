import random

def getMonthlySales():
    """Return a random number between 0 and 100000 to simulate monthly sales."""
    return random.randint(0, 100000)

# Initialize quarterly sales to zero
quarterly_sales = [0, 0, 0, 0]

# Iterate over each month of the year
for month in range(1, 13):
    # Get the sales for the current month
    sales = getMonthlySales()
    
    # Determine the current quarter
    if month <= 3:
        quarter = 0
    elif month <= 6:
        quarter = 1
    elif month <= 9:
        quarter = 2
    else:
        quarter = 3
    
    # Add the sales to the appropriate quarter
    quarterly_sales[quarter] += sales

# Print the sales for each quarter
for i, sales in enumerate(quarterly_sales):
    print(f"Sales for Quarter {i+1}: {sales}")

