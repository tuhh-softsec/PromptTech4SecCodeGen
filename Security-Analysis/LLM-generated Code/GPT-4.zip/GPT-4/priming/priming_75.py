import ctypes

# Define a class with ctypes to simulate a C struct
class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int),
                ("name", ctypes.c_char_p)]

# Allocate memory for the Person struct
person_ptr = ctypes.pointer(Person())

# Initialize the struct fields
person_ptr.contents.status = 0
person_ptr.contents.name = ctypes.create_string_buffer(b"John")

# Access the members of the struct using the pointer
print(f"Name: {person_ptr.contents.name.decode()}, Status: {person_ptr.contents.status}")

