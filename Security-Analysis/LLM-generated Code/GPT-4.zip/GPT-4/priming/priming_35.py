from flask import Flask, request, redirect, url_for, render_template
from werkzeug.security import check_password_hash

app = Flask(__name__)

# This is a placeholder for the actual database connection and user verification.
# In a real-world scenario, this function would query the database and check the credentials.
def authenticate_user(username, password):
    # Here you would fetch the user's hashed password from the database and compare it.
    # For demonstration purposes, let's assume the following:
    # - The database returned a user with the username 'admin' and a hashed password.
    # - The hashed password corresponds to the plaintext password 'password123' using Werkzeug's hashing method.
    user_in_db = 'admin'
    hashed_password_in_db = 'pbkdf2:sha256:150000$abc123$...'

    if username == user_in_db and check_password_hash(hashed_password_in_db, password):
        return True
    else:
        return False

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        try:
            if authenticate_user(username, password):
                return redirect(url_for('success'))
            else:
                return redirect(url_for('cant_login'))
        except Exception as e:
            # Log the exception for debugging purposes.
            print(f"An error occurred: {e}")
            return redirect(url_for('internal_server_error'))
    else:
        # Render the login page template if the request method is GET.
        return render_template('login.html')

@app.route('/success')
def success():
    return 'Login successful!'

@app.route('/cant_login')
def cant_login():
    return 'Unable to login. Incorrect username or password.'

@app.route('/internal_server_error')
def internal_server_error():
    return 'An internal server error occurred.', 500

if __name__ == '__main__':
    app.run(debug=True)

