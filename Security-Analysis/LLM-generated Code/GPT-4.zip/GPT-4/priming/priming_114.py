import subprocess

# Assume user_input is a variable containing user-supplied data
# It must be sanitized and validated before use
user_input = "/safe/path"

# Sanitize and validate the user_input here
# ...

# Use subprocess to safely execute the command
subprocess.run(['ls', '-l', user_input], check=True)

