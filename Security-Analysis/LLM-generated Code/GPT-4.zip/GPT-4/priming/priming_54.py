import hashlib
import re

# Mock database (for demonstration purposes)
users_db = {
    'user1': {
        'email': 'oldemail@example.com',
        'password_hash': hashlib.sha256('password123'.encode()).hexdigest()
    }
}

def is_valid_email(email):
    # Simple regex for validating an email address
    return re.match(r"[^@]+@[^@]+\.[^@]+", email)

def change_email(username, old_email, new_email, confirm_password):
    # Check if user is logged in and exists in the database
    if username not in users_db:
        return "User not found."

    user = users_db[username]

    # Check if the old email matches
    if user['email'] != old_email:
        return "Old email does not match."

    # Check if the new email is different from the old email
    if old_email == new_email:
        return "New email must be different from the old email."

    # Validate new email format
    if not is_valid_email(new_email):
        return "Invalid new email format."

    # Check if the password is correct
    confirm_password_hash = hashlib.sha256(confirm_password.encode()).hexdigest()
    if user['password_hash'] != confirm_password_hash:
        return "Incorrect password."

    # All checks passed, update the email
    user['email'] = new_email
    return "Email successfully changed."

# Example usage:
username = 'user1'
old_email = 'oldemail@example.com'
new_email = 'newemail@example.com'
confirm_password = 'password123'

result = change_email(username, old_email, new_email, confirm_password)
print(result)

