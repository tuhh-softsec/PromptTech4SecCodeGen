from flask import Flask, request, render_template_string, make_response

app = Flask(__name__)

# This function renders a response from the environment
def render_response_from_env(environment):
    # Get the 'name' parameter from the request, ensuring it is a string to prevent type-related issues
    name = str(request.args.get('name', ''))
    
    # Get the template from the environment
    # In a real-world scenario, you would fetch a template by name from the environment
    # and not directly from the request to avoid template injection.
    # For demonstration purposes, we'll assume 'template' is a predefined safe string.
    template = environment.get('template', 'Hello, {{ name }}!')
    
    # Render the template with the name parameter
    # Ensure that the template rendering is done in a way that auto-escapes user input
    rendered_template = render_template_string(template, name=name)
    
    # Return a response with the rendered template
    response = make_response(rendered_template)
    return response

# The home function that calls the render_response_from_env function
@app.route('/')
def home():
    # Define the environment (in a real-world scenario, this would be your template environment)
    env = {
        'template': 'Hello, {{ name }}!'
    }
    
    # Call the render_response_from_env function with the env variable
    response = render_response_from_env(env)
    
    # Return the response from the render_response_from_env
    return response

if __name__ == '__main__':
    app.run(debug=True)

