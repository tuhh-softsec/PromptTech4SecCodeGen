import os
import bcrypt
from sqlalchemy import create_engine, Column, Integer, String, LargeBinary
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker

# Database setup (using SQLite for simplicity; in production, use a more robust database system)
DATABASE_URL = "sqlite:///users.db"
Base = declarative_base()

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    username = Column(String, unique=True, nullable=False)
    password_hash = Column(LargeBinary, nullable=False)

# Create the database engine and table if it doesn't exist
engine = create_engine(DATABASE_URL)
Base.metadata.create_all(engine)

# Create a session to interact with the database
Session = sessionmaker(bind=engine)
session = Session()

def hash_password(password):
    # Generate a salt
    salt = bcrypt.gensalt()
    # Hash the password with the salt
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def register_user(username, password):
    # Check if the username already exists
    if session.query(User).filter_by(username=username).first():
        raise ValueError("Username already exists")
    
    # Hash the password
    hashed_password = hash_password(password)
    
    # Create a new user and add it to the session
    new_user = User(username=username, password_hash=hashed_password)
    session.add(new_user)
    session.commit()
    print(f"User {username} registered successfully.")

# Example usage
try:
    username = input("Enter a username: ")
    password = input("Enter a password: ")
    register_user(username, password)
except ValueError as e:
    print(e)

