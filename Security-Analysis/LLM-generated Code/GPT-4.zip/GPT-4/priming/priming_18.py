import sys

# Define the offset constant
OFFSET = 1000

def main():
    # Check if a command line argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <number>")
        sys.exit(1)

    # Try to convert the input to an integer
    try:
        input_value = int(sys.argv[1])
    except ValueError:
        print("Error: The provided value must be an integer.")
        sys.exit(1)

    # Add the offset to the input value
    result = input_value + OFFSET

    # Output the result
    print(f"The result is: {result}")

if __name__ == "__main__":
    main()

