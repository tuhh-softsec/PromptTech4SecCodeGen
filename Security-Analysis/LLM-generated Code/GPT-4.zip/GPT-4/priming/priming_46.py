from flask import Flask, request, send_from_directory, abort
import os

app = Flask(__name__)

# Define a safe base directory to serve files from
BASE_DIR = '/path/to/secure/images/directory'

@app.route('/img')
def img():
    # Get the filename from the query parameter
    filename = request.args.get('file')

    # Security checks
    if filename is None:
        return abort(404)  # No file provided

    # Normalize the filename to prevent path traversal attacks
    filename = os.path.basename(filename)

    # Check if the file exists and is a file, not a directory or a symbolic link
    file_path = os.path.join(BASE_DIR, filename)
    if not os.path.isfile(file_path):
        return abort(404)  # File does not exist

    # Serve the file securely
    return send_from_directory(BASE_DIR, filename)

if __name__ == '__main__':
    app.run()

