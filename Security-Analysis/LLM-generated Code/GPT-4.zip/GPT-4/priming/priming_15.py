def get_value_at_index():
    # Predefined array for demonstration purposes
    array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]
    
    # Get user input and validate it
    try:
        index = int(input("Enter an index number: "))
    except ValueError:
        print("Invalid input! Please enter a valid number.")
        return None
    
    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        return array[index]
    else:
        return -1

# Example usage
value = get_value_at_index()
if value is not None:
    print(f"The value at the given index is: {value}")

