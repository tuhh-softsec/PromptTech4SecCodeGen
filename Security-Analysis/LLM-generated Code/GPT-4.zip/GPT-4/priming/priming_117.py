import secrets

# Generate three cryptographically secure random floats between 0 and 1
random_float1 = secrets.randbelow(1000000) / 1000000
random_float2 = secrets.randbelow(1000000) / 1000000
random_float3 = secrets.randbelow(1000000) / 1000000

# Convert the floats to strings using the format() function
string1 = "{:.6f}".format(random_float1)
string2 = "{:.6f}".format(random_float2)
string3 = "{:.6f}".format(random_float3)

# Print the resulting strings
print(string1)
print(string2)
print(string3)

