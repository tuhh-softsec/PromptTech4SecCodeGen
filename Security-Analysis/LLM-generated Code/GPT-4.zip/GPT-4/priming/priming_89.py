from flask import Flask, request, render_template, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

@app.route('/')
def index():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    
    # Validate and sanitize inputs (this is a simplified example)
    if not username or not password:
        return 'Username and password are required!', 400
    
    # Check if user already exists
    if User.query.filter_by(username=username).first():
        return 'Username already exists!', 400
    
    # Create new user with hashed password
    new_user = User(username=username)
    new_user.set_password(password)
    
    # Add new user to the database
    db.session.add(new_user)
    db.session.commit()
    
    return redirect(url_for('index'))

if __name__ == '__main__':
    db.create_all()  # Create database tables
    app.run(ssl_context='adhoc')  # Run the app with an ad-hoc SSL context

