# Placeholder implementation of getMonthlySales function
# In a real-world scenario, this function would retrieve actual sales data for the given month
def getMonthlySales(month):
    # Placeholder sales data for demonstration
    monthly_sales_data = {
        0: 1000,  # Sales for January
        1: 1500,  # Sales for February
        2: 1200,  # Sales for March
    }
    return monthly_sales_data.get(month, 0)  # Return sales for the month or 0 if not found

# Initialize sum to 0 to start accumulating sales
sum = 0

# Iterate 3 times starting at 0 and ending at 2
for i in range(3):
    # Call getMonthlySales with the current value of i and add the return value to sum
    sum += getMonthlySales(i)

# After the loop, sum contains the total sales for the first quarter
print(f"Total sales for the first quarter: {sum}")

