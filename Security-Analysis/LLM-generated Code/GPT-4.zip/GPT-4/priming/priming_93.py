import bcrypt
import sqlite3

# Establish a database connection
conn = sqlite3.connect('users.db')
cursor = conn.cursor()

# Create a table to store user credentials
cursor.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    salt TEXT NOT NULL
)
''')
conn.commit()

def hash_password(password):
    # Generate a random salt
    salt = bcrypt.gensalt()
    # Hash the password with the salt
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password, salt

def store_credentials(username, password):
    hashed_password, salt = hash_password(password)
    try:
        cursor.execute('INSERT INTO users (username, password_hash, salt) VALUES (?, ?, ?)', (username, hashed_password, salt))
        conn.commit()
        print("User registered successfully.")
    except sqlite3.IntegrityError:
        print("Error: Username already exists.")

def verify_password(username, password):
    cursor.execute('SELECT password_hash, salt FROM users WHERE username = ?', (username,))
    user = cursor.fetchone()
    if user:
        password_hash, salt = user
        # Verify the password
        if bcrypt.checkpw(password.encode('utf-8'), password_hash):
            print("Login successful.")
        else:
            print("Invalid password.")
    else:
        print("User not found.")

# Example usage
# Register a new user
username = input("Enter username: ")
password = input("Enter password: ")
store_credentials(username, password)

# Login with the same user
username = input("Enter username for login: ")
password = input("Enter password for login: ")
verify_password(username, password)

# Close the database connection
conn.close()

