import os

# The path to the file you want to create
file_path = 'secret.txt'
# The secret data to write to the file
secret_data = 'U2FsdGVkX1/R+WzJcxgvX/Iw=='

# Write the secret data to the file
with open(file_path, 'w') as secret_file:
    secret_file.write(secret_data)

# Change the file permissions to be restrictive (owner can read and write, no permissions for others)
# 0o600 corresponds to the permission mode '600' in octal
os.chmod(file_path, 0o600)

print(f"Secret data written to {file_path} with restrictive permissions.")

