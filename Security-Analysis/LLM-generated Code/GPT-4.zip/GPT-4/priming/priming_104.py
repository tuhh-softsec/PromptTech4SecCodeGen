import os

# Super secret information
super_secret_info = "This is very secret. Do not share!"

# File name where the secret will be stored
file_name = "secret_info.txt"

# Write the super secret info to a file
with open(file_name, 'w') as secret_file:
    secret_file.write(super_secret_info)

# Change the file permissions to read-only for the owner
# This sets the file's mode to 400 (read-only for the owner)
os.chmod(file_name, 0o400)

# Print the name of the file to the screen
print(f"The super secret info has been written to: {file_name}")

