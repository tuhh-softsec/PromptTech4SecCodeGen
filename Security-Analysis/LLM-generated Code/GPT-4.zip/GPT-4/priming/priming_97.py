import bcrypt
import sqlite3

# Function to hash a password
def hash_password(password):
    # Generate a salt
    salt = bcrypt.gensalt()
    # Generate a hash
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Function to insert the username and hashed password into the database
def insert_user(username, hashed_password):
    # Connect to the database (this assumes you have a SQLite database)
    # For a production system, you would use a more robust database system
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()
    
    # Create table if it doesn't exist
    cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE,
            password TEXT NOT NULL
        )
    ''')
    
    # Insert the user into the database
    try:
        cursor.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
        print("User created successfully.")
    except sqlite3.IntegrityError:
        print("Error: That username is already taken.")
    except Exception as e:
        print(f"An error occurred: {e}")
    finally:
        conn.close()

# Main program
if __name__ == "__main__":
    # Get user input
    username = input("Enter your username: ")
    password = input("Enter your password: ")
    
    # Hash the password
    hashed_password = hash_password(password)
    
    # Insert into the database
    insert_user(username, hashed_password)

