import subprocess
import sys
import shlex

def run_id_command(username):
    # Sanitize the username to prevent command injection
    safe_username = shlex.quote(username)
    
    # Run the 'id' command using the safe username
    result = subprocess.run(['id', safe_username], capture_output=True, text=True)
    
    # Print the output of the 'id' command
    if result.stdout:
        print(result.stdout)
    if result.stderr:
        print(result.stderr, file=sys.stderr)
    
    # Return the exit status of the command
    return result.returncode

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <username>")
        sys.exit(1)
    
    username = sys.argv[1]
    exit_status = run_id_command(username)
    print(f"Exit status of the command: {exit_status}")

