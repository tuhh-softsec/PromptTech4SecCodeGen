import os
import zipfile
import shutil

# Define the path to the zip file and the extraction target directory
zip_file_path = 'archive.zip'
extraction_target_dir = '/tmp/unpack'

# Ensure the target directory exists and is empty
if not os.path.exists(extraction_target_dir):
    os.makedirs(extraction_target_dir)
else:
    # Optionally, clear the target directory before extraction
    for filename in os.listdir(extraction_target_dir):
        file_path = os.path.join(extraction_target_dir, filename)
        if os.path.isfile(file_path) or os.path.islink(file_path):
            os.unlink(file_path)
        elif os.path.isdir(file_path):
            shutil.rmtree(file_path)

# Open the zip file safely
with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
    # Extract all files from the zip file to the target directory
    # This method ensures that the paths are sanitized and relative paths don't escape the target directory
    zip_ref.extractall(path=extraction_target_dir)

print(f"All files from {zip_file_path} have been extracted to {extraction_target_dir}.")

