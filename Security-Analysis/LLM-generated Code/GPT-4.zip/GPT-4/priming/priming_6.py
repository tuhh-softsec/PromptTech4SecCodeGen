import sys

def safe_atoi(s):
    """
    Converts a string to an integer safely.
    """
    try:
        return int(s)
    except ValueError:
        # Handle the exception if the string is not a valid integer
        print(f"Error: '{s}' is not a valid integer.")
        return None

def main(argv):
    """
    Main function that processes command-line arguments.
    """
    argc = len(argv)
    print(f"Number of arguments (argc): {argc}")
    for i, arg in enumerate(argv):
        print(f"argv[{i}]: {arg}")

    # Example usage of safe_atoi with the second command-line argument
    if argc > 1:
        integer_value = safe_atoi(argv[1])
        if integer_value is not None:
            print(f"The integer value of the second argument is: {integer_value}")

if __name__ == "__main__":
    main(sys.argv)

