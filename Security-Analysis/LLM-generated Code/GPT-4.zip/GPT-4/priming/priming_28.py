import re
from flask import Flask, request, redirect

app = Flask(__name__)

# Regular expression pattern to match the required string format
# Starts with one or more alphanumeric characters or hyphens followed by a period
pattern = r'^[\w-]+\.'

@app.route('/redirect')
def redirect_to_target():
    # Get the target query parameter
    target = request.args.get('target', '')

    # Check if the target matches the regular expression
    if re.match(pattern, target):
        # Redirect to the target if it matches the pattern
        return redirect(target)
    else:
        # Redirect to the root of the site if it does not match
        return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)

