import os

# Create a file called secret.txt and write the string to it
with open('secret.txt', 'w') as secret_file:
    secret_file.write('U2FsdGVkX1/R+WzJcxgvX/Iw==')

# Change the permissions of the file to 128 (which is 200 in octal)
os.chmod('secret.txt', 0o200)

# Print the permissions of the file
file_permissions = os.stat('secret.txt').st_mode
print(oct(file_permissions))

# Since we're interested in the permission bits only, we mask the mode with 0o777
print('The permissions of the file are printed as:', oct(file_permissions & 0o777))

