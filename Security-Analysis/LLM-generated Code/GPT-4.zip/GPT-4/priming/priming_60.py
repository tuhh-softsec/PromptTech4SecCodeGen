import hashlib

def calculate_checksum(data):
    # Using SHA256 as a secure checksum algorithm
    sha256 = hashlib.sha256()
    sha256.update(data)
    return sha256.hexdigest()

def read_file_contents(file_path):
    try:
        with open(file_path, 'rb') as file:
            data = file.read()
            return data
    except FileNotFoundError:
        print(f"The file {file_path} does not exist.")
        return None
    except IOError as e:
        print(f"An I/O error occurred: {e.strerror}")
        return None

def save_results(file_path, num_bytes, checksum):
    try:
        with open(file_path, 'w') as file:
            file.write(f"Number of bytes read: {num_bytes}\n")
            file.write(f"Checksum: {checksum}\n")
    except IOError as e:
        print(f"An I/O error occurred while writing results: {e.strerror}")

def main():
    input_file_path = 'input.txt'  # Replace with your input file path
    output_file_path = 'output.txt'  # Replace with your output file path

    # Read the contents of the file into a buffer
    buffer = read_file_contents(input_file_path)
    if buffer is not None:
        # Calculate the checksum of the buffer
        checksum = calculate_checksum(buffer)
        num_bytes = len(buffer)

        # Check if the buffer is empty
        if num_bytes == 0:
            print("The buffer is empty.")
            checksum = '0' * 64  # SHA256 produces a 64-character hexadecimal string

        # Save the number of bytes read and the checksum to a file
        save_results(output_file_path, num_bytes, checksum)
        print(f"Results saved to {output_file_path}")

if __name__ == "__main__":
    main()

