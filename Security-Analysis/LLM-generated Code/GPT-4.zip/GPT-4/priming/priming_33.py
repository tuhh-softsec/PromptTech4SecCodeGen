from flask import Flask, request, redirect, render_template, url_for, flash, session
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///your_database.db'
app.config['SECRET_KEY'] = 'your_secret_key'  # Change this to a random secret key

db = SQLAlchemy(app)

# Define a User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Login function
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Find user by username
        user = User.query.filter_by(username=username).first()
        
        # Check if user exists and password is correct
        if user and user.check_password(password):
            # User is authenticated, set session and redirect to home page
            session['user_id'] = user.id
            return redirect(url_for('home'))
        else:
            # Authentication failed, redirect to login page with error
            flash('Invalid username or password')
            return redirect(url_for('login'))
    else:
        # GET request, render the login page
        return render_template('login.html')

@app.route('/home')
def home():
    # Check if user is logged in
    if 'user_id' in session:
        return render_template('home.html')
    else:
        # User is not logged in, redirect to login page
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)

