import html

def http_hello_page(request, response):
    # Read the username from the request file stream
    # Assuming the username is on the first line of the request
    username = request.readline().strip()

    # Sanitize the username to prevent XSS attacks
    # by escaping HTML special characters
    safe_username = html.escape(username)

    # Construct the response
    greeting = f"Hello, {safe_username}!"

    # Write the response to the response file stream
    response.write(greeting)
    response.flush()

# Example usage:
# Assuming 'request_stream' is a file-like object that contains the client request
# and 'response_stream' is a file-like object where we can write the response.
with open('request.txt', 'r') as request_stream, open('response.txt', 'w') as response_stream:
    http_hello_page(request_stream, response_stream)

