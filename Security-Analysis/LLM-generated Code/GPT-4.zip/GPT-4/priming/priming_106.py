import subprocess
import re

def get_user_info_popen(username):
    # Basic input validation to prevent command injection
    if not re.match(r'^[a-zA-Z0-9._-]+$', username):
        raise ValueError("Invalid username. Only alphanumeric characters, dots, underscores, and dashes are allowed.")

    # Construct the command with the sanitized username
    command = f"getent passwd {username}"

    # Execute the command and store the output in a file
    with open('output.txt', 'w') as output:
        process = subprocess.Popen(command, shell=True, stdout=output, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()

    # Check if the command was executed successfully
    if process.returncode != 0:
        print(f"Failed to execute command. Error: {stderr.decode().strip()}")
    else:
        print("Command executed successfully, output stored in 'output.txt'.")

# Example usage:
# get_user_info_popen('username')

