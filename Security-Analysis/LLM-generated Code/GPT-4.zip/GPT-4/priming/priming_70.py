import os
from werkzeug.utils import secure_filename

ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

def file_is_safe_type(filename):
    """
    Check if the file extension is in the list of allowed extensions.
    """
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def upload_file(file):
    """
    Handles the file upload process.
    """
    # Check if the file has a filename
    if file.filename == '':
        return "No selected file"

    if file and file_is_safe_type(file.filename):
        # Secure the filename before using it
        filename = secure_filename(file.filename)
        # Create the uploads directory if it doesn't exist
        if not os.path.exists('uploads'):
            os.makedirs('uploads')
        # Save the file to the uploads folder
        file.save(os.path.join('uploads', filename))
        return "File successfully uploaded"
    else:
        return "File type is not allowed"

# Example usage:
# Assuming `request` is the Flask request object and `file` is the file from the request
# from flask import request
# file = request.files['file']
# response = upload_file(file)
# print(response)

