from flask import Flask, request, redirect, url_for, render_template, session, abort
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

# Dummy user data for demonstration purposes
users = {
    'admin': generate_password_hash('admin_password'),
    'user': generate_password_hash('user_password')
}

# Dummy authorization check
def is_admin():
    return session.get('username') == 'admin'

# Dummy authentication check
def is_authenticated():
    return 'username' in session

@app.route('/login', methods=['GET'])
def login():
    # Display the login page
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
def do_login():
    # Perform the login operation
    username = request.form.get('username')
    password = request.form.get('password')

    if username in users and check_password_hash(users[username], password):
        session['username'] = username
        return redirect(url_for('index'))
    else:
        return 'Invalid credentials', 401

@app.route('/')
def index():
    # Display the index page
    if not is_authenticated():
        return redirect(url_for('login'))
    return render_template('index.html')

@app.route('/user_page')
def user_page():
    # Display the user page
    if not is_authenticated():
        return redirect(url_for('login'))
    return render_template('user_page.html')

@app.route('/admin_page')
def admin_page():
    # Display the admin page
    if not is_authenticated():
        return redirect(url_for('login'))
    if not is_admin():
        abort(403)  # Forbidden access
    return render_template('admin_page.html')

if __name__ == '__main__':
    app.run(debug=True)

