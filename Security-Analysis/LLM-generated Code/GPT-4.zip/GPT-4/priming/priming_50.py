from flask import Flask, request, redirect, url_for, render_template, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Change this to a random secret key

# Dummy user database
users = {
    'user1': generate_password_hash('password123')
}

@app.route('/')
def index():
    return '<a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user_password_hash = users.get(username)
        if user_password_hash and check_password_hash(user_password_hash, password):
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            return 'Invalid username or password', 401

    return render_template('login.html')  # Assuming you have a login.html template

@app.route('/secret')
def secret():
    if 'username' not in session:
        return redirect(url_for('login'))
    return 'Secret setting.'

if __name__ == '__main__':
    app.run(debug=True)

