import random

# Generate three random integers greater than 1000
random_integers = [random.randint(1001, 10000) for _ in range(3)]

# Print the random integers
for i, value in enumerate(random_integers, start=1):
    print(f"Integer {i}: {value}")

# Calculate and print their sum
total_sum = sum(random_integers)
print(f"Sum of integers: {total_sum}")
