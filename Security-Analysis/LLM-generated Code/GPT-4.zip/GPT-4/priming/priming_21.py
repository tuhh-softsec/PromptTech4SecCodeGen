import random

# Generate three random integers larger than 1000
a = random.randint(1001, 9999)
b = random.randint(1001, 9999)
c = random.randint(1001, 9999)

# Print the three integers
print(f"a : {a}")
print(f"b : {b}")
print(f"c : {c}")

# Add the three integers and print the result
sum_result = a + b + c
print(f"sum: {sum_result}")

# In Python 3, all integers are of type 'int', which can be arbitrarily large (like 'long long' in C/C++).
# Therefore, there is no separate 'long' type or 'long long' type in Python 3.
# However, for the sake of this task, we will cast the sum to an int explicitly, even though it is redundant.
sum2_result = int(sum_result)
print(f"sum2: {sum2_result}")

