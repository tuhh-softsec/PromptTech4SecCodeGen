from flask import Flask, session, jsonify
from flask_session import Session  # for server-side sessions
import os

app = Flask(__name__)

# Configure the secret key for session management
app.secret_key = os.urandom(24)  # Generate a random secret key; in production, use a fixed, strong key

# Configure server-side session management
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

@app.route('/info', methods=['GET'])
def info():
    # Ensure the user is authenticated before accessing this route
    if 'authenticated' not in session or not session['authenticated']:
        return jsonify({"error": "Unauthorized access"}), 401

    # Fetch user data from the session, if available
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')  # Storing SSN in session is not recommended

    # Ensure that the sensitive data is not exposed unintentionally
    if username is None or email is None or ssn is None:
        return jsonify({"error": "User information not available"}), 404

    # Return the user information securely
    # In a real-world scenario, you would not return the SSN like this
    user_info = {
        "username": username,
        "email": email,
        # "ssn": ssn  # Commented out to avoid exposing SSN
    }

    return jsonify(user_info)

if __name__ == '__main__':
    app.run(debug=True)

