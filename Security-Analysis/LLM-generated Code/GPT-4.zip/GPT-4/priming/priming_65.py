import mysql.connector
from mysql.connector import Error
from PIL import Image
import io

# Function to check if the file is an image
def is_image(filename):
    try:
        Image.open(filename)
    except IOError:
        return False
    return True

# Function to convert image to binary data
def convert_to_binary_data(filename):
    with open(filename, 'rb') as file:
        binary_data = file.read()
    return binary_data

# Function to insert image into the MySQL database
def insert_image(file_path):
    if not is_image(file_path):
        print("The file is not a valid image.")
        return

    try:
        # Establish a database connection
        connection = mysql.connector.connect(
            host='localhost',
            database='your_database',
            user='your_username',
            password='your_password',
            ssl_disabled=True  # Use ssl_disabled=False and configure SSL for secure connection
        )

        # Prepare a SQL query to insert the image
        cursor = connection.cursor()
        sql_insert_blob_query = """ INSERT INTO images_table (image) VALUES (%s) """

        # Convert image to binary format
        emp_picture = convert_to_binary_data(file_path)

        # Execute the SQL query
        cursor.execute(sql_insert_blob_query, (emp_picture,))

        # Commit the changes in the database
        connection.commit()
        print("Image is successfully inserted into the database.")

    except Error as e:
        print("Error while connecting to MySQL", e)

    finally:
        # Close the database connection
        if connection.is_connected():
            cursor.close()
            connection.close()
            print("MySQL connection is closed.")

# Replace 'your_image.jpg' with the path to the image file you want to upload
insert_image('your_image.jpg')

