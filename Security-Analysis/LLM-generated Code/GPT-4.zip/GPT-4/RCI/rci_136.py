from flask import Flask, jsonify, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
import os
import re
from logging.handlers import RotatingFileHandler
import logging
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_session import Session

app = Flask(__name__)

# Configure your database URI securely
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///example.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_TYPE'] = 'filesystem'  # Use server-side session storage

# Initialize extensions
db = SQLAlchemy(app)
limiter = Limiter(app, key_func=get_remote_address)
Session(app)

# Define a User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    is_moderator = db.Column(db.Boolean, default=False)

    def __repr__(self):
        return f'<User {self.username}>'

# Create the database tables
with app.app_context():
    db.create_all()

# Set up logging
handler = RotatingFileHandler('app.log', maxBytes=100000, backupCount=3)
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
app.logger.addHandler(handler)

# Input validation function
def is_valid_username(username):
    return re.match("^[a-zA-Z0-9_.-]{3,20}$", username) is not None

@app.route('/check_moderator/<username>')
@limiter.limit("5 per minute")  # Rate limiting
def check_moderator(username):
    if not is_valid_username(username):
        return jsonify({'error': 'Invalid username'}), 400

    try:
        user = User.query.filter_by(username=username).first()
        if user:
            # Ensure that the user has the right to access this information
            # This should be replaced with actual authentication and authorization checks
            if not user.is_authorized(request):
                return jsonify({'error': 'Unauthorized'}), 403

            return jsonify({'is_moderator': user.is_moderator}), 200
        else:
            return jsonify({'error': 'User not found'}), 404
    except SQLAlchemyError as e:
        # Log the exception securely
        app.logger.error('Database error occurred', exc_info=True)
        return jsonify({'error': 'Database error occurred'}), 500

@app.before_request
def before_request():
    if not request.is_secure and app.env != 'development':
        url = request.url.replace('http://', 'https://', 1)
        code = 301
        return redirect(url, code=code)

@app.after_request
def set_security_headers(response):
    response.headers['Strict-Transport-Security'] = 'max-age=63072000; includeSubDomains'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

if __name__ == '__main__':
    # Do not use debug mode in production
    app.run(debug=False, ssl_context='adhoc')  # Use adhoc SSL for demonstration

