import os
import bcrypt
import re
from flask import Flask, session, redirect, request, render_template_string
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from email_validator import validate_email, EmailNotValidError
from flask_session import Session
from flask_wtf.csrf import CSRFProtect

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')  # Load from environment variable
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_TYPE'] = 'filesystem'  # Use server-side sessions
app.config['SESSION_PERMANENT'] = False

db = SQLAlchemy(app)
Session(app)
csrf = CSRFProtect(app)

class User(db.Model):
    username = db.Column(db.String(80), primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(60), nullable=False)

db.create_all()

@app.route('/login', methods=['GET', 'POST'])
@csrf.exempt
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        user = User.query.filter_by(username=username).first()
        if user and bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
            session.regenerate()  # Mitigate session fixation
            session['username'] = username
            return redirect('/change_email')
        else:
            return 'Login failed', 401
    return 'Login form here'

@app.route('/change_email', methods=['GET', 'POST'])
def change_email_route():
    if 'username' not in session:
        return redirect('/login')
    if request.method == 'POST':
        password = request.form['password']
        new_email = request.form['new_email']
        try:
            # Validate email
            validate_email(new_email)
            user = User.query.filter_by(username=session['username']).first()
            if user and bcrypt.checkpw(password.encode('utf-8'), user.password.encode('utf-8')):
                user.email = new_email
                db.session.commit()
                return 'Email changed successfully', 200
            else:
                return 'Authentication failed', 403
        except EmailNotValidError as e:
            return str(e), 400
    return 'Email change form here'

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/login')

if __name__ == '__main__':
    # Use a production-ready server like gunicorn in production
    app.run(ssl_context='adhoc')  # Use 'adhoc' for demo purposes only

