import sys

# Function to display usage message and exit with an error code
def usage():
    sys.exit("Usage: python script.py <argument>\nPlease provide exactly one argument.")

# Function to validate the input argument
def validate_input(argument, allowed_chars):
    if not set(argument).issubset(allowed_chars):
        raise ValueError("Invalid characters in argument. Only alphanumeric characters and underscores are allowed.")

# Function to process the input argument
def process_argument(argument):
    # Input validation (example: allow only alphanumeric characters and underscores)
    # This should be adjusted based on the expected input
    allowed_chars = set("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_")
    validate_input(argument, allowed_chars)

    # The strip() method is used to remove any leading and trailing whitespace from the string
    trimmed_argument = argument.strip()

    # Further processing steps should ensure that trimmed_argument is used securely
    # For example, if used in a database query, it should be parameterized
    # If used in a command line, it should be properly escaped

    # Return the processed string
    return trimmed_argument

# Main script execution
if __name__ == "__main__":
    # Check to make sure that the user provided exactly one argument
    if len(sys.argv) != 2:
        usage()

    try:
        # Process the argument and print the result
        processed_string = process_argument(sys.argv[1])
        print("Processed string:", processed_string)
    except ValueError as e:
        sys.exit(e)

