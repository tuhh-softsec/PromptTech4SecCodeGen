import argparse
import hashlib
import logging
import os
import sys
from fcntl import flock, LOCK_EX, LOCK_UN

# Configure logging within the main function to avoid global side effects
def configure_logging(log_level):
    logging.basicConfig(level=log_level)

def calculate_checksum(file_path, chunk_size):
    sha256 = hashlib.sha256()
    num_bytes = 0
    try:
        with open(file_path, 'rb') as file:
            while True:
                chunk = file.read(chunk_size)
                if not chunk:
                    break
                sha256.update(chunk)
                num_bytes += len(chunk)
        return sha256.hexdigest(), num_bytes
    except FileNotFoundError:
        logging.error(f"The file {file_path} was not found.")
        sys.exit(2)
    except IOError as e:
        logging.error(f"An error occurred while reading the file: {e}")
        sys.exit(3)

def write_statistics(stats_file_path, num_bytes, checksum):
    flags = os.O_WRONLY | os.O_CREAT | os.O_EXCL
    try:
        with os.fdopen(os.open(stats_file_path, flags), 'w') as file:
            flock(file, LOCK_EX)
            file.write(f"Number of bytes read: {num_bytes}\n")
            file.write(f"Checksum: {checksum}\n")
            flock(file, LOCK_UN)
        return True
    except FileExistsError:
        logging.error(f"The file {stats_file_path} already exists. Aborting to prevent overwrite.")
        sys.exit(4)
    except IOError as e:
        logging.error(f"An error occurred while writing to the file: {e}")
        sys.exit(5)

def sanitize_file_path(file_path, safe_directory):
    # Resolve symbolic links and check if the path is within the safe directory
    absolute_path = os.path.realpath(file_path)
    if not absolute_path.startswith(safe_directory):
        logging.error("Invalid file path provided.")
        sys.exit(6)
    return absolute_path

def main():
    parser = argparse.ArgumentParser(description="Calculate file checksum and write statistics.")
    parser.add_argument("input_file_path", help="Path to the input file.")
    parser.add_argument("stats_file_path", help="Path to the output statistics file.")
    parser.add_argument("--chunk-size", type=int, default=int(os.getenv('CHUNK_SIZE', 4096)),
                        help="Chunk size for reading files.")
    parser.add_argument("--log-level", default=logging.ERROR, type=lambda x: getattr(logging, x),
                        help="Set the logging level (e.g., DEBUG, INFO, WARNING, ERROR, CRITICAL)")
    args = parser.parse_args()

    configure_logging(args.log_level)

    safe_directory = os.getenv('SAFE_DIRECTORY', os.path.abspath("safe_directory"))
    if not os.path.isdir(safe_directory):
        logging.error(f"The safe directory {safe_directory} does not exist or is not accessible.")
        sys.exit(7)

    input_file_path = sanitize_file_path(args.input_file_path, safe_directory)
    stats_file_path = sanitize_file_path(args.stats_file_path, safe_directory)

    checksum, num_bytes = calculate_checksum(input_file_path, args.chunk_size)
    if not write_statistics(stats_file_path, num_bytes, checksum):
        sys.exit(8)

    print(f"Checksum and statistics successfully written to {stats_file_path}")

if __name__ == "__main__":
    main()

