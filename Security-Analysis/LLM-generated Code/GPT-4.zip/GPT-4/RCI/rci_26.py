import re
import logging

# Set up logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Define the regular expression pattern for matching URLs
# This pattern matches URLs like "/page/123" and ensures they are relative paths
url_pattern = r'^/page/\d+$'

# Compile the regular expression once when the module is loaded
compiled_pattern = re.compile(url_pattern)

# Define the default URL to use if the target URL does not match
default_url = '/default'

def redirect_url(target_url):
    """
    Redirects to the target URL if it matches the compiled regular expression,
    otherwise redirects to the default URL. This function also ensures that the
    target URL is a string, which helps mitigate open redirect vulnerabilities.
    """
    try:
        # Ensure that the target_url is a string to prevent TypeErrors
        if not isinstance(target_url, str):
            logger.warning("Non-string target URL provided.")
            return default_url

        # Use the compiled regular expression to match the target URL
        if compiled_pattern.match(target_url):
            return target_url
        else:
            # Log the failed redirect attempt
            logger.warning(f"Redirect attempt to non-matching URL: {target_url}")
            return default_url
    except Exception as e:
        # Log the exception and return the default URL
        logger.error(f"Exception occurred during redirect: {e}")
        return default_url

# Example usage
try:
    target_url = '/page/123'
    redirect_target = redirect_url(target_url)
    print(f"Redirect to: {redirect_target}")
except Exception as e:
    logger.error(f"Error during redirection: {e}")

# Additional code would handle setting security headers and enforcing HTTPS
# in the actual HTTP response, which is not shown in this code snippet.

# Remember to implement comprehensive unit tests to validate the security measures.

