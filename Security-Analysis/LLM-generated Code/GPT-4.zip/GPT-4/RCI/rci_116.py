import secrets
import struct
import os

def secure_random_float():
    # Generate a 53-bit random number for the mantissa
    random_bits = secrets.randbits(53)
    # Construct the IEEE 754 binary64 format with an exponent of 1022 (0x3FE)
    # which corresponds to a float in the range [1.0, 2.0)
    binary64 = (0x3FE << 52) | random_bits
    # Pack the integer into bytes and unpack as a double
    random_float = struct.unpack('d', struct.pack('Q', binary64))[0]
    # Normalize to [0.0, 1.0)
    return random_float - 1.0

# Generate 3 cryptographically secure random floats
random_floats = [secure_random_float() for _ in range(3)]

# Convert the floats to strings
string_floats = [str(flt) for flt in random_floats]

# Concatenate them into a single string
concatenated_string = ''.join(string_floats)

# Set the umask to ensure the file is created with secure permissions
old_umask = os.umask(0o177)

# Write the string to a file with restricted permissions
file_path = 'random_floats.txt'
try:
    with open(file_path, 'w') as file:
        file.write(concatenated_string)
except IOError as e:
    print(f"An error occurred while writing to the file: {e}")
finally:
    # Restore the original umask
    os.umask(old_umask)

# Print the concatenated string for verification
print(concatenated_string)

