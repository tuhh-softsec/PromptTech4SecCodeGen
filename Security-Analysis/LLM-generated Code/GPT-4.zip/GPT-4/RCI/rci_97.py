import bcrypt
import os
import psycopg2
from getpass import getpass
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

# Assume Flask app is already created
limiter = Limiter(app, key_func=get_remote_address)

# Function to hash a password with a specified work factor
def hash_password(password, work_factor=12):
    salt = bcrypt.gensalt(rounds=work_factor)
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

# Function to insert the username and hashed password into the database
def insert_user(username, hashed_password):
    # Use a secrets management tool to retrieve database credentials
    db_credentials = get_db_credentials_from_secrets_manager()

    # Use context manager for database connection
    with psycopg2.connect(**db_credentials) as conn:
        with conn.cursor() as cursor:
            # Check for username uniqueness and handle potential errors
            try:
                cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
                if cursor.fetchone():
                    return "Error: Username already exists.", False
                
                # Use parameterized queries to avoid SQL injection
                cursor.execute("INSERT INTO users (username, password) VALUES (%s, %s)", (username, hashed_password))
                conn.commit()
                return "User registered successfully!", True
            except Exception as e:
                # Log the detailed error internally
                log_error(e)
                return "An error occurred during registration.", False

# Main function to prompt the user for their username and password
@limiter.limit("5 per minute")  # Rate limiting for registration attempts
def main():
    username = input("Enter your username: ")
    password = getpass("Enter your password: ")  # Securely prompt for the password
    
    # Validate username and enforce password policy here
    if not validate_username(username) or not enforce_password_policy(password):
        return "Invalid username or password does not meet the policy requirements."
    
    hashed_password = hash_password(password)
    
    message, success = insert_user(username, hashed_password)
    print(message)
    if success:
        # Handle post-registration session management here
        pass

if __name__ == "__main__":
    main()

