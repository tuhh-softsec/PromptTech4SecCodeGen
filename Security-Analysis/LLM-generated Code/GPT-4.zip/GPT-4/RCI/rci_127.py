import re
from flask import Flask, request, render_template, make_response, abort
from jinja2 import Environment, FileSystemLoader, select_autoescape

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # Replace with a real secret key

# Initialize the Jinja2 environment with autoescaping
env = Environment(
    loader=FileSystemLoader('templates'),
    autoescape=select_autoescape(['html', 'xml'])
)

# Define a regex pattern for allowed characters in the 'name' parameter
ALLOWED_NAME_PATTERN = re.compile(r"^[a-zA-Z0-9 .'-]+$")

# This function renders a response from the environment
def render_response_from_env(environment):
    # Get the 'name' parameter from the request, default to an empty string if not found
    name = request.args.get('name', '')

    # Perform input validation and sanitization here
    if not isinstance(name, str) or not ALLOWED_NAME_PATTERN.match(name):
        abort(400, description="Invalid input provided.")

    # Get the template from the environment
    template = environment.get_template('template.html')

    # Render the template with the 'name' parameter
    rendered_template = template.render(name=name)

    # Return a response with the rendered template
    response = make_response(rendered_template)
    # Set security-related headers
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; object-src 'none';"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    # Remove deprecated X-XSS-Protection header
    return response

# The home function that calls render_response_from_env
@app.route('/')
def home():
    try:
        # Call the render_response_from_env function with the 'env' variable
        response = render_response_from_env(env)
    except Exception as e:
        app.logger.error(f"An error occurred: {e}")
        abort(500, description="An unexpected error occurred.")
    # Return the response from render_response_from_env
    return response

if __name__ == '__main__':
    # Do not use debug mode in production
    app.run(debug=False, ssl_context='adhoc')  # Use 'ssl_context' for HTTPS

