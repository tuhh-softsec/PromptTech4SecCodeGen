import os
import secrets
from flask import Flask, request, redirect, url_for, flash, abort, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_wtf.csrf import CSRFProtect
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import magic  # python-magic is a Python interface to the libmagic file type identification library.

UPLOAD_FOLDER = '/path/to/secure/location'  # Outside of web root
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB upload limit
app.secret_key = secrets.token_urlsafe(16)  # Generate a random secret key

# Security enhancements
csrf = CSRFProtect(app)
Talisman(app, content_security_policy=None)  # Define your CSP policy
limiter = Limiter(app, key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def file_is_safe_type(file):
    # Use python-magic to check the file's actual MIME type
    mime = magic.from_buffer(file.stream.read(1024), mime=True)
    file.stream.seek(0)  # Reset file pointer after reading
    return mime in ['text/plain', 'application/pdf', 'image/png', 'image/jpeg', 'image/gif']

@app.route('/upload', methods=['GET', 'POST'])
@limiter.limit("10 per minute")  # Rate limit to protect against DoS attacks
def upload_file():
    if request.method == 'POST':
        # CSRF protection is automatically applied with Flask-WTF
        file = request.files.get('file')
        if not file:
            flash('No file part')
            return redirect(request.url)
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            # Prevent directory traversal
            filename = os.path.basename(filename)
            # Generate a unique filename to prevent overwrites and race conditions
            unique_filename = secrets.token_hex(8) + "_" + filename
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            if file_is_safe_type(file):
                file.save(file_path)
                # Implement anti-virus scanning here
                return redirect(url_for('uploaded_file', filename=unique_filename))
            else:
                flash('File type not allowed or file is not safe')
                return redirect(request.url)
    return '''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new File</h1>
    <form method=post enctype=multipart/form-data>
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    '''

@app.route('/uploads/<filename>')
def uploaded_file(filename):
    # Implement access control checks here
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)

@app.errorhandler(413)
def request_entity_too_large(error):
    flash('File Too Large')
    return redirect(request.url), 413

# Additional error handling
@app.errorhandler(400)
def bad_request(error):
    flash('Bad Request')
    return redirect(request.url), 400

# ... Add more error handlers as needed ...

if __name__ == '__main__':
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)
    # Do not use app.run(debug=True) in production
    # Instead, use a production-ready server like Gunicorn
    app.run(host='0.0.0.0', port=5000)

