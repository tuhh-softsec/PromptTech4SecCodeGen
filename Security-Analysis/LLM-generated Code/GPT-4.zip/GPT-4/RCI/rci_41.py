import os
import logging
from pathlib import Path

# Configure logging
logging.basicConfig(filename='app.log', level=logging.ERROR)

def read_secure_file(filename):
    # Get the safe directory from an environment variable or configuration
    safe_directory = Path(os.environ.get('SAFE_DIRECTORY', '/safe')).resolve(strict=True)

    # Sanitize the filename to prevent directory traversal and validate input
    filename = ''.join(char for char in filename if char.isalnum() or char in ('-', '_'))
    if not filename:
        logging.error("Invalid filename provided")
        raise ValueError("Invalid filename")

    # Construct the full file path and resolve it to prevent symlink attacks
    file_path = safe_directory / filename
    try:
        real_path = file_path.resolve(strict=True)
    except FileNotFoundError:
        logging.error(f"The file {filename} does not exist")
        raise FileNotFoundError("The file does not exist")

    # Validate that the file is within the safe directory
    if not real_path.is_relative_to(safe_directory):
        logging.error("Attempted to read a file outside the safe directory")
        raise ValueError("Invalid file path")

    # Ensure the file exists and is not a directory
    if not real_path.is_file():
        logging.error(f"The file {filename} does not exist or is a directory")
        raise FileNotFoundError("The file does not exist")

    # Check file permissions
    if not os.access(str(real_path), os.R_OK):
        logging.error(f"Insufficient permissions to read the file {filename}")
        raise PermissionError("Insufficient permissions to read the file")

    try:
        # Open the file in read-only mode with the specified encoding
        with open(real_path, 'r', encoding='utf-8') as file:
            # Read the file content
            content = file.read()
            return content
    except UnicodeDecodeError as e:
        logging.error(f"File encoding error: {e}")
        raise ValueError("File encoding error")
    except IOError as e:
        # Log the error and raise a generic error message
        logging.error(f"An error occurred while reading the file: {e}")
        raise IOError("An error occurred while reading the file")

# Example usage
try:
    file_content = read_secure_file('example.txt')
    print(file_content)
except Exception as e:
    logging.error(f"An error occurred: {e}")
    print("An error occurred while processing the file")

