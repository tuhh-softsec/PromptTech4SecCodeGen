from flask import Flask, request, redirect, render_template, session, flash
from flask_wtf import FlaskForm, CSRFProtect
from wtforms import StringField, TextAreaField
from wtforms.validators import DataRequired, Length
from flask_sqlalchemy import SQLAlchemy
from flask_session import Session
from os import environ
import logging
from logging.handlers import RotatingFileHandler
from flask_talisman import Talisman
from flask_migrate import Migrate

app = Flask(__name__)
app.config['SECRET_KEY'] = environ.get('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = environ.get('DATABASE_URI')
app.config['SESSION_TYPE'] = 'sqlalchemy'
app.config['SESSION_SQLALCHEMY'] = db

db = SQLAlchemy(app)
migrate = Migrate(app, db)
Session(app)
CSRFProtect(app)
Talisman(app)

# Define the Message model
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    message = db.Column(db.Text, nullable=False)

# Define the message form
class MessageForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(max=80)])
    message = TextAreaField('Message', validators=[DataRequired(), Length(max=500)])

# Define the post() function to handle message submission
@app.route('/post_message', methods=['GET', 'POST'])
def post():
    form = MessageForm()
    if form.validate_on_submit():
        message = Message(username=form.username.data, message=form.message.data)
        db.session.add(message)
        db.session.commit()
        flash('Message posted successfully!')
        return redirect('/')
    return render_template('post_message.html', form=form)

# Route to display messages
@app.route('/')
def main_page():
    messages = Message.query.all()
    return render_template('main_page.html', messages=messages)

if __name__ == '__main__':
    # Configure logging
    handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
    handler.setLevel(logging.INFO)
    app.logger.addHandler(handler)

    # Run the application with a proper SSL/TLS context
    app.run(ssl_context=('cert.pem', 'key.pem'))

# Additional security measures not shown in the code:
# - Implement user authentication and authorization.
# - Add proper error handling to avoid information leakage.
# - Use a dedicated secret management tool for managing secrets.
# - Regularly update dependencies and check for vulnerabilities.
# - Implement rate limiting to protect against brute-force attacks.
# - Ensure database security with proper configuration and encryption.
# - Use a dedicated session storage mechanism, such as Redis.
# - Apply database migrations to manage schema changes safely.

