import subprocess
import re

class UserInfoError(Exception):
    """Custom exception for user info retrieval errors."""
    pass

# Function to safely execute the command and store the output
def get_user_info(username):
    # Validate the username to ensure it only contains alphanumeric characters and no shell metacharacters
    if not re.match(r'^\w+$', username):
        raise ValueError("Invalid username. Only alphanumeric characters and underscores are allowed.")

    # Use a list to specify the command and arguments
    command = ["getent", "passwd", username]
    
    # Execute the command using subprocess.Popen without shell=True
    with subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) as process:
        # Read the output from the command
        output, errors = process.communicate()
        
        # Check if there were any errors
        if process.returncode != 0:
            raise UserInfoError(f"Error retrieving user info: {errors.strip()}")
        else:
            # Return the output as a string
            return output

# Example usage:
username = "exampleuser"  # Replace with the actual username
try:
    output = get_user_info(username)
    if output:
        # Handle the output securely, e.g., mask sensitive information if necessary
        print(output)
except ValueError as ve:
    print(f"Input validation error: {ve}")
except UserInfoError as uie:
    print(uie)
except Exception as e:
    # Catch-all for unexpected exceptions
    print(f"An unexpected error occurred: {e}")

