import os
from flask import Flask, request, redirect, url_for, flash, abort, render_template_string, session
from werkzeug.utils import secure_filename
import magic  # python-magic is a Python interface to the libmagic file type identification library.
import subprocess
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_session import Session

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}
MAX_FILE_COUNT = 10  # Maximum number of files a user can upload
MAX_STORAGE_SPACE = 100 * 1024 * 1024  # 100MB maximum storage space used by uploads

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB upload limit
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_TYPE'] = 'filesystem'  # Use server-side session storage
app.secret_key = os.environ.get('SECRET_KEY', os.urandom(24))  # Use an environment variable for the secret key

# Initialize Flask-Session
Session(app)

# Initialize Flask-Limiter for rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Ensure the upload folder exists and is not within the web root
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def is_safe_path(basedir, path, follow_symlinks=False):
    # Ensure the path is within the basedir and not a symlink
    return os.path.realpath(path).startswith(basedir)

@app.route('/', methods=['GET', 'POST'])
def upload_file():
    if request.method == 'POST':
        # CSRF protection
        if not request.form.get('csrf_token') == session.get('csrf_token'):
            abort(403)

        # Check if the post request has the file part
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        # If the user does not select a file, the browser submits an
        # empty file without a filename.
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if not is_safe_path(app.config['UPLOAD_FOLDER'], file_path):
                abort(400)
            file_content = file.read()  # Read the file to check its MIME type and scan for viruses
            file_mime_type = magic.from_buffer(file_content, mime=True)
            if file_mime_type != 'application/pdf':
                flash('File is not a valid PDF')
                return redirect(request.url)
            # Virus scanning (using ClamAV or similar)
            try:
                process = subprocess.run(['clamscan', '--stdout', '-'], input=file_content, capture_output=True, check=True, text=True)
                if "FOUND" in process.stdout:
                    flash('File is infected with a virus')
                    return redirect(request.url)
            except subprocess.CalledProcessError as e:
                app.logger.error(f'Virus scanning error: {e}')
                flash('Error scanning file for viruses')
                return redirect(request.url)
            # Save the file if it's safe
            with open(file_path, 'wb') as f:
                f.write(file_content)
            flash('File successfully uploaded')
            return redirect(url_for('upload_file'))
        else:
            flash('Allowed file types are pdf')
            return redirect(request.url)
    # CSRF token generation
    session['csrf_token'] = os.urandom(16).hex()
    return render_template_string('''
    <!doctype html>
    <title>Upload new File</title>
    <h1>Upload new PDF</h1>
    <form method=post enctype=multipart/form-data>
      <input type=hidden name=csrf_token value="{{ session['csrf_token'] }}">
      <input type=file name=file>
      <input type=submit value=Upload>
    </form>
    ''')

if __name__ == '__main__':
    # Use a production-ready SSL context in production
    # app.run(ssl_context=('cert.pem', 'key.pem'))
    app.run()  # Do not use ad-hoc SSL in production

# Additional security configurations (not shown in the code snippet):
# - Implement file storage limits and checks for file overwrite.
# - Use a proper SSL certificate for production.
# - Configure security headers and rate limiting.
# - Regularly update dependencies and check for known vulnerabilities.
# - Implement logging for monitoring and auditing purposes.

