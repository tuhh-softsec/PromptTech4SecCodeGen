from flask import Flask, render_template, escape, request, session, redirect, url_for
from flask_session import Session
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)

# Set a persistent secret key for session management
app.secret_key = 'your-secure-random-secret-key'

# Configure session to use filesystem (instead of signed cookies)
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Enforce HTTPS in production by setting the PREFERRED_URL_SCHEME
app.config['PREFERRED_URL_SCHEME'] = 'https'

@app.route('/hello/<username>')
@limiter.limit("10 per minute")
def hello(username):
    # Validate the username (e.g., check length and allowed characters)
    if not username.isalnum() or len(username) > 20:
        return "Invalid username", 400

    # Escape the username to prevent XSS attacks
    safe_username = escape(username)
    
    # Render the template, passing the safe username
    return render_template('hello.html', username=safe_username)

@app.errorhandler(404)
def page_not_found(e):
    # Custom error handling to avoid exposing sensitive information
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    # Custom error handling for internal server errors
    return render_template('500.html'), 500

# Additional security headers
@app.after_request
def add_security_headers(response):
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Feature-Policy'] = "geolocation 'self'"
    response.headers['Strict-Transport-Security'] = 'max-age=63072000; includeSubDomains'
    response.headers['Set-Cookie'] = 'Secure; HttpOnly; SameSite=Lax'
    return response

if __name__ == '__main__':
    # Run the application in production mode with secure settings
    app.run(debug=False, host='0.0.0.0', port=5000)

