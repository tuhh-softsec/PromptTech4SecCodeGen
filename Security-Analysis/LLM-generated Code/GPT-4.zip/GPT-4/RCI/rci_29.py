from urllib.parse import urlparse, unquote
from flask import redirect, abort, request, Flask
import logging

def is_valid_domain(domain):
    # Check if the domain ends with 'example.com' and handle subdomains
    # Also check for edge cases such as additional trailing dots
    domain = domain.rstrip('.')
    return domain.lower().endswith('.example.com') or domain.lower() == 'example.com'

def redirect_url(url):
    try:
        # Decode URL to handle percent-encoding
        url = unquote(url)
        # Parse the URL to retrieve the domain and scheme
        parsed_url = urlparse(url)
        domain = parsed_url.netloc
        scheme = parsed_url.scheme

        # Validate that the URL starts with the allowed schemes
        if not (url.startswith('http://') or url.startswith('https://')):
            abort(400, 'Invalid URL scheme')

        # Validate the domain
        if not is_valid_domain(domain):
            abort(404, 'Invalid domain')

        # Redirect to the URL if the domain and scheme are valid
        # Enforce HTTPS by replacing 'http' with 'https'
        secure_url = url.replace('http://', 'https://', 1)
        return redirect(secure_url)
    except ValueError:
        # Handle malformed URLs
        abort(400, 'Error processing the URL')

# Example usage with Flask
app = Flask(__name__)

@app.route('/redirect')
def redirect_to_url():
    # Get the URL parameter from the query string and ensure it is a string
    url = request.args.get('url', type=str)
    if not url:
        abort(400, 'No URL provided')
    # Perform input sanitization
    sanitized_url = sanitize_input(url)
    return redirect_url(sanitized_url)

def sanitize_input(input_url):
    # Implement sanitization logic to remove or encode dangerous characters
    # This is a placeholder for actual sanitization logic
    return input_url

if __name__ == '__main__':
    # Add logging to monitor for suspicious activities
    app.logger.setLevel(logging.INFO)
    app.run(ssl_context='adhoc')  # Enforce HTTPS by using an ad-hoc SSL context

# Note: Implement rate limiting and/or CAPTCHA as part of the broader application security strategy

