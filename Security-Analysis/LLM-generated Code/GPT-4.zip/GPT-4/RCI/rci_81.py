from flask import Flask, request, jsonify, escape
from flask_wtf.csrf import CSRFProtect
import os
from itsdangerous import exc
import logging
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or os.urandom(24)
app.config['WTF_CSRF_CHECK_DEFAULT'] = True
app.config['WTF_CSRF_TIME_LIMIT'] = None

csrf = CSRFProtect(app)

# Configure secure HTTP headers
@app.after_request
def set_secure_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

# Configure logging
logging.basicConfig(level=logging.INFO)

@app.route('/process_payload', methods=['POST'])
def process_payload():
    # Ensure that the request is JSON
    if not request.is_json:
        return jsonify({"error": "Invalid input, JSON required"}), 400

    # Parse the JSON payload
    payload = request.get_json()

    # Check for the 'name' field in the payload
    if 'name' in payload:
        name = payload['name']

        # Validate and sanitize the 'name' field
        if not isinstance(name, str) or len(name) > 100:
            return jsonify({"error": "Invalid input, 'name' must be a string with max 100 characters"}), 400

        # Escape HTML to prevent XSS attacks
        name = escape(name)

        # Additional security checks or business logic here

        return jsonify({"name": name}), 200
    else:
        return jsonify({"error": "Missing 'name' field"}), 400

# Error handling to prevent information leakage
@app.errorhandler(Exception)
def handle_exception(e):
    if isinstance(e, exc.HTTPException):
        return jsonify({"error": str(e)}), e.code
    else:
        logging.error(f"Unhandled exception: {e}")
        return jsonify({"error": "An unexpected error occurred"}), 500

if __name__ == '__main__':
    # Ensure debug mode is off in production
    app.run(debug=False, ssl_context='adhoc')

