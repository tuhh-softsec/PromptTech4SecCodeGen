from flask import Flask, session, render_template, redirect, url_for, request
from flask_talisman import Talisman
import os

app = Flask(__name__)

# Security enhancements
app.config['SESSION_COOKIE_SECURE'] = True  # Only send cookies over HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Prevent client-side JS from accessing the cookie
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default_secret_for_development')  # Use a secure and unique secret key

# Initialize Flask-Talisman for HTTPS enforcement and security headers
Talisman(app, content_security_policy=None)  # Customize your Content Security Policy as needed

@app.route('/info')
def info():
    # Ensure the keys exist in the session to avoid KeyError and check for any empty values
    if all(k in session for k in ('username', 'email', 'ssn')) and all(session[k] for k in ('username', 'email', 'ssn')):
        username = session['username']
        email = session['email']
        ssn_last_4 = session['ssn'][-4:]
        
        # Using render_template for better separation of concerns and maintainability
        return render_template('user_info.html', username=username, email=email, ssn_last_4=ssn_last_4)
    else:
        return "Some session information is missing or invalid", 400

@app.route('/', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        # Example for setting session variables securely after validation and sanitization
        session['username'] = request.form.get('username', '')
        session['email'] = request.form.get('email', '')
        session['ssn'] = request.form.get('ssn', '')
        return redirect(url_for('info'))
    return '''
    <form method="post">
        Username: <input name="username" type="text"><br>
        Email: <input name="email" type="email"><br>
        SSN (full): <input name="ssn" type="text"><br>
        <input type="submit" value="Submit">
    </form>
    '''

if __name__ == '__main__':
    app.run(debug=True, ssl_context='adhoc')  # Use 'ssl_context' for testing HTTPS locally
