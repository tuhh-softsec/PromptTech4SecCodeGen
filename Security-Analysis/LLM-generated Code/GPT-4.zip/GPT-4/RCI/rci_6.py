import sys

def safe_atoi(s):
    try:
        return int(s)
    except ValueError as e:
        print(f"Error: Cannot convert '{s}' to an integer. {e}")
        return None
    except OverflowError as e:
        print(f"Error: The value '{s}' is too large to convert to an integer. {e}")
        return None

def validate_input(argv):
    # Example validation logic
    if len(argv) < 3:
        print("Error: Not enough arguments provided.")
        return False
    if not argv[2].isdigit() and (argv[2][0] != '-' or not argv[2][1:].isdigit()):
        print("Error: The second argument must be an integer.")
        return False
    return True

def main():
    argc = len(sys.argv)
    argv = sys.argv
    
    if not validate_input(argv):
        print("Usage: python script.py [integer value]")
        sys.exit(1)
    
    print(f"Number of arguments (argc): {argc}")
    for i, arg in enumerate(argv):
        print(f"argv[{i}]: {arg}")
    
    number = safe_atoi(argv[2])
    if number is None:
        sys.exit(1)
    
    print(f"The integer value of the second argument is: {number}")

if __name__ == "__main__":
    main()

