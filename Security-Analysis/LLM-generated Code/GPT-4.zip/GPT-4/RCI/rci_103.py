import os
import tempfile
import shutil
import base64
from cryptography.fernet import Fernet
from cryptography.hazmat.primitives import constant_time
import logging
import stat

# Initialize logging for audit purposes
logging.basicConfig(filename='audit.log', level=logging.INFO)

# Securely generate a key and instantiate a Fernet object
# The key should be securely stored and managed, e.g., using an environment variable or a key management service
key = Fernet.generate_key()
cipher_suite = Fernet(key)

# Define the filename and the content to write
filename = 'secret.txt'
sensitive_data = 'Sensitive data to be encrypted'

# Encrypt the data before writing to the file
encrypted_data = cipher_suite.encrypt(sensitive_data.encode())

# Create a temporary file with secure permissions from the outset
fd, temp_path = tempfile.mkstemp()
os.chmod(temp_path, stat.S_IRUSR | stat.S_IWUSR)  # Set file to be readable and writable only by the owner

try:
    # Write the encrypted content to the temporary file
    with os.fdopen(fd, 'wb') as temp_file:
        temp_file.write(encrypted_data)

    # Atomically move the temporary file to the desired filename
    # Ensure that the destination does not exist to prevent overwriting
    if not os.path.exists(filename):
        shutil.move(temp_path, filename)
        logging.info(f"Encrypted file {filename} created successfully.")
    else:
        logging.error(f"Destination file {filename} already exists.")
        raise FileExistsError(f"Destination file {filename} already exists.")
except Exception as e:
    # Handle any exceptions that occur
    logging.error(f"An error occurred: {e}")
    raise
finally:
    # Ensure the temporary file is removed if it still exists
    if os.path.exists(temp_path):
        os.remove(temp_path)
        logging.info(f"Temporary file {temp_path} removed successfully.")

# Clear sensitive data from memory
del sensitive_data
del encrypted_data
# Use constant-time comparison to clear the key from memory
constant_time.bytes_eq(key, key)
del key

# Additional security measures:
# - Ensure the script is run with minimal privileges
# - Set restrictive permissions on the script file itself (chmod 700 script.py)
# - Use secure deletion methods when removing sensitive files (e.g., shred on Unix-like systems)
# - Implement audit logging for file creation and permission changes
# - Keep the software and dependencies up to date
# - Follow secure coding practices

# Note: This code assumes that the 'cryptography' package is installed
# You can install it using pip: pip install cryptography

