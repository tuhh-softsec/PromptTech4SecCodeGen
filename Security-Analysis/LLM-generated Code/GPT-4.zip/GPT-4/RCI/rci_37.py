from flask import Flask, request, redirect, render_template, session, flash
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf.csrf import CSRFProtect
import os
from datetime import timedelta

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default_secret_key')  # Load secret key from environment variable or set a default
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///users.db')  # Configure database URI from environment variable or use default
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = True  # Ensure you are using HTTPS in production
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(days=14)  # Set session persistence duration (14 days recommended for "remember me" feature)
app.config['SESSION_COOKIE_NAME'] = 'myapp_session'  # Set a custom session cookie name

db = SQLAlchemy(app)
csrf = CSRFProtect(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)  # Adjusted length for future-proofing

# Create the database and add a user for demonstration purposes
# In a real-world scenario, you would have a registration system
def initialize_database():
    with app.app_context():
        db.create_all()
        if not User.query.filter_by(username='admin').first():
            hashed_password = generate_password_hash('your_secure_password')
            new_user = User(username='admin', password_hash=hashed_password)
            db.session.add(new_user)
            db.session.commit()

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    # Fetch user from the database
    user = User.query.filter_by(username=username).first()

    # Check if the user exists and the password is correct
    if user and check_password_hash(user.password_hash, password):
        session['logged_in'] = True
        flash('Login successful.')
        return redirect('/session')
    else:
        flash('Invalid credentials.')
        return redirect('/')

@app.route('/session')
def session_page():
    if not session.get('logged_in'):
        return redirect('/')
    return 'Welcome to the session page!'

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

if __name__ == '__main__':
    initialize_database()  # Initialize the database only once, not on every app start
    app.run(debug=False)  # Turn off debug mode for production

# Ensure you have Flask, Flask-WTF, Flask-SQLAlchemy installed:
# pip install Flask Flask-WTF Flask-SQLAlchemy

