import os
import json
import html
from flask import Flask, request, jsonify, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from logging.handlers import RotatingFileHandler
import logging

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'default-secret-key')

# Set up logging
log_file_path = os.environ.get('LOG_PATH', 'app.log')
handler = RotatingFileHandler(log_file_path, maxBytes=100000, backupCount=3)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)

# Set up rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@app.errorhandler(500)
def handle_500(error):
    app.logger.error(f"Server error: {error}, route: {request.url}")
    return jsonify({"error": "An unexpected error occurred"}), 500

@app.errorhandler(Exception)
def handle_exception(error):
    app.logger.error(f"Unhandled exception: {error}, route: {request.url}")
    return jsonify({"error": "An unexpected error occurred"}), 500

@app.route('/api', methods=['POST'])
@limiter.limit("10 per minute")
def api():
    try:
        # Load the payload from the request data
        payload_dict = request.get_json()
        
        # Ensure that the payload is a dictionary
        if not isinstance(payload_dict, dict):
            abort(400, description="Invalid payload format")
        
        # Get the 'name' value from the dictionary
        name = payload_dict.get('name')
        
        if name is None or not isinstance(name, str) or len(name) > 100:
            abort(400, description="Invalid or missing name in payload")
        
        # Sanitize the 'name' value to prevent XSS
        sanitized_name = html.escape(name)
        
        # Return the sanitized 'name' value
        return jsonify({"name": sanitized_name})
    
    except json.JSONDecodeError:
        abort(400, description="Invalid JSON payload")

# Set a Content Security Policy
@app.after_request
def set_csp(response):
    response.headers['Content-Security-Policy'] = "default-src 'self'; script-src 'self'; object-src 'none'"
    return response

# Remove server headers
@app.after_request
def remove_server_headers(response):
    response.headers.pop('Server', None)
    return response

if __name__ == '__main__':
    # Use a production-ready server like Gunicorn in production environments
    ssl_cert = os.environ.get('SSL_CERT_PATH', 'cert.pem')
    ssl_key = os.environ.get('SSL_KEY_PATH', 'key.pem')
    app.run(ssl_context=(ssl_cert, ssl_key))

