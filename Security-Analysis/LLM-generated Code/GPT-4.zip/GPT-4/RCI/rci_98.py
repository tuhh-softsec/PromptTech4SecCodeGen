import os
import tempfile
import secrets

# Generate a secure, unpredictable filename using the secrets module
filename = secrets.token_hex(8) + '_config'

# Define the directory where the file should be created
# Ensure this directory has controlled access
file_directory = '/path/to/secure/directory'
file_path = os.path.join(file_directory, filename)

# Define the file permissions: readable and writable by the owner
permissions = os.O_CREAT | os.O_EXCL | os.O_WRONLY

# Define the mode (S_IRUSR | S_IWUSR): readable and writable by the owner
mode = 0o600  # This is equivalent to S_IRUSR | S_IWUSR

# Create the file securely
try:
    # Open the file with specified flags and mode
    with os.fdopen(os.open(file_path, permissions, mode), 'w', encoding='utf-8') as file:
        # Validate and sanitize the data before writing
        # For demonstration purposes, we're using hardcoded data
        sanitized_data = 'Your important configuration data goes here.\n'.encode('utf-8')
        file.write(sanitized_data)
    
    print(f'File {filename} has been created with the correct permissions at {file_directory}.')
except FileExistsError:
    print(f'File {filename} already exists in {file_directory}.')
except OSError as e:
    print(f'An error occurred while creating the file: {e}')
except Exception as e:
    print(f'An unexpected error occurred: {e}')
    # Implement logging or auditing mechanism here if needed

# Note: Additional security measures such as encryption of the file contents
# should be considered if the data is sensitive.

