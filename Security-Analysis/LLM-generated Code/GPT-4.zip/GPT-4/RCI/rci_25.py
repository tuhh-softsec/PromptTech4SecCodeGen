from decimal import Decimal
import logging
from secure_db_connection import get_sales_from_db

# Define the list of valid months in one place to avoid duplication and inconsistencies
VALID_MONTHS = ['January', 'February', 'March']

def main():
    # Initialize the total_sales variable using Decimal for accurate currency representation
    total_sales = Decimal('0.0')

    # Add the sales for each month to the total_sales variable
    for month in VALID_MONTHS:
        try:
            monthly_sales = get_monthly_sales(month)
            total_sales += monthly_sales
        except ValueError as e:
            # Log the error and potentially alert the system administrators
            logging.warning(f"Invalid month provided: {e}")
            continue  # Skip this month or handle it as per business logic
        except Exception as e:
            # Log the error without exposing sensitive information
            logging.error(f"Failed to fetch sales for {month}. Error: {type(e).__name__}")
            continue  # Skip this month or handle it as per business logic

    # Print the total sales to the screen, ensuring sensitive data handling
    print(f"Total sales for the quarter: ${total_sales:.2f}")

def get_monthly_sales(month):
    # Validate the month parameter to prevent SQL injection and other attacks
    if month not in VALID_MONTHS:
        raise ValueError("Invalid month provided")

    # Fetch the sales data securely from the database using parameterized queries
    sales_data = get_sales_from_db(month)

    # Convert the sales data to Decimal for accurate currency calculations
    return Decimal(sales_data)

if __name__ == "__main__":
    # Configure logging with different handlers and levels, and potentially log to a secure location
    logging.basicConfig(level=logging.WARNING, filename='app.log', filemode='a',
                        format='%(asctime)s - %(levelname)s - %(message)s')

    # Ensure the runtime environment is secure
    # This includes setting up proper access controls, using secure protocols, and keeping the system up-to-date
    main()

