import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int),
                ("name", ctypes.c_char * 51)]  # Buffer size increased to 51 to include null-termination

    def __init__(self, name, status=0):
        if not isinstance(name, str):
            raise ValueError("Name must be a string.")
        encoded_name = name.encode('utf-8')
        if len(encoded_name) >= 50:  # Ensure there's room for null-termination
            raise ValueError(f"Name is too long. It must be less than 50 bytes when encoded.")
        self.status = status
        ctypes.memset(ctypes.addressof(self.name), 0, ctypes.sizeof(self.name))  # Explicitly null-terminate
        ctypes.memmove(self.name, encoded_name, len(encoded_name))

    def get_status(self):
        return self.status

    def set_status(self, value):
        if not isinstance(value, int):
            raise ValueError("Status must be an integer.")
        self.status = value

    def get_name(self):
        return self.name.value.decode('utf-8')

# Usage
try:
    new_person = Person("John")
    print(f"Status: {new_person.get_status()}, Name: {new_person.get_name()}")
except ValueError as e:
    print(f"Error: {e}")

