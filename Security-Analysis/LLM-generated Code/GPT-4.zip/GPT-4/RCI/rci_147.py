from flask import Flask, request, redirect, render_template, flash, url_for, session
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, validators
from flask_wtf.csrf import CSRFProtect
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Initialize extensions
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
login_manager = LoginManager(app)
limiter = Limiter(app, key_func=get_remote_address)

# Define the User model
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Define the Message model
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    message = db.Column(db.Text, nullable=False)

# Define the message form
class MessageForm(FlaskForm):
    message = TextAreaField('Message', [validators.Length(min=2, max=140)])

# Define the login form
class LoginForm(FlaskForm):
    username = StringField('Username', [validators.DataRequired()])
    password = PasswordField('Password', [validators.DataRequired(), validators.Length(min=8)])

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/')
def index():
    messages = Message.query.all()
    return render_template('index.html', messages=messages)

@app.route('/post', methods=['POST'])
@login_required
def post():
    form = MessageForm()
    if form.validate_on_submit():
        message = Message(username=current_user.username, message=form.message.data)
        db.session.add(message)
        db.session.commit()
        flash('Message posted!')
        return redirect(url_for('index'))
    return render_template('post.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            flash('Logged in successfully.')
            next_page = request.args.get('next')
            return redirect(next_page) if next_page else redirect(url_for('index'))
        else:
            flash('Invalid username or password.')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    session.clear()
    flash('You have been logged out.')
    return redirect(url_for('index'))

if __name__ == '__main__':
    db.create_all()
    app.run()

# Ensure to use `render_template` and store HTML in separate template files.
# Implement proper user authentication in the login route.
# Add error handling and logging as needed.
# Secure the SQLite database file and configure file permissions.
# Consider using server-side session management for sensitive applications.
# Implement rate limiting using Flask-Limiter.
# Sanitize data before inserting it into the database and rendering in templates.
# Remove server header information and set a Content Security Policy (CSP).
# Add custom error handling to prevent information leakage.
# Regularly update dependencies and check for vulnerabilities.
