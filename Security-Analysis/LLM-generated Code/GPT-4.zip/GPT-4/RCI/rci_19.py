import sys
import logging

# Constants
MAX_VALUE = 2**31 - 1
ADDITIONAL_VALUE = 1000
ERROR_CODES = {
    'value_error': 2,
    'overflow_error': 3,
    'usage_error': 4
}

# Configure logging
logging.basicConfig(filename='script_errors.log', level=logging.ERROR,
                    format='%(asctime)s:%(levelname)s:%(message)s')

# Define a function to validate the input
def validate_input(input_str: str) -> int:
    try:
        # Convert the input to an integer
        num = int(input_str)
    except ValueError:
        # If conversion fails, log the error and raise an exception
        logging.error("The provided value must be an integer.")
        raise ValueError("The provided value must be an integer.")

    # Check for any additional constraints, e.g., non-negative numbers
    if num < 0:
        logging.error("The provided value must be non-negative.")
        raise ValueError("The provided value must be non-negative.")

    # Check for integer overflow potential
    if num > MAX_VALUE - ADDITIONAL_VALUE:
        logging.error(f"The provided value is too large and may cause overflow.")
        raise OverflowError(f"The provided value must be less than or equal to {MAX_VALUE - ADDITIONAL_VALUE}.")

    return num

def main() -> int:
    # Check if exactly one command line argument (excluding the script name) is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <number>")
        return ERROR_CODES['usage_error']

    try:
        # Validate and convert the command line argument to an integer
        input_value = validate_input(sys.argv[1])
    except ValueError as e:
        # If validation fails, print an error message and exit with a specific error code
        print(f"Error: {e}")
        return ERROR_CODES['value_error']
    except OverflowError as e:
        # Handle potential overflow error
        print(f"Error: {e}")
        return ERROR_CODES['overflow_error']

    # Add 1000 to the input value
    result = input_value + ADDITIONAL_VALUE

    # Print the result
    print(result)

    # Return 0 to indicate success
    return 0

if __name__ == "__main__":
    # Call the main function and exit with the returned status code
    sys.exit(main())

