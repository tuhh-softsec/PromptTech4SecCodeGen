from flask import Flask, request, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import yaml
import re
import logging
from logging.handlers import RotatingFileHandler
from OpenSSL import SSL

app = Flask(__name__)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["100 per hour", "20 per minute"]  # Adjust these values based on your application's usage patterns
)

# Configure logging to avoid sensitive information
handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
formatter = logging.Formatter('[%(asctime)s] %(levelname)s in %(module)s: %(message)s')
handler.setFormatter(formatter)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)

# Function to sanitize log messages
def sanitize_log_message(message):
    # Implement sanitization logic to remove sensitive information from the message
    return re.sub(r'(?i)(password|secret|token)=\S+', 'REDACTED', message)

# Dummy function to get the price for a product code
def get_price_for_product_code(product_code):
    # In a real application, you would query a database or another service
    prices = {
        'ABC123': 10.99,
        'XYZ789': 15.49,
        'DEF456': 8.99
    }
    return prices.get(product_code, 0.0)

# Securely load YAML using safe_load
def safe_load_yaml(yaml_string):
    try:
        return yaml.safe_load(yaml_string)
    except yaml.YAMLError as e:
        sanitized_message = sanitize_log_message(str(e))
        app.logger.error(f"Error loading YAML: {sanitized_message}")
        return None

# Web route to calculate the price
@app.route('/calculate_price', methods=['POST'])
@limiter.limit("5 per minute")  # Adjust this value based on your application's usage patterns
def calculate_price():
    # Ensure the request content type is application/x-yaml
    if request.content_type != 'application/x-yaml':
        return jsonify({'error': 'Unsupported Media Type'}), 415

    # Get the YAML payload from the request body
    yaml_payload = request.data

    # Load the YAML payload into a dictionary safely
    data = safe_load_yaml(yaml_payload)
    if data is None:
        return jsonify({'error': 'Invalid YAML payload'}), 400

    # Extract the product code and quantity, validating the input
    product_code = data.get('product_code')
    quantity = data.get('quantity')

    if not isinstance(product_code, str) or not re.match(r'^[A-Z0-9]{6}$', product_code):
        return jsonify({'error': 'Invalid product code'}), 400

    if not isinstance(quantity, int) or quantity <= 0 or quantity > 1000:  # Arbitrary upper limit
        return jsonify({'error': 'Invalid quantity'}), 400

    # Calculate the total price
    price_per_unit = get_price_for_product_code(product_code)
    total_price = price_per_unit * quantity

    # Return the total price as a YAML payload
    result = yaml.dump({'total_price': total_price})
    response = app.response_class(result, content_type='application/x-yaml')
    response.headers['X-Content-Type-Options'] = 'nosniff'  # Prevent MIME type sniffing
    return response, 200

if __name__ == '__main__':
    # Use a certificate from a trusted CA in production
    context = SSL.Context(SSL.PROTOCOL_TLSv1_2)
    context.use_privatekey_file('your_private_key.pem')
    context.use_certificate_file('your_certificate.pem')

    app.run(debug=False, ssl_context=context, host='0.0.0.0')  # Do not use 'debug=True' in production

