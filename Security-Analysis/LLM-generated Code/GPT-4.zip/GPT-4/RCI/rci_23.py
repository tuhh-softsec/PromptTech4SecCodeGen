import secrets
from typing import List

# Constants for configuration
SALES_RANGE_MIN = 0
SALES_RANGE_MAX = 100000
MONTHS_IN_YEAR = 12
MONTHS_IN_QUARTER = 3

def getMonthlySales() -> int:
    """Simulate getting monthly sales, returning a cryptographically secure random number."""
    return secrets.randbelow(SALES_RANGE_MAX - SALES_RANGE_MIN + 1) + SALES_RANGE_MIN

def validateSalesFigure(sales: int) -> bool:
    """Validate that a sales figure is an integer within the expected range."""
    return isinstance(sales, int) and SALES_RANGE_MIN <= sales <= SALES_RANGE_MAX

def calculateQuarterlySales(monthly_sales: List[int]) -> List[int]:
    """Calculate the quarterly sales totals from monthly sales data."""
    if len(monthly_sales) % MONTHS_IN_QUARTER != 0:
        raise ValueError("The length of monthly_sales must be a multiple of 3.")
    if not all(validateSalesFigure(sale) for sale in monthly_sales):
        raise ValueError("All sales figures must be integers within the defined range.")
    
    quarterly_sales = []
    for i in range(0, len(monthly_sales), MONTHS_IN_QUARTER):
        quarter_total = sum(monthly_sales[i:i + MONTHS_IN_QUARTER])
        quarterly_sales.append(quarter_total)
    return quarterly_sales

def main():
    try:
        # Get monthly sales for each month and store them in a list
        monthly_sales = [getMonthlySales() for _ in range(MONTHS_IN_YEAR)]

        # Calculate quarterly sales
        quarterly_sales = calculateQuarterlySales(monthly_sales)

        # Print the quarterly sales results (consider masking or encrypting if sensitive)
        for i, sales in enumerate(quarterly_sales, 1):
            print(f"Sales for Quarter {i}: {sales}")
    except (ValueError, TypeError) as e:
        print(f"Error: {e}")

if __name__ == "__main__":
    main()

