import os
import re
from werkzeug.security import generate_password_hash, check_password_hash
from flask import Flask, request, jsonify
from flask_jwt_extended import JWTManager, jwt_required, create_access_token
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from icmplib import ping as icmp_ping
import logging

app = Flask(__name__)
limiter = Limiter(app, key_func=get_remote_address)
jwt = JWTManager(app)

# Load credentials from environment variables
ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME')
ADMIN_PASSWORD_HASH = os.environ.get('ADMIN_PASSWORD_HASH')  # Assuming the hash is already generated and stored in environment.

app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY')

# JWT-based auth
@app.route('/login', methods=['POST'])
def login():
    username = request.json.get('username', None)
    password = request.json.get('password', None)
    if username == ADMIN_USERNAME and check_password_hash(ADMIN_PASSWORD_HASH, password):
        access_token = create_access_token(identity=username)
        return jsonify(access_token=access_token)
    return jsonify({"error": "Invalid credentials"}), 401

# Ping route
@app.route('/ping', methods=['GET'])
@jwt_required()
@limiter.limit("5 per minute")
def api_ping():
    hostname = request.args.get('hostname', '')
    if not hostname or not is_valid_hostname(hostname):
        return jsonify({"error": "Invalid hostname"}), 400

    try:
        result = icmp_ping(hostname, count=4, timeout=2)
        output = str(result)
    except Exception as e:
        output = str(e)

    return jsonify({"output": output})

def is_valid_hostname(hostname):
    # Improved regular expression to validate the hostname
    if re.match(r"^[a-zA-Z0-9][-a-zA-Z0-9]{1,63}(\.[a-zA-Z0-9][-a-zA-Z0-9]{1,63})*$", hostname):
        return True
    return False

if __name__ == '__main__':
    app.run(ssl_context=('path/to/cert.pem', 'path/to/key.pem'))

logging.basicConfig(filename='app.log', level=logging.WARNING)
