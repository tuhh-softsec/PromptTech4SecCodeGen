from flask import Flask, send_file, abort, safe_join
import os
import re
from werkzeug.exceptions import HTTPException

app = Flask(__name__)

# Define a decorator to associate the URL /img with the img() function
@app.route('/img/<name>')
def img(name):
    # Use a more restrictive regular expression to validate the filename
    if not re.match(r'^[a-zA-Z0-9_\-]+$', name):
        # If the filename is not valid, return a 400 Bad Request response
        abort(400)
    
    # Check the file type (assuming images are .png, .jpg, or .jpeg)
    # Perform this check before accessing the file system
    if not name.lower().endswith(('.png', '.jpg', '.jpeg')):
        # If the file type is not allowed, return a 400 Bad Request response
        abort(400)
    
    # Use safe_join to securely construct the file path and prevent path traversal
    image_path = safe_join('images', name)
    
    # Check if the file exists and is a file, not a directory or other entity
    if not os.path.isfile(image_path):
        # If the file does not exist, return a 404 Not Found response
        abort(404)
    
    # Open the file securely and send it back to the browser as the response
    try:
        response = send_file(image_path)
        # Set security-related headers
        response.headers['X-Content-Type-Options'] = 'nosniff'
        response.headers['X-Frame-Options'] = 'DENY'
        response.headers['Content-Security-Policy'] = "default-src 'none'; img-src 'self';"
        return response
    except HTTPException as http_ex:
        # Catch specific HTTP exceptions and re-raise them
        raise http_ex
    except Exception as ex:
        # Log the exception details here (logging not shown for brevity)
        # If there's an error opening the file, return a 500 Internal Server Error response
        # Ensure no sensitive error information is returned to the client
        abort(500)

if __name__ == '__main__':
    # Ensure that debug mode is off in production
    app.run(debug=False, ssl_context='adhoc')  # Use adhoc SSL context for demonstration purposes

# Additional security measures to consider:
# - Implement access control to restrict file access based on user authentication and authorization
# - Serve static files through a dedicated server or CDN for improved performance and security
# - Set appropriate timeouts and limits to prevent resource exhaustion
# - Add logging and monitoring to detect and respond to security incidents
# - Keep Flask and other dependencies up to date and manage their versions with tools like pipenv or poetry
# - Enforce the use of HTTPS to protect data in transit, and consider setting the Strict-Transport-Security header

