import hashlib
import os
import sys
import logging
from tempfile import NamedTemporaryFile
import shutil

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def calculate_checksum(file_path):
    # Using SHA256 for checksum calculation
    sha256 = hashlib.sha256()
    try:
        with open(file_path, 'rb') as file:
            while True:
                data = file.read(65536)  # Read the file in chunks of 64KB
                if not data:
                    break
                sha256.update(data)
        return sha256.hexdigest()
    except Exception as e:
        logging.error(f"An error occurred while calculating the checksum: {e}")
        raise

def write_results_to_file(output_file_path, bytes_read, checksum):
    # Use a temporary file to write results atomically
    with NamedTemporaryFile('w', delete=False) as tmp_file:
        tmp_file.write(f"Bytes read: {bytes_read}\nChecksum: {checksum}\n")
        temp_name = tmp_file.name

    # Rename the temporary file to the output file path atomically
    shutil.move(temp_name, output_file_path)

def process_file(input_file_path, output_file_path):
    # Get the size of the file first
    bytes_read = os.path.getsize(input_file_path)

    # Calculate the checksum of the file
    checksum = calculate_checksum(input_file_path)

    # Check if the output file already exists
    if os.path.exists(output_file_path):
        user_input = input(f"The file {output_file_path} already exists. Overwrite? (y/n): ")
        if user_input.lower() != 'y':
            logging.info("User chose not to overwrite the existing file.")
            return

    # Save the number of bytes read and the checksum to the output file
    write_results_to_file(output_file_path, bytes_read, checksum)

if __name__ == "__main__":
    if len(sys.argv) != 3:
        logging.error("Usage: python script.py <input_file_path> <output_file_path>")
        sys.exit(1)

    input_file_path = sys.argv[1]
    output_file_path = sys.argv[2]

    # Validate and sanitize the input file path
    if not os.path.isfile(input_file_path):
        logging.error(f"The input file path {input_file_path} is not valid.")
        sys.exit(1)

    # Validate and sanitize the output file path
    output_dir = os.path.dirname(output_file_path)
    if output_dir and not os.path.isdir(output_dir):
        logging.error(f"The output file directory {output_dir} is not valid.")
        sys.exit(1)

    try:
        process_file(input_file_path, output_file_path)
    except Exception as e:
        logging.error(f"An error occurred during file processing: {e}")
        sys.exit(1)

