import sqlite3
import bcrypt
import os
from getpass import getpass

# Require environment variables for sensitive information
DATABASE_PATH = os.getenv('DATABASE_PATH')
if not DATABASE_PATH:
    raise ValueError("The DATABASE_PATH environment variable must be set.")

# Connect to the SQLite database using a context manager
def get_db_connection():
    conn = sqlite3.connect(DATABASE_PATH)
    return conn

# Function to hash a password with a specified cost factor
def hash_password(password, cost=12):
    salt = bcrypt.gensalt(rounds=cost)
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Function to validate username format
def validate_username(username):
    # Add appropriate validation rules as per your requirements
    if not username.isalnum() or len(username) < 3:
        raise ValueError("Username must be alphanumeric and at least 3 characters long.")

# Function to validate password strength
def validate_password_strength(password):
    # Implement password strength validation rules here
    if len(password) < 8:
        raise ValueError("Password must be at least 8 characters long.")

# Function to insert a new user into the database
def insert_user(username, password):
    validate_username(username)
    validate_password_strength(password)
    hashed_password = hash_password(password)
    with get_db_connection() as conn:
        cursor = conn.cursor()
        try:
            cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed_password))
            conn.commit()
            print("User created successfully.")
        except sqlite3.IntegrityError:
            print("Error: That username is already taken.")
        except sqlite3.OperationalError as e:
            print(f"An error occurred: {e}")

# Function to create the users table
def create_users_table():
    with get_db_connection() as conn:
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
        ''')
        conn.commit()

# Main program
def main():
    # Create the users table
    create_users_table()

    # Prompt for a username and password
    try:
        username = input("Enter a username: ")
        password = getpass("Enter a password: ")

        # Insert the new user into the database
        insert_user(username, password)
    except ValueError as e:
        print(e)

# Run the main program
if __name__ == "__main__":
    main()

