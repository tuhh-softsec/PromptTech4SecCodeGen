import os
import threading

def secure_delete(buffer):
    # Overwrite the buffer with random data in smaller chunks to avoid MemoryError
    chunk_size = 1024  # 1KB chunks
    for i in range(0, len(buffer), chunk_size):
        end = min(i + chunk_size, len(buffer))
        buffer[i:end] = os.urandom(end - i)

def allocate_and_free_buffer(buffer_size):
    # Validate buffer size to prevent memory exhaustion
    if not isinstance(buffer_size, int) or buffer_size <= 0:
        raise ValueError("Buffer size must be a positive integer")

    # Limit the buffer size to a reasonable maximum (e.g., 1MB)
    max_buffer_size = 1024 * 1024
    if buffer_size > max_buffer_size:
        raise ValueError("Buffer size cannot exceed {} bytes".format(max_buffer_size))

    buffer = None
    try:
        # Allocate the buffer
        buffer = bytearray(buffer_size)

        # Simulate some work with the buffer
        # ...

        # Securely clear sensitive data from the buffer
        secure_delete(buffer)

    except MemoryError:
        # Handle memory allocation errors gracefully
        print("Memory allocation failed. Please try a smaller buffer size.")
    finally:
        # Explicitly free the buffer if it was allocated
        if buffer is not None:
            del buffer

# Example usage:
buffer_size = 1024  # Size of the buffer in bytes
lock = threading.Lock()

def thread_safe_allocate_and_free():
    with lock:
        try:
            allocate_and_free_buffer(buffer_size)
        except ValueError as e:
            print(e)

# Create and start threads
threads = [threading.Thread(target=thread_safe_allocate_and_free) for _ in range(10)]
for thread in threads:
    thread.start()
for thread in threads:
    thread.join()

# Note: The secure_delete function is used to overwrite sensitive data in the buffer
# with random bytes in smaller chunks to avoid MemoryError. The threading.Lock is used
# to ensure thread safety when the function is called from multiple threads.

# When working with other resources like file handles or network sockets, use context
# managers (e.g., the `with` statement) to ensure they are properly cleaned up even if
# an error occurs.

# The `del` statement is used here to remove the reference to the buffer, which signals
# to Python that the memory can be freed. However, the actual freeing of memory is
# handled by Python's garbage collector, and the `del` statement does not guarantee
# immediate memory deallocation.

# It is important to avoid leaking information through error messages. The error messages
# in this code are generic and do not disclose system limits or configurations.

# This code snippet includes comments explaining the security considerations and rationale
# behind certain decisions. For a production system, it is recommended to provide more
# in-depth documentation and to implement unit tests to validate the correct behavior of
# the code.

