import os
from flask import Flask, request, redirect, url_for, flash, jsonify
from flask_wtf.csrf import CSRFProtect
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, login_user, logout_user, login_required
from werkzeug.security import generate_password_hash, check_password_hash
from sqlalchemy.exc import IntegrityError
import psycopg2
import psycopg2.extras
import psycopg2.pool

# Load database configuration from environment variables
db_params = {
    'dbname': os.environ.get('DB_NAME'),
    'user': os.environ.get('DB_USER'),
    'password': os.environ.get('DB_PASSWORD'),
    'host': os.environ.get('DB_HOST'),
    'sslmode': 'require',
    'sslrootcert': os.environ.get('DB_SSLROOTCERT')  # Path to the trusted CA bundle
}

# Initialize connection pool
connection_pool = psycopg2.pool.SimpleConnectionPool(1, 10, **db_params)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY')  # Needed for CSRF protection
csrf = CSRFProtect(app)

# Initialize Flask-Login
login_manager = LoginManager()
login_manager.init_app(app)

# Initialize SQLAlchemy
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URL')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# User authentication setup
# ...

@app.route('/buy_stock', methods=['POST'])
@csrf.protect  # Ensure CSRF protection is enforced
def handle_buy_stock():
    stock_name = request.form.get('stock_name', '').strip()
    quantity = request.form.get('quantity', '').strip()

    # Enhanced input validation
    if not stock_name.isalpha() or not quantity.isdigit() or int(quantity) <= 0:
        flash("Invalid input. Please enter a valid stock name and quantity.", "error")
        return redirect(url_for('buy_stock_page'), 400)

    # Call the buy_stock function with the form data
    buy_stock(stock_name, int(quantity))

    # Redirect to a success page or indicate success
    flash("Stock purchase successful!", "success")
    return redirect(url_for('success_page'))

# Additional routes and functions
# ...

if __name__ == '__main__':
    # Use a WSGI server like Gunicorn for production deployments
    # app.run() should only be used for development
    pass

