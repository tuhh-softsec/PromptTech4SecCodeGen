import secrets
import logging

# Configure logging to use a secure logging service with appropriate access controls
logging.basicConfig(level=logging.ERROR)

# Function to generate a random integer within a specified range
def generate_random_integer(min_value=1000, range_size=1000):
    if range_size <= 0:
        raise ValueError("range_size must be a positive number.")
    
    # Generate a secure random integer within the range [min_value, min_value + range_size - 1]
    try:
        return secrets.randbelow(range_size) + min_value
    except Exception as e:
        # Log the error using a secure logging service instead of printing it
        logging.error(f"An error occurred: {e}")
        # Re-raise the exception to be handled by the caller
        raise

# Example usage of the function
try:
    # Generate a random integer within the specified range
    random_integer = generate_random_integer()
    # Use the random integer in your application logic
except ValueError as ve:
    logging.error(f"Invalid input parameter: {ve}")
except Exception as e:
    logging.error(f"Unexpected error: {e}")