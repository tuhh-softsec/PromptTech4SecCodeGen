import os
from dotenv import load_dotenv
from flask import Flask, render_template, redirect, url_for, request, session, flash
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import InputRequired, Length, Regexp
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_bcrypt import Bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY')  # Load secret key from environment variable
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SECURE'] = True
app.config['REMEMBER_COOKIE_DURATION'] = 3600  # Set session timeout to 1 hour

bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["5 per minute"]
)

talisman = Talisman(app)

# Dummy user database with hashed passwords
users = {'user1': {'password_hash': bcrypt.generate_password_hash('Password1!').decode('utf-8')}}

# User class
class User(UserMixin):
    def __init__(self, username):
        self.id = username

# Forms
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[InputRequired(), Length(min=3, max=20)])
    password = PasswordField('Password', validators=[
        InputRequired(),
        Length(min=8, max=72),
        Regexp(r'^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]', message="Password must include uppercase, lowercase, numeric, and special characters.")
    ])

@login_manager.user_loader
def load_user(user_id):
    if user_id in users:
        return User(user_id)
    return None

@app.route('/')
def index():
    return '<a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("10/minute")  # Rate limiting for login attempts
def login():
    form = LoginForm()
    if form.validate_on_submit():
        username = form.username.data
        password = form.password.data
        user = users.get(username)
        
        if user and bcrypt.check_password_hash(user['password_hash'], password):
            user_obj = User(username)
            login_user(user_obj)
            return redirect(url_for('secret'))
        else:
            flash('Invalid username or password.')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/secret')
@login_required
def secret():
    return 'Secret setting.'

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Use ad-hoc SSL for demonstration purposes

