import sys
import logging
import signal

# Set up basic logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class ArrayProcessor:
    @staticmethod
    def get_value_from_array(array, index):
        if not isinstance(index, int) or index < 0:
            raise ValueError("Index must be a non-negative integer.")
        if index >= len(array):
            raise IndexError(f"Index out of bounds. Valid range: 0-{len(array)-1}")
        return array[index]

def handle_sigint(signum, frame):
    logging.info("Interrupt signal received. Exiting gracefully.")
    sys.exit(130)  # Exit code 130 is standard for termination by Ctrl+C

def main(id_sequence):
    signal.signal(signal.SIGINT, handle_sigint)  # Handle Ctrl+C (SIGINT)

    max_retries = 3
    for _ in range(max_retries):
        try:
            input_index = int(input("Enter an index: "))
            value = ArrayProcessor.get_value_from_array(id_sequence, input_index)
            print(f"The value at index {input_index} is {value}.")
            return  # Exit the loop and function on success
        except ValueError as ve:
            logging.error(ve)
        except IndexError as ie:
            logging.error(ie)

    logging.error("Maximum retries reached. Exiting.")
    sys.exit(1)  # Exit with a status code indicating an error

if __name__ == "__main__":
    # Example array, in a real-world scenario this would be dynamic or passed as an argument
    id_sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]

    try:
        main(id_sequence)
        sys.exit(0)  # Exit with a status code indicating success
    except KeyboardInterrupt:
        # This block is redundant due to the signal handler but included for clarity
        pass
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        sys.exit(2)  # Exit with a status code indicating an unexpected error

