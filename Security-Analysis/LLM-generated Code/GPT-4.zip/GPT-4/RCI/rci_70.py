import os
import uuid
from werkzeug.utils import secure_filename
from flask import Flask, request, abort, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_httpauth import HTTPBasicAuth
import magic  # python-magic is a Python interface to the libmagic file type identification library.
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

# Define the allowed MIME types
ALLOWED_MIME_TYPES = {'text/plain', 'application/pdf', 'image/png', 'image/jpeg', 'image/gif'}

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Ensure the uploads folder exists and is not publicly accessible
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Set up rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["10 per minute"]
)

# Set up basic authentication
auth = HTTPBasicAuth()

# Replace with your actual validation logic
@auth.verify_password
def verify_password(username, password):
    return username == os.getenv('UPLOAD_USERNAME') and password == os.getenv('UPLOAD_PASSWORD')

def file_is_safe_type(filestream):
    """
    Check if the file MIME type is allowed.
    """
    mime = magic.from_buffer(filestream.read(1024), mime=True)
    filestream.seek(0)  # Reset file pointer after reading
    return mime in ALLOWED_MIME_TYPES

@app.route('/upload', methods=['POST'])
@auth.login_required
@limiter.limit("5 per minute")  # Adjust rate limit as needed
def upload_route():
    """
    Handle the file upload process with added security checks.
    """
    # Check if the post request has the file part
    if 'file' not in request.files:
        abort(400, 'No file part in the request.')
    
    file = request.files['file']
    
    # If the user does not select a file, the browser submits an
    # empty file without a filename.
    if file.filename == '':
        abort(400, 'No selected file.')
    
    if file and file_is_safe_type(file):
        # Secure the filename before using it
        filename = secure_filename(file.filename)
        # Generate a unique identifier for the file to prevent overwriting and information disclosure
        unique_id = str(uuid.uuid4())
        filename = f"{unique_id}-{filename}"
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        # Save the file to the uploads folder
        file.save(filepath)
        return jsonify(message='File successfully uploaded.', filename=filename), 200
    else:
        abort(400, 'Invalid file type.')

if __name__ == '__main__':
    # Ensure that the application runs in production mode and over HTTPS
    app.run(debug=False, ssl_context='adhoc')  # Use 'adhoc' for self-signed cert or provide your own

