import os
import mimetypes
from PIL import Image
import mysql.connector
from mysql.connector import Error
import configparser
import hashlib

# Load configuration from a file
config = configparser.ConfigParser()
config.read(os.path.join(os.path.dirname(__file__), 'config.ini'))

# Function to validate an image file
def is_image_file(filename):
    # Check MIME type
    mime_type, _ = mimetypes.guess_type(filename)
    if mime_type not in ['image/png', 'image/jpeg', 'image/gif']:
        return False

    # Open the image to ensure it's not corrupted
    try:
        with Image.open(filename) as img:
            img.verify()
    except (IOError, SyntaxError):
        return False

    return True

# Function to convert image to binary data
def convert_image_to_binary(filename):
    with open(filename, 'rb') as file:
        binary_data = file.read()
    return binary_data

# Function to insert image into the database
def insert_image_to_db(image_data, cursor, connection):
    try:
        query = "INSERT INTO images_table (image) VALUES (%s)"
        cursor.execute(query, (image_data,))
        connection.commit()
        print("Image has been inserted successfully.")
    except Error as e:
        print(f"An error occurred: {e}")

# Main function to handle the upload process
def upload_image(image_path):
    if not is_image_file(image_path):
        print("The provided file is not a valid image.")
        return

    # Check file size to prevent DoS attacks
    if os.path.getsize(image_path) > 10 * 1024 * 1024:  # 10MB limit
        print("The file size exceeds the maximum allowed limit.")
        return

    # Check for duplicate files using a hash
    file_hash = hashlib.md5(convert_image_to_binary(image_path)).hexdigest()
    if file_exists_in_db(file_hash):
        print("This file has already been uploaded.")
        return

    image_data = convert_image_to_binary(image_path)

    connection = None
    try:
        # Establish a database connection using SSL if supported
        connection = mysql.connector.connect(
            host=config['mysql']['host'],
            database=config['mysql']['database'],
            user=config['mysql']['user'],
            password=config['mysql']['password'],
            ssl_ca=config['mysql']['ssl_ca'],
            ssl_verify_identity=True  # Correct option for SSL certificate verification
        )

        if connection.is_connected():
            with connection.cursor() as cursor:
                insert_image_to_db(image_data, cursor, connection)
    except Error as e:
        print(f"Error while connecting to MySQL: {e}")
    finally:
        if connection and connection.is_connected():
            connection.close()

def file_exists_in_db(file_hash):
    # Function to check if the file already exists in the database
    # Implement the logic to check the database for the file hash
    pass

if __name__ == "__main__":
    # Securely get the image path from the user
    image_path = input("Please enter the path to the image file: ").strip()
    image_path = os.path.realpath(image_path)  # Resolve any symbolic links

    # Check if the file is within a safe directory
    safe_directory = os.path.realpath(config['paths']['safe_directory'])
    if not os.path.commonpath([safe_directory, image_path]) == safe_directory:
        print("The file is not within the allowed directory.")
    else:
        upload_image(image_path)

