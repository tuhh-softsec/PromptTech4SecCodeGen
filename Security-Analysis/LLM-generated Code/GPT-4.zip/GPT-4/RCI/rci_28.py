from flask import Flask, request, redirect, make_response
from urllib.parse import urlparse, urljoin
import re

app = Flask(__name__)

# Regular expression pattern to match any subdomain of example.com, including the root domain
pattern = re.compile(r'^(?:[\w-]+\.)?example\.com$', re.IGNORECASE)

@app.route('/redirect')
def redirect_to_target():
    target = request.args.get('target', '')

    # Parse the URL to extract the domain and scheme
    parsed_url = urlparse(target)
    domain = parsed_url.netloc
    scheme = parsed_url.scheme

    # Validate the scheme
    if scheme not in ['http', 'https']:
        return "Invalid URL scheme. Only HTTP and HTTPS are allowed.", 400

    # Check if the domain matches the regular expression
    if pattern.match(domain):
        # Force HTTPS by replacing the scheme with 'https://'
        secure_target = urljoin('https://', urlparse(target)._replace(scheme='https').geturl())

        # Redirect to the target using HTTPS
        response = redirect(secure_target)
    else:
        # Provide user feedback explaining why the redirect did not occur
        response = make_response("Invalid target. Redirect only allowed to the same site (example.com).", 400)

    # Add security headers to the response
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "SAMEORIGIN"
    response.headers['Strict-Transport-Security'] = "max-age=63072000; includeSubDomains"

    return response

if __name__ == '__main__':
    # Use a trusted SSL/TLS certificate for production
    app.run(ssl_context=('path/to/cert.pem', 'path/to/key.pem'))

