import html
from http.server import BaseHTTPRequestHandler, HTTPServer
import ssl
import os
from urllib.parse import parse_qs
import cgi

class SecureHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            # Read the content length from the headers
            content_length = int(self.headers['Content-Length'])
            if content_length > 10000:  # Set a reasonable limit to prevent buffer overflow
                self.send_error(413, "Content-Length too large")
                return
            
            # Read the correct amount of data from the request
            post_data = self.rfile.read(content_length)
            
            # Use cgi module to parse post_data safely
            ctype, pdict = cgi.parse_header(self.headers.get('content-type'))
            if ctype == 'multipart/form-data':
                post_vars = cgi.parse_multipart(self.rfile, pdict)
            elif ctype == 'application/x-www-form-urlencoded':
                post_vars = parse_qs(post_data.decode('utf-8'), keep_blank_values=1)
            else:
                post_vars = {}
            
            # Validate and sanitize the username
            username = post_vars.get('username', [None])[0]
            if not username or not username.isalnum():
                self.send_error(400, "Invalid username")
                return
            safe_username = html.escape(username)
            
            # Construct the response
            response_content = f"hello {safe_username}"
            response_bytes = response_content.encode('utf-8')
            
            # Write the response headers
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(response_bytes)))
            self.send_header("Connection", "close")
            # Add security headers
            self.send_header("X-Content-Type-Options", "nosniff")
            self.send_header("X-Frame-Options", "DENY")
            self.send_header("X-XSS-Protection", "1; mode=block")
            self.send_header("Strict-Transport-Security", "max-age=63072000; includeSubDomains")
            self.end_headers()
            
            # Write the response content
            self.wfile.write(response_bytes)
        except Exception as e:
            self.send_error(500, "Server error: " + str(e))

def run(server_class=HTTPServer, handler_class=SecureHTTPRequestHandler, addr='localhost', port=443):
    server_address = (addr, port)
    httpd = server_class(server_address, handler_class)
    
    # Set up an SSL context to use HTTPS
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain(certfile=os.getenv('CERT_FILE', 'path/to/cert.pem'), keyfile=os.getenv('KEY_FILE', 'path/to/key.pem'))
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    
    print(f"Starting HTTPS server on {addr}:{port}")
    httpd.serve_forever()

if __name__ == "__main__":
    run()

