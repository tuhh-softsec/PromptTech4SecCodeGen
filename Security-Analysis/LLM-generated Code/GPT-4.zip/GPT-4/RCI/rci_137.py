import os
import psycopg2
from psycopg2 import pool
import logging
from logging.handlers import RotatingFileHandler

# Configure logging to avoid sensitive information and use rotating logs
log_formatter = logging.Formatter('%(name)s - %(levelname)s - %(message)s')
log_handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
log_handler.setFormatter(log_formatter)
log_handler.setLevel(logging.ERROR)  # Only log errors to avoid verbose output
logger = logging.getLogger('database_logger')
logger.setLevel(logging.ERROR)
logger.addHandler(log_handler)

# Set file permissions for logs (to be done in deployment scripts)
# os.chmod('app.log', 0o640) # Uncomment this line in deployment scripts

# Initialize the connection pool
try:
    db_connection_pool = psycopg2.pool.SimpleConnectionPool(
        1,  # Minimum number of connections
        10,  # Maximum number of connections
        host=os.getenv('DB_HOST'),
        database=os.getenv('DB_NAME'),
        user=os.getenv('DB_USER'),
        password=os.getenv('DB_PASSWORD'),
        sslmode='require'  # Enforce SSL/TLS connection
    )
except psycopg2.OperationalError as e:
    logger.error("An error occurred while connecting to the database.")
    raise RuntimeError("Database connection failed") from None

def is_user_moderator(username):
    # Validate input more comprehensively
    if not isinstance(username, str) or len(username) > 100 or not username.isalnum():
        logger.error("Invalid username provided.")
        return False

    conn = None
    try:
        # Get a connection from the pool
        conn = db_connection_pool.getconn()
        if conn is None:
            logger.error("Failed to obtain a database connection from the pool.")
            return False

        # Create a cursor object
        with conn.cursor() as cur:
            # Define the query to check if the user is a moderator
            query = "SELECT is_moderator FROM users WHERE username = %s;"

            # Execute the query safely with parameterized SQL
            cur.execute(query, (username,))

            # Fetch the result
            result = cur.fetchone()

            # Check if the user is a moderator
            return result[0] if result else False

    except psycopg2.Error as e:
        logger.error("An error occurred while executing the query.")
        return False
    finally:
        # Return the connection to the pool
        if conn:
            db_connection_pool.putconn(conn)

# Example usage
username = 'example_user'
moderator_status = is_user_moderator(username)
print(f"Is the user a moderator? {moderator_status}")

