import os
import magic
from flask import Flask, request, jsonify
from werkzeug.utils import secure_filename
import sqlalchemy as db
from sqlalchemy.orm import sessionmaker

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB limit

# Database configuration
DATABASE_URI = os.environ.get('DATABASE_URI')  # Get from environment variable
engine = db.create_engine(DATABASE_URI)
Session = sessionmaker(bind=engine)

ALLOWED_EXTENSIONS = {'pdf'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def is_valid_pdf(file_path):
    mime = magic.Magic(mime=True)
    mime_type = mime.from_file(file_path)
    return mime_type == 'application/pdf'

def save_file_path(file_name):
    with Session() as session:
        session.execute("INSERT INTO FilePaths (path) VALUES (:path)", {'path': file_name})
        session.commit()

@app.route('/upload_pdf', methods=['POST'])
def upload_pdf():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        if not is_valid_pdf(file_path):
            os.remove(file_path)  # Remove the uploaded file
            return jsonify({'error': 'Invalid PDF file'}), 400

        save_file_path(filename)  # Store only the filename, not the full path
        return jsonify({'message': 'File uploaded successfully', 'file_name': filename})
    else:
        return jsonify({'error': 'Invalid file type'}), 400

if __name__ == '__main__':
    app.run(debug=False)

# Ensure proper authentication, rate limiting, logging, and error handling (not shown in this snippet)
