import sys
import re
import logging
import os

# Configure logging
logging.basicConfig(filename='user_info.log', level=logging.INFO, format='%(asctime)s %(message)s')

# Configurable file path via environment variable or default to '/etc/passwd'
PASSWD_FILE = os.getenv('PASSWD_FILE', '/etc/passwd')

def get_user_info(username):
    # Validate username using a regular expression to allow only alphanumeric characters and underscores
    if not re.match(r'^\w+$', username):
        sanitized_username = re.sub(r'[^\w]', '_', username)  # Sanitize username before logging
        logging.warning("Invalid username attempted: %s", sanitized_username)
        return "Invalid username. Usernames must be alphanumeric or underscore characters only."

    try:
        with open(PASSWD_FILE, 'r', encoding='utf-8') as passwd_file:
            for line in passwd_file:
                if re.match(r'^' + re.escape(username) + r':', line):
                    logging.info("User info retrieved for username: %s", username)
                    return line.strip()
        return "User not found."
    except FileNotFoundError:
        logging.error("The passwd file does not exist.")
        return "An error occurred: passwd file not found."
    except PermissionError:
        logging.error("Permission denied when accessing the passwd file.")
        return "An error occurred: permission denied."
    except Exception as e:
        logging.error("An unexpected error occurred: %s", e)
        return "An unexpected error occurred."

if __name__ == "__main__":
    if os.geteuid() == 0:
        print("Warning: Running with elevated privileges is not recommended unless necessary.")
    
    if len(sys.argv) != 2:
        print("Usage: python3 script.py <username>")
        sys.exit(1)

    username = sys.argv[1]
    user_info = get_user_info(username)
    
    print(user_info)

