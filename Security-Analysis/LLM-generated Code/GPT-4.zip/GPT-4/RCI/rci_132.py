import os
from flask import Flask, escape, request, make_response, jsonify
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.exceptions import HTTPException

app = Flask(__name__)

# Configure a strong secret key for session management
app.secret_key = os.urandom(24)

# Set up rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Decorator to map the URL to the hello function
@app.route('/hello/<username>')
@limiter.limit("10 per minute")  # Rate limit for this endpoint
def hello(username):
    # Validate the username (e.g., check length, character set, etc.)
    if not validate_username(username):
        return make_response(jsonify({"error": "Invalid username"}), 400)

    # Use the escape function to convert special characters to HTML-safe sequences
    safe_username = escape(username)
    # Return the string with the escaped username
    return jsonify({"message": f'Hello, {safe_username}!'})

def validate_username(username):
    # Implement username validation logic here
    # For example, check if the username is alphanumeric and has a certain length
    # and does not contain any malicious patterns or Unicode characters
    return username.isalnum() and 1 <= len(username) <= 50

@app.errorhandler(HTTPException)
def handle_exception(e):
    """Return JSON instead of HTML for HTTP errors."""
    response = e.get_response()
    response.data = jsonify({"code": e.code, "message": e.description})
    response.content_type = "application/json"
    return response

if __name__ == '__main__':
    # Run the Flask app with secure settings for production
    from waitress import serve
    serve(app, host='0.0.0.0', port=5000)  # Use a production-ready server like Waitress

