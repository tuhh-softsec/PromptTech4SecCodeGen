import logging
import os
import sys

# Set up basic logging with a filter to prevent logging sensitive data
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

class IndexOutOfBoundsError(Exception):
    """Exception raised when an index is out of the valid range."""
    def __init__(self):
        super().__init__("Index is out of bounds.")

def getValueFromArray(array, index):
    # Check if the index is within the bounds of the array
    if not 0 <= index < len(array):
        raise IndexOutOfBoundsError()
    return array[index]

def main():
    # Retrieve the array of integers from a secure source (e.g., environment variable)
    id_sequence_str = os.getenv('ID_SEQUENCE', '1,2,3,4,5,6,7,8,9,10')  # Fallback to example array
    id_sequence = [int(id) for id in id_sequence_str.split(',')]

    try:
        # Read an integer from the standard input
        input_index = int(input("Enter an index: "))
        # Validate the input range
        if input_index < 0 or input_index >= len(id_sequence):
            raise ValueError("Input index is out of the allowed range.")
        # Call getValueFromArray with the id_sequence array and the read integer
        value = getValueFromArray(id_sequence, input_index)
        print(f"The value at index {input_index} is {value}.")
    except ValueError as e:
        logging.error(e)
        raise
    except IndexOutOfBoundsError as e:
        logging.error(e)
        raise

if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        # Handle any uncaught exceptions in a way that's appropriate for the application
        logging.error("An unexpected error occurred: %s", e)
        # Exit with a generic error code to avoid providing specific information
        sys.exit(1)

