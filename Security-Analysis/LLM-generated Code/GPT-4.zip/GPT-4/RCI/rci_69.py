import os
import magic
from flask import Flask, request, redirect, url_for, flash, render_template
from werkzeug.utils import secure_filename
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
import logging
from itsdangerous import exc
import antivirus  # hypothetical antivirus library

UPLOAD_FOLDER = 'uploads'
ALLOWED_MIME_TYPES = {'text/plain', 'application/pdf', 'image/png', 'image/jpeg', 'image/gif'}

app = Flask(__name__)
app.wsgi_app = ProxyFix(app.wsgi_app)
Talisman(app)
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max-limit.
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'you-should-really-change-this'
if app.config['SECRET_KEY'] == 'you-should-really-change-this':
    raise ValueError("SECRET_KEY environment variable not set!")

app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'

# Ensure the upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(file_stream):
    mime = magic.from_buffer(file_stream.read(1024), mime=True)
    file_stream.seek(0)  # Reset file pointer after reading
    return mime in ALLOWED_MIME_TYPES

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limit file upload endpoint
def upload_file():
    try:
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
        file = request.files['file']
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if file and allowed_file(file.stream):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            if os.path.exists(file_path):
                # Implement a more robust file versioning system here
                flash('File already exists with that name')
                return redirect(request.url)
            # Scan for malware before saving the file
            if antivirus.scan_stream(file.stream):
                file.save(file_path)
                flash('File successfully uploaded')
                return redirect(url_for('index'))
            else:
                flash('File is potentially dangerous and has been rejected')
                return redirect(request.url)
        else:
            flash('Invalid file type')
            return redirect(request.url)
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        flash('An error occurred while uploading the file.')
        return redirect(request.url)

# Setup logging
if not app.debug:
    logging.basicConfig(level=logging.INFO)

if __name__ == '__main__':
    # Do not use 'debug=True' in production!
    app.run(ssl_context=('cert.pem', 'key.pem'))  # Use proper SSL certificates

