import os

def secure_file_open(file_path, data_to_write):
    # Validate the file path to prevent directory traversal attacks
    if os.path.isabs(file_path) or '..' in file_path:
        raise ValueError("Invalid file path.")

    # Define the flags
    flags = os.O_CREAT | os.O_WRONLY
    # Define the mode (permissions) for the new file, if it is created
    mode = 0o600

    # Check for symbolic links if required by the application's security policy
    if os.path.islink(file_path):
        raise ValueError("File path points to a symbolic link.")

    # Attempt to open the file safely
    try:
        # Open the file descriptor
        fd = os.open(file_path, flags, mode)
    except PermissionError as e:
        print(f"Permission denied: {e}")
        return
    except FileNotFoundError as e:
        print(f"File not found: {e}")
        return
    except OSError as e:
        print(f"An error occurred: {e}")
        return

    # Use a context manager to ensure the file descriptor is closed properly
    try:
        with os.fdopen(fd, 'wb') as file_obj:
            # Write data to the file, ensuring proper encoding for text data
            file_obj.write(data_to_write.encode('utf-8'))
    except OSError as e:
        print(f"An error occurred while writing to the file: {e}")
    finally:
        # Ensure that the file descriptor is closed in case of an exception
        if 'fd' in locals() and not fd.closed:
            os.close(fd)

# Usage example
try:
    secure_file_open('example.txt', 'Hello, world!\n')
except ValueError as e:
    print(f"Error: {e}")

# Additional security considerations:
# - Ensure that the script does not run with elevated privileges unless necessary.
# - Be cautious about the information you expose in error messages.
# - Document the behavior of `os.O_TRUNC` to inform users about potential data loss.
# - Implement file locks or atomic rename operations if atomicity is required.

