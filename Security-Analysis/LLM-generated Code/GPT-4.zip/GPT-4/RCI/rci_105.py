import os
import errno
from cryptography.fernet import Fernet

# Define a secure location for the sensitive file
secure_directory = os.getenv('SECURE_DIRECTORY', '/default/path/to/secure/directory')
file_name = 'secret.txt'
file_path = os.path.join(secure_directory, file_name)

# Use a secrets management tool or service to store sensitive data and encryption key
sensitive_data = os.getenv('SENSITIVE_DATA')
encryption_key = os.getenv('ENCRYPTION_KEY')

# Validate that the sensitive data and encryption key are not None
if sensitive_data is None or encryption_key is None:
    raise ValueError("Sensitive data or encryption key not found in environment variables.")

# Encrypt the sensitive data before writing to the file
fernet = Fernet(encryption_key)
encrypted_data = fernet.encrypt(sensitive_data.encode())

# Ensure the secure directory exists with the correct permissions
if not os.path.exists(secure_directory):
    os.makedirs(secure_directory, mode=0o700)
else:
    os.chmod(secure_directory, 0o700)

# Create a file with secure permissions from the outset
try:
    # Open the file with write permissions for the owner only
    fd = os.open(file_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, 'wb') as file:
        # Write the encrypted sensitive data to the file
        file.write(encrypted_data)
except OSError as e:
    if e.errno == errno.EEXIST:
        print("Error: The file already exists.")
    else:
        raise

# Avoid printing file permissions or paths to prevent disclosure
# Implement audit logging for sensitive operations (not shown here due to complexity)

# Note: Error handling is included to manage file operations and permission changes.
# The sensitive data is not hardcoded and is retrieved from an environment variable.
# The file is created with secure permissions (0o600) to allow read/write for the owner only.
# The file is created in a secure directory with proper access controls.
# Encryption is implemented using the cryptography library.
# Secure deletion practices should be implemented as needed.

