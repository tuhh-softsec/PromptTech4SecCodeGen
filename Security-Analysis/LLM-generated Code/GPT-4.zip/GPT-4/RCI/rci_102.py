import os
import tempfile
import hashlib

# Define the content you want to write to the file
important_config = 'some_important_configuration_data'

# Use the tempfile module to securely create a temporary file
with tempfile.NamedTemporaryFile(mode='w+', delete=False) as temp_file:
    file_path = temp_file.name
    # Write the content to the temporary file
    temp_file.write(important_config)
    temp_file.flush()
    os.fsync(temp_file.fileno())  # Ensure all data is written to disk

# Define the final path where you want to store the configuration securely
final_path = '/secure/path/to/config_file.txt'

# Validate and sanitize the final_path here if it comes from user input

# Set the umask to ensure file permissions are set to 0o700 from the start
old_umask = os.umask(0o077)

try:
    # Check that the final_path does not exist and is not a symlink
    if os.path.exists(final_path) or os.path.islink(final_path):
        raise FileExistsError(f"The file {final_path} already exists or is a symlink.")

    # Open the file with the specified flags and permissions
    with os.fdopen(os.open(final_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o700), 'wb') as final_file:
        # Read the content from the temporary file
        with open(file_path, 'rb') as temp_file:
            data = temp_file.read()
            # Verify data integrity by comparing hashes
            original_hash = hashlib.sha256(important_config.encode()).hexdigest()
            temp_hash = hashlib.sha256(data).hexdigest()
            if original_hash != temp_hash:
                raise ValueError("Data integrity check failed.")
            # Write the content to the final file
            final_file.write(data)
except OSError as e:
    print(f"An error occurred: {e.strerror}")
finally:
    # Restore the original umask
    os.umask(old_umask)
    # Securely delete the temporary file by overwriting with random data
    with open(file_path, 'ba+') as temp_file:
        temp_file.write(os.urandom(os.path.getsize(file_path)))
    os.remove(file_path)

print(f"File '{final_path}' has been written with the specified permissions.")

