import sqlite3
import bcrypt
import logging
import os
from getpass import getpass

# Configure logging to write to a secure file with a specific format
logging.basicConfig(
    level=logging.INFO,
    filename='/path/to/secure/logfile.log',  # Replace with a secure log file path
    filemode='a',
    format='%(asctime)s - %(levelname)s - %(message)s'
)

# Function to hash a password
def hash_password(password):
    # Generate a salt
    salt = bcrypt.gensalt()
    # Generate a password hash
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

# Function to verify a password
def verify_password(stored_password, provided_password):
    # Check that an unhashed password matches one that has previously been hashed
    return bcrypt.checkpw(provided_password.encode('utf-8'), stored_password)

# Function to insert a new user into the database
def insert_user(cursor, username, password):
    hashed_password = hash_password(password)
    # Use a parameterized query to prevent SQL injection
    cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, hashed_password))

# Function to create a database connection
def create_db_connection(db_file):
    if not os.path.isfile(db_file):
        raise FileNotFoundError(f"Database file {db_file} does not exist.")
    return sqlite3.connect(db_file)

# Main program
def main(db_file):
    try:
        # Connect to the database using a context manager
        with create_db_connection(db_file) as conn:
            # Create a cursor object using the cursor() method
            cursor = conn.cursor()
            # Create table if it doesn't exist
            cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL
            )
            ''')
            conn.commit()

            # Prompt the user for a username and password
            username = input("Enter your username: ")
            password = getpass("Enter your password: ")

            # Validate user input
            if len(username) < 3 or len(password) < 6:
                logging.error("Username must be at least 3 characters and password at least 6 characters long.")
                return

            # Insert the username and hashed password into the database
            insert_user(cursor, username, password)
            conn.commit()
            logging.info("User created successfully.")
    except sqlite3.IntegrityError:
        logging.error("Error: That username is already taken.")
    except FileNotFoundError as e:
        logging.error(e)
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")

# Run the main program
if __name__ == "__main__":
    db_file = os.getenv('DB_FILE_PATH', 'users.db')  # Use an environment variable for the database file path
    main(db_file)

