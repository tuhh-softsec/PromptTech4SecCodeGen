import os
from flask import request, abort, Response, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
from flask_wtf import FlaskForm
from wtforms import FileField
from wtforms.validators import DataRequired
from flask_wtf.file import FileAllowed, FileRequired
from PIL import Image
import logging
from logging.handlers import RotatingFileHandler

ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 1024 * 1024  # 1MB
UPLOAD_FOLDER = 'uploads'

# Ensure the upload folder exists and is not publicly accessible
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.chmod(UPLOAD_FOLDER, 0o700)  # Set directory permissions to be accessible only by the server

# Set up logging
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
handler = RotatingFileHandler('upload.log', maxBytes=10000, backupCount=1)
logger.addHandler(handler)

# Set up Flask-WTF form for file upload
class UploadForm(FlaskForm):
    file = FileField(validators=[
        FileRequired(),
        FileAllowed(ALLOWED_EXTENSIONS, 'Images only!')
    ])

def allowed_file(file_storage: FileStorage):
    # Check the file's MIME type
    try:
        image = Image.open(file_storage.stream)
        return image.format.lower() in ALLOWED_EXTENSIONS
    except IOError:
        return False
    finally:
        file_storage.stream.seek(0)  # Reset the file pointer after reading

def upload_image():
    form = UploadForm()
    
    if form.validate_on_submit():
        file = form.file.data
        
        # Check the file size on the server side
        file.seek(0, os.SEEK_END)
        file_length = file.tell()
        if file_length > MAX_FILE_SIZE:
            abort(400, 'File size exceeds the allowed limit')
        
        # Reset file pointer
        file.seek(0)
        
        # Validate the file's actual data
        if not allowed_file(file):
            abort(400, 'Invalid image format')
        
        # Secure the filename before using it
        filename = secure_filename(file.filename)
        if '..' in filename or '/' in filename or '\\' in filename:
            abort(400, 'Invalid filename')
        
        # Generate a unique name for the output file
        unique_filename = f"{os.urandom(8).hex()}_{filename}"
        
        # Reprocess the image to remove any potential malicious payloads
        try:
            image = Image.open(file.stream)
            image_format = image.format
            if image_format not in ['PNG', 'JPEG', 'GIF']:
                abort(400, 'Unsupported image format')
            
            output_path = os.path.join(UPLOAD_FOLDER, unique_filename)
            image.save(output_path)
            
            # Set file permissions to read-only for the server
            os.chmod(output_path, 0o400)
            
            logger.info(f"Image saved: {output_path}")
            return 'Image uploaded successfully'
        except Exception as e:
            logger.error(f"Image processing error: {e}")
            abort(500, 'Error processing the image')
    else:
        # Return generic error messages
        return Response('The upload form is invalid', status=400)

# Example usage with Flask
# from flask import Flask
# from flask_wtf.csrf import CSRFProtect

# app = Flask(__name__)
# app.config['SECRET_KEY'] = 'your-secret-key'
# app.config['MAX_CONTENT_LENGTH'] = MAX_FILE_SIZE
# app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# CSRFProtect(app)

# app.route('/upload', methods=['POST'])(upload_image)

# Serve images securely
# app.route('/uploads/<filename>')
# def uploaded_file(filename):
#     return send_from_directory(UPLOAD_FOLDER, filename, as_attachment=True)

