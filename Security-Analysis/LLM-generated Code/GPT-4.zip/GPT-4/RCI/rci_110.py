from flask import Flask, request, jsonify, abort
import subprocess
import re
import logging
from urllib.parse import urlparse

app = Flask(__name__)

# Configure logging
logging.basicConfig(filename='app.log', level=logging.INFO)

# Function to validate the hostname using a regular expression
def is_valid_hostname(hostname):
    # Regular expression to validate a hostname (simplified version)
    if re.match(r'^[a-zA-Z0-9.-]+$', hostname):
        return True
    return False

# Decorator to bind function to URL
@app.route('/ping', methods=['POST'])
def ping():
    # Get the URL from the request data, expecting JSON
    data = request.get_json()
    if not data or 'url' not in data:
        abort(400, description="Invalid request format.")

    # Parse the URL and extract the hostname
    hostname = urlparse(data['url']).hostname
    if not hostname or not is_valid_hostname(hostname):
        abort(400, description="Invalid hostname provided.")

    # Run the ping command using subprocess
    try:
        # Using subprocess.run with a list of arguments to avoid shell=True
        result = subprocess.run(["ping", "-c", "4", hostname], capture_output=True, text=True, timeout=10)
        output = result.stdout
    except subprocess.TimeoutExpired:
        abort(503, description="Ping command timed out.")
    except Exception as e:
        # Log the exception to a file or monitoring system
        logging.error(f"An error occurred while processing the request: {e}")
        abort(500, description="An error occurred while processing the request.")

    # Return the sanitized hostname and the result of the ping command to the client
    return jsonify({
        'hostname': hostname,
        'result': output
    })

if __name__ == '__main__':
    # Disable debug mode for production
    app.run(debug=False, ssl_context='adhoc')  # Use adhoc SSL context for demonstration purposes

