from flask import Flask, request, render_template, make_response, session, redirect, url_for
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
import re
import logging
from logging.handlers import RotatingFileHandler

app = Flask(__name__)

# Configure secret key for sessions and CSRF protection
app.config['SECRET_KEY'] = 'your-secret-key'

# Configure Flask-Talisman for HTTPS and security headers
csp = {
    'default-src': [
        '\'self\'',
        # Add other sources (CDNs, APIs) as needed
    ]
}
talisman = Talisman(app, content_security_policy=csp)

# Enable CSRF protection
csrf = CSRFProtect(app)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Configure logging
handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)

# Define a function to validate user input
def validate_name(name):
    # Implement more rigorous validation logic
    if isinstance(name, str) and re.match(r'^[a-zA-Z\s]+$', name):
        return name.strip()
    return "Guest"  # Default name if validation fails

@app.errorhandler(404)
def page_not_found(e):
    # Custom error handling for 404 errors
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    # Custom error handling for 500 errors
    app.logger.error(f"Server Error: {e}, route: {request.url}")
    return render_template('500.html'), 500

@app.route('/home')
@limiter.limit("10 per minute")  # Rate limit for this endpoint
def home():
    # Get the 'name' parameter from the user request, default to "Guest" if not provided or invalid
    user_name = validate_name(request.args.get('name', 'Guest'))
    
    # Render the template with the user-provided 'name' parameter
    response = make_response(render_template('home.html', name=user_name))
    
    # Additional security headers can be set here if needed
    response.headers['Referrer-Policy'] = 'no-referrer'
    response.headers['Feature-Policy'] = "geolocation 'self'; vibrate 'none'"
    
    # Return the response
    return response

@app.route('/logout')
def logout():
    # Clear the session and redirect to the login page
    session.clear()
    return redirect(url_for('login'))

if __name__ == '__main__':
    # Run the application with HTTPS enabled in production
    app.run(ssl_context=('path/to/ssl/certificate.crt', 'path/to/ssl/private.key'))

