import logging
from threading import Lock

# Sample array of vehicles
vehicles = ['Car', 'Truck', 'Bike', 'Bus', 'Motorcycle']
vehicles_lock = Lock()  # Lock for thread-safe access to the vehicles list

# Configure logging to avoid logging sensitive information
logging.basicConfig(level=logging.ERROR, format='%(asctime)s - %(levelname)s - %(message)s')

def get_vehicle_by_index(vehicles):
    max_attempts = 3  # Limit the number of attempts to prevent resource exhaustion
    attempts = 0

    while attempts < max_attempts:
        try:
            # Prompt the user to enter an index
            user_input = input("Please enter the index of the vehicle you want to access: ")
            
            # Convert the index to an integer
            index = int(user_input)
            
            # Check if the index is within the bounds of the vehicle array
            if 0 <= index < len(vehicles):
                with vehicles_lock:  # Ensure thread-safe access to the vehicles list
                    # Access and print the vehicle at the index
                    print(f"The vehicle at index {index} is: {vehicles[index]}")
                return  # Exit the function after successful retrieval
            else:
                print(f"Index is out of range. Please enter a number between 0 and {len(vehicles) - 1}.")
        except ValueError:
            # Handle the error if the input is not an integer
            print("Invalid input. Please enter a valid integer index.")
        except Exception as e:
            # Log the exception details in a way that does not expose sensitive information
            logging.error("An unexpected error occurred: %s", str(e))
            print("An unexpected error occurred. Please try again or contact support.")

        attempts += 1  # Increment the attempt counter

    print("Maximum attempts reached. Please try again later.")

# Call the function to get and print the vehicle by index
get_vehicle_by_index(vehicles)

