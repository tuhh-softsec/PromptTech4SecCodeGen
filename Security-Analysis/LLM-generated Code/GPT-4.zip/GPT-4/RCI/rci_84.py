from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import func
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os
import logging
from secure import SecureHeaders

app = Flask(__name__)
Talisman(app, content_security_policy=None)  # CSP to be configured as per the application's requirements
secure_headers = SecureHeaders()
limiter = Limiter(app, key_func=get_remote_address)

# Configure logging to avoid logging sensitive information
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Securely load database credentials and API key
db_user = os.environ.get('DB_USER')
db_password = os.environ.get('DB_PASSWORD')
db_host = os.environ.get('DB_HOST', 'localhost')
db_name = os.environ.get('DB_NAME')
api_key = os.environ.get('API_KEY')

# Ensure SSL certificate verification for database connections
app.config['SQLALCHEMY_DATABASE_URI'] = f'mysql+pymysql://{db_user}:{db_password}@{db_host}/{db_name}?ssl_mode=verify_identity'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# Create the SQLAlchemy db instance
db = SQLAlchemy(app)

# Define the Temperature model
class Temperature(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    location = db.Column(db.String(255), nullable=False)
    temperature = db.Column(db.Float, nullable=False)
    timestamp = db.Column(db.DateTime, default=func.now(), nullable=False)

    def __repr__(self):
        return f'<Temperature {self.location} {self.temperature}>'

# Enhanced authentication decorator with brute force protection
from functools import wraps
def require_api_key(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        provided_api_key = request.headers.get('X-API-KEY')
        if not provided_api_key or provided_api_key != api_key:
            return jsonify({"error": "Unauthorized"}), 403
        return f(*args, **kwargs)
    return decorated_function

@app.route('/api/temperature_for_location', methods=['GET'])
@limiter.limit("10 per minute")
@require_api_key
def get_temperature_for_location():
    try:
        location = request.args.get('location')
        if not location:
            return jsonify({"error": "Missing location parameter"}), 400
        
        # Query the database for the latest temperature for a given location
        temperature_record = Temperature.query.filter_by(location=location).order_by(Temperature.timestamp.desc()).first()
        if temperature_record:
            return jsonify({
                "location": temperature_record.location,
                "temperature": temperature_record.temperature,
                "timestamp": temperature_record.timestamp.isoformat()
            })
        else:
            return jsonify({"error": "No temperature records found for the specified location"}), 404

    except Exception as e:
        logging.error(f"An error occurred: {e}", exc_info=True)
        return jsonify({"error": "An internal server error occurred"}), 500

@app.after_request
def set_secure_headers(response):
    secure_headers.flask(response)
    return response

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5000)
