from flask import Flask, request, jsonify
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker
import datetime

app = Flask(__name__)

# Database configuration (modify with your actual database credentials)
DATABASE_URI = 'database_uri_here'
engine = create_engine(DATABASE_URI, connect_args={"sslmode": "require"})  # ensure secure connection
Session = sessionmaker(bind=engine)

def is_valid_coordinate(coord):
    try:
        return -180 <= float(coord) <= 180
    except ValueError:
        return False

# Function to get temperature from the database
def get_temperature_from_db(latitude, longitude, date):
    with Session() as session:
        sql_query = text("SELECT temperature FROM Senso WHERE latitude = :latitude AND longitude = :longitude AND date = :date")
        result = session.execute(sql_query, {'latitude': latitude, 'longitude': longitude, 'date': date}).fetchone()
        return result[0] if result else None

# Route to handle the temperature_for_location API
@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    try:
        # Get and validate data from payload
        payload = request.json
        latitude = payload.get('latitude')
        longitude = payload.get('longitude')
        date_str = payload.get('date')

        # Validate inputs
        if not all([latitude, longitude, date_str]) or not all(map(is_valid_coordinate, [latitude, longitude])):
            return jsonify({'error': 'Invalid or missing latitude, longitude, or date'}), 400

        try:
            date = datetime.datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format, should be YYYY-MM-DD'}), 400

        # Get temperature from database
        temperature = get_temperature_from_db(latitude, longitude, date)
        if temperature is None:
            return jsonify({'error': 'Temperature data not found'}), 404

        return jsonify({'temperature': temperature})

    except Exception:
        # Log the error internally (not shown in this snippet)
        # Return a generic error message
        return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    app.run(debug=False)  # Ensure debug is set to False in production

# Ensure you have proper logging, monitoring, and rate limiting (not shown in this snippet)
