from flask import Flask, send_from_directory, abort, safe_join, request
from werkzeug.utils import secure_filename
import os
import logging
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Set up rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Define the decorator for URL routing with rate limiting
@app.route('/images/<filename>')
@limiter.limit("10 per minute")
def get_image(filename):
    # Define the directory where images are stored
    images_directory = 'images'
    
    # Validate the filename to ensure it's secure
    filename = secure_filename(filename)
    if not filename.lower().endswith(('.png', '.jpg', '.jpeg', '.gif')):
        # If the file extension is not allowed, return a 404 not found response
        abort(404)

    # Use safe_join to securely join the directory and filename
    filepath = safe_join(images_directory, filename)

    # Check if the file exists
    if os.path.isfile(filepath):
        # Send the file to the browser with security headers
        response = send_from_directory(images_directory, filename)
        response.headers['X-Content-Type-Options'] = 'nosniff'
        return response
    else:
        # If the file does not exist, return a 404 not found response
        abort(404)

if __name__ == '__main__':
    # Run the Flask app with production settings
    app.run(debug=False, host='127.0.0.1', port=5000)

