from flask import Flask, request, jsonify, session, redirect, url_for
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_session import Session
from flask_talisman import Talisman
from flask_wtf.csrf import CSRFProtect
import bcrypt
import os

app = Flask(__name__)
Talisman(app)  # Apply security headers
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')  # Load secret key from environment variable
app.config['SESSION_TYPE'] = 'redis'  # Configure session to use Redis
app.config['SESSION_PERMANENT'] = True
app.config['SESSION_USE_SIGNER'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = 3600  # Session timeout in seconds
Session(app)
csrf = CSRFProtect(app)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=lambda: request.headers.get('X-Real-IP') or get_remote_address(),
    default_limits=["5 per minute"]
)

# Replace with a real database connection and user retrieval logic
def get_user(username):
    # Dummy user data for demonstration purposes
    return {
        "admin": bcrypt.hashpw("your-password".encode('utf-8'), bcrypt.gensalt())
    }.get(username)

@app.route('/check_mod', methods=['POST'])
@limiter.limit("5 per minute")  # Apply rate limiting to the endpoint
@csrf.exempt  # Exempt this route from CSRF token requirement
def check_mod():
    # Get the username and password from the POST request
    username = request.form.get('username')
    password = request.form.get('password')

    # Validate input
    if not username or not password:
        return 'Invalid input', 400

    # Check if the username exists and the password is correct
    user_hash = get_user(username)
    if user_hash and bcrypt.checkpw(password.encode('utf-8'), user_hash):
        session['user'] = username  # Create a secure session
        return 'true'
    else:
        # Return a generic error message to avoid user enumeration
        return 'Login failed', 401  # Unauthorized

@app.before_request
def before_request():
    if not request.is_secure and app.env != 'development':
        url = request.url.replace('http://', 'https://', 1)
        code = 301
        return redirect(url, code=code)

if __name__ == '__main__':
    # Use a production-ready server like gunicorn and obtain a certificate from a trusted CA
    # Ensure that HTTPS is configured with strong ciphers and protocols
    pass

