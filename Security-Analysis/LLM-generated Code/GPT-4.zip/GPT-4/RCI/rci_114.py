import os
import subprocess
import shlex

# Function to validate the directory input
def validate_directory(directory):
    # Check if the directory exists
    if not os.path.isdir(directory):
        return False

    # Check if the directory is within an allowed set of paths
    # This is just an example; you should adjust the allowed paths according to your application's requirements
    allowed_paths = ['/path/to/allowed/directory', '/another/allowed/directory']
    if not any(os.path.commonpath([allowed_path, directory]) == allowed_path for allowed_path in allowed_paths):
        return False

    # Check for directory traversal attempts
    if os.path.abspath(directory) != directory:
        return False

    # Add more checks if necessary
    return True

# Function to safely execute the ls command with a given directory
def safe_ls(directory):
    # Validate the directory input
    if not validate_directory(directory):
        raise ValueError("Invalid directory input")

    # Define the command to be executed as a list
    command = ["ls", "-la", directory]  # '-la' option is used to include hidden files and details
    
    # Execute the command safely using subprocess without shell=True
    try:
        result = subprocess.run(command, text=True, capture_output=True, check=True, timeout=10)  # Added a timeout of 10 seconds
        # Output the result
        print(result.stdout)
    except subprocess.CalledProcessError as e:
        # Handle the error case without exposing sensitive information
        print("Command execution failed with an error.")
    except subprocess.TimeoutExpired:
        # Handle the case where the command times out
        print("Command execution timed out.")

# Example usage with a user-provided directory
user_directory = input("Please enter a directory to list: ")
safe_ls(user_directory)

