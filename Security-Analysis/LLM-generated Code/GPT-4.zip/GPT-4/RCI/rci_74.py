class Person:
    def __init__(self, status=0):
        self.status = status

# Allocate a new Person instance
new_person = Person()

# Set the status of the new person
new_person.status = 1

# Access the status of the person
print(new_person.status)

