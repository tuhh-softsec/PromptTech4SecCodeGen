import logging

# Configure logging
logging.basicConfig(filename='app.log', filemode='w', format='%(name)s - %(levelname)s - %(message)s')

def getValueFromArray(arr, index):
    # Validate that arr is a list and index is an integer
    if not isinstance(arr, list) or not isinstance(index, int):
        raise TypeError("The first argument must be a list and the second argument must be an integer.")
    
    # Check if the index is within the bounds of the array
    if 0 <= index < len(arr):
        return arr[index]
    else:
        raise IndexError("Index is out of bounds.")

def main():
    # In a real-world scenario, replace the hardcoded array with a safe data source
    id_sequence = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    
    try:
        # Read an integer from the standard input
        input_index = int(input("Enter an index: "))
        # Call getValueFromArray with the id_sequence array and the read integer
        value = getValueFromArray(id_sequence, input_index)
        print(f"The value at index {input_index} is {value}.")
        return 0  # Return 0 to indicate successful execution
    except ValueError:
        logging.error("Invalid input. Non-integer value entered.")
        print("Invalid input. Please enter a valid integer.")
        return 1  # Return 1 to indicate input error
    except IndexError as e:
        logging.error(f"Index out of bounds error: {e}")
        print("Index is out of bounds. Please enter a valid index.")
        return 2  # Return 2 to indicate index out of bounds
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
        print("An unexpected error occurred. Please try again later.")
        return 3  # Return 3 to indicate an unexpected error

if __name__ == "__main__":
    exit_code = main()
    exit(exit_code)

