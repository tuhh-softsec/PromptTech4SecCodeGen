import os
import bcrypt
import sqlite3
import logging
from flask import Flask, request, redirect, url_for, render_template, flash, session
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, validators
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sslify import SSLify

# Initialize Flask app
app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY')  # Load secret key from environment variable

# Enforce SSL/TLS in production
sslify = SSLify(app)

# Configure logging
logging.basicConfig(filename='error.log', level=logging.WARNING)

# Initialize rate limiter
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["5 per minute"]
)

# Define a WTForms Form for the registration
class RegistrationForm(FlaskForm):
    username = StringField('Username', [validators.Length(min=4, max=25)])
    password = PasswordField('New Password', [
        validators.DataRequired(),
        validators.EqualTo('confirm', message='Passwords must match'),
        validators.Length(min=8, message='Password must be at least 8 characters long')
    ])
    confirm = PasswordField('Repeat Password')

# Function to hash the password
def hash_password(password):
    # Hash the password with a generated salt and specify the cost factor
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt(12))
    return hashed_password

# Function to store the username and hashed password in the database
def store_credentials_in_db(username, hashed_password):
    try:
        # Use context manager to handle the database connection
        with sqlite3.connect("users.db", uri=True) as conn:
            conn.execute("PRAGMA foreign_keys = ON")  # Enable foreign key constraint support
            cursor = conn.cursor()
            # Use parameterized query to prevent SQL injection
            cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            conn.commit()
    except sqlite3.IntegrityError:
        flash("Username already exists. Please choose a different one.")
        return False
    except Exception as e:
        logging.exception("An error occurred while registering a user.")
        flash("An error occurred while registering. Please try again.")
        return False
    return True

@app.route('/register', methods=['GET', 'POST'])
@limiter.limit("5 per minute")  # Apply rate limiting to the registration route
def register():
    form = RegistrationForm(request.form)
    if request.method == 'POST' and form.validate():
        username = form.username.data
        password = form.password.data
        confirm = form.confirm.data
        
        # Verify that the password and confirmation match
        if password != confirm:
            flash("Passwords do not match.")
            return render_template('register.html', form=form)
        
        # Hash the password
        hashed_password = hash_password(password)
        
        # Store the credentials in the database
        if store_credentials_in_db(username, hashed_password):
            flash("Registration successful!")
            return redirect(url_for('login'))  # Redirect to login page after successful registration
        else:
            return render_template('register.html', form=form)
    return render_template('register.html', form=form)

@app.route('/login')
def login():
    # Placeholder for login page
    return "Login Page"

if __name__ == "__main__":
    # Load SSL/TLS certificate and private key from environment variables or configuration file
    ssl_context = (os.environ.get('SSL_CERT_PATH'), os.environ.get('SSL_KEY_PATH'))
    app.run(ssl_context=ssl_context)  # Use proper SSL/TLS for secure transmission

