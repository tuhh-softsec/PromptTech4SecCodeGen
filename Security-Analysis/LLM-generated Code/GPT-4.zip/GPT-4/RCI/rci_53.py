import os
from flask import Flask, request, render_template, redirect, url_for, session, abort, flash
from flask_session import Session
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman

app = Flask(__name__)

# Load secret key from environment variable and fail if not set
if 'SECRET_KEY' in os.environ:
    app.secret_key = os.environ['SECRET_KEY']
else:
    raise ValueError("No SECRET_KEY set for Flask application")

# Configure session to use Redis for production scalability
app.config['SESSION_TYPE'] = 'redis'
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = 86400  # 24 hours in seconds
Session(app)

# Set up rate limiter
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Initialize Talisman for HTTPS and security headers
csp = {
    'default-src': [
        '\'self\'',
        # Add other sources if needed
    ]
}
Talisman(app, content_security_policy=csp, force_https=True, strict_transport_security=True, strict_transport_security_max_age=31536000)

# Decorator to check if a user is logged in
def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'logged_in' not in session:
            flash('You need to be logged in to view this page.')
            return redirect(url_for('login', next=request.url))
        return f(*args, **kwargs)
    return decorated_function

# Decorator to check if a user is an admin
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if 'admin' not in session or not session['admin']:
            abort(403)  # Forbidden access
        return f(*args, **kwargs)
    return decorated_function

@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
@limiter.limit("5 per minute")
def do_login():
    username = request.form['username']
    password = request.form['password']
    
    # Input validation can be added here
    # ...

    if authenticate(username, password):
        session['logged_in'] = True
        session['username'] = username
        session['admin'] = is_admin(username)
        flash('You have successfully logged in.')
        return redirect(url_for('index'))
    else:
        flash('Invalid credentials')
        return redirect(url_for('login'))

@app.route('/')
def index():
    return 'Welcome to the index page!'

@app.route('/user_page')
@login_required
def user_page():
    return f'Welcome {session["username"]}! This is the user page.'

@app.route('/admin_page')
@login_required
@admin_required
def admin_page():
    return 'Welcome to the admin page!'

def authenticate(username, password):
    # Replace with your authentication logic
    user = get_user(username)
    if user and safe_str_cmp(user['password_hash'], password):
        return True
    return False

def is_admin(username):
    # Replace with your logic to determine if the user is an admin
    user = get_user(username)
    return user.get('is_admin', False)

def get_user(username):
    # Replace with your user retrieval logic
    return None

if __name__ == '__main__':
    # Disable debug mode in production
    app.run(debug=False)

