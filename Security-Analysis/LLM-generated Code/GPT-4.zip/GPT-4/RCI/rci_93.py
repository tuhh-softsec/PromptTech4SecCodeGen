import bcrypt
import sqlite3
import os
from getpass import getpass

# Function to establish a database connection
def get_db_connection(db_path):
    return sqlite3.connect(db_path)

# Function to create the users table if it doesn't exist
def create_users_table(db_path):
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL
        )
        ''')
        conn.commit()

# Function to hash the password
def hash_password(password):
    # Hash the password with a random salt
    password_hash = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    return password_hash

# Function to register a new user
def register_user(db_path, username, password):
    if not validate_password(password):
        print("Error: Password does not meet complexity requirements.")
        return

    password_hash = hash_password(password)
    try:
        with get_db_connection(db_path) as conn:
            cursor = conn.cursor()
            cursor.execute('INSERT INTO users (username, password_hash) VALUES (?, ?)', (username, password_hash))
            conn.commit()
            print("User registered successfully!")
    except sqlite3.IntegrityError:
        print("Error: An account with that username already exists.")

# Function to verify the user's password
def verify_password(db_path, username, password):
    with get_db_connection(db_path) as conn:
        cursor = conn.cursor()
        cursor.execute('SELECT password_hash FROM users WHERE username = ?', (username,))
        user = cursor.fetchone()
        
        if user:
            password_hash = user[0]
            # Hash the provided password and compare it to the stored hash
            if bcrypt.checkpw(password.encode('utf-8'), password_hash):
                return True
        return False

# Function to prompt for username and password
def prompt_credentials():
    username = input("Enter your username: ")
    password = getpass("Enter your password: ")
    return username, password

# Function to validate password complexity
def validate_password(password):
    # Implement password complexity checks here (e.g., length, mix of characters)
    return len(password) >= 8

# Main function to handle user registration and login
def main():
    db_path = os.getenv('DATABASE_PATH', 'users.db')
    create_users_table(db_path)
    
    # Register a new user
    print("Register a new user:")
    username, password = prompt_credentials()
    register_user(db_path, username, password)

    # Login
    print("\nLogin:")
    username, password = prompt_credentials()
    if verify_password(db_path, username, password):
        print("Login successful!")
    else:
        print("Invalid username or password.")

if __name__ == "__main__":
    main()

