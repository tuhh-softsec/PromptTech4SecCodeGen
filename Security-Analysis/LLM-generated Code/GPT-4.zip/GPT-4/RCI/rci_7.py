import argparse
import sys

def main():
    # Use argparse to handle command line arguments more robustly
    parser = argparse.ArgumentParser(description='Print the command line argument at the specified index.')
    parser.add_argument('index', type=int, help='The index of the command line argument to print')
    args = parser.parse_args()

    # Check if the index is within the range of command line arguments
    # Note: We no longer use sys.argv to access the argument, we use args.index directly
    try:
        # Assuming the rest of the arguments are stored in a list called 'arguments'
        arguments = sys.argv[1:]  # This excludes the script name
        if args.index < 0 or args.index >= len(arguments):
            print("Error: Index is out of range.")
            sys.exit(1)

        # Print the argument at the specified index
        # We access the argument directly from the parsed arguments
        print(arguments[args.index])
    except Exception as e:
        print(f"An error occurred: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()

