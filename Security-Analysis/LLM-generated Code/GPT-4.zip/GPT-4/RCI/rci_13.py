import logging

# Create a logger for this module
logger = logging.getLogger(__name__)

class IndexOutOfBoundsError(Exception):
    """Custom exception for index out of bounds errors."""
    pass

class InvalidSequenceError(Exception):
    """Custom exception for invalid sequence errors."""
    pass

def get_value_at_index(sequence, index):
    try:
        # Validate the sequence is indexable
        if not hasattr(sequence, '__getitem__'):
            raise InvalidSequenceError("The sequence is not indexable.")
        
        # Check if the index value is in bounds
        if 0 <= index < len(sequence):
            # Return the value at the index in sequence
            return sequence[index]
        else:
            # Index out of bounds, raise a custom exception
            raise IndexOutOfBoundsError("Index out of bounds.")
    except TypeError as e:
        # Handle the case where the index is not an integer
        logger.error("Invalid index type.")
        raise
    except (IndexOutOfBoundsError, InvalidSequenceError) as e:
        # Log the error and re-raise the exception
        logger.error(e)
        raise

# Example usage:
# Assuming sequence is predefined, e.g.:
sequence = [10, 20, 30, 40, 50]

# Configure logging level from an environment variable or default to INFO
logging_level = logging.INFO  # This could be set from an environment variable
logger.setLevel(logging_level)

# Set up logging configuration
logging.basicConfig(level=logging_level)

# Get the index from the user or another part of the application
def get_user_input():
    try:
        user_input = input("Please enter an index value: ")
        return int(user_input)
    except ValueError:
        print("Invalid input: Please enter a valid integer index.")
        return None

index = get_user_input()
if index is not None:
    try:
        value_at_index = get_value_at_index(sequence, index)
        print(f"The value at the given index is: {value_at_index}")
    except (IndexOutOfBoundsError, InvalidSequenceError) as e:
        print(f"An error occurred: {e}")

