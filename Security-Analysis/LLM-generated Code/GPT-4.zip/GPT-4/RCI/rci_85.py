import os
from flask import Flask, request, jsonify
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import scoped_session, sessionmaker
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, Float, Date
import logging
from datetime import datetime
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman

app = Flask(__name__)
# Use environment variables for sensitive information
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///temperature.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['DEBUG'] = False  # Ensure debug mode is off in production

# Initialize Flask-Limiter for rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Initialize Flask-Talisman for setting security-related HTTP headers
csp = {
    'default-src': '\'self\''
}
Talisman(app, content_security_policy=csp)

db = SQLAlchemy(app)
Base = declarative_base()

# Define the Temperature model
class Temperature(Base):
    __tablename__ = 'temperatures'
    id = Column(Integer, primary_key=True)
    latitude = Column(Float)
    longitude = Column(Float)
    date = Column(Date)
    temperature = Column(Float)

# Create the database engine and tables
engine = db.create_engine(app.config['SQLALCHEMY_DATABASE_URI'], {})
Base.metadata.create_all(engine)

Session = scoped_session(sessionmaker(bind=engine))

@app.route('/api/temperature_for_location', methods=['GET'])
@limiter.limit("10 per minute")  # Apply rate limiting to this endpoint
def temperature_for_location():
    session = Session()
    try:
        # Get parameters from the request
        latitude = request.args.get('latitude', type=float)
        longitude = request.args.get('longitude', type=float)
        date_str = request.args.get('date', type=str)

        # Validate the input
        if latitude is None or longitude is None or date_str is None:
            return jsonify({'error': 'Missing latitude, longitude, or date parameter'}), 400
        if not (-90 <= latitude <= 90) or not (-180 <= longitude <= 180):
            return jsonify({'error': 'Latitude must be between -90 and 90 and longitude between -180 and 180'}), 400

        # Validate the date format
        try:
            date = datetime.strptime(date_str, '%Y-%m-%d').date()
        except ValueError:
            return jsonify({'error': 'Invalid date format. Use YYYY-MM-DD.'}), 400

        # Perform a query using parameterized input to prevent SQL injection
        temperature_record = session.query(Temperature).filter(
            Temperature.latitude == latitude,
            Temperature.longitude == longitude,
            Temperature.date == date
        ).first()

        # Check if a record was found
        if temperature_record:
            return jsonify({'temperature': temperature_record.temperature}), 200
        else:
            return jsonify({'error': 'Temperature data not found'}), 404

    except Exception as e:
        logging.error(f"An error occurred: {e}", exc_info=True)
        return jsonify({'error': 'An error occurred while processing the request'}), 500
    finally:
        session.remove()  # Ensure the session is closed even if an error occurs

if __name__ == '__main__':
    # Load SSL context if HTTPS is enabled
    # context = ('cert.pem', 'key.pem')  # Uncomment and set paths to your certificate and key files
    # app.run(ssl_context=context)  # Uncomment to enable HTTPS
    app.run()

