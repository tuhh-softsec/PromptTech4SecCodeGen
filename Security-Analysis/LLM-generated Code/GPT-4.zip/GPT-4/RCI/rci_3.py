import sys

def is_safe_integer(input_string):
    try:
        # Convert the input string to an integer and check for overflow
        value = int(input_string)
        # If the script will be adapted for a different language with potential overflow issues,
        # additional checks should be implemented here.
    except ValueError:
        return False
    return True

def main():
    # Define your array here
    my_array = [10, 20, 30, 40, 50]

    # Check if an argument is provided
    if len(sys.argv) != 2:
        print("Usage: python script.py <index>")
        sys.exit(1)

    input_string = sys.argv[1]

    # Perform additional input validation
    if not is_safe_integer(input_string):
        print("Invalid input: please enter a valid integer.")
        sys.exit(1)

    try:
        # Convert the argument to an integer
        index = int(input_string)

        # Check if the index is within the range of the array
        if 0 <= index < len(my_array):
            print(my_array[index])
        else:
            # Provide a generic error message to avoid giving too much information
            print("Error: Index out of range.")

    except ValueError:
        # This block may not be reached due to prior validation, but it's kept for safety
        print("Error: An unexpected error occurred.")

    # Additional considerations for future modifications:
    # - Implement resource limits if handling large or untrusted data.
    # - Ensure script permissions are set correctly to prevent unauthorized access or modifications.
    # - If user-provided data is introduced, implement proper sanitization and validation.
    # - Consider adding logging for monitoring and debugging purposes, avoiding sensitive information.
    # - Sanitize command-line arguments if used in system commands or database queries.
    # - Regularly review and refactor code to maintain high quality and follow best practices.

if __name__ == "__main__":
    main()

