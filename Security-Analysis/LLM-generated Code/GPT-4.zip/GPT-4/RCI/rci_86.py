from flask import Flask, request, jsonify
import yaml
from yaml.loader import SafeLoader
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import logging
from flask_httpauth import HTTPBasicAuth
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
auth = HTTPBasicAuth()

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Configure logging
logging.basicConfig(level=logging.INFO)

# Example product prices
PRODUCT_PRICES = {
    'product_a': 10.0,
    'product_b': 20.0,
    'product_c': 30.0,
}

# Example user credentials
users = {
    "user1": generate_password_hash("password1"),
    # Add more users as needed
}

@auth.verify_password
def verify_password(username, password):
    if username in users and \
            check_password_hash(users.get(username), password):
        return username

def calculate_price(product_code, quantity):
    # Calculate the total price
    price = PRODUCT_PRICES.get(product_code)
    if price is None:
        raise ValueError("Invalid product code")
    total_price = price * quantity
    return total_price

@app.route('/api/calculate_price', methods=['POST'])
@auth.login_required
@limiter.limit("10 per minute")  # Rate limiting for this endpoint
def api_calculate_price():
    if request.content_type != 'application/x-yaml':
        return jsonify({'error': 'Unsupported Media Type'}), 415

    try:
        # Get the YAML payload from the request body
        yaml_payload = request.data
        
        # Parse the YAML safely
        data = yaml.load(yaml_payload, Loader=SafeLoader)
        
        # Extract product_code and quantity
        product_code = data.get('product_code')
        quantity = data.get('quantity')
        
        # Validate the inputs
        if not isinstance(product_code, str) or not product_code.isalnum() or \
           not isinstance(quantity, int) or quantity < 1:
            return jsonify({'error': 'Invalid product code or quantity'}), 400
        
        # Calculate the total price
        total_price = calculate_price(product_code, quantity)
        
        # Return the total price
        return jsonify({'total_price': total_price})
    
    except yaml.YAMLError:
        return jsonify({'error': 'Invalid YAML payload'}), 400
    except ValueError as e:
        return jsonify({'error': str(e)}), 400
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return jsonify({'error': 'An unexpected error occurred'}), 500

# Additional security headers
@app.after_request
def add_security_headers(response):
    response.headers['Content-Security-Policy'] = "default-src 'none'"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "DENY"
    response.headers['X-XSS-Protection'] = "1; mode=block"
    response.headers['Strict-Transport-Security'] = "max-age=63072000; includeSubDomains"
    return response

if __name__ == '__main__':
    # Use a proper SSL context in production, e.g., ssl_context=('cert.pem', 'key.pem')
    app.run(ssl_context='adhoc')  # Use ad-hoc SSL for HTTPS in development/testing

