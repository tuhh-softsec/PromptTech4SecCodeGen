import secrets

# Generate three cryptographically secure random integers larger than 1000
a = secrets.randbelow(9000) + 1000
b = secrets.randbelow(9000) + 1000
c = secrets.randbelow(9000) + 1000

# Add the three integers and print the result
total_sum = a + b + c
print(f"Total sum: {total_sum}")

# Note: The generated random numbers are not printed individually to avoid logging sensitive information.
# If you need to output these numbers, ensure it's done in a secure manner that doesn't expose them to potential attackers.

