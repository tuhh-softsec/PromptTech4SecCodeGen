from flask import Flask, request, jsonify, abort
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_talisman import Talisman
from werkzeug.exceptions import HTTPException
from dotenv import load_dotenv
import os
import decimal

# Load environment variables from a .env file
load_dotenv()

app = Flask(__name__)
csp = {
    'default-src': '\'self\'',
    # Add other CSP policies as needed
}
Talisman(app, content_security_policy=csp)  # Enforce HTTPS and set security headers including CSP

limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Fetch product prices from a secure external source, e.g., a database
# For demonstration purposes, we'll use a placeholder function
def fetch_product_prices():
    # This function should interact with a secure database or service
    return {
        'product1': decimal.Decimal('10.00'),
        'product2': decimal.Decimal('20.00'),
        'product3': decimal.Decimal('30.00'),
    }

PRODUCT_PRICES = fetch_product_prices()

def get_price(product_code):
    """Function to get the price for a given product code."""
    return PRODUCT_PRICES.get(product_code)

@app.route('/calculate_price', methods=['POST'])
@limiter.limit("10 per minute")  # Rate limiting to protect against brute-force attacks
def calculate_price():
    """Route to calculate the price for a product code and quantity."""
    data = request.json
    product_code = data.get('product_code')
    quantity = data.get('quantity')

    # Validate input
    if not product_code or not isinstance(quantity, int) or quantity < 1:
        abort(400, description="Invalid product code or quantity.")
    if product_code not in PRODUCT_PRICES:
        abort(400, description="Invalid product code.")
    if quantity > 1000:  # Arbitrary limit to prevent integer overflow and DoS attacks
        abort(400, description="Quantity too large.")

    # Get the price for the product code
    price = get_price(product_code)
    if price is None:
        abort(404, description="Product not found.")

    # Calculate the total price using decimal to avoid floating-point issues
    total_price = price * decimal.Decimal(quantity)
    return jsonify({'total_price': str(total_price)})

@app.errorhandler(HTTPException)
def handle_exception(e):
    """Return JSON instead of HTML for HTTP errors."""
    response = e.get_response()
    response.data = jsonify({
        "description": "An error occurred."
    }).data
    response.content_type = "application/json"
    return response

if __name__ == '__main__':
    # Do not use the development server in production!
    if os.environ.get("FLASK_ENV") == "development":
        app.run(port=5000, debug=True)
    else:
        print("This script is not suitable for production use. Use a production WSGI server like Gunicorn or uWSGI, and ensure SSL/TLS configuration is properly set up with a reverse proxy like Nginx.")

