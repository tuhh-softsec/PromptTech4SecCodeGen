import time

class IndexOutOfBoundsError(Exception):
    """Custom exception for index out of bounds."""
    pass

def get_value_at_index(id_sequence, index):
    """
    Returns the value at the specified index in id_sequence.
    Raises IndexOutOfBoundsError if the index is out of bounds.
    """
    if index < 0 or index >= len(id_sequence):
        raise IndexOutOfBoundsError("Index is out of bounds.")
    return id_sequence[index]

def main():
    # Example array of ID sequences, in a real-world scenario, this would be loaded securely
    id_sequence = [10, 20, 30, 40, 50]

    # Simple rate limiting mechanism
    max_attempts = 5
    attempt_count = 0
    retry_delay = 2  # seconds

    while attempt_count < max_attempts:
        try:
            index = int(input("Enter an index value: "))
            if index < 0 or index >= len(id_sequence):
                print(f"Please enter a non-negative integer less than {len(id_sequence)}.")
                attempt_count += 1
                time.sleep(retry_delay)  # Implementing a delay to mitigate brute-force attacks
                continue
            break
        except ValueError:
            print("Invalid input! Please enter an integer.")
            attempt_count += 1
            time.sleep(retry_delay)

        if attempt_count == max_attempts:
            print("Maximum attempts reached. Please try again later.")
            return

    try:
        value = get_value_at_index(id_sequence, index)
        print(f"The value at index {index} is {value}.")
    except IndexOutOfBoundsError as e:
        print(e)

if __name__ == "__main__":
    main()

