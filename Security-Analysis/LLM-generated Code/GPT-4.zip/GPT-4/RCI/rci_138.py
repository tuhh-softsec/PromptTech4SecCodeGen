import psycopg2
from psycopg2 import sql
import os
import logging
from psycopg2.extras import RealDictCursor

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Use environment variables for database connection details
DB_NAME = os.getenv("DB_NAME")
DB_USER = os.getenv("DB_USER")
DB_PASS = os.getenv("DB_PASS")
DB_HOST = os.getenv("DB_HOST")
DB_PORT = os.getenv("DB_PORT")
SSL_ROOT_CERT = os.getenv("SSL_ROOT_CERT")  # Path to the CA certificate

# Function to check if the username exists in the database
def check_username_exists(username):
    # Validate the input (adapt validation to your needs)
    if not username.replace('_', '').replace('.', '').isalnum():
        logger.error("Invalid username format.")
        return False

    # Use a context manager to ensure connection is closed
    try:
        with psycopg2.connect(
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASS,
            host=DB_HOST,
            port=DB_PORT,
            sslmode='verify-full',  # Verify server certificate
            sslrootcert=SSL_ROOT_CERT
        ) as conn:
            with conn.cursor(cursor_factory=RealDictCursor) as cur:
                # Use parameterized query to prevent SQL injection
                query = sql.SQL("SELECT EXISTS(SELECT 1 FROM users WHERE username = %s)")
                cur.execute(query, (username,))
                exists = cur.fetchone()['exists']
                return exists

    except psycopg2.OperationalError as e:
        logger.error("Database connection failed: %s", e)
        return False
    except psycopg2.DatabaseError as e:
        logger.error("Database error: %s", e)
        return False
    except Exception as e:
        logger.error("An unexpected error occurred: %s", e)
        return False

# Example usage
username_to_check = "example_username"
user_exists = check_username_exists(username_to_check)
print(f"Does the user exist? {user_exists}")

# Remember to:
# - Set up the environment variables with your actual database connection details before running the code.
# - Configure the logging mechanism to suit your application's needs.
# - Ensure that the database user has the least privileges necessary to perform the task.
# - Secure your environment variables and ensure they are not exposed in logs or error messages.
# - Consider using a secrets management tool for handling database credentials.
# - Harden your server environment with security best practices.
# - Ensure secure code deployment processes.

