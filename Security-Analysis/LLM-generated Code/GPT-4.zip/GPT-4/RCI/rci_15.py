import html

def get_value_at_index(array, user_input):
    generic_error_message = "An error occurred. Please try again."
    try:
        # Convert user input to an integer and check for overflow
        index = int(user_input)
        if index < 0 or index >= 2**31:  # Example limit for 32-bit systems
            raise ValueError("Index out of range or too large.")
    except ValueError as e:
        # Log the error and user input for monitoring purposes
        log_error(e, user_input)
        return generic_error_message

    # Check if the index is within the bounds of the array
    if 0 <= index < len(array):
        # Encode the output to prevent XSS when used in a web context
        return html.escape(str(array[index]))
    else:
        # Log the out-of-range attempt for monitoring purposes
        log_error("Index out of range error", user_input)
        return generic_error_message

def log_error(error, user_input):
    # Basic logging function (should be replaced with a proper logging mechanism)
    print(f"Error logged: {error} - User input: {user_input}")

# Example usage:
if __name__ == "__main__":
    # Define your array with some values
    my_array = [10, 20, 30, 40, 50]

    # Get user input safely
    user_input = input("Enter an index to retrieve the value from the array: ")

    # Call the function and print the result
    result = get_value_at_index(my_array, user_input)
    print(result)

