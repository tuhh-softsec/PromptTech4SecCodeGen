import subprocess
import sys
import re
import os
import time

# Optional: import logging module for auditing purposes
import logging

# Configure logging
logging.basicConfig(filename='script_audit.log', level=logging.INFO, format='%(asctime)s %(levelname)s:%(message)s')

def run_id_command(username):
    # Validate the username to ensure it only contains ASCII alphanumeric characters and underscores
    if not re.match(r'^[a-zA-Z0-9_]+$', username):
        raise ValueError("Invalid username. Only ASCII alphanumeric characters and underscores are allowed.")

    try:
        # Specify an empty environment for security, but consider adding necessary variables if required
        env = {'PATH': '/usr/bin:/bin'}  # Minimal PATH or consider specifying the full path to 'id' command

        # Use subprocess.run to safely run the command without shell=True
        result = subprocess.run(['id', username], text=True, capture_output=True, env=env)

        # Print the output of the command if it was successful
        if result.returncode == 0:
            print(result.stdout)
            logging.info(f"Command executed successfully for user: {username}")
        else:
            # Error messages are sanitized to avoid information disclosure
            print("An error occurred while executing the command.", file=sys.stderr)
            logging.error(f"Command execution failed for user: {username} with error: {result.stderr}")

    except FileNotFoundError as e:
        # Sanitize the error message to avoid information disclosure
        print("Command execution failed due to missing executable.", file=sys.stderr)
        logging.error(f"FileNotFoundError: {e}")
        return 1
    except Exception as e:
        # Catch-all for other exceptions with sanitized message
        print("An unexpected error occurred.", file=sys.stderr)
        logging.error(f"Unexpected error: {e}")
        return 1

    # Return the exit status of the command
    return result.returncode

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <username>", file=sys.stderr)
        sys.exit(1)

    username = sys.argv[1]
    try:
        # Implement rate limiting or access control here if necessary
        time.sleep(1)  # Simple rate limiting example

        exit_status = run_id_command(username)
        print(f"Exit status: {exit_status}")
        sys.exit(exit_status)
    except ValueError as e:
        print(e, file=sys.stderr)
        logging.warning(f"Invalid user input: {e}")
        sys.exit(1)

