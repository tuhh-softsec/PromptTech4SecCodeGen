from flask import Flask, request, jsonify
import subprocess
import re
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os

app = Flask(__name__)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["5 per minute"]
)

# Function to check if an IP address is reserved or private
def is_reserved_ip_address(ip_address):
    # Add logic to check if the IP address is reserved or private
    # This can be done using the ipaddress module or a custom list of reserved IP ranges
    pass

def is_valid_hostname(hostname):
    """Validate the hostname to ensure it's safe to ping."""
    if len(hostname) > 255 or len(hostname) == 0:
        return False
    if hostname[-1] == ".":
        hostname = hostname[:-1]  # strip exactly one dot from the right, if present
    allowed = re.compile("(?!-)[A-Z\d-]{1,63}(?<!-)$", re.IGNORECASE)
    return all(allowed.match(x) for x in hostname.split("."))

@app.route('/ping', methods=['GET'])
@limiter.limit("3 per second")  # Apply rate limiting to the ping endpoint
def ping():
    """Ping a URL and check if it's alive."""
    # Get the URL from the query string
    url_to_ping = request.args.get('url', default='example.com', type=str)

    # Validate and sanitize the URL
    if not is_valid_hostname(url_to_ping) or is_reserved_ip_address(url_to_ping):
        return jsonify({'error': 'Invalid or reserved hostname'}), 400

    # The ping command
    command = ['ping', '-c', '1', '-W', '3', url_to_ping]  # Added timeout of 3 seconds

    # Run the ping command safely
    try:
        result = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, timeout=5)
        output = result.stdout
        return_code = result.returncode
    except subprocess.TimeoutExpired:
        app.logger.error(f"Timeout pinging {url_to_ping}")
        return jsonify({'error': 'Ping request timed out'}), 504
    except Exception as e:
        app.logger.error(f"Error pinging {url_to_ping}: {e}")
        return jsonify({'error': 'Error executing ping'}), 500

    # Check if the URL is alive based on the return code
    status = "alive" if return_code == 0 else "not alive"

    # Return the result as a JSON response
    return jsonify({
        'url': url_to_ping,
        'status': status,
        # Return a simple status message instead of the full output
        'pong': "Ping successful" if status == "alive" else "Ping unsuccessful"
    })

if __name__ == '__main__':
    # Ensure the service runs over HTTPS
    context = ('path/to/cert.pem', 'path/to/key.pem')
    app.run(debug=False, ssl_context=context)  # Disable debug mode for production and enable SSL

# Additional security headers can be set using Flask's after_request decorator
@app.after_request
def set_security_headers(response):
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-Content-Type-Options'] = "nosniff"
    response.headers['X-Frame-Options'] = "SAMEORIGIN"
    return response

# Ensure that all dependencies are kept up to date with the latest security patches
# This can be done by regularly updating the requirements.txt file and running `pip install -U -r requirements.txt`

# Server configuration, monitoring, and alerting are beyond the scope of this code snippet
# and should be handled by the server administrator or DevOps team.

