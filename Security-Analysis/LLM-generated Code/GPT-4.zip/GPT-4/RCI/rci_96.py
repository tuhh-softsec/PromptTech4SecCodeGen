import os
import sqlite3
import bcrypt
import re
from flask import Flask, request, render_template, redirect, url_for, abort, session
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sslify import SSLify
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY')  # Set a secret key for session management
sslify = SSLify(app)  # Enforce HTTPS
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["5 per minute"]
)

# Initialize the database connection
def get_db_connection():
    conn = sqlite3.connect(os.environ.get('DATABASE_URL'))
    conn.row_factory = sqlite3.Row
    return conn

# Create users table if it doesn't exist
def init_db():
    with app.app_context():
        conn = get_db_connection()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL
            )
        ''')
        conn.commit()
        conn.close()

# Hash a password
def hash_password(password):
    salt = bcrypt.gensalt()
    hashed = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed

# Validate username and password
def validate_credentials(username, password):
    if not username or not password:
        return False
    if len(password) < 8 or not re.search("[a-zA-Z]", password) or not re.search("[0-9]", password) or not re.search("[!@#$%^&*(),.?\":{}|<>]", password):
        return False
    return True

# Insert a new user into the database
def insert_user(username, hashed_password):
    conn = get_db_connection()
    try:
        conn.execute('INSERT INTO users (username, password) VALUES (?, ?)', (username, hashed_password))
        conn.commit()
    except sqlite3.IntegrityError:
        abort(400, "Registration failed.")  # Use a generic error message
    finally:
        conn.close()

@app.route('/register', methods=['GET', 'POST'])
@limiter.limit("1 per second")
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Validate the input
        if not validate_credentials(username, password):
            abort(400, "Invalid username or password. Password must be at least 8 characters long and contain letters, numbers, and special characters.")

        # Hash the password
        hashed_password = hash_password(password)

        # Insert the new user
        insert_user(username, hashed_password)

        # Redirect to a different page, e.g., login page
        return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login')
def login():
    # Render a login page (not implemented here)
    return "Login Page (not implemented)"

if __name__ == '__main__':
    init_db()  # Initialize the database
    app.run(ssl_context=('cert.pem', 'key.pem'))  # Use proper SSL certificates

