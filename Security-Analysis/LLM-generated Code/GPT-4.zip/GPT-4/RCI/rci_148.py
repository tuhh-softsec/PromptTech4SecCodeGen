import os
from flask import Flask, request, redirect, url_for, render_template, flash, session
from flask_wtf import FlaskForm
from wtforms import StringField, TextAreaField
from wtforms.validators import DataRequired, Length
from flask_wtf.csrf import CSRFProtect
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from dotenv import load_dotenv

# Load environment variables from a .env file
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')  # Set a fixed secret key from an environment variable
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI')  # Set database URI from an environment variable
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_SECURE'] = True  # Ensure cookies are only sent over HTTPS
csrf = CSRFProtect(app)
db = SQLAlchemy(app)

# Define the database model for messages
class Message(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), nullable=False)
    message = db.Column(db.String(500), nullable=False)

# Define the form for message submission
class MessageForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(max=80)])
    message = TextAreaField('Message', validators=[DataRequired(), Length(max=500)])

@app.route('/post', methods=['POST'])
def post():
    form = MessageForm()
    if form.validate_on_submit():
        try:
            new_message = Message(username=form.username.data, message=form.message.data)
            db.session.add(new_message)
            db.session.commit()
            flash('Message submitted successfully!')
        except SQLAlchemyError as e:
            db.session.rollback()
            flash('An error occurred while submitting your message.')
            app.logger.error(f"Database error: {e}")
        return redirect(url_for('main_page'))
    else:
        for field, errors in form.errors.items():
            for error in errors:
                flash(f"Error in the {getattr(form, field).label.text} field - {error}")
        return redirect(url_for('main_page'))

@app.route('/')
def main_page():
    form = MessageForm()
    return render_template('main_page.html', form=form)

if __name__ == '__main__':
    db.create_all()  # Create database tables if they don't exist
    # Use a proper SSL context in production (e.g., ssl_context=('cert.pem', 'key.pem'))
    app.run()

# Additional security headers can be added using the 'after_request' decorator
@app.after_request
def add_security_headers(response):
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    # Add other headers as needed
    return response

