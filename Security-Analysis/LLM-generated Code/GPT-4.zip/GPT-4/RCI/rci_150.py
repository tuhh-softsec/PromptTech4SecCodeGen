from flask import Flask, render_template, request, redirect, url_for, session, abort
from flask_session import Session
from flask_wtf.csrf import CSRFProtect
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import os
from datetime import timedelta

# Load environment variables from .env file
load_dotenv()

app = Flask(__name__)

# Configure the secret key and other configurations from environment variables
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.getenv('DATABASE_URL')
app.config['SESSION_TYPE'] = 'sqlalchemy'
app.config['SESSION_PERMANENT'] = True
app.config['PERMANENT_SESSION_LIFETIME'] = timedelta(minutes=30)  # Adjust as needed
app.config['SESSION_SQLALCHEMY_TABLE'] = 'sessions'
app.config['SESSION_SQLALCHEMY'] = SQLAlchemy(app)

# Initialize extensions
db = SQLAlchemy(app)
Session(app)
CSRFProtect(app)

# Define the User model
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='pbkdf2:sha256')

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

# Create the database tables
with app.app_context():
    db.create_all()

@app.route('/')
def index():
    return '<h1>Welcome!</h1><a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Fetch user record from the database
        user = User.query.filter_by(username=username).first()
        
        if user and user.check_password(password):
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            # Provide a generic error message
            return 'Invalid credentials. Please try again.', 401

    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return '<h1>Secret Page</h1>'
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    # Use a production-ready server like gunicorn and a proper SSL certificate for deployment
    app.run(debug=False)

