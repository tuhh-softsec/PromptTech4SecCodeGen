import ctypes

def safe_memory_copy(destination, dest_size, source, source_size, num_bytes):
    """
    Copies a number of bytes from one memory location to another using ctypes.
    
    :param destination: A ctypes pointer to the destination buffer.
    :param dest_size: The size of the destination buffer.
    :param source: A ctypes pointer to the source buffer.
    :param source_size: The size of the source buffer.
    :param num_bytes: The number of bytes to copy.
    :raises ValueError: If num_bytes is negative or exceeds buffer sizes.
    :raises TypeError: If source and destination are not ctypes pointer types.
    """
    if num_bytes < 0:
        raise ValueError("Number of bytes to copy cannot be negative.")
    
    # Ensure that the source and destination are ctypes pointers
    if not isinstance(destination, ctypes._Pointer) or not isinstance(source, ctypes._Pointer):
        raise TypeError("Source and destination must be ctypes pointer types.")
    
    # Check that the destination and source buffers are large enough
    if dest_size < num_bytes:
        raise ValueError("Destination buffer is not large enough.")
    if source_size < num_bytes:
        raise ValueError("Source buffer does not contain enough data.")
    
    # Perform the memory copy
    ctypes.memmove(destination, source, num_bytes)

def copy_message_to_buffer(message, buffer_size):
    """
    Copies a message to a buffer if it fits, including the null terminator.
    
    :param message: The message string to copy.
    :param buffer_size: The size of the buffer.
    :return: A ctypes buffer containing the message.
    :raises ValueError: If the message is too long to fit in the buffer.
    :raises TypeError: If the message is not a string.
    """
    if not isinstance(message, str):
        raise TypeError("Message must be a string.")
    
    encoded_message = message.encode('utf-8')
    message_length = len(encoded_message) + 1  # Include the null terminator
    
    # Check if the message fits in the buffer, including the null terminator
    if message_length > buffer_size:
        raise ValueError("The message is too long to fit in the buffer.")
    
    # Create a buffer with the specified size
    buffer = (ctypes.c_char * buffer_size)()
    
    # Get a pointer to the encoded message string
    message_ptr = ctypes.create_string_buffer(encoded_message, message_length)
    
    # Copy the message to the buffer
    safe_memory_copy(ctypes.cast(buffer, ctypes.c_void_p), buffer_size,
                     ctypes.cast(message_ptr, ctypes.c_void_p), message_length,
                     message_length)
    
    return buffer

# Example of copying a message to a buffer
message = "Hello, World!"
buffer_size = 64  # Define the size of the buffer
buffer = copy_message_to_buffer(message, buffer_size)

# Print the buffer content
print(buffer[:].decode('utf-8'))

