import secrets
import sys

# Function to generate a secure random float in the range [0.0, 1.0)
def secure_random_float(precision=10**8):
    try:
        # Generate a random integer with the desired precision
        random_int = secrets.randbelow(precision)
        # Convert to a float and divide by precision to get the desired range
        return random_int / precision
    except Exception as e:
        # Handle any unexpected errors that may occur during generation
        print(f"An error occurred: {e}", file=sys.stderr)
        sys.exit(1)

# Function to convert a float to a string with full precision
def float_to_string(value, precision=8):
    # Use the 'g' format specifier to avoid scientific notation for small numbers
    return format(value, f'.{precision}g')

# Generate three cryptographically secure random floats
random_floats = [secure_random_float() for _ in range(3)]

# Convert the floats to strings with full precision
str_floats = [float_to_string(flt) for flt in random_floats]

# Print the string representations of the floats
for i, str_flt in enumerate(str_floats, start=1):
    print(f"String {i}: {str_flt}")

# Additional considerations:
# - Ensure that the OS and its randomness sources are secure.
# - If these strings are used in a context where they could be exposed, consider additional security measures such as encryption.
# - Be aware of the performance implications if generating a large number of random numbers.

