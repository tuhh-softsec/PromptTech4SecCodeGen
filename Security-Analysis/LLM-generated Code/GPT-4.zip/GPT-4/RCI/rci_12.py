import logging
from typing import List, Any

# Configure the logging mechanism
logging.basicConfig(level=logging.ERROR, filename='app.log', filemode='a',
                    format='%(name)s - %(levelname)s - %(message)s')

def get_id_at_index(id_sequence: List[Any], index: int) -> Any:
    if not isinstance(id_sequence, list):
        raise TypeError("id_sequence must be a list.")
    if not all(isinstance(id, (int, str)) for id in id_sequence):  # Assuming IDs are ints or strs
        raise ValueError("id_sequence must contain only integers or strings.")
    if not isinstance(index, int):
        raise ValueError("Index must be an integer.")
    if not 0 <= index < len(id_sequence):
        raise IndexError("Index out of bounds.")
    return id_sequence[index]

# Example usage:
# Define the id_sequence array
id_sequence = [10, 20, 30, 40, 50]

# Get the index from the user in a separate part of the code
try:
    user_input = input("Please enter an index value: ")
    index = int(user_input)
    result = get_id_at_index(id_sequence, index)
    print(f"The value at the given index is: {result}")
except ValueError as ve:
    logging.error(f"ValueError: {ve}")
    print(f"Invalid input. Please try again.")
except IndexError as ie:
    logging.error(f"IndexError: {ie}")
    print(f"Index error. Please try again.")
except TypeError as te:
    logging.error(f"TypeError: {te}")
    print(f"Type error. Please try again.")
except Exception as e:
    logging.error(f"Unexpected error: {e}")
    print(f"An unexpected error occurred. Please contact support.")

