from flask import Flask, redirect, request, abort
from urllib.parse import urlparse, urljoin
import re

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key'  # Replace with a real secret key

# Define a function to check if the domain is a subdomain of example.com
def is_valid_domain(domain):
    return domain == 'example.com' or domain.endswith('.example.com')

@app.route('/redirect')
def redirect_to_url():
    url = request.args.get('url', '')

    # Validate the URL scheme and sanitize the URL
    parsed_url = urlparse(url)
    if parsed_url.scheme not in ['http', 'https']:
        abort(400, description="Invalid URL scheme. Only 'http://' or 'https://' URLs are allowed.")

    # Validate the domain without regex to avoid open redirect vulnerability
    if not is_valid_domain(parsed_url.netloc):
        abort(400, description="Invalid URL. Redirection only allowed to URLs within example.com.")

    # Enforce HTTPS without using private methods
    secure_url = urljoin('https://', urlparse(url).netloc + urlparse(url).path)

    # Sanitize the path and query parameters
    sanitized_path = re.sub(r'[^a-zA-Z0-9_\-./]', '', parsed_url.path)
    sanitized_query = re.sub(r'[^a-zA-Z0-9_\-=&]', '', parsed_url.query)
    secure_url = secure_url + sanitized_path + '?' + sanitized_query

    # Redirect to the secure URL
    return redirect(secure_url)

if __name__ == '__main__':
    # Set debug to False in production
    app.run(debug=False, host='0.0.0.0', port=5000)  # Bind to 0.0.0.0 to make the server publicly available

# Additional security measures to consider:
# - Implement Content Security Policy (CSP) headers.
# - Add logging and monitoring to detect and respond to security incidents.
# - Implement rate limiting to prevent abuse and reduce the risk of DoS attacks.
# - Ensure the server is configured to redirect all HTTP requests to HTTPS and set the Strict-Transport-Security header.
# - Keep Flask and all dependencies up to date to patch known vulnerabilities.
# - Use a production-ready server like Gunicorn or uWSGI and a reverse proxy like Nginx for deployment.

