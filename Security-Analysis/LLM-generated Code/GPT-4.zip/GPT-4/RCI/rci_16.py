import logging
import logging.handlers

# Set up secure logging
LOG_FILENAME = 'app_secure.log'
LOG_FORMAT = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)

# Use a rotating file handler to limit log file size and manage log rotation
handler = logging.handlers.RotatingFileHandler(
    LOG_FILENAME, maxBytes=1000000, backupCount=5)
formatter = logging.Formatter(LOG_FORMAT)
handler.setFormatter(formatter)
logger.addHandler(handler)

def get_value_at_index(array, index):
    try:
        # Validate and sanitize the index input
        index = int(index.strip())
        if not 0 <= index < len(array):
            raise ValueError("Index is out of bounds.")
        
        return array[index]
    except ValueError as e:
        logger.error(f"ValueError: {e}")
        # Return a generic error message to the user
        return "Error: Invalid input."
    except Exception as e:
        logger.error(f"Unexpected error: {e}")
        # Return a generic error message for unexpected errors
        return "Error: An unexpected error occurred."

# Example usage:
def main():
    # Define your array with some values
    my_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

    # Get input from the user
    user_input = input("Enter an index: ")

    # Call the function and print the result
    result = get_value_at_index(my_array, user_input)
    print(result)

if __name__ == "__main__":
    main()

