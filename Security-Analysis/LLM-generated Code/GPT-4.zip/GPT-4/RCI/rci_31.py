from flask import Flask, redirect, request, abort, make_response
from urllib.parse import urlparse
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)

# Define a set of allowed domains for secure redirection
ALLOWED_DOMAINS = {'example.com', 'www.example.com'}

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

@app.route('/redirect')
@limiter.limit("10 per minute")  # Adjust rate limit as necessary
def redirect_to_url():
    # Get the URL parameter from the query string and sanitize it
    url = request.args.get('url', '').strip()

    # Parse the URL to retrieve the domain and scheme
    parsed_url = urlparse(url)
    domain = parsed_url.netloc
    scheme = parsed_url.scheme

    # Validate the domain is an exact match in the allowed set and enforce HTTPS
    if domain in ALLOWED_DOMAINS and scheme == 'https':
        # Redirect to the URL if it's valid
        return redirect(url)
    else:
        # Return a generic error message if the URL is not allowed
        abort(400, description="Invalid URL.")

@app.after_request
def set_security_headers(response):
    response.headers['Server'] = 'SecureServer'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    # Add other security headers as needed
    return response

if __name__ == '__main__':
    # Disable debug mode for production
    app.run(debug=False)

