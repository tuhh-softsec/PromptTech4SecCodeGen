from flask import Flask, request, jsonify, render_template, redirect, url_for, abort
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField
from wtforms.validators import DataRequired, Email
from flask_wtf.csrf import CSRFProtect
from sqlalchemy.exc import SQLAlchemyError
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import os

app = Flask(__name__)

# Ensure that the necessary environment variables are set
if 'DATABASE_URI' not in os.environ or 'SECRET_KEY' not in os.environ:
    raise EnvironmentError("Critical environment variables are missing.")

app.config['SQLALCHEMY_DATABASE_URI'] = os.environ['DATABASE_URI']
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SECRET_KEY'] = os.environ['SECRET_KEY']
app.config['WTF_CSRF_SECRET_KEY'] = os.environ.get('WTF_CSRF_SECRET_KEY', os.urandom(32))

db = SQLAlchemy(app)
csrf = CSRFProtect(app)
limiter = Limiter(app, key_func=get_remote_address, default_limits=["5 per minute"])

# Define the Subscriber model
class Subscriber(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)

    def __repr__(self):
        return '<Subscriber %r>' % self.email

# Define the Unsubscribe form
class UnsubscribeForm(FlaskForm):
    email = StringField('Email', validators=[DataRequired(), Email()])

# Create the database tables
with app.app_context():
    db.create_all()

@app.route('/unsubscribe', methods=['GET', 'POST'])
@limiter.limit("5 per minute")  # Rate limiting to prevent abuse
def unsubscribe():
    form = UnsubscribeForm()
    if form.validate_on_submit():
        email = form.email.data
        try:
            # Use SQLAlchemy's ORM features to safely query and delete the subscriber
            subscriber = Subscriber.query.filter_by(email=email).first()
            if subscriber:
                db.session.delete(subscriber)
                db.session.commit()
                return jsonify({"message": "You have been successfully unsubscribed."}), 200
            else:
                # Return a generic message to avoid data exposure
                return jsonify({"message": "If your email was found, you have been unsubscribed."}), 200
        except SQLAlchemyError as e:
            # Handle database errors without exposing details
            db.session.rollback()
            app.logger.error(f"Database error: {e}")
            return jsonify({"error": "An error occurred while processing your request."}), 500
    elif request.method == 'POST':
        # If the form fails to validate, return a generic error message
        return jsonify({"error": "Invalid form submission."}), 400

    # Render the unsubscribe form for GET requests
    return render_template('unsubscribe.html', form=form)

if __name__ == '__main__':
    # Ensure that the application runs over HTTPS with a proper SSL context in production
    if app.debug or app.testing:
        app.run()
    else:
        if 'SSL_CERT_PATH' not in os.environ or 'SSL_KEY_PATH' not in os.environ:
            raise EnvironmentError("SSL certificate paths are not set.")
        ssl_context = (os.environ['SSL_CERT_PATH'], os.environ['SSL_KEY_PATH'])
        app.run(ssl_context=ssl_context)

