import sys

class MaxAttemptsReachedError(Exception):
    pass

def main():
    # Retrieve the list of vehicles from a secure data source (placeholder for actual implementation)
    vehicles = get_vehicles_from_secure_source()

    max_attempts = 3
    attempts = 0

    while attempts < max_attempts:
        try:
            # Prompt the user for the index of a vehicle
            user_input = input(f"Enter the index of the vehicle you want (0-{len(vehicles) - 1}): ").strip()
            index = int(user_input)
            
            # Check for extremely large numbers that could cause issues in different contexts
            if index.bit_length() > 64:
                raise ValueError("The number is too large.")
            
            # Check if the index is within the range of the vehicles array
            if 0 <= index < len(vehicles):
                # Print the vehicle at the given index
                print(f"The selected vehicle is: {vehicles[index]}")
                break
            else:
                print("Invalid index. Please try again.")
        except ValueError as e:
            print(f"Invalid input: {e}")
        
        attempts += 1
        if attempts == max_attempts:
            raise MaxAttemptsReachedError("Maximum attempts reached. Access denied.")

    # Check the size of the list before pagination to avoid resource-intensive operations
    if len(vehicles) > 1000:
        print("The list is too large to display at once. Please use a search or filter feature.")
    else:
        # Paginate the output if the list is too long
        page_size = 10
        for i in range(0, len(vehicles), page_size):
            print("\nList of vehicles:")
            for vehicle in vehicles[i:i+page_size]:
                print(vehicle)
            input("Press Enter to see more...")

def get_vehicles_from_secure_source():
    # Placeholder function for fetching vehicles from a secure data source
    # Ensure secure protocols and proper authentication are used here
    return ["Car", "Truck", "Bike", "Bus", "Motorcycle", "Scooter"]

if __name__ == "__main__":
    try:
        main()
    except MaxAttemptsReachedError as e:
        print(e)
        # Implement logging and monitoring of this event
        # Consider rate limiting or account locking mechanisms here
        # Exit gracefully or redirect the user to a safe state

