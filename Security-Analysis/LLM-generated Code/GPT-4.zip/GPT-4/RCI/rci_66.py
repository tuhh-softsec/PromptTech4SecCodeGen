import base64
import os
import secrets
from io import BytesIO
from PIL import Image
from flask import request, Flask, jsonify, abort
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, scoped_session
from werkzeug.utils import secure_filename
import logging
from logging.handlers import RotatingFileHandler
import mimetypes

# Configure your database URI
DATABASE_URI = os.getenv('DATABASE_URI', 'sqlite:///your_database.db')

# Create a database engine with SSL/TLS if necessary
engine = create_engine(DATABASE_URI, connect_args={"sslmode": "require"})

# Create a scoped session
Session = scoped_session(sessionmaker(bind=engine))

# Define allowed extensions and max file size (e.g., 5MB)
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
MAX_FILE_SIZE = 5 * 1024 * 1024  # 5MB

# Set up logging
logger = logging.getLogger('image_upload_logger')
logger.setLevel(logging.INFO)
handler = RotatingFileHandler('image_upload.log', maxBytes=10000, backupCount=1)
logger.addHandler(handler)

# Function to check allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Define the upload_image function
def upload_image():
    # Get the uploaded file from the request
    file = request.files.get('image')
    
    # Check if a file is provided and if it has an allowed extension
    if not file or not allowed_file(file.filename):
        return "Invalid file type or no file provided", 400
    
    # Check file size without reading the file into memory
    file.seek(0, os.SEEK_END)
    file_length = file.tell()
    if file_length > MAX_FILE_SIZE:
        return "File size exceeds limit", 400
    file.seek(0)
    
    # Validate the image and convert to base64 in one step
    try:
        image = Image.open(file)
        image.verify()  # Verify that it's an image
        buffered = BytesIO()
        image = Image.open(file)
        image_format = image.format
        if not image_format:
            raise ValueError("Invalid image format")
        image.save(buffered, format=image_format)
        img_str = base64.b64encode(buffered.getvalue()).decode()
    except Exception as e:
        logger.error(f"Invalid image: {e}")
        return "Invalid image", 400
    
    # Generate a secure random file name without relying on the original extension
    random_hex = secrets.token_hex(8)
    _, file_ext = os.path.splitext(file.filename)
    file_ext = mimetypes.guess_extension(mimetypes.guess_type(file.filename)[0])
    image_name = random_hex + (file_ext or '.img')
    
    # Insert into the database using a secure parameterized query
    with Session() as session:
        try:
            query = text("INSERT INTO images (name, data) VALUES (:name, :data)")
            session.execute(query, {'name': image_name, 'data': img_str})
            session.commit()
        except Exception as e:
            session.rollback()
            logger.error(f"Database error: {e}")
            return "An error occurred while uploading the image", 500
        finally:
            Session.remove()
    
    return "Image uploaded successfully", 200

# Example usage with Flask
app = Flask(__name__)

@app.route('/upload', methods=['POST'])
def handle_upload():
    # Implement authentication and authorization checks here
    # ...
    
    # Implement CSRF protection
    # ...
    
    result, status = upload_image()
    return jsonify({'message': result}), status

if __name__ == '__main__':
    # Set secure HTTP headers
    app.config['SESSION_COOKIE_HTTPONLY'] = True
    app.config['SESSION_COOKIE_SECURE'] = True
    app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
    
    # Disable debug mode for production
    app.run(debug=False)

