import os
import logging
from flask import Flask, render_template, request, redirect, url_for, flash, session, make_response
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, logout_user, login_required
from flask_principal import Principal, Permission, RoleNeed
from flask_bcrypt import Bcrypt
from datetime import timedelta
from werkzeug.middleware.proxy_fix import ProxyFix
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField
from wtforms.validators import DataRequired, Length

app = Flask(__name__)

# Ensure the SECRET_KEY is set
if not app.secret_key:
    raise ValueError("No SECRET_KEY set for Flask application")

app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI')
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['REMEMBER_COOKIE_DURATION'] = timedelta(hours=2)

bcrypt = Bcrypt(app)

# Define User model
class User(UserMixin, db.Model):
    # Assuming you have already defined the User model
    pass

# Placeholder for the admin role permission
admin_permission = Permission(RoleNeed('admin'))

# Replace generate_password_hash with bcrypt
users = {
    'user1': {'password': bcrypt.generate_password_hash('password1').decode('utf-8'), 'roles': []},
    # Add other users as needed
}

# Initialize extensions
db = SQLAlchemy(app)
login_manager = LoginManager(app)
principal = Principal(app)
limiter = Limiter(app, key_func=get_remote_address, default_limits=["200 per day", "50 per hour"])

app.wsgi_app = ProxyFix(app.wsgi_app, x_for=1, x_proto=1)

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.errorhandler(500)
def internal_server_error(e):
    response = make_response(render_template('500.html'), 500)
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Referrer-Policy'] = 'no-referrer'
    return response

# Define the login form
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=3, max=25)])
    password = PasswordField('Password', validators=[DataRequired()])

# Apply limiter to login route
@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5 per minute")
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and bcrypt.check_password_hash(user.password_hash, form.password.data):
            login_user(user)
            flash('Login successful.')
            return redirect(url_for('admin'))
        else:
            flash('Invalid username or password.')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('login'))

@app.route('/admin')
@admin_permission.require(http_exception=403)
def admin():
    return render_template('admin.html')

if __name__ == '__main__':
    if app.env == 'production':
        handler = logging.FileHandler('app.log')
        handler.setLevel(logging.INFO)
        app.logger.addHandler(handler)
    
    db.create_all()
    app.run(ssl_context='adhoc', debug=False)
