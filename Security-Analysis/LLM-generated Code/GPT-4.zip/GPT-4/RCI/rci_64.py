import os
from flask import Flask, request, redirect, url_for, flash, send_from_directory, session, make_response, render_template
from werkzeug.utils import secure_filename
from werkzeug.datastructures import FileStorage
from flask_session import Session
import magic
import uuid
import logging

# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf'}
MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16 MB limit
SECRET_KEY = os.environ.get('SECRET_KEY')  # Set this environment variable securely

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = MAX_CONTENT_LENGTH
app.config['SECRET_KEY'] = SECRET_KEY
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
Session(app)

# Ensure the upload folder exists with strict permissions
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
os.chmod(UPLOAD_FOLDER, 0o700)  # Only the owner can access the folder

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def allowed_file(file_storage: FileStorage):
    # Stream the file to check the MIME type without loading it into memory
    mime = magic.from_buffer(file_storage.stream.read(1024), mime=True)
    file_storage.stream.seek(0)  # Reset file pointer after reading
    return mime == 'application/pdf'

@app.route('/upload', methods=['GET', 'POST'])
def upload_file():
    if 'authenticated' not in session or 'user_id' not in session:
        flash('You are not authorized to upload files.')
        return redirect(url_for('login'))

    if request.method == 'POST':
        file = request.files.get('file')
        if not file:
            flash('No file part')
            return redirect(request.url)
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)
        if allowed_file(file):
            try:
                filename = secure_filename(file.filename)
                # Generate a unique filename to prevent overwrites
                unique_filename = f"{uuid.uuid4().hex}_{filename}"
                file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
                # Ensure filename does not contain path traversal characters
                if '..' in filename or filename.startswith('/'):
                    raise ValueError('Invalid filename')

                # Stream the file directly to disk
                with open(file_path, 'wb') as f:
                    file.save(f)

                flash('File successfully uploaded')
                return redirect(url_for('upload_file'))
            except Exception as e:
                logger.error(f'An error occurred: {e}', exc_info=True)
                flash('An error occurred while uploading the file.')
                return redirect(request.url)
        else:
            flash('Invalid file type')
            return redirect(request.url)

    # Set CSP headers
    response = make_response(render_template('upload.html'))
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    return response

@app.route('/login', methods=['GET', 'POST'])
def login():
    # Implement user authentication here
    # On successful authentication, set session['authenticated'] = True and session['user_id'] = user_id
    pass

# Additional routes and functions as needed

if __name__ == '__main__':
    # Use a production-ready server like Gunicorn
    # Ensure Gunicorn is configured securely (e.g., worker processes, timeouts)
    from gunicorn.app.wsgiapp import run
    run()

