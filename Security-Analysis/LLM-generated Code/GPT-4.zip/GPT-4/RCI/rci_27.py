from flask import Flask, redirect, request, abort, make_response
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
import re
import logging
from logging.handlers import RotatingFileHandler

app = Flask(__name__)

# Configure logging
handler = RotatingFileHandler('app.log', maxBytes=10000, backupCount=1)
handler.setLevel(logging.INFO)
app.logger.addHandler(handler)

# Configure rate limiting
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["200 per day", "50 per hour"]
)

# Updated regular expression to match URLs containing 'example.com' more securely
url_pattern = re.compile(r'https?://(?:[a-zA-Z0-9-]+\.)*example\.com(/|$)')

@app.route('/redirect')
@limiter.limit("10 per minute")
def redirect_to_target():
    target = request.args.get('target', '')
    if url_pattern.fullmatch(target):
        app.logger.info(f"Redirecting to {target}")
        return redirect(target)
    else:
        app.logger.warning(f"Invalid redirect attempt to {target}")
        abort(400, description="Invalid URL. Only redirection to 'example.com' is allowed.")

@app.route('/')
def index():
    response = make_response('Welcome to the home page!')
    # Apply security headers to all responses
    response.headers['Content-Security-Policy'] = "default-src 'self'"
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['X-Frame-Options'] = 'SAMEORIGIN'
    response.headers['X-XSS-Protection'] = '1; mode=block'
    response.headers['Strict-Transport-Security'] = 'max-age=63072000; includeSubDomains'
    return response

if __name__ == '__main__':
    app.run()

# Additional security considerations and improvements:

# SSL/TLS Configuration: Ensure that the application is only accessible over HTTPS by configuring SSL in the web server.

# Error Handling: Provide generic error messages to avoid leaking information about the URL validation process.

# Input Sanitization: Extend input sanitization to all inputs or parameters the application handles.

# Dependency Management: Use tools like Dependabot or Snyk to automate the process of keeping dependencies up to date.

# Session Management: If sessions are used, implement secure session management practices.

# Data Protection: Apply encryption at rest and in transit for sensitive data and use secure hashing algorithms for storing passwords.

# Deployment: Set up a reverse proxy with Nginx or Apache to handle SSL/TLS termination and provide an additional layer of security.

# Security Misconfiguration: Regularly review the application for any default settings or misconfigurations that could expose it to vulnerabilities.

# CORS: If cross-origin requests are necessary, configure CORS securely to prevent unauthorized access to resources.

# Environment Configuration: Use environment variables or a configuration file to manage different settings for development and production environments.

# Remember to remove or alter server headers in production to avoid disclosing software versions.

