import tarfile
import os

# Define the source directory and the output tar.gz file
source_dir = 'path/to/source_directory'
output_tar_gz = 'output_archive.tar.gz'

# Validate the source directory and output file path
if not os.path.isdir(source_dir):
    raise ValueError("Source directory does not exist or is not a directory")
if os.path.exists(output_tar_gz):
    raise ValueError("Output tar.gz file already exists")

# Create a tar.gz archive
with tarfile.open(output_tar_gz, 'w:gz') as tar:
    tar.add(source_dir, arcname='.')

# Define the tar.gz file and the extraction directory
input_tar_gz = 'input_archive.tar.gz'
extraction_dir = 'path/to/extraction_directory'

# Validate the input tar.gz file and extraction directory
if not os.path.isfile(input_tar_gz):
    raise ValueError("Input tar.gz file does not exist or is not a file")
if not os.path.isdir(extraction_dir):
    raise ValueError("Extraction directory does not exist or is not a directory")

# Extract the tar.gz archive safely
with tarfile.open(input_tar_gz, 'r:gz') as tar:
    for member in tar.getmembers():
        # Resolve the member's target path
        member_target_path = os.path.realpath(os.path.join(extraction_dir, member.name))
        extraction_target_path = os.path.realpath(extraction_dir)

        # Ensure the target path is within the extraction directory
        if not member_target_path.startswith(extraction_target_path):
            raise Exception("Dangerous tar archive: member path is outside the extraction directory")

        # Check for symlinks and handle according to your security policy
        if member.issym() or member.islnk():
            raise Exception("Tar archive contains symlinks, which is not allowed for security reasons")

        # Check for file overwrite
        if os.path.exists(member_target_path):
            raise Exception("File already exists at the extraction path")

        # Check for archive bombs by inspecting the size
        if member.size > 100000000:  # Example size limit of 100 MB
            raise Exception("Member exceeds the maximum allowed size")

        # Extract member with safe path and without setting file permissions
        tar.extract(member, path=extraction_dir, set_attrs=False)

        # Set secure default permissions (e.g., 600 for files)
        os.chmod(member_target_path, 0o600)

# Read from a file with exception handling
file_path = 'path/to/file.txt'

try:
    if not os.path.isfile(file_path):
        raise ValueError("File does not exist or is not a file")

    with open(file_path, 'r') as file:
        content = file.read()
        print(content)
except IOError as e:
    print(f"An error occurred: {e}")

# Write to a file with file existence checks and exception handling
file_path = 'path/to/file.txt'

try:
    if os.path.exists(file_path):
        raise ValueError("File already exists")

    with open(file_path, 'w') as file:
        file.write('Hello, World!')
except IOError as e:
    print(f"An error occurred: {e}")

