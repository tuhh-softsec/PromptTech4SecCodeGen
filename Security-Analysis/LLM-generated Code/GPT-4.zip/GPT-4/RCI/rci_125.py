import html
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs
import ssl
import logging
from http.cookies import SimpleCookie

class SecureHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_GET(self):
        try:
            # Ensure that the request uses HTTPS
            if self.headers.get('X-Forwarded-Proto') != 'https':
                self.send_error(400, "Bad Request", "HTTPS is required.")
                return

            # Parse the query parameters to get the username
            query_components = parse_qs(urlparse(self.path).query)
            username = query_components.get("username", [""])[0]
            
            # Validate and sanitize the username to prevent XSS attacks
            if not username.isalnum() or len(username) > 64:  # Limit the input length
                raise ValueError("Invalid username")
            safe_username = html.escape(username)
            
            # Construct the response message
            response_message = f"Hello, {safe_username}!"
            encoded_response_message = response_message.encode('utf-8')
            
            # Send the HTTP response headers
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.send_header("Content-Length", str(len(encoded_response_message)))
            self.send_header("Content-Security-Policy", "default-src 'self'")  # Set CSP header
            self.send_header("X-Content-Type-Options", "nosniff")  # Prevent MIME type sniffing
            self.send_header("X-Frame-Options", "DENY")  # Prevent clickjacking
            self.send_header("Server", "SecureServer")  # Custom server header
            self.end_headers()
            
            # Write the response content
            self.wfile.write(encoded_response_message)
            
        except ValueError as ve:
            self.send_error(400, "Bad Request", str(ve))
            logging.error(f"ValueError: {ve}")
        except Exception as e:
            self.send_error(500, "Internal Server Error", "An error occurred on the server.")
            logging.error(f"Exception: {e}")

    # Implement other HTTP methods as needed (e.g., do_POST)

# Example usage:
if __name__ == "__main__":
    logging.basicConfig(filename='server.log', level=logging.INFO)  # Set up logging
    server_address = ('localhost', 8000)
    httpd = HTTPServer(server_address, SecureHTTPRequestHandler)
    
    # Set up SSL/TLS
    httpd.socket = ssl.wrap_socket(httpd.socket, keyfile='path/to/key.pem', certfile='path/to/cert.pem', server_side=True)
    
    print("Starting secure server, use <Ctrl-C> to stop")
    httpd.serve_forever()

