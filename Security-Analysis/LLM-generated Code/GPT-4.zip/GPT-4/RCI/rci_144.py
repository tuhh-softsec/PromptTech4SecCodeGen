from flask import Flask, request, redirect, url_for, render_template, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, IntegerField
from wtforms.validators import DataRequired
from flask_talisman import Talisman
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from werkzeug.security import generate_password_hash, check_password_hash
import os

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'a_secret_key')
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'sqlite:///mydatabase.db')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['SESSION_COOKIE_SECURE'] = True
app.config['SESSION_COOKIE_HTTPONLY'] = True
app.config['REMEMBER_COOKIE_DURATION'] = 86400  # One day in seconds

# Security configurations
csp = {
    'default-src': '\'self\'',
    'img-src': '*',
    'style-src': '\'self\' \'unsafe-inline\'',
    'script-src': '\'self\''
}
Talisman(app, content_security_policy=csp, force_https=True)
limiter = Limiter(app, key_func=get_remote_address)

db = SQLAlchemy(app)
login_manager = LoginManager(app)

# Define the User and Order models
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

class Order(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    stock_name = db.Column(db.String(80), nullable=False)
    stock_quantity = db.Column(db.Integer, nullable=False)

# Define the BuyStockForm
class BuyStockForm(FlaskForm):
    stock_name = StringField('Stock Name', validators=[DataRequired()])
    stock_quantity = IntegerField('Stock Quantity', validators=[DataRequired()])

# Define the LoginForm
class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])

# Create the database tables
with app.app_context():
    db.create_all()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

@app.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        user = User.query.filter_by(username=form.username.data).first()
        if user and user.check_password(form.password.data):
            login_user(user)
            return redirect(url_for('profile', username=user.username))
        flash('Invalid username or password')
    return render_template('login.html', form=form)

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('login'))

@app.route('/buy_stock', methods=['POST'])
@login_required
@limiter.limit("5 per minute")
def buy_stock():
    form = BuyStockForm()
    if form.validate_on_submit():
        new_order = Order(user_id=current_user.id, stock_name=form.stock_name.data, stock_quantity=form.stock_quantity.data)
        db.session.add(new_order)
        db.session.commit()
        return redirect(url_for('profile', username=current_user.username))
    flash('Error with form submission')
    return render_template('buy_stock.html', form=form), 400

@app.route('/profile/<username>')
@login_required
def profile(username):
    if username != current_user.username:
        flash('Unauthorized access.')
        return redirect(url_for('login'))
    # Retrieve and display the user's profile information
    return render_template("profile.html", username=username)

@app.errorhandler(404)
def page_not_found(e):
    return render_template('404.html'), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template('500.html'), 500

if __name__ == '__main__':
    app.run(debug=False)

