def get_value_at_index(array, index):
    """
    Get the value at the specified index of the array.

    Preconditions:
    - `array` should be a list or tuple of elements.
    - `index` should be an integer within the bounds of the array.

    :param array: List or tuple of values.
    :param index: Integer index to access.
    :return: Value at the specified index.
    :raises: TypeError if the index is not an integer.
             IndexError if the index is out of bounds.
    """
    if not isinstance(index, int):
        raise TypeError("Index must be an integer.")
    if index < 0 or index >= len(array):
        raise IndexError("Index is out of bounds.")
    return array[index]

# Example usage:
if __name__ == "__main__":
    # Define your array with some example values
    example_array = [10, 20, 30, 40, 50, 60, 70, 80, 90, 100]

    # Safely get input from the user
    try:
        user_input = input("Enter an integer index: ")
        # Validate that the input can be converted to an integer
        user_index = int(user_input) if user_input.lstrip('-').replace('.', '', 1).isdigit() else None
        if user_index is None:
            raise ValueError("Input is not a valid integer.")
        # Get the value at the given index
        value = get_value_at_index(example_array, user_index)
        print(f"The value at index {user_index} is: {value}")
    except ValueError as ve:
        # Handle the case where the input is not a valid integer
        print(f"Invalid input! {ve}")
    except IndexError as ie:
        # Handle the case where the index is out of bounds
        print(f"Invalid index! Index is out of bounds.")
    except TypeError as te:
        # Handle the case where the index is not an integer
        print(f"Invalid index type! Index must be an integer.")

