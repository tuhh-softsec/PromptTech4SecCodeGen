import secrets

def secure_random_int(min_value, max_value):
    """
    Generate a cryptographically secure random integer within a specified range.

    Args:
        min_value (int): The minimum value of the range (inclusive).
        max_value (int): The maximum value of the range (inclusive).

    Returns:
        int: A secure random integer within the range [min_value, max_value].

    Raises:
        TypeError: If min_value or max_value is not an integer.
        ValueError: If min_value is not less than max_value.
        OverflowError: If the range_size is too large for secrets.randbelow() to handle.
    """
    # Input validation
    if not isinstance(min_value, int):
        raise TypeError(f"min_value must be an integer, got {type(min_value).__name__}.")
    if not isinstance(max_value, int):
        raise TypeError(f"max_value must be an integer, got {type(max_value).__name__}.")
    if min_value >= max_value:
        raise ValueError(f"min_value must be less than max_value, got min_value={min_value} and max_value={max_value}.")

    # Calculate the size of the range
    range_size = max_value - min_value + 1

    # Ensure the range_size is within the bounds that secrets.randbelow() can handle
    if range_size < 0:
        raise OverflowError("The range size is too large or negative due to integer overflow.")

    # Generate a random number within the range
    return min_value + secrets.randbelow(range_size)

# Example usage
try:
    # Generate two secure random integers between 10 and 1000
    first_integer = secure_random_int(10, 1000)
    second_integer = secure_random_int(10, 1000)

    # Calculate the difference between the two integers
    difference = abs(first_integer - second_integer)

    # Print the results
    print(f"First integer: {first_integer}")
    print(f"Second integer: {second_integer}")
    print(f"Difference: {difference}")
except (TypeError, ValueError) as e:
    print(f"Input error: {e}")
except OverflowError as e:
    print(f"Range error: {e}")

# Note: It is important to ensure that the rest of the application maintains the same level of security
# as provided by this function. Additionally, document any limitations or maximum values that the function
# can handle safely to prevent misuse that could lead to vulnerabilities such as DoS attacks.

