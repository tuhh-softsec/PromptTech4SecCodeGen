import bcrypt
import re
import os
from flask import Flask, request, jsonify, redirect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.exc import SQLAlchemyError
from flask_migrate import Migrate
from flask_talisman import Talisman

# Initialize Flask app
app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI', 'postgresql://user:password@localhost/dbname')
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
migrate = Migrate(app, db)

# Initialize rate limiter
limiter = Limiter(
    app,
    key_func=get_remote_address,
    default_limits=["1 per minute"]  # Adjusted rate limit
)

# Initialize Talisman for secure headers
talisman = Talisman(app)

# Define User model for SQLAlchemy
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    hashed_password = db.Column(db.String(120), nullable=False)

# Create the database tables
with app.app_context():
    db.create_all()

def validate_username(username):
    # Add regex or other validation rules as needed
    if len(username) < 3 or len(username) > 20:
        raise ValueError("Username must be between 3 and 20 characters long.")
    if not re.match("^[a-zA-Z0-9_]+$", username):
        raise ValueError("Username can only contain letters, numbers, and underscores.")

def validate_password(password):
    # Implement strong password policies
    if len(password) < 8 or not re.match(r'(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*\W)', password):
        raise ValueError("Password must be at least 8 characters long and include uppercase, lowercase, numbers, and special characters.")

def hash_password(password):
    # Generate a salt and hash the password with a specified work factor
    salt = bcrypt.gensalt(rounds=12)
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
    return hashed_password

def store_user_credentials(username, hashed_password):
    try:
        user = User(username=username, hashed_password=hashed_password)
        db.session.add(user)
        db.session.commit()
    except SQLAlchemyError as e:
        db.session.rollback()
        if 'unique constraint' in str(e):
            raise ValueError("Username already exists.")
        raise

@app.route('/register', methods=['POST'])
@limiter.limit("1 per minute")  # Adjusted rate limit
def register_user():
    try:
        username = request.form['username']
        password = request.form['password']
        validate_username(username)
        validate_password(password)
        hashed_password = hash_password(password)
        store_user_credentials(username, hashed_password)
        return jsonify({"message": "Registration successful!"}), 201
    except ValueError as ve:
        return jsonify({"error": str(ve)}), 400
    except SQLAlchemyError:
        return jsonify({"error": "An error occurred while storing credentials."}), 500

if __name__ == "__main__":
    # Ensure you are using HTTPS in production
    if not os.getenv('FLASK_DEBUG'):
        talisman.force_https = True
    app.run(ssl_context=('cert.pem', 'key.pem'))  # Use proper SSL/TLS certificates

