from http.server import BaseHTTPRequestHandler, HTTPServer
from socketserver import ThreadingMixIn
import html
import ssl
import cgi
import os
import re

class ThreadedHTTPServer(ThreadingMixIn, HTTPServer):
    """Handle requests in a separate thread."""

class SecureHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        try:
            if self.path == '/hello':
                # Validate Content-Type header
                content_type = self.headers.get('Content-Type')
                if content_type not in ['multipart/form-data', 'application/x-www-form-urlencoded']:
                    self.send_error(415, "Unsupported Media Type")
                    return

                # Validate Content-Length header
                content_length = self.headers.get('Content-Length')
                if content_length is None or not content_length.isdigit() or int(content_length) <= 0:
                    self.send_error(400, "Invalid Content-Length header value")
                    return

                content_length = int(content_length)
                # Limit the size of the input to prevent DoS attacks
                if content_length > 1024:  # Arbitrary limit, adjust as needed
                    self.send_error(413, "Request entity too large")
                    return

                # Read the request body safely
                post_data = self.rfile.read(content_length)

                # Parse the request body
                form_data = cgi.FieldStorage(
                    fp=self.rfile,
                    headers=self.headers,
                    environ={'REQUEST_METHOD': 'POST',
                             'CONTENT_TYPE': self.headers['Content-Type'],
                             })

                # Extract the username safely
                username = form_data.getvalue('username')
                # Perform additional input validation on username
                if not username or len(username) > 100 or not re.match(r'^[a-zA-Z0-9_]+$', username):  # Arbitrary length and character check
                    self.send_error(400, "Invalid username")
                    return

                # Escape HTML to prevent XSS attacks
                safe_username = html.escape(username)

                # Construct the response body
                outputbuf = f"""
                <html>
                <head><title>Hello Page</title></head>
                <body>
                <h1>Hello, {safe_username}!</h1>
                </body>
                </html>
                """

                # Write the response headers
                self.send_response(200)
                self.send_header('Content-type', 'text/html')
                self.send_header('X-Content-Type-Options', 'nosniff')
                self.send_header('X-Frame-Options', 'DENY')
                self.send_header('Content-Security-Policy', "default-src 'none'; script-src 'self'; connect-src 'self'; img-src 'self'; style-src 'self';")
                self.send_header('Strict-Transport-Security', 'max-age=63072000; includeSubDomains')
                self.end_headers()

                # Write the response body to the response stream
                self.wfile.write(outputbuf.encode('utf-8'))

            else:
                # Handle other paths or send a 404 Not Found response
                self.send_error(404, "File Not Found")

        except Exception as e:
            # Implement proper error handling
            self.send_error(500, "Internal Server Error")
            # Log the exception for debugging purposes
            print(f"Error handling request: {e}")

def run(server_class=ThreadedHTTPServer, handler_class=SecureHTTPRequestHandler, port=443):
    server_address = ('', port)
    httpd = server_class(server_address, handler_class)
    # Set up HTTPS with TLS using SSLContext
    context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    context.load_cert_chain('path/to/cert.pem', 'path/to/key.pem')
    httpd.socket = context.wrap_socket(httpd.socket, server_side=True)
    print(f'Starting https server on port {port}...')
    httpd.serve_forever()

if __name__ == "__main__":
    run()

