import getpass
import re
import logging

# Configure logging
logging.basicConfig(filename='app.log', level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def read_input(sensitive=False):
    # Initialize a mutable bytearray
    buffer = bytearray()

    try:
        # Prompt the user for input
        print("Please enter some data (only first 10 characters will be stored):")
        
        # Use getpass if the data is sensitive, otherwise use input()
        input_data = getpass.getpass(prompt='') if sensitive else input()

        # Limit the input as it is being received
        input_data = input_data[:1024]

        # Perform input validation using regex
        if not re.match(r'^[a-zA-Z0-9\s]+$', input_data):
            raise ValueError("Invalid input. Only alphanumeric characters and spaces are allowed.")

        # Slice the input to get only the first 10 characters
        buffer.extend(input_data.encode('utf-8')[:10])

        # Provide user feedback for successful input
        print("Input received successfully.")

    except EOFError:
        logging.error("No input received. Exiting.")
    except ValueError as e:
        logging.error(f"Input validation error: {e}")
    except Exception as e:
        logging.error(f"An unexpected error occurred: {e}")
    finally:
        # Clear sensitive data from memory
        del input_data

    # The buffer now contains up to 10 characters from the input
    return buffer

# Call the function and get the buffer with the input
user_input = read_input(sensitive=True)
print("Stored input:", user_input.decode('utf-8'))

# Clear the buffer after use
user_input.clear()

