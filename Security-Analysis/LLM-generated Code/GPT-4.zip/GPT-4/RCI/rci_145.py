from flask import Flask, redirect, url_for, render_template_string, flash, session
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField
from wtforms.validators import DataRequired, NumberRange
from flask_wtf.csrf import CSRFProtect
from flask_talisman import Talisman

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'a_secure_random_secret_key_for_development')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///stock_orders.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)
Talisman(app)
csrf = CSRFProtect(app)

class StockOrder(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    stock_name = db.Column(db.String(80), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)

@app.before_first_request
def create_tables():
    db.create_all()

class StockOrderForm(FlaskForm):
    stock_name = StringField('Stock Name', validators=[DataRequired()])
    quantity = IntegerField('Quantity', validators=[DataRequired(), NumberRange(min=1)])
    submit = SubmitField('Place Order')

@app.route('/buy_order', methods=['GET', 'POST'])
def buy_order():
    form = StockOrderForm()
    if form.validate_on_submit():
        try:
            new_order = StockOrder(stock_name=form.stock_name.data, quantity=form.quantity.data)
            db.session.add(new_order)
            db.session.commit()
            flash('Stock order placed successfully!', 'success')
            return redirect(url_for('stock_view'))
        except Exception as e:
            db.session.rollback()
            flash('Error placing order. Please try again.', 'error')
    return render_template_string('''
    <!doctype html>
    <html>
        <head><title>Buy Stock</title></head>
        <body>
            {% with messages = get_flashed_messages(with_categories=true) %}
                {% if messages %}
                    {% for category, message in messages %}
                        <div class="{{ category }}">{{ message }}</div>
                    {% endfor %}
                {% endif %}
            {% endwith %}
            <h2>Place a Stock Order</h2>
            <form method="POST">
                {{ form.hidden_tag() }}
                {{ form.stock_name.label }} {{ form.stock_name }}<br>
                {% if form.stock_name.errors %}
                    {% for error in form.stock_name.errors %}
                        <span style="color: red;">{{ error }}</span>
                    {% endfor %}
                {% endif %}
                {{ form.quantity.label }} {{ form.quantity }}<br>
                {% if form.quantity.errors %}
                    {% for error in form.quantity.errors %}
                        <span style="color: red;">{{ error }}</span>
                    {% endfor %}
                {% endif %}
                {{ form.submit }}
            </form>
        </body>
    </html>
    ''', form=form)

@app.route('/stock_view')
def stock_view():
    return "Stock order placed successfully! (Placeholder for stock_view page)"

if __name__ == '__main__':
    app.run(debug=True, ssl_context='adhoc')
