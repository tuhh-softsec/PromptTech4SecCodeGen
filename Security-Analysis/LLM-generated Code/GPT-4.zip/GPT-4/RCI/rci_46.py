from flask import Flask, send_from_directory, request, abort, safe_join
from werkzeug.utils import secure_filename
import os
import re
import logging
from flask_talisman import Talisman

app = Flask(__name__)
Talisman(app)  # Enable security headers

# Define the directory where images are stored
IMAGE_FOLDER = '/path/to/your/image/folder'

# Configure logging
logging.basicConfig(level=logging.INFO)

@app.route('/img')
def img():
    # Get the filename from the query parameter
    filename = request.args.get('file')

    # Sanitize the filename to prevent injection attacks
    filename = sanitize_filename(filename)

    # Security check: Ensure that the filename is not None and does not contain any directory traversal characters
    if filename is None or not is_safe_path(IMAGE_FOLDER, filename):
        logging.warning(f"Invalid path or traversal attempt: {filename}")
        abort(404)  # Not found

    # Check if the file exists and is a file
    file_path = safe_join(IMAGE_FOLDER, filename)
    if not os.path.isfile(file_path):
        logging.warning(f"File not found: {filename}")
        abort(404)  # Not found

    # Serve the image file securely
    response = send_from_directory(IMAGE_FOLDER, filename, conditional=True)
    response.headers['Content-Type'] = 'image/jpeg'  # Set the appropriate Content-Type
    return response

def is_safe_path(basedir, path, follow_symlinks=False):
    # Check if the path is safe to open
    if path is None:
        return False
    # Resolve the absolute path and normalize it
    abs_path = os.path.normpath(os.path.abspath(os.path.join(basedir, path)))
    # Check if the path is within the base directory and is not a symlink
    return os.path.commonpath([abs_path]) == os.path.commonpath([basedir, abs_path]) and not os.path.islink(abs_path)

def sanitize_filename(filename):
    # Use Werkzeug's secure_filename to handle edge cases and potentially dangerous file names
    return secure_filename(filename)

if __name__ == '__main__':
    # Use a production-ready server like Gunicorn in production
    # Ensure that the Flask app is run behind a reverse proxy like Nginx or Apache
    # Replace 'adhoc' with a valid SSL certificate in production
    app.run(ssl_context='adhoc')

# Additional security measures to consider:
# - Implement access control checks based on your application's requirements.
# - Ensure that all dependencies are kept up-to-date.
# - Set up error logging with care to avoid logging sensitive information.
# - Separate development and production configurations.
# - If file uploads are allowed, ensure that uploaded files are scanned for malware and are not executable.

