import os
import re
from flask import Flask, request, session, redirect, url_for, render_template, flash
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address
from flask_sslify import SSLify
from validate_email import validate_email
import logging
from logging.handlers import RotatingFileHandler

app = Flask(__name__)
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY')  # Load from environment variable
app.config['SQLALCHEMY_DATABASE_URI'] = os.environ.get('DATABASE_URI')  # Load from environment variable
app.config['SESSION_COOKIE_SECURE'] = True  # Ensure cookies are sent over HTTPS
app.config['SESSION_COOKIE_HTTPONLY'] = True  # Prevent JavaScript access to session cookie
app.config['PERMANENT_SESSION_LIFETIME'] = 600  # Session expiration (e.g., 10 minutes)

db = SQLAlchemy(app)
csrf = CSRFProtect(app)
limiter = Limiter(app, key_func=get_remote_address, default_limits=["5 per minute"])  # Rate limiting
serializer = URLSafeTimedSerializer(app.config['SECRET_KEY'])  # For generating secure tokens

# Ensure SSL is used in production
sslify = SSLify(app, permanent=True)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(128))

    def set_password(self, password):
        self.password_hash = generate_password_hash(password, method='bcrypt')

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def change_email(self, new_email):
        self.email = new_email
        db.session.commit()

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5 per minute")  # Adjusted rate limiting for login attempts
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        # Perform password check even if user does not exist
        password_valid = user.check_password(password) if user else False
        if user and password_valid:
            session.regenerate()  # Regenerate session ID to prevent fixation
            session['user_id'] = user.id
            session['user_token'] = serializer.dumps(user.id, salt=str(user.id))  # Use unique salt
            return redirect(url_for('change_email'))
        else:
            flash('Invalid login attempt.')
    return render_template('login.html')

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    if 'user_id' not in session or 'user_token' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']
    user_token = session['user_token']
    user = User.query.get(user_id)

    try:
        if serializer.loads(user_token, salt=str(user_id), max_age=600) != user_id:  # Validate token
            raise ValueError('Invalid user token.')
    except (BadSignature, SignatureExpired):
        session.clear()  # Invalidate session
        return redirect(url_for('login'))

    if request.method == 'POST':
        old_email = request.form['old_email']
        new_email = request.form['new_email']
        confirm_password = request.form['confirm_password']

        if old_email != user.email or not user.check_password(confirm_password):
            flash('Old email or password does not match our records.')
            return render_template('change_email.html')

        # Robust email format validation using validate_email library
        if not validate_email(new_email):
            flash('Invalid email format.')
            return render_template('change_email.html')

        user.change_email(new_email)
        session.clear()  # Invalidate session after email change
        flash('Email successfully changed. Please log in again.')
        return redirect(url_for('login'))

    return render_template('change_email.html')

@app.route('/profile')
def profile():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    user_id = session['user_id']
    user = User.query.get(user_id)
    return render_template('profile.html', user=user)

if __name__ == '__main__':
    db.create_all()  # Create database tables
    if not app.debug:
        
        file_handler = RotatingFileHandler('app.log', maxBytes=10240, backupCount=10)
        file_handler.setLevel(logging.INFO)
        app.logger.addHandler(file_handler)
    app.run(debug=False)  # Disable debug mode

