import sys
import os

# Use an environment variable for maximum buffer size or default to 10 MB
MAX_BUFFER_SIZE = int(os.getenv('MAX_BUFFER_SIZE', 10 * 1024 * 1024))

def allocate_buffer(size):
    """Allocate and initialize a buffer with the given size."""
    if size > MAX_BUFFER_SIZE:
        print(f"Error: Buffer size must not exceed {MAX_BUFFER_SIZE} bytes.")
        sys.exit(1)
    try:
        buffer = bytearray(size)
        buffer[:] = b'\x00' * size
        return buffer
    except MemoryError:
        print("Error: Insufficient memory to allocate the buffer.")
        sys.exit(1)

def main():
    # Use a secure method to get the buffer size, such as an environment variable
    buffer_size_str = os.getenv('BUFFER_SIZE')
    if not buffer_size_str:
        print("Error: BUFFER_SIZE environment variable is not set.")
        sys.exit(1)

    # Try to convert the environment variable to an integer and validate it
    try:
        buffer_size = int(buffer_size_str)
        if buffer_size <= 0:
            print("Error: Buffer size must be a positive integer.")
            sys.exit(1)
    except ValueError:
        print("Error: Invalid input. Buffer size must be an integer.")
        sys.exit(1)

    # Allocate and initialize the buffer
    buffer = allocate_buffer(buffer_size)

    # Avoid printing the contents of the buffer to prevent data exposure
    print("Buffer allocated successfully.")

    # Exit the program
    sys.exit(0)

if __name__ == "__main__":
    main()

