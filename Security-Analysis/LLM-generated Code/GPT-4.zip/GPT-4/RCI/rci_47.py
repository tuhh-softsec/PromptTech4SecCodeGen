import os
import zipfile
from tempfile import mkdtemp

class ZipExtractionError(Exception):
    pass

class PathTraversalError(ZipExtractionError):
    pass

class SymlinkAttackError(ZipExtractionError):
    pass

class FileExistsError(ZipExtractionError):
    pass

class ArchiveBombError(ZipExtractionError):
    pass

def secure_extract(zip_path, extract_to=None):
    if not os.path.isfile(zip_path):
        raise ZipExtractionError("Invalid ZIP file path.")

    # Create a unique temporary directory if no specific extraction path is provided
    if extract_to is None:
        extract_to = mkdtemp()

    # Ensure the extraction directory exists
    os.makedirs(extract_to, exist_ok=True)

    extract_to = os.path.abspath(extract_to) + os.sep

    with zipfile.ZipFile(zip_path, 'r') as zip_ref:
        # Check for archive bombs
        num_files = len(zip_ref.infolist())
        if num_files > 1000:  # Example limit, adjust as needed
            raise ArchiveBombError("Too many files to extract.")

        total_size = sum(file_info.file_size for file_info in zip_ref.infolist())
        if total_size > 1000000000:  # Example limit, adjust as needed
            raise ArchiveBombError("Total uncompressed size too large.")

        for file_info in zip_ref.infolist():
            relative_path = os.path.normpath(file_info.filename)
            if relative_path.startswith('..') or os.path.isabs(relative_path):
                raise PathTraversalError(f"Detected path traversal attempt in {file_info.filename}")

            extracted_path = os.path.join(extract_to, relative_path)
            if not extracted_path.startswith(extract_to):
                raise PathTraversalError(f"Detected path traversal attempt in {file_info.filename}")

            # Check for symlink attack
            if file_info.is_symlink():
                raise SymlinkAttackError(f"Symlink found in archive: {file_info.filename}")

            # Check for file overwrite
            if os.path.exists(extracted_path):
                raise FileExistsError(f"File already exists: {extracted_path}")

            # Extract the file
            zip_ref.extract(file_info, extract_to)

            # Set permissions (optional, depending on security requirements)
            # os.chmod(extracted_path, desired_permission)

    # Clean up the temporary directory if it was created
    if extract_to == mkdtemp():
        os.rmdir(extract_to)

# Usage
try:
    secure_extract('archive.zip')
    print("Extraction completed successfully.")
except ZipExtractionError as e:
    print(f"An error occurred: {e}")

