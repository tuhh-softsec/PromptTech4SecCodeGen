import ctypes

def safe_memory_copy(destination, destination_size, source, source_size, num_bytes):
    """
    Copies a number of bytes from one memory location to another, ensuring that the copy
    does not exceed the sizes of the source and destination buffers.

    :param destination: A ctypes pointer to the destination buffer.
    :param destination_size: The size of the destination buffer in bytes.
    :param source: A ctypes pointer to the source buffer.
    :param source_size: The size of the source buffer in bytes.
    :param num_bytes: The number of bytes to copy.
    :raises ValueError: If the number of bytes to copy is negative or exceeds buffer sizes.
    :raises TypeError: If the source or destination are not the correct ctypes types.
    :raises RuntimeError: If the memory copy operation fails.
    """
    if not isinstance(destination, ctypes._Pointer) or not isinstance(source, ctypes._Pointer):
        raise TypeError("Source and destination must be ctypes pointers.")
    if num_bytes < 0:
        raise ValueError("Number of bytes to copy cannot be negative.")
    if num_bytes > source_size or num_bytes > destination_size:
        raise ValueError("Number of bytes to copy exceeds buffer size.")

    # Check for pointer validity (not NULL)
    if not source or not destination:
        raise ValueError("Source or destination pointers are NULL.")

    # Check for overlap if using memcpy (not shown here, but would be necessary if not using memmove)
    # ...

    # Use the ctypes `memmove` function to copy memory safely
    try:
        ctypes.memmove(destination, source, num_bytes)
    except (OSError, TypeError, ctypes.ArgumentError) as e:
        raise RuntimeError("Memory copy failed.") from e

def create_buffer_from_string(s, encoding='utf-8'):
    """
    Creates a ctypes buffer from a Python string, ensuring correct encoding and size,
    including space for a null terminator.

    :param s: The string to convert to a buffer.
    :param encoding: The encoding to use for the string.
    :return: A ctypes buffer containing the encoded string.
    :raises ValueError: If the string cannot be encoded with the specified encoding.
    """
    if not isinstance(s, str):
        raise TypeError("Input must be a string.")

    try:
        encoded_string = s.encode(encoding)
    except UnicodeEncodeError as e:
        raise ValueError(f"String encoding failed with encoding {encoding}.") from e

    buffer_size = len(encoded_string) + 1  # Add one for the null terminator
    buffer = ctypes.create_string_buffer(buffer_size)
    ctypes.memmove(buffer, encoded_string, len(encoded_string))
    return buffer

# Example usage:
if __name__ == "__main__":
    input_string = "Hello"

    # Create buffers for source and destination
    source_buffer = create_buffer_from_string(input_string)
    destination_buffer = ctypes.create_string_buffer(len(input_string) + 1)

    # Perform the copy
    safe_memory_copy(destination_buffer, ctypes.sizeof(destination_buffer),
                     source_buffer, ctypes.sizeof(source_buffer),
                     len(input_string))

    # Verify the copy
    print(destination_buffer.value.decode('utf-8'))  # Should print "Hello"

