import sys
import unicodedata

def safe_input(prompt, max_length):
    print(prompt, end='', flush=True)
    try:
        # Use sys.stdin.buffer to read raw bytes and limit the input length
        input_bytes = sys.stdin.buffer.readline(max_length + 2)  # Read one more byte to check for excess
        input_str = input_bytes.decode('utf-8', errors='strict').rstrip('\n')

        # Perform Unicode normalization to ensure consistent representation
        input_str = unicodedata.normalize('NFC', input_str)

        if len(input_str) > max_length:
            print(f"Warning: input truncated to {max_length} characters.")
            input_str = input_str[:max_length]
        return input_str
    except UnicodeDecodeError as e:
        print("Error: Input could not be decoded. Please use valid UTF-8 characters.")
        return None
    except EOFError:
        print("End of File reached.")
        return None  # Instead of sys.exit(), allow the application to handle EOF
    except Exception as e:
        print(f"An unexpected error occurred: {e}")
        return None

# Define buffer size based on application requirements
BUFFER_SIZE = 100

# Read input safely with a maximum length
input_str = safe_input("Enter your input: ", BUFFER_SIZE)

# Read another input safely with a maximum length
input_str1 = safe_input("Enter your input: ", BUFFER_SIZE)
if input_str1 is not None:
    # Perform additional input validation if necessary
    # ...
    pass

# Now input_str and input_str1 contain the input data
# Do something with the input...

