import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int)]

# Allocate memory for a person struct
person_ptr = ctypes.pointer(Person())
person_size = ctypes.sizeof(Person)
person_memory = ctypes.cast(ctypes.pointer(person_ptr), ctypes.POINTER(ctypes.c_ubyte * person_size))

# Access members of the struct using the -> operator
person = person_memory.contents
person.status = 0

# Print the updated status
print("Person status:", person.status)

