import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int),
                ("name", ctypes.c_char * 20)]

def create_person(status, name):
    if len(name) > 19:
        raise ValueError("Name exceeds maximum length of 19 characters")
    person = Person()
    person.status = status
    person.name = name.encode('utf-8')
    return person

def main():
    try:
        # Memory allocation
        person_ptr = ctypes.pointer(Person())

        # Accessing struct members using pointer
        person_ptr.contents.status = 0
        person_ptr.contents.name = b"Joh.."  # Limit name to 19 characters to avoid buffer overflow

        # Creating a new person
        new_person = create_person(person_ptr.contents.status, person_ptr.contents.name.decode('utf-8'))

        # Printing the new person's details
        print("Status:", new_person.status)
        print("Name:", new_person.name.decode('utf-8'))

    except ValueError as e:
        print("Error:", str(e))

    finally:
        # Explicitly free allocated memory
        ctypes.pointer(person_ptr.contents).free()

if __name__ == "__main__":
    main()

