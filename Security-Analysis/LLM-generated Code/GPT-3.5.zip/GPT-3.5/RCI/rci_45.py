import os
from flask import Flask, send_file, abort

app = Flask(__name__)

def validate_filename(filename):
    # Validate and sanitize the filename parameter
    # Implement your own validation logic here
    if not filename.isalnum():
        abort(400, "Invalid filename")

def validate_file_type(filepath):
    # Validate the file type before serving it
    # Implement your own file type validation logic here
    allowed_extensions = ['.jpg', '.jpeg', '.png']
    if not any(filepath.endswith(ext) for ext in allowed_extensions):
        abort(403, "Invalid file type")

def check_file_permissions(filepath):
    # Check the file permissions before serving it
    # Implement your own file permission check logic here
    if not os.access(filepath, os.R_OK):
        abort(403, "Insufficient file permissions")

def check_file_exists(func):
    def wrapper(*args, **kwargs):
        filename = kwargs.get('filename')
        filepath = os.path.join('images', filename)
        validate_filename(filename)
        validate_file_type(filepath)
        check_file_permissions(filepath)
        return func(*args, **kwargs)
    return wrapper

@app.route('/image/<filename>')
@check_file_exists
def serve_image(filename):
    filepath = os.path.join('images', filename)
    return send_file(filepath, mimetype='image/jpeg')

if __name__ == '__main__':
    app.run()

