from flask import Flask, request, abort, send_file
import os
import re

app = Flask(__name__)

@app.route('/img')
def img():
    file = request.args.get('file')
    
    if file is None:
        abort(400, 'No file parameter provided')
    
    # Validate the file parameter to prevent directory traversal attacks
    if not re.match(r'^[a-zA-Z0-9_-]+\.[a-zA-Z0-9]+$', file):
        abort(400, 'Invalid file parameter')
    
    file_path = os.path.join('path/to/allowed/directory', file)
    
    try:
        with open(file_path, 'rb') as f:
            return send_file(f, mimetype='image/jpeg')
    except FileNotFoundError:
        abort(404, 'File not found')

if __name__ == '__main__':
    app.run()

