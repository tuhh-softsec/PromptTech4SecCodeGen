import mysql.connector
from flask import Flask, redirect, request
from dotenv import load_dotenv
import os

app = Flask(__name__)
load_dotenv()

@app.route('/buy', methods=['POST'])
def buy_stock():
    # Get user input from the form
    stock_name = request.form.get('stock_name')
    stock_quantity = request.form.get('stock_quantity')
    username = request.form.get('username')

    # Validate user input
    if not stock_name or not stock_quantity or not username:
        return "Invalid input"

    # Additional input validation
    if not validate_stock_name(stock_name) or not validate_stock_quantity(stock_quantity) or not validate_username(username):
        return "Invalid input"

    # Connect to the database
    db = mysql.connector.connect(
        host=os.getenv("DB_HOST"),
        user=os.getenv("DB_USER"),
        password=os.getenv("DB_PASSWORD"),
        database=os.getenv("DB_NAME"),
        ssl_disabled=True
    )
    cursor = db.cursor()

    # Insert the buy order into the database
    sql = "INSERT INTO buy_orders (stock_name, stock_quantity, username) VALUES (%s, %s, %s)"
    values = (stock_name, stock_quantity, username)
    cursor.execute(sql, values)
    db.commit()

    # Close the database connection
    cursor.close()
    db.close()

    # Redirect the user to the profile page
    return redirect('/profile')

def validate_stock_name(stock_name):
    # Implement validation logic for stock name
    return True

def validate_stock_quantity(stock_quantity):
    # Implement validation logic for stock quantity
    return True

def validate_username(username):
    # Implement validation logic for username
    return True

if __name__ == '__main__':
    app.run(ssl_context='adhoc')

