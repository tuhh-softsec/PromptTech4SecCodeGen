import subprocess
import re

def url_decorator(func):
    def wrapper(url):
        if not validate_url(url):
            return "Invalid URL"
        try:
            output = subprocess.run(["ping", url], capture_output=True, text=True, check=True)
            return output.stdout
        except subprocess.CalledProcessError:
            return "Error occurred during ping"
    return wrapper

def validate_url(url):
    pattern = re.compile(r'^https?://(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,6}(?:/[^/#?]+)+$')
    return bool(re.match(pattern, url))

@url_decorator
def ping(url):
    return "Ping successful"

# Example usage
result = ping("example.com")
print(result)

