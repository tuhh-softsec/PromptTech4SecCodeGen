from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/process_payload', methods=['POST'])
def process_payload():
    try:
        if not request.is_json:
            return jsonify({'error': 'Invalid request format'}), 400

        payload = request.get_json()
        if 'name' not in payload:
            return jsonify({'error': 'Field "name" not found in payload'}), 400

        name = payload['name']
        if not isinstance(name, str) or len(name) > 100:
            return jsonify({'error': 'Invalid name field'}), 400

        # Perform additional input validation and sanitization if necessary

        return jsonify({'name': name})
    except Exception as e:
        return jsonify({'error': 'An error occurred'}), 500

if __name__ == '__main__':
    app.run(ssl_context='adhoc')

