from flask import Flask, redirect, request
from urllib.parse import urlparse
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
limiter = Limiter(app, key_func=get_remote_address)

@app.route('/redirect')
@limiter.limit("10/minute")  # Limit to 10 requests per minute per IP address
def redirect_invalid_url():
    url = request.args.get('url')
    if url and is_valid_url(url):
        return redirect(url)
    else:
        return 'Invalid URL'

def is_valid_url(url):
    parsed_url = urlparse(url)
    if parsed_url.scheme not in ['http', 'https']:
        return False
    if parsed_url.netloc != 'example.com':
        return False
    if parsed_url.path or parsed_url.query:
        return False
    return True

if __name__ == '__main__':
    app.run(ssl_context='adhoc')  # Enable HTTPS for the web application

