import os
import logging

def create_or_open_file(filename):
    try:
        # Validate and sanitize the filename parameter
        if not is_valid_filename(filename):
            logging.error("Invalid filename!")
            return
        
        # Use a more restrictive file permission
        flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_EXCL
        file_descriptor = os.open(filename, flags, 0o400) # Set file permissions to 400
        os.close(file_descriptor)
        logging.info("File created successfully!")
    except FileExistsError:
        logging.warning("File already exists!")
    except (PermissionError, OSError) as e:
        logging.error(f"Error creating or opening file: {e}")

def is_valid_filename(filename):
    # Perform input validation to prevent directory traversal attacks
    allowed_characters = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_"
    if any(char not in allowed_characters for char in filename):
        return False
    return True

# Example usage
create_or_open_file("example.txt")

