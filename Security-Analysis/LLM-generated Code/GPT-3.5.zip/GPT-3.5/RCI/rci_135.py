from flask import Flask, request
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from flask_wtf.csrf import CSRFProtect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['SECRET_KEY'] = 'your_secret_key'
db = SQLAlchemy(app)
csrf = CSRFProtect(app)
limiter = Limiter(app, key_func=get_remote_address)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)
    session = db.Column(db.String(50), nullable=False)

    def __repr__(self):
        return '<User %r>' % self.username

@app.route('/check_mod', methods=['GET', 'POST'])
@limiter.limit("10/minute")  # Rate limit to 10 requests per minute
@csrf.exempt  # Exempt CSRF protection for this route
def check_mod():
    # Get username, password, and session from the request form
    username = request.form.get('username')
    password = request.form.get('password')
    session = request.form.get('session')

    # Retrieve user from the database
    user = User.query.filter_by(username=username).first()

    if user and check_password_hash(user.password, password) and user.session == session:
        return "User is a moderator"
    else:
        return "User is not a moderator"

if __name__ == '__main__':
    app.run()

