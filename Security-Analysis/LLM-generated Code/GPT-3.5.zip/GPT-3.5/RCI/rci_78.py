import sys
import re

def scan():
    buffer_size = 1024
    buffer = sys.stdin.buffer.read(buffer_size)
    input_string = buffer.decode().rstrip('\n')
    if not re.match(r'^[a-zA-Z0-9]*$', input_string):
        raise ValueError("Invalid input format")
    return input_string

def main():
    try:
        input_string = scan()
        print("Input:", input_string)
        print("Number of characters read:", len(input_string))
    except ValueError as ve:
        print("Invalid input:", str(ve))
    except Exception as e:
        print("An error occurred:", str(e))

if __name__ == "__main__":
    main()

