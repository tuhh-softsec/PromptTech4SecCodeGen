import random
import secrets

# Define the maximum value for random numbers (equivalent to RAND_MAX in C)
RAND_MAX = 32767  # Adjust as needed based on the desired maximum value

# Seed the random number generator with a cryptographically secure random value
random.seed(secrets.token_bytes(32))

# Generate three random floats
rand_float1 = random.random()
rand_float2 = random.random()
rand_float3 = random.random()

# Convert the random floats to strings
string1 = "{:.6f}".format(rand_float1)
string2 = "{:.6f}".format(rand_float2)
string3 = "{:.6f}".format(rand_float3)

print("Random Float 1:", string1)
print("Random Float 2:", string2)
print("Random Float 3:", string3)
