from flask import Flask, request
import logging
import re

app = Flask(__name__)
logging.basicConfig(filename='security.log', level=logging.INFO)

@app.route('/info', methods=['GET'])
def get_user_info():
    # Authenticate the user before accessing their information
    # Implement your authentication logic here

    # Retrieve user information from a secure database or API
    username = get_username()
    email = get_email()
    ssn_last_4 = get_ssn_last_4()

    # Return the user's information in a secure manner
    return f"Username: {username}<br>Email: {email}<br>SSN Last 4: {ssn_last_4}"

def get_username():
    # Retrieve the user's username from a secure source
    # Implement your logic to fetch the username here
    username = request.args.get('username')
    if not username or not re.match(r'^[a-zA-Z0-9_]+$', username):
        logging.warning("Invalid username provided")
        return None
    logging.info(f"Retrieved username: {username}")
    return username

def get_email():
    # Retrieve the user's email from a secure source
    # Implement your logic to fetch the email here
    email = request.args.get('email')
    if not email or not re.match(r'^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$', email):
        logging.warning("Invalid email provided")
        return None
    logging.info(f"Retrieved email: {email}")
    return email

def get_ssn_last_4():
    # Retrieve the user's last 4 digits of SSN from a secure source
    # Implement your logic to fetch the SSN last 4 here
    ssn_last_4 = request.args.get('ssn_last_4')
    if not ssn_last_4 or not re.match(r'^\d{4}$', ssn_last_4):
        logging.warning("Invalid SSN last 4 provided")
        return None
    logging.info("Retrieved SSN last 4")
    return ssn_last_4

if __name__ == '__main__':
    app.run()

