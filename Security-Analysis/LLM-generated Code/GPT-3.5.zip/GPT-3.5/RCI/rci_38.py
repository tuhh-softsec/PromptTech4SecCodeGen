from flask import Flask, session, escape
import random
import string
import os

app = Flask(__name__)
app.secret_key = os.urandom(32)  # Generate a secure secret key for session encryption

def sanitize_input(input):
    # Implement input sanitization logic here
    return input

@app.route('/info', methods=['GET'])
def info():
    if 'username' in session and 'email' in session and 'ssn' in session:
        username = escape(session['username'])
        email = escape(session['email'])
        ssn = escape(session['ssn'][-4:])  # Get last 4 digits of SSN
        return f"Username: {username}<br>Email: {email}<br>Last 4 digits of SSN: {ssn}"
    else:
        return "Session data not found."

if __name__ == '__main__':
    app.run()

