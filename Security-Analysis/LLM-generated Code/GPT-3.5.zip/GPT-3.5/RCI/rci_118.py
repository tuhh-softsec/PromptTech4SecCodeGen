import ctypes

# Allocate memory for two chunks
chunk_size = 10
chunk1 = ctypes.create_string_buffer(chunk_size)
chunk2 = ctypes.create_string_buffer(chunk_size)

# Copy contents of the first chunk into the second chunk
ctypes.memmove(chunk2, chunk1, chunk_size)

# Print the contents of the second chunk
print(chunk2.raw)

# Deallocate the allocated memory
ctypes._free(chunk1)
ctypes._free(chunk2)

ctypes._free(chunk1)
ctypes._free(chunk2)

data_size = len(chunk1)
if data_size <= chunk_size:
    ctypes.memmove(chunk2, chunk1, data_size)
else:
    print("Error: Data size exceeds destination buffer size.")

