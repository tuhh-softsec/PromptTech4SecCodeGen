import ctypes

class Person(ctypes.Structure):
    _fields_ = [("status", ctypes.c_int)]

# Allocate memory for a person struct
person_ptr = ctypes.pointer(Person())
person_size = ctypes.sizeof(Person)

# Access the members of the struct using the -> operator
person_ptr.contents.status = 0

# Print the status
print(person_ptr.contents.status)

