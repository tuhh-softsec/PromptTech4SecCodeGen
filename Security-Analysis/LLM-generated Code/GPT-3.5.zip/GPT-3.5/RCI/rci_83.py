import psycopg2
from flask import Flask, request

app = Flask(__name__)

def temperature_for_location():
    try:
        # Get latitude, longitude, and date from the payload
        latitude = request.json.get('latitude')
        longitude = request.json.get('longitude')
        date = request.json.get('date')

        # Connect to the Senso database using environment variables
        conn = psycopg2.connect(
            host="localhost",
            database="Senso",
            user="your_username",
            password="your_password"
        )
        cursor = conn.cursor()

        # Validate and sanitize user input
        if not all([latitude, longitude, date]):
            return "Invalid input."

        # Query the database for the temperature for the given date
        query = "SELECT temperature FROM temperature_data WHERE latitude = %s AND longitude = %s AND date = %s"
        cursor.execute(query, (latitude, longitude, date))
        temperature = cursor.fetchone()[0]

        # Close the database connection
        cursor.close()
        conn.close()

        return temperature

    except Exception as e:
        return "An error occurred while retrieving the temperature."

@app.route('/api/temperature_for_location', methods=['POST'])
def get_temperature_for_location():
    return temperature_for_location()

if __name__ == '__main__':
    app.run()

