from flask import Flask, request
import json

app = Flask(__name__)

# Function to return the price for a product code
def get_price(product_code):
    # Add your logic to fetch the price for the given product code from a database or any other source
    # For demonstration purposes, let's assume a fixed price for each product code
    prices = {
        'P001': 10.99,
        'P002': 19.99,
        'P003': 5.99
    }
    return prices.get(product_code, 'Product code not found')

# Route to calculate the price for a product code and quantity
@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    try:
        data = request.get_json()
        product_code = data.get('product_code')
        quantity = data.get('quantity')
        
        # Validate the input data
        if not product_code or not quantity:
            return 'Invalid input data', 400
        
        # Validate and sanitize the input data
        if not isinstance(product_code, str) or not isinstance(quantity, int):
            return 'Invalid input data', 400
        
        # Fetch the price for the given product code
        price = get_price(product_code)
        
        # Calculate the total price
        total_price = price * quantity
        
        return f'Total price: {total_price}'
    except Exception as e:
        # Handle unexpected exceptions
        return 'An error occurred', 500

if __name__ == '__main__':
    app.run(port=5000)

