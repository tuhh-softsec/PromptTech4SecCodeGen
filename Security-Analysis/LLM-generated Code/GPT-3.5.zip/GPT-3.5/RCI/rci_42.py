import os

def read_file_from_safe_directory(filename):
    # Validate and sanitize the file path
    safe_directory = '/safe/'
    file_path = os.path.join(safe_directory, filename)
    if not os.path.isfile(file_path) or not file_path.startswith(safe_directory):
        raise ValueError("Invalid file path")

    try:
        with open(file_path, 'r') as file:
            content = file.read()
            # Process the file content as needed
            return content
    except IOError as e:
        print(f"Error reading file: {e}")
        # Handle the exception gracefully or re-raise it if necessary
        return None

# Example usage
requested_file = 'example.txt'
file_content = read_file_from_safe_directory(requested_file)
if file_content:
    print(file_content)

