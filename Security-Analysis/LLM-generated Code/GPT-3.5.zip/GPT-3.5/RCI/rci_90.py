import bcrypt
import getpass
import re
import sqlite3

def register():
    username = input("Enter username: ")
    password = getpass.getpass("Enter password: ")

    # Validate and sanitize the input
    if not validate_input(username) or not validate_input(password):
        print("Invalid input. Please try again.")
        return

    # Check if the username already exists in the database
    if username_exists(username):
        print("Username already exists. Please choose a different username.")
        return

    # Hash the password with a salt
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

    # Save the username and hashed password to a secure database
    save_to_database(username, hashed_password)

    print("Registration successful!")

def validate_input(input_data):
    # Implement input validation and sanitization techniques here
    # For example, you can use regular expressions or a library like bleach

    # Check for minimum password length and special characters
    if len(input_data) < 8 or not re.search(r'[!@#$%^&*(),.?":{}|<>]', input_data):
        return False

    # Return True if the input is valid, False otherwise
    return True

def username_exists(username):
    # Check if the username already exists in the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("SELECT COUNT(*) FROM users WHERE username = ?", (username,))
    count = cursor.fetchone()[0]

    conn.close()

    return count > 0

def save_to_database(username, hashed_password):
    # Code to save the username and hashed password to a secure database
    # Replace this with your own implementation

    # For example, you can use a secure database connection and execute SQL queries
    # Ensure that you use parameterized queries to prevent SQL injection

    # Alternatively, you can use an ORM (Object-Relational Mapping) library like SQLAlchemy

    # Here's a simple example using SQLite3
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password.decode('utf-8')))

    conn.commit()
    conn.close()

register()

