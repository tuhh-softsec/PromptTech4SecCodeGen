import base64
import os
import sqlite3
import secrets
import string

DATABASE_FILE = 'database.db'
UPLOAD_FOLDER = 'uploads'

def upload_image(image_file):
    # Validate image file
    if not is_valid_image(image_file):
        return "Invalid image file"

    # Validate image size
    if not is_valid_image_size(image_file):
        return "Image file size exceeds the limit"

    # Read and convert image to base64
    image_data = read_image(image_file)
    base64_string = convert_to_base64(image_data)

    # Insert image name and base64 string into the database
    if insert_into_database(image_file.filename, base64_string):
        return "Image uploaded successfully"
    else:
        return "Failed to upload image"

def is_valid_image(image_file):
    allowed_extensions = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in image_file.filename and \
           image_file.filename.rsplit('.', 1)[1].lower() in allowed_extensions

def is_valid_image_size(image_file):
    max_file_size = 10 * 1024 * 1024  # 10MB
    return image_file.content_length <= max_file_size

def read_image(image_file):
    return image_file.read()

def convert_to_base64(image_data):
    return base64.b64encode(image_data).decode('utf-8')

def insert_into_database(image_name, base64_string):
    # Connect to the database
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()

    try:
        # Create the uploads folder if it doesn't exist
        if not os.path.exists(UPLOAD_FOLDER):
            os.makedirs(UPLOAD_FOLDER)

        # Generate a secure random file name
        file_name = generate_secure_file_name()

        # Save the image file in the uploads folder
        image_path = os.path.join(UPLOAD_FOLDER, file_name)
        with open(image_path, 'wb') as f:
            f.write(base64.b64decode(base64_string))

        # Insert image details into the database
        cursor.execute("INSERT INTO images (name, base64) VALUES (?, ?)", (image_name, base64_string))
        conn.commit()
        return True
    except Exception as e:
        print(f"Error inserting into database: {e}")
        return False
    finally:
        cursor.close()
        conn.close()

def generate_secure_file_name():

    secure_chars = string.ascii_letters + string.digits
    secure_file_name = ''.join(secrets.choice(secure_chars) for _ in range(16))
    return secure_file_name

