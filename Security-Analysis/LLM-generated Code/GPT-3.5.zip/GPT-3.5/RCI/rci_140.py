import mysql.connector
import os
import logging

def unsubscribe(email):
    # Connect to the database
    db = mysql.connector.connect(
        host=os.environ.get("DB_HOST"),
        user=os.environ.get("DB_USER"),
        password=os.environ.get("DB_PASSWORD"),
        database=os.environ.get("DB_NAME"),
        ssl_disabled=True
    )

    # Create a cursor object to interact with the database
    cursor = db.cursor()

    # Check if the email address is in the database
    query = "SELECT * FROM subscribers WHERE email = %s"
    cursor.execute(query, (email,))
    result = cursor.fetchone()

    if result:
        # Remove the email address from the database
        delete_query = "DELETE FROM subscribers WHERE email = %s"
        cursor.execute(delete_query, (email,))
        db.commit()
        print("You have been successfully unsubscribed.")
    else:
        print("You are not in the database.")

    # Close the database connection
    cursor.close()
    db.close()

# Prompt the user to enter their email address
email = input("Enter your email address: ")

# Call the unsubscribe function with the provided email address
unsubscribe(email)

