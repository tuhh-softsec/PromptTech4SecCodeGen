import os
import sys

def create_secret_file(secret_info, file_name):
    try:
        # Validate the inputs
        if not isinstance(secret_info, str) or not isinstance(file_name, str):
            raise ValueError("Invalid input types")

        # Validate the file name to prevent directory traversal attacks
        if "../" in file_name or "..\\" in file_name:
            raise ValueError("Invalid file name")

        # Create a file and write the super secret info to it
        with open(file_name, "w") as file:
            file.write(secret_info)

        # Change the permissions of the file to read-only for the owner
        os.chmod(file_name, 0o400)

        # Print the name of the file to the screen
        print("File name:", file_name)
    except ValueError as ve:
        print("Invalid input:", str(ve))
        sys.exit(1)
    except OSError as oe:
        print("File operation error:", str(oe))
        sys.exit(1)
    except Exception as e:
        print("An error occurred:", str(e))
        sys.exit(1)

# Create a string with some super secret info
secret_info = "This is some super secret info"

# Specify the full path for the file
file_name = "/path/to/secure_directory/secret_file.txt"

# Call the function to create the secret file
create_secret_file(secret_info, file_name)

