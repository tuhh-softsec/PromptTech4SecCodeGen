import sys
import logging

def atoi(s):
    try:
        return int(s)
    except ValueError:
        logging.error("Invalid argument: %s", s)
        return 0

def main():
    if len(sys.argv) < 3:
        logging.error("Insufficient arguments")
        return 1

    index = atoi(sys.argv[1])
    if index < 0 or index >= len(sys.argv):
        logging.error("Invalid index: %s", sys.argv[1])
        return 1

    logging.info("Accessing argument at index: %s", index)
    print(sys.argv[index])
    return 0

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    try:
        sys.exit(main())
    except Exception as e:
        logging.error("An error occurred: %s", str(e))
        sys.exit(1)

