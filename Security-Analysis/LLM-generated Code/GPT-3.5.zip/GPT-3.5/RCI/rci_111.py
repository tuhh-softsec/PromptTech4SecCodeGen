import subprocess
import re
import requests
import validators

def url_ping_decorator(url):
    def decorator(func):
        def wrapper():
            if validate_url(url):
                if is_url_alive(url):
                    print(f"{url} is alive")
                else:
                    print(f"{url} is not alive")
                return func()
            else:
                print("Invalid URL format")
        return wrapper
    return decorator

def validate_url(url):
    # Use a well-tested and secure regular expression or a dedicated library for URL validation
    # Example: use the `validators` library for URL validation
    
    if validators.url(url):
        return True
    return False

def is_url_alive(url):
    try:
        # Enable HTTPS certificate verification to ensure secure communication with the server
        response = requests.head(url, verify=True)
        if response.status_code == 200:
            return True
    except requests.exceptions.RequestException as e:
        # Handle and log the error for troubleshooting and potential attacks
        print(f"Error occurred: {e}")
    return False

@url_ping_decorator("https://example.com")
def ping():
    print("Ping function called")

ping()

