import logging

def get_value_at_index(id_sequence):
    try:
        index = int(input("Enter an index value: "))
    except ValueError:
        logging.error("Invalid input. Please enter an integer.")
        return None
    
    if index >= 0 and index < len(id_sequence):
        return id_sequence[index]
    else:
        logging.error("Index out of bounds.")
        return None

