import os
import psycopg2

def check_user_moderator(username):
    # Get database credentials from a secure credential management system or encrypted file
    db_host = get_secure_credential('DB_HOST')
    db_port = get_secure_credential('DB_PORT')
    db_name = get_secure_credential('DB_NAME')
    db_user = get_secure_credential('DB_USER')
    db_password = get_secure_credential('DB_PASSWORD')

    # Connect to the database using SSL/TLS encryption
    conn = psycopg2.connect(
        host=db_host,
        port=db_port,
        dbname=db_name,
        user=db_user,
        password=db_password,
        sslmode='require'
    )

    # Create a cursor object to execute queries
    cursor = conn.cursor()

    # Use parameterized queries to prevent SQL injection attacks
    query = "SELECT is_moderator FROM users WHERE username = %s"
    cursor.execute(query, (username,))

    # Fetch the result
    result = cursor.fetchone()

    # Close the cursor and connection
    cursor.close()
    conn.close()

    # Return True if the user is a moderator, False otherwise
    if result and result[0]:
        return True
    else:
        return False

def get_secure_credential(credential_name):
    # Implement a secure method to retrieve credentials, such as from a secure credential management system or encrypted file
    return os.environ.get(credential_name)

