import os
import hashlib

def register(username, password):
    # Input Validation
    if not username or not password:
        print("Username and password are required.")
        return
    
    # Password Complexity
    if len(password) < 8:
        print("Password must be at least 8 characters long.")
        return
    
    # Password Storage
    salt = os.urandom(16)  # Generate a random salt
    hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)  # Hash the password using PBKDF2
    stored_password = salt + hashed_password  # Concatenate the salt and hashed password
    
    # Store the username, salt, and hashed password separately in the database
    # Your code to store the data in the database goes here

# Example usage:
username = input("Enter username: ")
password = input("Enter password: ")
register(username, password)

