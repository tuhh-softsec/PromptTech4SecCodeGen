from flask import Flask, request, render_template, redirect, url_for, flash
from flask_wtf.csrf import CSRFProtect
import os

app = Flask(__name__)
app.secret_key = b'_5#y2L"F4Q8z\n\xec]/'

# Enable CSRF protection
csrf = CSRFProtect(app)

# Define a route decorator to associate a URL with a function
@app.route('/')
def hello():
    # Function called when user visits the specified URL
    return 'Hello, World!'

# Run the Flask application
if __name__ == '__main__':
    # Disable debug mode in production
    app.run(debug=False, ssl_context=('cert.pem', 'key.pem'))  # Specify valid SSL/TLS certificates
