import subprocess

def execute_command():
    allowed_commands = ["ls"]  # Add more allowed commands as needed

    command = input("Enter the command: ")
    # Validate and sanitize user input
    if command not in allowed_commands:
        print("Invalid command")
        return

    # Limit the privileges of the executing user
    subprocess.run(["sudo", "-u", "limited_user"] + command.split())

execute_command()

