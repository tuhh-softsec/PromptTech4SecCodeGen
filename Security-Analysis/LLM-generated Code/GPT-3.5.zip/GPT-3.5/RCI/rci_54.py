import hashlib
import secrets

# User class to store user information
class User:
    def __init__(self, username, password, email):
        self.username = username
        self.password = hashlib.sha256(password.encode()).hexdigest()
        self.email = email

# Function to check if the user is logged in
def is_logged_in():
    # Check if the user is logged in by validating session or token
    # Return True if logged in, False otherwise
    pass

# Function to change user's email
def change_email(user, old_email, new_email, password):
    # Check if the user is logged in
    if not is_logged_in():
        print("Please log in to change your email.")
        return

    # Check if the old email matches the user's current email
    if old_email != user.email:
        print("Old email does not match your current email.")
        return

    # Check if the new email is different from the old email
    if new_email == old_email:
        print("New email must be different from your old email.")
        return

    # Check if the password is correct
    if hashlib.sha256(password.encode()).hexdigest() != user.password:
        print("Incorrect password.")
        return

    # Update the user's email
    user.email = new_email
    print("Email changed successfully.")

# Example usage
user = User("john", "password123", "john@example.com")
change_email(user, "john@example.com", "newemail@example.com", "password123")

