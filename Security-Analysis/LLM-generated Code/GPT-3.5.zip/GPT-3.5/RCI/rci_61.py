import hashlib
import os

def calculate_checksum(data):
    checksum = hashlib.sha256(data).hexdigest()
    return checksum

def read_file(file_path):
    abs_path = os.path.abspath(file_path)
    if not abs_path.startswith('/allowed_directory/'):
        raise ValueError("Invalid file path.")
    with open(abs_path, 'rb') as file:
        buffer = file.read()
    return buffer

def save_results(file_path, bytes_read, checksum):
    if os.path.exists(file_path):
        overwrite = input("The output file already exists. Do you want to overwrite it? (y/n): ")
        if overwrite.lower() != 'y':
            print("Operation cancelled.")
            return
    with open(file_path, 'w') as file:
        file.write(f"Bytes Read: {bytes_read}\n")
        file.write(f"Checksum: {checksum}\n")
    os.chmod(file_path, 0o600)

def main():
    input_file = 'input.txt'
    output_file = 'output.txt'

    try:
        buffer = read_file(input_file)
        bytes_read = len(buffer)
        checksum = calculate_checksum(buffer)

        if bytes_read == 0:
            print("Buffer is empty.")
        else:
            save_results(output_file, bytes_read, checksum)
            print("Results saved successfully.")
    except FileNotFoundError:
        print("Input file not found.")
    except ValueError as e:
        print(str(e))
    except Exception as e:
        print(f"An error occurred: {str(e)}")

if __name__ == '__main__':
    main()

