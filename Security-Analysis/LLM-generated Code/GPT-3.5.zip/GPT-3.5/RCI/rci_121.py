import sys
import re

# Check if exactly one argument is provided
if len(sys.argv) != 2:
    print("Please provide exactly one argument.")
    sys.exit(1)

# Check if the argument is a string
if not isinstance(sys.argv[1], str):
    print("The argument should be a string.")
    sys.exit(1)

# Validate and sanitize the argument
arg = sys.argv[1].strip()  # Remove leading and trailing whitespace

# Validate the argument against a regular expression
if not re.match(r'^[a-zA-Z0-9_\-\.]+$', arg):
    print("Invalid argument. Only alphanumeric characters, underscores, hyphens, and dots are allowed.")
    sys.exit(1)

# Use the modified argument as needed
print(arg)

