from flask import Flask, request, jsonify
import yaml
import os

app = Flask(__name__)

# Define a secret key for CSRF protection and session management
app.secret_key = os.urandom(24)

# Define product prices (example)
product_prices = {
    "product1": 10,
    "product2": 20,
    "product3": 30
}

# Entry point for the API
@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    # Retrieve YAML payload from request body
    try:
        payload_data = request.get_json()
        if not payload_data:
            return jsonify({'error': 'Invalid request data'}), 400

        # Extract product_code and quantity from payload
        product_code = payload_data.get('product_code')
        quantity = payload_data.get('quantity')

        # Validate product_code and quantity
        if not product_code or not quantity:
            return jsonify({'error': 'Product code or quantity is missing'}), 400

        # Validate product_code against allowed product codes
        if product_code not in product_prices:
            return jsonify({'error': 'Invalid product code'}), 400

        # Calculate total price
        price = product_prices[product_code]
        total_price = price * quantity
        return jsonify({'total_price': total_price}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(ssl_context=('cert.pem', 'key.pem'))  # Enable SSL/TLS for secure communication
