import ctypes

def copy_bytes(destination, source, num_bytes):
    if num_bytes < 0:
        raise ValueError("Number of bytes cannot be negative")
    if num_bytes > ctypes.sizeof(destination):
        raise ValueError("Number of bytes exceeds buffer size")
    ctypes.memmove(destination, source, num_bytes)

def string_length(string):
    return len(string)

# Example usage
buffer_size = 10
buffer = ctypes.create_string_buffer(buffer_size)

# Copying "Hell." to the buffer
source_string = "Hell."
copy_bytes(buffer, source_string.encode(), string_length(source_string))

# Printing the buffer
print(buffer.value.decode())

