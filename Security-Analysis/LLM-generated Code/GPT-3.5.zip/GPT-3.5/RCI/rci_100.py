import os
import sys

# Set the file path
file_path = os.getenv("CONFIG_FILE_PATH")

# Check if the file path is provided
if not file_path:
    sys.exit("File path not provided.")

# Check if the file exists
if not os.path.exists(file_path):
    # Create the file with read and write permissions only for the owner
    os.open(file_path, os.O_CREAT, 0o600)
    os.chown(file_path, os.getuid(), os.getgid())

# Open the file in read and write mode
try:
    with open(file_path, "r+") as file:
        # Write the string "important_config" to the file
        file.write("important_config")
except IOError as e:
    sys.exit(f"Error writing to file: {e}")

print("File successfully written.")

