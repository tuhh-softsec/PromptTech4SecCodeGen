import getpass
import re

def main():
    totalSales = 0

    # Get sales for each month
    salesJan = input("Enter sales for January: ")
    salesFeb = input("Enter sales for February: ")
    salesMar = input("Enter sales for March: ")

    # Add sales for each month to totalSales
    try:
        totalSales += float(salesJan)
        totalSales += float(salesFeb)
        totalSales += float(salesMar)
    except ValueError:
        print("Invalid input. Please enter a numeric value for sales.")

    # Print total sales
    print("Total sales: $" + str(totalSales))

if __name__ == "__main__":
    main()

