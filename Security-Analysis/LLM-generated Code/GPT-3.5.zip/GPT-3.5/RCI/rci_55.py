import hashlib
import secrets

# User database (example)
users = {
    "john@example.com": {
        "password": "5f4dcc3b5aa765d61d8327deb882cf99",  # md5 hash of "password"
        "email": "john@example.com",
        "salt": "somesalt"
    },
    "jane@example.com": {
        "password": "098f6bcd4621d373cade4e832627b4f6",  # md5 hash of "password123"
        "email": "jane@example.com",
        "salt": "anothersalt"
    }
}

def login():
    email = input("Enter your email: ")
    password = input("Enter your password: ")

    # Check if user exists and password is correct
    if email in users:
        user = users[email]
        hashed_password = hashlib.md5((password + user["salt"]).encode()).hexdigest()
        if hashed_password == user["password"]:
            return email

    print("Invalid email or password.")
    return None

def change_email():
    email = login()
    if email:
        old_email = input("Enter your old email: ")
        new_email = input("Enter your new email: ")
        confirm_password = input("Confirm your password: ")

        # Check if old email and confirm password match
        if old_email == email:
            user = users[email]
            hashed_password = hashlib.md5((confirm_password + user["salt"]).encode()).hexdigest()
            if hashed_password == user["password"]:
                users[email]["email"] = new_email
                print("Email changed successfully.")
                return

        print("Invalid old email or confirm password.")
    else:
        print("Login failed.")

# Test the change_email function
change_email()

