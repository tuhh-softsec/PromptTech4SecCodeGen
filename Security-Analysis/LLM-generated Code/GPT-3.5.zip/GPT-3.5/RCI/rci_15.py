def get_value_at_index(array, index):
    if not isinstance(index, int):
        raise ValueError("Invalid input. Please enter a valid number.")
    if index < 0 or index >= len(array):
        raise IndexError("Index out of bounds.")
    return array[index]

# Example usage
user_input = input("Enter a number: ")
try:
    number = int(user_input)
    array = [1, 2, 3, 4, 5]
    result = get_value_at_index(array, number)
    print("Value at index", number, "is", result)
except ValueError as e:
    print(str(e))
except IndexError as e:
    print(str(e))

