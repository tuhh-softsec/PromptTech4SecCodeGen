import subprocess
import re
import logging

def get_user_info(username):
    try:
        # Validate the username parameter
        if not re.match(r'^[a-zA-Z0-9_]+$', username):
            logging.error("Invalid username")
            return

        # Sanitize the username parameter
        sanitized_username = username.replace(';', '').replace('&', '')

        # Using subprocess.run to execute the command and capture the output
        process = subprocess.run(['getent', 'passwd', sanitized_username], capture_output=True, text=True, check=True)

        # Opening a file in write mode to store the output
        with open('output.txt', 'w') as file:
            file.write(process.stdout)
        logging.info("Output stored in output.txt")
    except subprocess.CalledProcessError as e:
        logging.error("Error executing command:" + str(e))
    except OSError as e:
        logging.error("Error:"+  str(e))

# Example usage
get_user_info("username")

