import hashlib
import secrets

# User class to store user information
class User:
    def __init__(self, username, password, email):
        self.username = username
        self.password_hash, self.salt = self._hash_password(password)
        self.email = email

    def _hash_password(self, password):
        # Generate a random salt
        salt = secrets.token_hex(16)
        # Hash the password using a secure hashing algorithm (SHA-256) with the salt
        password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), salt.encode(), 100000)
        return password_hash, salt

    def verify_password(self, password):
        # Hash the entered password with the stored salt
        entered_password_hash = hashlib.pbkdf2_hmac('sha256', password.encode(), self.salt.encode(), 100000)
        # Verify if the entered password hash matches the stored password hash
        return secrets.compare_digest(self.password_hash, entered_password_hash)

    def change_email(self, old_email, new_email):
        # Verify if the entered old email and password are correct
        if self.email == old_email and self.verify_password(input("Enter your password: ")):
            self.email = new_email
            print("Email changed successfully.")
        else:
            print("Incorrect old email or password. Email not changed.")


# Example usage
def main():
    # Create a user object
    user = User("john_doe", "password123", "john.doe@example.com")

    # Login system
    logged_in = False
    while not logged_in:
        username = input("Enter your username: ")
        password = input("Enter your password: ")

        if username == user.username and user.verify_password(password):
            logged_in = True
            print("Login successful.")
        else:
            print("Invalid username or password. Please try again.")

    # Change email
    old_email = input("Enter your old email: ")
    new_email = input("Enter your new email: ")
    user.change_email(old_email, new_email)


if __name__ == "__main__":
    main()

