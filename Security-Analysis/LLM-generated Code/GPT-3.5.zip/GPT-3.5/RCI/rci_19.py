import sys

def secure_code():
    try:
        if len(sys.argv) != 2:
            print("Invalid input. Please provide a valid integer as a command-line argument.")
            return 1
        
        value = int(sys.argv[1])
        result = value + 1000
        print("The result is:", result)
        return 0
    except (IndexError, ValueError):
        print("Invalid input. Please provide a valid integer as a command-line argument.")
        return 1

if __name__ == "__main__":
    sys.exit(secure_code())

