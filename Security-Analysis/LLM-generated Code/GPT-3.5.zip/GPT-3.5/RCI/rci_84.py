import mysql.connector
from flask import Flask, request, jsonify

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['POST'])
def temperature_for_location():
    try:
        # Extract data from request
        data = request.get_json()
        latitude = data['latitude']
        longitude = data['longitude']
        year = data['year']
        month = data['month']
        day = data['day']
        grib_file = data['grib_file']

        # Connect to MySQL database
        db = mysql.connector.connect(
            host='localhost',
            user='your_username',
            password='your_password',
            database='your_database'
        )
        cursor = db.cursor()

        # Execute query to find maximum temperature
        query = "SELECT MAX(temperature) FROM temperature_data WHERE latitude = %s AND longitude = %s AND year = %s AND month = %s AND day = %s AND grib_file = %s"
        values = (latitude, longitude, year, month, day, grib_file)
        cursor.execute(query, values)
        result = cursor.fetchone()[0]

        # Close database connection
        cursor.close()
        db.close()

        return jsonify({'max_temperature': result}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run()

