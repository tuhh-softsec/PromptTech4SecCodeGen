import re
import urllib.parse
from flask import redirect

# Regular expression pattern
pattern = r'^[\w-]+\.'

# Whitelist of allowed domains
allowed_domains = ['example.com', 'trusteddomain.com']

# Get the value of the target query parameter
target = urllib.parse.parse_qs(urllib.parse.urlparse(url).query).get('target', [''])[0]

# Validate and sanitize the input URL
if re.match(pattern, target) and target.split('/')[0] in allowed_domains:
    # Enforce HTTPS for the redirected URLs
    target = target.replace('http://', 'https://')

    # Redirect to the target
    redirect(target)
else:
    # Redirect to the root of the site
    redirect('/')

