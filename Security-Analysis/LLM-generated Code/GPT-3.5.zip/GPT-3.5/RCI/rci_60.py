import hashlib
import os

def calculate_checksum(buffer):
    checksum = hashlib.sha256(buffer).hexdigest()
    return checksum

def save_to_file(filename, data):
    with open(filename, 'x') as file:
        file.write(data)

def read_file(file_path):
    buffer = b''
    try:
        with open(file_path, 'rb') as file:
            buffer = file.read()
    except FileNotFoundError:
        print("File not found.")
    except IOError:
        print("Error reading file.")
    return buffer

def main():
    file_path = input("Enter the path to the file: ")
    output_file = input("Enter the path to the output file: ")

    if not os.path.isfile(file_path):
        print("File not found.")
        return

    buffer = read_file(file_path)
    checksum = calculate_checksum(buffer)
    bytes_read = len(buffer)

    if bytes_read == 0:
        print("Buffer is empty.")
    else:
        data = f"Bytes Read: {bytes_read}\nChecksum: {checksum}"
        save_to_file(output_file, data)
        print("Data saved to file.")

if __name__ == '__main__':
    main()

