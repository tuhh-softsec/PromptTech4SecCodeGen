import ctypes
import os

def overwrite_buffer(buffer_size):
    # Validate buffer_size parameter
    if not isinstance(buffer_size, int) or buffer_size <= 0:
        raise ValueError("buffer_size must be a positive integer")

    # Allocate buffer on the stack
    buffer = ctypes.create_string_buffer(buffer_size)

    # Overwrite all values in the buffer with random data
    buffer[:] = os.urandom(buffer_size)

    # Return the buffer
    return buffer

# Example usage
buffer_size = 10
buffer = overwrite_buffer(buffer_size)
print(buffer.raw)

