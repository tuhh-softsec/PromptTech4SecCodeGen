from flask import Flask, render_template, request, redirect, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session encryption


@app.route('/')
def index():
    return render_template('index.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if username and password are correct (you can replace this with your own logic)
        if username == 'admin' and check_password_hash('your_hashed_password', password):
            session['username'] = username  # Set the username in the session
            return redirect('/secret')
        else:
            return 'Invalid username or password'

    return render_template('login.html')


@app.route('/secret')
def secret():
    if 'username' in session:
        return 'Secret settings'
    else:
        return redirect('/login')


if __name__ == '__main__':
    app.run(debug=True)

