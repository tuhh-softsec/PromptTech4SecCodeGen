from flask import Flask, render_template, request, redirect, session
from flask_bcrypt import Bcrypt
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
app.secret_key = 'your_secret_key'
bcrypt = Bcrypt(app)
limiter = Limiter(app, key_func=get_remote_address)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
@limiter.limit("5/minute")  # Rate limit to 5 login attempts per minute
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check username and password
        if username == 'admin' and bcrypt.check_password_hash('hashed_password', password):
            session['username'] = username
            return redirect('/secret')
        else:
            return render_template('login.html', error='Invalid username or password')
    
    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return render_template('secret.html')
    else:
        return redirect('/login')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)

