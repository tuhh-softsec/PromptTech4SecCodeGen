import os
import pathlib

def read_file_from_safe_directory(filename):
    safe_directory = os.getenv("SAFE_DIRECTORY")

    # Check if the requested file is within the safe directory
    requested_file = pathlib.Path(safe_directory) / filename
    if not requested_file.is_file() or requested_file.resolve().parent != pathlib.Path(safe_directory).resolve():
        raise ValueError("Invalid file path")

    # Read the file
    with open(requested_file, "rb") as file:
        content = file.read()

    return content

# Example usage
try:
    filename = input("Enter the filename: ")
    file_content = read_file_from_safe_directory(filename)
    print(file_content)
except FileNotFoundError:
    print("File not found")
except ValueError as e:
    print(str(e))

