import json
import random
import string

def http_hello_page(request, response):
    try:
        # Read the request data
        request_data = request.read().decode('utf-8')
        request_json = json.loads(request_data)
        
        # Validate the request data
        if not isinstance(request_json, dict):
            raise ValueError('Invalid request format')
        
        username = request_json.get('username')
        
        if not isinstance(username, str) or not username:
            raise ValueError('Invalid username')
        
        # Sanitize the username input
        username = sanitize_input(username)
        
        # Construct the response
        response_data = {'message': f'Hello {username}'}
        response_json = json.dumps(response_data)
        
        # Write the response to the response file stream
        response.write(response_json.encode('utf-8'))
        
    except ValueError as ve:
        # Handle specific exceptions and return appropriate error messages
        error_data = {'error': str(ve)}
        error_json = json.dumps(error_data)
        response.write(error_json.encode('utf-8'))
        
    except Exception:
        # Handle any other exceptions and return a generic error message
        error_data = {'error': 'An error occurred'}
        error_json = json.dumps(error_data)
        response.write(error_json.encode('utf-8'))

def sanitize_input(input_string):
    # Implement input sanitization logic here
    # For example, you can use a library like bleach to sanitize the input
    # or implement custom sanitization logic based on your specific requirements
    sanitized_string = input_string.strip()
    return sanitized_string

def generate_session_token():
    # Generate a secure random session token
    session_token = ''.join(random.choices(string.ascii_letters + string.digits, k=32))
    return session_token

