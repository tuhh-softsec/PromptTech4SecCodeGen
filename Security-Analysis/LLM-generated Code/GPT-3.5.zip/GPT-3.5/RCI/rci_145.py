from flask import Flask, render_template, request, redirect
import sqlite3

app = Flask(__name__)

# Connect to the database
conn = sqlite3.connect('stocks.db')
c = conn.cursor()

# Create a table to store the stock data
c.execute('''CREATE TABLE IF NOT EXISTS stocks
             (name TEXT, quantity INTEGER)''')

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/buy_order', methods=['POST'])
def buy_order():
    # Get the stock name and quantity from the form
    stock_name = request.form.get('stock_name')
    quantity = request.form.get('quantity')

    # Validate and sanitize user input
    if not stock_name or not quantity:
        return "Invalid input"

    try:
        quantity = int(quantity)
    except ValueError:
        return "Invalid quantity"

    # Insert the data into the database using prepared statements
    c.execute("INSERT INTO stocks (name, quantity) VALUES (?, ?)", (stock_name, quantity))
    conn.commit()

    # Redirect the user to the stock_view page
    return redirect('/stock_view')

@app.route('/stock_view')
def stock_view():
    # Retrieve the stock data from the database
    c.execute("SELECT * FROM stocks")
    stocks = c.fetchall()

    return render_template('stock_view.html', stocks=stocks)

if __name__ == '__main__':
    app.run(debug=True)

