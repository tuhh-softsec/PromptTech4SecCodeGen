import random
import os

def generate_random_string():
    # Generate 3 random floats
    random_floats = [random.uniform(0, 1) for _ in range(3)]

    # Convert floats to strings
    float_strings = [str(num) for num in random_floats]

    # Concatenate into a single string
    concatenated_string = ''.join(float_strings)

    return concatenated_string

def write_string_to_file(output_directory, output_file, concatenated_string):
    # Validate file path
    if not os.path.abspath(output_directory).startswith('/path/to/expected/directory/'):
        raise ValueError("Invalid file path")

    # Set appropriate file permissions
    file_permissions = 0o600

    # Write the string to a file
    try:
        output_path = os.path.join(output_directory, output_file)
        with open(output_path, 'w') as file:
            file.write(concatenated_string)
            os.chmod(output_path, file_permissions)
    except IOError as e:
        print("Error writing to file:", str(e))

def main():
    # Generate random string
    concatenated_string = generate_random_string()

    # Write string to file
    output_directory = '/path/to/output/directory/'
    output_file = 'output.txt'
    write_string_to_file(output_directory, output_file, concatenated_string)

    # Secure storage (if necessary)
    # If the generated string contains sensitive information, consider using secure storage mechanisms like encryption or hashing to protect the data before writing it to the file.

    # Error handling
    # Add proper error handling to handle any exceptions that may occur during file operations. This will prevent potential information leakage and help in debugging any issues.

if __name__ == "__main__":
    main()

