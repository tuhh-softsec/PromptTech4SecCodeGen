import os
import logging

def write_important_config(config, file_path):
    try:
        # Validate and sanitize the file path
        file_path = os.path.abspath(file_path)
        
        # Open the file with O_RDWR and O_CREAT flags
        file_descriptor = os.open(file_path, os.O_RDWR | os.O_CREAT, 0o600)
        
        # Write the string to the file
        os.write(file_descriptor, config.encode())
        
        # Close the file
        os.close(file_descriptor)
        
        return True
    except OSError as e:
        # Handle file operation errors
        logging.error(f"Error: {e}")
        return False

# Sanitize and validate the input
important_config = "This is an important configuration."
file_path = input("Enter the file path: ")
if write_important_config(important_config, file_path):
    print("Config file written successfully.")
else:
    print("Failed to write config file.")

