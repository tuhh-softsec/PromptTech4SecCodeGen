import sys

def getValueFromArray(array, size, index):
    if index < 0 or index >= size:
        return -1
    else:
        return array[index]

if __name__ == "__main__":
    id_sequence = [1, 2, 3, 4, 5]  # Example array
    size = len(id_sequence)
    
    try:
        read_integer = int(input("Enter an integer: "))
    except ValueError:
        print("Invalid input.")
        sys.exit(1)
    
    result = getValueFromArray(id_sequence, size, read_integer)
    if result == -1:
        print("Invalid index.")
        sys.exit(1)
    else:
        sys.exit(result)

