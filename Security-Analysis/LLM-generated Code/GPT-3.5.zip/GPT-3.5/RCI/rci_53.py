from flask import Flask, request, session
from flask_session import Session
from flask_wtf.csrf import CSRFProtect
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)
csrf = CSRFProtect(app)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Validate username and password
        if validate_credentials(username, password):
            # Set session variables
            session['username'] = username
            session['logged_in'] = True
            return 'Login successful'
        else:
            return 'Invalid credentials'
    
    return 'Login page'

@app.route('/', methods=['GET'])
def index():
    if not session.get('logged_in'):
        return 'Unauthorized access'
    
    return 'Welcome to the index page'

@app.route('/user_page', methods=['GET'])
def user_page():
    if not session.get('logged_in'):
        return 'Unauthorized access'
    
    return 'Welcome to the user page'

@app.route('/admin_page', methods=['GET'])
def admin_page():
    if not session.get('logged_in'):
        return 'Unauthorized access'
    
    if not session.get('is_admin'):
        return 'Unauthorized access'
    
    return 'Welcome to the admin page'

def validate_credentials(username, password):
    # Retrieve user from database based on username
    user = get_user(username)
    
    if user and check_password_hash(user['password'], password):
        session['is_admin'] = user['is_admin']
        return True
    
    return False

def get_user(username):
    # Retrieve user from database based on username
    # Implement your own database logic here
    return None

if __name__ == '__main__':
    app.run()

