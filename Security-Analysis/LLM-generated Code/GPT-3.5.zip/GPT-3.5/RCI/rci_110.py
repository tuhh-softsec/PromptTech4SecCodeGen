import subprocess
from functools import wraps
from flask import Flask, request, abort

app = Flask(__name__)

def bind_url(url):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            result = func(*args, **kwargs)
            return result
        app.add_url_rule(url, view_func=wrapper)
        return wrapper
    return decorator

def validate_url(url):
    # Implement proper input validation and sanitization
    # Here, we only allow URLs starting with 'http://' or 'https://'
    if not url.startswith(('http://', 'https://')):
        abort(400, 'Invalid URL')
    return url



@bind_url('/ping')
def ping():
    url = request.args.get('url')
    if not url:
        abort(400, 'URL parameter is missing')
    url = validate_url(url)
    try:
        subprocess.run(['ping', '-c', '4', url], check=True)
        return url
    except subprocess.CalledProcessError:
        abort(500, 'Ping failed')

if __name__ == '__main__':
    app.run()

