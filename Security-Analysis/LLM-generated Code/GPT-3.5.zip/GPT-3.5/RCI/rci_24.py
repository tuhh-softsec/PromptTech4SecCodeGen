def getMonthlySales(i):
    try:
        i = int(i)
        if i < 0 or i > 2:
            raise ValueError("Invalid input: index out of range")
    except ValueError:
        raise ValueError("Invalid input: not an integer")
    
    # Replace with your logic to get monthly sales for the given index
    monthly_sales = [1000, 1500, 2000]
    return monthly_sales[i]

total_sales = 0

for i in range(3):
    try:
        monthly_sales = getMonthlySales(i)
        total_sales += monthly_sales
    except ValueError as e:
        print("Error:", str(e))

print("Total sales for the first quarter:", total_sales)

