import hashlib
import secrets

# Database of usernames, hashed passwords, and salts
users = {
    "admin": {
        "password": "21232f297a57a5a743894a0e4a801fc3",  # md5 hash of "admin"
        "salt": "randomsalt1"
    },
    "user1": {
        "password": "ee11cbb19052e40b07aac0ca060c23ee",  # md5 hash of "password1"
        "salt": "randomsalt2"
    },
    "user2": {
        "password": "8f14e45fceea167a5a36dedd4bea2543",  # md5 hash of "password2"
        "salt": "randomsalt3"
    }
}

def login():
    username = input("Username: ")
    password = input("Password: ")

    if username in users:
        stored_password = users[username]["password"]
        salt = users[username]["salt"]
        hashed_password = hashlib.md5((password + salt).encode()).hexdigest()

        if stored_password == hashed_password:
            print("Login successful!")
            # Redirect to session page
            session_page()
            return

    print("Incorrect username or password.")

def session_page():
    print("Welcome to the session page!")

# Start the login process
login()

