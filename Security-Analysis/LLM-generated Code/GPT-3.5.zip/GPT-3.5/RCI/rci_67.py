import base64
import os

def upload_image(image_data, file_path):
    try:
        # Validate inputs
        if not isinstance(image_data, str) or not isinstance(file_path, str):
            raise ValueError("Invalid input types.")

        # Validate file path
        if not os.path.isabs(file_path):
            raise ValueError("Invalid file path.")

        # Validate image data
        decoded_image = base64.b64decode(image_data)

        # Enforce file size restrictions
        max_file_size = 10 * 1024 * 1024  # 10 MB
        if len(decoded_image) > max_file_size:
            raise ValueError("File size exceeds the maximum limit.")

        # Validate file type
        allowed_file_types = ['.jpg', '.jpeg', '.png']
        file_extension = os.path.splitext(file_path)[1].lower()
        if file_extension not in allowed_file_types:
            raise ValueError("Invalid file type.")

        # Validate file name
        allowed_characters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_'
        file_name = os.path.basename(file_path)
        if any(char not in allowed_characters for char in file_name):
            raise ValueError("Invalid file name.")

        # Write the decoded image to a file
        with open(file_path, 'wb') as file:
            file.write(decoded_image)

        print("Image uploaded successfully.")
    except Exception as e:
        print("Error uploading image:", str(e))

