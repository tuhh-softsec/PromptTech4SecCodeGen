import sys

def validate_input(input):
    # Perform input validation/sanitization here
    return input

try:
    if len(sys.argv) != 2:
        raise ValueError("Error: Invalid input. Please provide exactly one argument.")
    
    input = sys.argv[1]
    input = input.rstrip()
    
    input = validate_input(input)
    
    print("Input: " + input)
    
except Exception as e:
    print("Error:", str(e))

sys.exit()

