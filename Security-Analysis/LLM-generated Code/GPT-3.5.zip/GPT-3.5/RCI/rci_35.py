import hashlib
from flask import Flask, request, redirect

app = Flask(__name__)

# Simulated database of usernames and hashed passwords
database = {
    'user1': '$2b$12$3QK3Y3Y0QJZ0Jz7z7Zz7Zu3QK3Y3Y0QJZ0Jz7z7Zz7Zu',  # password: password
    'user2': '$2b$12$3QK3Y3Y0QJZ0Jz7z7Zz7Zu3QK3Y3Y0QJZ0Jz7z7Zz7Zu',  # password: test
    # Add more usernames and hashed passwords here
}

@app.route('/login', methods=['POST'])
def login():
    try:
        username = request.form['username']
        password = request.form['password']

        if username in database:
            hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode(), b'salt', 100000).hex()
            if database[username] == hashed_password:
                return redirect('/success')
            else:
                return redirect('/cant_login')
        else:
            return redirect('/cant_login')
    except Exception as e:
        print(e)
        return redirect('/internal_server_error')

@app.route('/success')
def success():
    return 'Login successful!'

@app.route('/cant_login')
def cant_login():
    return 'Invalid username or password.'

@app.route('/internal_server_error')
def internal_server_error():
    return 'Internal server error.'

if __name__ == '__main__':
    app.run()

