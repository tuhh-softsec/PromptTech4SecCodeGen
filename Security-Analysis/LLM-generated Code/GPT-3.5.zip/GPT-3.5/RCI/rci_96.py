import bcrypt
import sqlite3

def register(username, password):
    # Validate and sanitize the input
    if not username or not password:
        raise ValueError("Invalid username or password")

    # Enforce stronger password complexity requirements
    if len(password) < 8 or not any(char.isdigit() for char in password) or not any(char.isalpha() for char in password) or password.islower() or password.isupper() or password.isnumeric() or password.isalnum():
        raise ValueError("Password must be at least 8 characters long and contain a mix of uppercase and lowercase letters, numbers, and special characters")

    # Hash the password with salt and pepper
    salt = bcrypt.gensalt()
    pepper = b'mysecretpepper'
    hashed_password = bcrypt.hashpw(password.encode('utf-8') + pepper, salt)

    # Connect to the database securely using SSL/TLS encryption
    conn = sqlite3.connect('database.db', uri='file:encrypted_database.db?mode=ro', check_same_thread=False, ssl=True)

    # Implement user authentication and authorization checks
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM users WHERE username = ?", (username,))
    user = cursor.fetchone()
    if user:
        raise ValueError("Username already exists")

    # Insert the username and hashed password into the database
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    conn.commit()

    # Close the database connection
    conn.close()

# Example usage
register("john_doe", "StrongPassword123!")

