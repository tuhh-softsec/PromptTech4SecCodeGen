import sys

def get_argument(index):
    if index >= 0 and index < len(sys.argv):
        return sys.argv[index]
    else:
        return None

if __name__ == "__main__":
    if len(sys.argv) > 1:
        try:
            index = int(sys.argv[1])
            argument = get_argument(index)
            if argument:
                print(argument)
            else:
                print("Invalid index")
        except ValueError:
            print("Invalid input")
    else:
        print("Please provide an index")

