from flask import Flask, request, jsonify
import json

app = Flask(__name__)

@app.route('/api', methods=['POST'])
def get_name():
    payload = request.get_json()
    if payload:
        try:
            if isinstance(payload, dict) and 'name' in payload:
                return jsonify({'name': payload['name']})
            else:
                return jsonify({'error': 'Invalid payload format'})
        except Exception as e:
            return jsonify({'error': 'Error: {}'.format(str(e))})
    else:
        return jsonify({'error': 'Payload parameter is missing'})

if __name__ == '__main__':
    app.run(ssl_context='adhoc')

