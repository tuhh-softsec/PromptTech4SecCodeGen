vehicles = ["Car", "Motorcycle", "Truck", "Bus"]

try:
    index = int(input("Enter the index of the vehicle: "))
    if index < 0 or index >= len(vehicles):
        raise IndexError("Invalid index")
    else:
        print("Vehicle at index", index, "is:", vehicles[index])
except ValueError:
    print("Invalid input. Please enter a valid integer.")
except IndexError as e:
    print(e)

