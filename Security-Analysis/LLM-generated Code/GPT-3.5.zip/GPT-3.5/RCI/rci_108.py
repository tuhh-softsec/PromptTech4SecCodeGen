import subprocess
import sys
import logging
import re

def run_id_command(username):
    try:
        # Validate and sanitize the username input to prevent command injection attacks
        if not re.match("^[a-zA-Z0-9]+$", username):
            raise ValueError("Invalid username")

        subprocess.check_output(['id', username])
        return 0
    except subprocess.CalledProcessError as e:
        # Implement detailed error handling and logging mechanisms
        logging.error(f"Error executing 'id' command for username '{username}': {e}")
        return e.returncode
    except ValueError as ve:
        logging.error(f"Invalid username: {ve}")
        return 1

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python script.py <username>")
        sys.exit(1)

    username = sys.argv[1]
    exit_status = run_id_command(username)
    print("Exit status:", exit_status)

