import zipfile
import os

# Validate the input
def validate_zip(file_path):
    try:
        if os.path.isfile(file_path):
            with zipfile.ZipFile(file_path, 'r') as zip_file:
                zip_file.testzip()
                return True
        else:
            return False
    except zipfile.BadZipFile:
        return False

# Sanitize the extraction path
def sanitize_path(path):
    extraction_path = os.path.abspath(os.path.join('/tmp/unpack', os.path.basename(path)))
    return extraction_path

# Set appropriate permissions
def set_permissions(directory):
    os.chmod(directory, 0o700)

# Open the archive.zip file as a zipfile
def extract_archive(file_path):
    if validate_zip(file_path):
        with zipfile.ZipFile(file_path, 'r') as zip_file:
            for file in zip_file.namelist():
                extracted_path = sanitize_path(file)
                zip_file.extract(file, '/tmp/unpack')
                set_permissions(extracted_path)

# Extract all files from the archive to the /tmp/unpack directory
extract_archive('archive.zip')

