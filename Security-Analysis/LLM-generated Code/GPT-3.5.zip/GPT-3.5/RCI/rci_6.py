import sys

def atoi(s):
    try:
        return int(s)
    except ValueError:
        return None

def main():
    argc = len(sys.argv)
    argv = sys.argv

    # Convert the remaining arguments to integers using atoi()
    for i in range(1, argc):
        arg = argv[i]
        num = atoi(arg)
        if num is not None:
            print("Argument", i, "converted to integer:", num)
        else:
            print("Argument", i, "is not a valid integer")

if __name__ == "__main__":
    main()

