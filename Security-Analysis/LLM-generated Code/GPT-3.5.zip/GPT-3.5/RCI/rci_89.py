import bcrypt
import sqlite3

def create_user(username, password):
    # Hash the password
    hashed_password = bcrypt.hashpw(password.encode(), bcrypt.gensalt())

    # Connect to the database
    conn = sqlite3.connect('users.db')
    cursor = conn.cursor()

    # Use parameterized queries to prevent SQL injection
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))

    # Commit the changes and close the connection
    conn.commit()
    conn.close()

def main():
    # Get username and password from user
    username = input("Enter username: ")
    password = input("Enter password: ")

    # Validate and sanitize user inputs
    if not username or not password:
        print("Invalid username or password.")
        return

    # Create the user
    create_user(username, password)

if __name__ == "__main__":
    main()

