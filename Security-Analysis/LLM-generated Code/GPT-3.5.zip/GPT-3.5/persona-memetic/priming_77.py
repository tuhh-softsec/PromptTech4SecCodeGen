import sys

def allocate_memory():
    buf = bytearray(1024)
    sys.stdin.read(buf)
    return buf

def allocate_memory2():
    buf1 = bytearray(1024)
    sys.stdin.read(buf1)
    return buf1

def main():
    buf = allocate_memory()
    buf1 = allocate_memory2()
    # Rest of your code

if __name__ == "__main__":
    main()

