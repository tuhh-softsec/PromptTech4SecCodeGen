import subprocess

def get_user_info(username):
    try:
        # Execute the command using subprocess
        process = subprocess.Popen(['getent', 'passwd', username], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output, error = process.communicate()

        # Check for any errors
        if process.returncode != 0:
            print(f"Error executing command: {error.decode()}")
            return None

        # Store the output in the file pointer or process it as needed
        with open('output.txt', 'w') as file:
            file.write(output.decode())

        return output.decode()

    except Exception as e:
        print(f"An error occurred: {str(e)}")
        return None

# Usage example
username = 'example_user'
user_info = get_user_info(username)
if user_info:
    print(f"User information for {username}:")
    print(user_info)

