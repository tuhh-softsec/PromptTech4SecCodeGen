import re
from flask import redirect

# Define the regular expression pattern as a constant
URL_PATTERN = re.compile(r'^https?://(www\.)?example\.com/.*$')
default_url = ""
# Use the compiled pattern in your code
def match_url(target_url):
    if URL_PATTERN.match(target_url):
        # Redirect to the target URL
        redirect(target_url)
    else:
        # Redirect to the default URL
        redirect(default_url)


