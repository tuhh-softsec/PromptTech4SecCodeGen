import os
import base64

def upload_image(image_data, file_path):
    try:
        # Validate file path to prevent path traversal attacks
        if not os.path.isabs(file_path):
            raise ValueError("Invalid file path")

        # Decode the base64 encoded image data
        decoded_image = base64.b64decode(image_data)

        # Validate image file format to prevent malicious file execution
        allowed_formats = ['.jpg', '.jpeg', '.png', '.gif']
        file_extension = os.path.splitext(file_path)[1].lower()
        if file_extension not in allowed_formats:
            raise ValueError("Invalid image format")

        # Write the decoded image data to the file
        with open(file_path, 'wb') as file:
            file.write(decoded_image)

        print("Image uploaded successfully")
    except Exception as e:
        print("Error:", str(e))

