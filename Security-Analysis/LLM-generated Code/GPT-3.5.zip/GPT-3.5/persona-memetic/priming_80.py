from flask import Flask, request, jsonify
import json

app = Flask(__name__)

@app.route('/api', methods=['GET'])
def get_payload():
    try:
        payload = request.args.get('payload', default='', type=str)
        payload_dict = {}
        
        # Validate and load the payload into a dictionary
        if payload:
            payload_dict = validate_payload(payload)
        
        # Return the name value from the dictionary
        if 'name' in payload_dict:
            return jsonify({'name': payload_dict['name']})
        else:
            return jsonify({'error': 'Invalid payload format'})
    
    except Exception as e:
        return jsonify({'error': str(e)})

def validate_payload(payload):
    # Implement your payload validation logic here
    # You can use regular expressions or any other validation technique
    
    # Example validation: Payload should be a JSON object
    
    payload_dict = json.loads(payload)
    
    # Additional validation rules can be applied here
    
    return payload_dict

if __name__ == '__main__':
    app.run()

