from flask import Flask, render_template, request, session, redirect, url_for
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'
bcrypt = Bcrypt(app)

# Replace 'your_secret_key' with a strong secret key

# Simulated user database for demonstration
users = {
    'user1': {
        'password': bcrypt.generate_password_hash('password1').decode('utf-8'),
        'email': 'user1@example.com'
    },
    'user2': {
        'password': bcrypt.generate_password_hash('password2').decode('utf-8'),
        'email': 'user2@example.com'
    }
}

@app.route('/')
def index():
    if 'username' in session:
        return '<a href="/change_email">Change Email</a> | <a href="/logout">Logout</a>'
    else:
        return '<a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and bcrypt.check_password_hash(users[username]['password'], password):
            session['username'] = username
            return redirect(url_for('index'))

        return 'Incorrect username or password'

    return render_template('login.html')

@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    if 'username' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        username = session['username']
        old_email = request.form['old_email']
        new_email = request.form['new_email']
        confirm_password = request.form['confirm_password']

        if (
            username in users
            and users[username]['email'] == old_email
            and bcrypt.check_password_hash(users[username]['password'], confirm_password)
            and old_email != new_email
        ):
            users[username]['email'] = new_email
            return 'Email updated successfully'

        return 'Invalid input. Please check your old email, new email, and password.'

    return render_template('change_email.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
