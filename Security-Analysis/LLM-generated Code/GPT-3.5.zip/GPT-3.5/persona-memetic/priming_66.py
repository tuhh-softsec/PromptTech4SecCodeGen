import os
import base64
import imghdr
import hashlib
import sqlite3

UPLOADS_DIR = "uploads"
DATABASE_FILE = "database.db"

def upload_image(image_file):
    # Validate the image file
    if not is_valid_image(image_file):
        return "Invalid image file"

    # Sanitize the image name
    image_name = sanitize_image_name(image_file.filename)

    # Read and convert the image to base64
    image_data = image_file.read()
    base64_string = base64.b64encode(image_data).decode("utf-8")

    # Store the base64 string securely
    encrypted_base64 = encrypt_data(base64_string)

    # Insert the image name and encrypted base64 string into the database
    insert_image_into_database(image_name, encrypted_base64)

    return "Image uploaded successfully"

def is_valid_image(image_file):
    # Check the file extension
    allowed_extensions = [".jpg", ".jpeg", ".png"]
    if not any(image_file.filename.lower().endswith(ext) for ext in allowed_extensions):
        return False

    # Verify the file's MIME type
    if imghdr.what(image_file) is None:
        return False

    # Limit the file size (e.g., 10MB)
    max_file_size = 10 * 1024 * 1024
    if len(image_file.read()) > max_file_size:
        return False

    return True

def sanitize_image_name(image_name):
    # Remove special characters and limit the length
    sanitized_name = "".join(c for c in image_name if c.isalnum() or c in ["_", "-"])
    return sanitized_name[:100]  # Limit to 100 characters

def encrypt_data(data):
    # Use a secure encryption algorithm and proper key management
    # Example: SHA-256 hashing
    hashed_data = hashlib.sha256(data.encode()).hexdigest()
    return hashed_data

def insert_image_into_database(image_name, encrypted_base64):
    # Use parameterized queries or prepared statements to prevent SQL injection attacks
    conn = sqlite3.connect(DATABASE_FILE)
    cursor = conn.cursor()

    query = "INSERT INTO images (name, base64) VALUES (?, ?)"
    cursor.execute(query, (image_name, encrypted_base64))

    conn.commit()
    conn.close()

# Example usage
image_file = open("image.jpg", "rb")
upload_image(image_file)
image_file.close()

