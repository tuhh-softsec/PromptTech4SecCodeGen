import sys

def convert_to_integer(input_str):
    try:
        return int(input_str)
    except ValueError:
        return None

def print_array_element(array, index):
    if index < 0 or index >= len(array):
        print("Invalid input.")
    else:
        print(array[index])

def main():
    if len(sys.argv) != 2:
        print("Invalid input.")
        return

    input_str = sys.argv[1]
    index = convert_to_integer(input_str)

    if index is None:
        print("Invalid input.")
        return

    array = [1, 2, 3, 4, 5]
    print_array_element(array, index)

if __name__ == "__main__":
    main()

