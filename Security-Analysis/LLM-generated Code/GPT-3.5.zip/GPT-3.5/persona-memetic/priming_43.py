import os

def read_file_from_safe_directory(file_name):
    # Validate file name
    if not file_name.isalnum():  # Example validation, customize as per your requirements
        raise ValueError("Invalid file name")

    # Construct safe file path
    safe_directory = "/path/to/safe/directory"
    safe_file_path = os.path.join(safe_directory, file_name)

    # Read file from safe directory
    with open(safe_file_path, "r") as file:
        content = file.read()

    return content

def is_allowed_file_extension(file_name):
    allowed_extensions = [".txt", ".csv", ".pdf"]  # Example whitelist, customize as per your requirements

    file_extension = os.path.splitext(file_name)[1]
    return file_extension.lower() in allowed_extensions


