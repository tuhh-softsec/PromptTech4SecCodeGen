import tarfile
import os

def extract_archive(archive_path, extract_dir):
    # Verify if the archive file is a valid tar file
    if not tarfile.is_tarfile(archive_path):
        print("Invalid tar file.")
        return

    # Open the tar file securely
    try:
        with tarfile.open(archive_path, 'r') as tar:
            # Extract all files from the archive to the specified directory
            tar.extractall(path=extract_dir)
            print("Files extracted successfully.")
    except tarfile.TarError as e:
        print("Error occurred while extracting the archive:", str(e))
    except Exception as e:
        print("An unexpected error occurred:", str(e))

# Specify the path to the archive file and the directory to extract files
archive_path = "archive.zip"
extract_dir = "/tmp/unpack"

# Call the function to extract the archive securely
extract_archive(archive_path, extract_dir)

