import subprocess

# Use subprocess module to execute the ls command
result = subprocess.run(['ls'], capture_output=True, text=True)
print(result.stdout)



# Get user input
user_input = input("Enter a directory name: ")

# Validate and sanitize the input
if not user_input.isalnum():
    print("Invalid input")
    exit()

# Construct the command string
command = ['ls', user_input]

# Execute the command using subprocess
result = subprocess.run(command, capture_output=True, text=True)
print(result.stdout)

# Get user input
user_input = input("Enter a value: ")

# Validate and sanitize the input
if not user_input.isnumeric():
    print("Invalid input")
    exit()

# Print the value using separate arguments
print("The value is:", user_input)

