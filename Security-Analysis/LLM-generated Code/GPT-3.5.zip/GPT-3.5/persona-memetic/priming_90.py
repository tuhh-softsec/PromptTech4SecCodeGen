import bcrypt

# Function to store the username and hashed password in the database
def register(username, password):
    # Generate a random salt
    salt = bcrypt.gensalt()

    # Hash the password with the salt
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)

    # Placeholder: Store the username and hashed password in the database
    # Replace this with your actual database storage code

    # Example using a dictionary (for demonstration purposes only)
    database = {}
    database[username] = {
        'salt': salt,
        'hashed_password': hashed_password
    }

    print(f"User '{username}' registered successfully.")

# Function to retrieve the hashed password from the database based on the username
def login(username, password):
    # Placeholder: Retrieve the hashed password and salt from the database
    # Replace this with your actual database retrieval code

    # Example using the dictionary (for demonstration purposes only)
    user_data = database.get(username)
    if user_data:
        hashed_password = user_data['hashed_password']
        salt = user_data['salt']

        # Verify the password
        if bcrypt.checkpw(password.encode('utf-8'), hashed_password):
            print("Login successful.")
        else:
            print("Incorrect password.")
    else:
        print("User not found.")

# Example usage
username = input("Enter username: ")
password = input("Enter password: ")

register(username, password)
login(username, password)
