import secrets

# Generate three random floats between 0 and 1
random_float1 = secrets.randbelow(1000000) / 1000000.0
random_float2 = secrets.randbelow(1000000) / 1000000.0
random_float3 = secrets.randbelow(1000000) / 1000000.0

# Convert the floats to strings using f-string formatting
string1 = f"{random_float1}"
string2 = f"{random_float2}"
string3 = f"{random_float3}"

# Print the resulting strings
print(string1)
print(string2)
print(string3)

