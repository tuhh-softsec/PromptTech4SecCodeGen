import subprocess

def execute_command(command):
    try:
        output = subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
        print(output.decode())
    except subprocess.CalledProcessError as e:
        print("Command execution failed:", e.output.decode())

# Example usage
command = input("Enter the command to execute: ")
execute_command(command)

