from flask import Flask, render_template, request, session, redirect, url_for
from flask_bcrypt import Bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'
bcrypt = Bcrypt(app)

# Replace 'your_secret_key' with a strong secret key

# Simulated user database for demonstration
users = {
    'user1': {'password': bcrypt.generate_password_hash('password1').decode('utf-8')},
    'user2': {'password': bcrypt.generate_password_hash('password2').decode('utf-8')}
}

@app.route('/')
def index():
    return '<a href="/login">Login</a>'

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and bcrypt.check_password_hash(users[username]['password'], password):
            session['username'] = username
            return redirect(url_for('secret'))

        return 'Incorrect username or password'

    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return 'Secret setting.'
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run(debug=True)
