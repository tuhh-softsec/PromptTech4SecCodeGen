import mysql.connector

def check_username(username):
    try:
        # Establish database connection
        db_connection = mysql.connector.connect(
            host="your_host",
            user="your_username",
            password="your_password",
            database="your_database"
        )

        # Create a cursor object to execute queries
        cursor = db_connection.cursor(prepared=True)

        # Prepare the query with a parameterized statement
        query = "SELECT COUNT(*) FROM users WHERE username = %s"
        data = (username,)

        # Execute the query
        cursor.execute(query, data)

        # Fetch the result
        result = cursor.fetchone()[0]

        # Close the cursor and database connection
        cursor.close()
        db_connection.close()

        # Check if the username exists
        if result == 1:
            return True
        else:
            return False

    except mysql.connector.Error as error:
        print("Error while connecting to MySQL:", error)
        return False

# Usage example
username = "example_username"
exists = check_username(username)
print(exists)

