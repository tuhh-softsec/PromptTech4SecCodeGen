def get_value_at_index(id_sequence):
    try:
        index = int(input("Enter the index value: "))
    except ValueError:
        print("Invalid input. Please enter a valid integer.")
        return 0

    if index < 0 or index >= len(id_sequence):
        print("Index out of bounds.")
        return 0

    return id_sequence[index]

