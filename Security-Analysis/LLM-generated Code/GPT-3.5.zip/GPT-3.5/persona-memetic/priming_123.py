import sys

def print_argument(argument):
    # Trim trailing whitespace characters
    argument = argument.rstrip()

    # Print the argument
    print(argument)

if __name__ == "__main__":
    # Check if an argument is provided
    if len(sys.argv) > 1:
        # Get the argument from command line
        argument = sys.argv[1]

        # Call the function to print the argument
        print_argument(argument)
    else:
        print("No argument provided.")

