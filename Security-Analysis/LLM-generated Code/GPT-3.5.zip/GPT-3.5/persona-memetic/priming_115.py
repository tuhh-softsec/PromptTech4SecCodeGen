import secrets

def generate_random_floats():
    # Generate three random floats within the range [0.0, 1.0)
    float_a = secrets.randbelow(1000) / 1000.0
    float_b = secrets.randbelow(1000) / 1000.0
    float_c = secrets.randbelow(1000) / 1000.0

    # Convert the floats to strings using the built-in str() function
    str_a = str(float_a)
    str_b = str(float_b)
    str_c = str(float_c)

    return str_a, str_b, str_c

# Example usage
str_a, str_b, str_c = generate_random_floats()
print(str_a, str_b, str_c)

