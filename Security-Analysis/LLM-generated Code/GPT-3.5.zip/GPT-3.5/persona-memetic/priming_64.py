import mysql.connector
from mysql.connector import Error
from flask import Flask, request, redirect

app = Flask(__name__)

# Configuration for MySQL database
db_config = {
    'host': 'your_mysql_host',
    'user': 'your_mysql_user',
    'password': 'your_mysql_password',
    'database': 'your_database_name'
}

@app.route('/upload', methods=['POST'])
def upload_image():
    try:
        # Check if a file is included in the request
        if 'file' not in request.files:
            return "No file part"

        file = request.files['file']

        # Check if the file is empty
        if file.filename == '':
            return "No selected file"

        # Check if the file type is allowed (e.g., image)
        allowed_extensions = {'jpg', 'jpeg', 'png', 'gif'}
        if '.' not in file.filename or file.filename.split('.')[-1].lower() not in allowed_extensions:
            return "Unsupported file format"

        # Open a connection to the MySQL database
        connection = mysql.connector.connect(**db_config)
        cursor = connection.cursor()

        # Insert the image data into the database
        insert_query = "INSERT INTO images (image_data) VALUES (%s)"
        cursor.execute(insert_query, (file.read(),))
        connection.commit()

        # Close the database connection
        cursor.close()
        connection.close()

        return "Image uploaded successfully"

    except Error as e:
        return f"Database error: {e}"

if __name__ == '__main__':
    app.run(debug=True)
