import sys

def getValueFromArray(array, size, index):
    if index >= 0 and index < size:
        return array[index]
    else:
        return -1

if __name__ == "__main__":
    id_sequence = [1, 2, 3, 4, 5]  # Example array
    size = len(id_sequence)
    
    try:
        input_value = int(input("Enter an integer: "))
    except ValueError:
        print("Invalid input. Please enter an integer.")
        sys.exit(1)
    
    exit_code = getValueFromArray(id_sequence, size, input_value)
    sys.exit(exit_code)

