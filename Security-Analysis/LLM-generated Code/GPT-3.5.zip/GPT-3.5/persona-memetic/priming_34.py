import sqlite3
from flask import Flask, request, session, redirect
from itsdangerous import URLSafeTimedSerializer
import bcrypt

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a strong secret key

@app.route('/login', methods=['POST'])
def login():
    # Your login code here

    def login():
        if request.method == 'POST':
            username = request.form['username']
            password = request.form['password']

            conn = sqlite3.connect('database.db')
            cursor = conn.cursor()

            # Use parameterized query to prevent SQL injection
            cursor.execute("SELECT * FROM users WHERE username = ?;", (username,))
            user = cursor.fetchone()

            if user:
                stored_password = user[1]  # Assuming password is stored in the second column
                if bcrypt.checkpw(password.encode('utf-8'), stored_password.encode('utf-8')):
                    # Generate a secure session token
                    session_token = URLSafeTimedSerializer(app.secret_key).dumps({'username': username})

                    # Set the session token as a secure cookie
                    session['session_token'] = session_token

                    # Redirect to the home page upon successful login
                    return redirect('/home')
                else:
                    return "Incorrect password"
            else:
                return "Username does not exist"

            conn.close()

        # Handle other HTTP methods or return login page
        return "Login Page HTML Here"


@app.route('/home')
def home():
    # Verify the session token from the secure cookie
    session_token = request.cookies.get('session_token')
    if session_token:
        try:
            data = URLSafeTimedSerializer(app.secret_key).loads(session_token, max_age=3600)
            username = data['username']
            # Continue with authenticated user
        except:
            # Invalid or expired session token, redirect to login page
            redirect('\login')
    else:
        # No session token found, redirect to login page
        redirect('\login')

