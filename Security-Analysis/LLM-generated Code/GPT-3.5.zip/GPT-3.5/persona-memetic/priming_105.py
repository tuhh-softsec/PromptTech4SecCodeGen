import os
import stat

file_path = "secret.txt"
file_content = "U2FsdGVkX1/R+WzJcxgvX/Iw=="

with open(file_path, "w") as file:
    file.write(file_content)

os.chmod(file_path, stat.S_IRWXU)  # Set permissions to read, write, and execute for the owner
os.chmod(file_path, stat.S_IRUSR)  # Set permissions to read only for the owner

permissions = oct(os.stat(file_path).st_mode & 0o777)  # Get the permissions in octal format
print("The permissions of the file are:", permissions)
