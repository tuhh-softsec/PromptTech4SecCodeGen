import os
from werkzeug.utils import secure_filename
from flask import Flask, request

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def file_is_safe_type(filename):
    return allowed_file(filename)

def upload_file(file):
    if file_is_safe_type(file.filename):
        filename = secure_filename(file.filename)
        file.save(os.path.join(UPLOAD_FOLDER, filename))
        return "File uploaded successfully."
    else:
        return "File type not allowed."

# Example usage
if __name__ == '__main__':
    

    app = Flask(__name__)
    app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

    @app.route('/upload', methods=['POST'])
    def upload():
        file = request.files['file']
        return upload_file(file)

    app.run()

