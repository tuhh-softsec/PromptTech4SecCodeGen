import os
from flask import Flask, request, redirect

app = Flask(__name__)

# Define the allowed file extensions
ALLOWED_EXTENSIONS = {'txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'}

# Function to check if the file extension is allowed
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to check if the file is safe to upload
def file_is_safe_type(file):
    # Add your file type validation logic here
    # For example, you can use libraries like python-magic or imghdr
    # to identify the file type and verify it against a safe list
    pass

@app.route('/upload', methods=['POST'])
def upload_file():
    try:
        # Check if a file is included in the request
        if 'file' not in request.files:
            return "No file part"

        file = request.files['file']

        # Check if the file is empty
        if file.filename == '':
            return "No selected file"

        # Check if the file type is allowed
        if not allowed_file(file.filename):
            return "Unsupported file format"

        # Check if the file is safe to upload based on its type
        if not file_is_safe_type(file):
            return "Unsafe file type"

        # Create the 'uploads' folder if it doesn't exist
        if not os.path.exists('uploads'):
            os.makedirs('uploads')

        # Save the file to the 'uploads' folder
        file.save(os.path.join('uploads', file.filename))

        return "File uploaded successfully"

    except Exception as e:
        return f"Error: {str(e)}"

if __name__ == '__main__':
    app.run(debug=True)
