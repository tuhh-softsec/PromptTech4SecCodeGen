import hashlib
import sqlite3
from flask import Flask, request, redirect, render_template, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Connect to the database
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Create a table to store user credentials if it doesn't exist
cursor.execute('''CREATE TABLE IF NOT EXISTS users
                  (username TEXT, password TEXT)''')
conn.commit()

@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Hash the password using a secure hashing algorithm (e.g., SHA-256)
        hashed_password = hashlib.sha256(password.encode()).hexdigest()

        # Check if the username and hashed password match the database records
        cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, hashed_password))
        user = cursor.fetchone()

        if user:
            # Redirect to the dashboard if the username and password are correct
            return redirect('/dashboard')
        else:
            # Redirect to the login page if the username and password are incorrect
            return redirect('/')
    else:
        return render_template('login.html')

@app.route('/dashboard')
def dashboard():
    # Check if the user is authenticated before accessing the dashboard
    if 'username' in session:
        return render_template('dashboard.html')
    else:
        return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)

