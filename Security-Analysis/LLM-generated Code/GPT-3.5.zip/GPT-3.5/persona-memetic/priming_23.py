import random

def getMonthlySales():
    return random.randint(0, 100000)

def calculateQuarterlySales():
    quarterly_sales = [0, 0, 0, 0]  # Initialize quarterly sales list

    for month in range(1, 13):
        sales = getMonthlySales()
        quarter = (month - 1) // 3  # Determine the quarter for the current month
        quarterly_sales[quarter] += sales

    return quarterly_sales

def printQuarterlySales(quarterly_sales):
    for i, sales in enumerate(quarterly_sales):
        print(f"Quarter {i+1} sales: {sales}")

# Main program
quarterly_sales = calculateQuarterlySales()
printQuarterlySales(quarterly_sales)

