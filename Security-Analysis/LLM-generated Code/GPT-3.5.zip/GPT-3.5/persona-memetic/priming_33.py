import sqlite3
import bcrypt
from flask import Flask, request, session, redirect
from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Create a Limiter instance to limit login attempts
limiter = Limiter(app, key_func=get_remote_address)

# Database connection and login validation
def validate_login(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = "SELECT * FROM users WHERE username = ?"
    cursor.execute(query, (username,))
    result = cursor.fetchone()

    conn.close()

    if result:
        hashed_password = result[1]  # Assuming password is stored in the second column
        if bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8')):
            return True

    return False

@app.route('/login', methods=['POST'])
@limiter.limit("5/minute")  # Limit to 5 login attempts per minute
def login_attempt():
    username = request.form['username']
    password = request.form['password']

    if validate_login(username, password):
        session['username'] = username
        # Redirect to the home page upon successful login
        return redirect('/home')
    else:
        # Redirect to the login page upon failed login
        return redirect('/login.html')

@app.route('/home')
def home():
    if 'username' in session:
        # Render the home page if the user is logged in
        return 'Welcome, ' + session['username']
    else:
        # Redirect to the login page if the user is not logged in
        return redirect('/login.html')

if __name__ == '__main__':
    app.run()
