import sqlite3
import html
import bcrypt
import re

# Establish a database connection
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# User input
username = input("Enter username: ")
password = input("Enter password: ")


# Password policy checks
if len(password) < 8:
    print("Password must be at least 8 characters long.")
elif not re.search(r'[A-Z]', password):
    print("Password must contain at least one uppercase letter.")
elif not re.search(r'[a-z]', password):
    print("Password must contain at least one lowercase letter.")
elif not re.search(r'\d', password):
    print("Password must contain at least one digit.")
elif not re.search(r'[!@#$%^&*(),.?":{}|<>]', password):
    print("Password must contain at least one special character.")
else:
    # Hash and insert the password into the database
    hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())
    cursor.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    conn.commit()

