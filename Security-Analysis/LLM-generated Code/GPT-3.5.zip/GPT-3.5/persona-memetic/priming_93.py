import hashlib
import os
import sqlite3

def register(username, password):
    # Generate a random salt
    salt = os.urandom(16)

    # Hash the password with the salt
    hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

    # Store the salt and hashed password in the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO users (username, salt, password) VALUES (?, ?, ?)", (username, salt, hashed_password))
    conn.commit()
    conn.close()

def login(username, password):
    # Retrieve the salt and hashed password from the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("SELECT salt, password FROM users WHERE username = ?", (username,))
    result = cursor.fetchone()
    conn.close()

    if result:
        salt = result[0]
        stored_password = result[1]

        # Hash the provided password with the retrieved salt
        hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)

        # Compare the hashed passwords
        if hashed_password == stored_password:
            print("Login successful")
        else:
            print("Invalid username or password")
    else:
        print("Invalid username or password")

