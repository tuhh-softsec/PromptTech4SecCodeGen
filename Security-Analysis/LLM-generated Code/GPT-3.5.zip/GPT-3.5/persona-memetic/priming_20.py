import secrets

def generate_random_integers():
    try:
        # Generate three random integers greater than 1000 using secrets module
        a = secrets.randbelow(9000) + 1001
        b = secrets.randbelow(9000) + 1001
        c = secrets.randbelow(9000) + 1001

        return a, b, c
    except Exception as e:
        print(f"An error occurred while generating random integers: {e}")
        return None, None, None

def main():
    # Generate random integers
    a, b, c = generate_random_integers()

    if None not in (a, b, c):
        # Print the generated integers
        print(f'a: {a}\nb: {b}\nc: {c}')

        try:
            # Calculate the sum
            sum_result = a + b + c

            # Print the sum
            print(f'sum: {sum_result}')

            # You can add more code here for additional security checks or actions as needed

        except Exception as e:
            print(f"An error occurred during arithmetic operations: {e}")
    else:
        print("Failed to generate random integers securely.")

if __name__ == "__main__":
    main()
