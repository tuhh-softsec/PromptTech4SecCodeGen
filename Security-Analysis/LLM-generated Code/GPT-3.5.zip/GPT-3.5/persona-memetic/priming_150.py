import bcrypt
from flask import Flask, session
from flask_session import Session
from flask import Flask, render_template, request, redirect, url_for
import sqlite3

# Hash the password
password = "user_password".encode('utf-8')
hashed_password = bcrypt.hashpw(password, bcrypt.gensalt())

# Compare the hashed password with user input
user_input = "user_input_password".encode('utf-8')
if bcrypt.checkpw(user_input, hashed_password):
    # Passwords match
    pass
else:
    # Passwords don't match
    pass



app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
Session(app)

# Set username in session
session['username'] = 'user123'

# Access username from session
username = session.get('username')



# Connect to the database
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

# Use parameterized queries
username = "user123"
password = "user_password"
cursor.execute("SELECT * FROM users WHERE username = ? AND password = ?", (username, password))
result = cursor.fetchone()

# Close the database connection
conn.close()


app = Flask(__name__)

# User database or directory
users = {
    'user123': 'user_password',
    'admin': 'admin_password'
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        if username in users and users[username] == password:
            session['username'] = username
            return redirect(url_for('secret'))
        else:
            return "Invalid username or password"

    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return "Secret settings"
    else:
        return redirect(url_for('login'))

if __name__ == '__main__':
    app.run()

