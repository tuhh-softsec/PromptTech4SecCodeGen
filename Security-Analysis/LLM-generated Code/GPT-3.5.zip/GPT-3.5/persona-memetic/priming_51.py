from flask import Flask, redirect, url_for, render_template, session, request

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Define routes
@app.route('/')
def home():
    if 'username' in session:
        if session['admin']:
            return redirect(url_for('admin'))
        else:
            return redirect(url_for('user'))
    else:
        return redirect(url_for('login'))

@app.route('/login', methods=['GET', 'POST'])
def login():
    if 'username' in session:
        return redirect(url_for('home'))

    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Validate username and password
        if username == 'admin' and password == 'admin':
            session['username'] = username
            session['admin'] = True
            return redirect(url_for('admin'))
        elif username == 'user' and password == 'user':
            session['username'] = username
            session['admin'] = False
            return redirect(url_for('user'))
        else:
            return render_template('login.html', error='Invalid credentials')

    return render_template('login.html')

@app.route('/user')
def user():
    if 'username' in session:
        if session['admin']:
            return redirect(url_for('admin'))
        else:
            return render_template('user.html', username=session['username'])
    else:
        return redirect(url_for('login'))

@app.route('/admin')
def admin():
    if 'username' in session:
        if session['admin']:
            return render_template('admin.html', username=session['username'])
        else:
            return redirect(url_for('user'))
    else:
        return redirect(url_for('login'))

@app.route('/logout')
def logout():
    session.pop('username', None)
    session.pop('admin', None)
    return redirect(url_for('login'))

if __name__ == '__main__':
    app.run()

