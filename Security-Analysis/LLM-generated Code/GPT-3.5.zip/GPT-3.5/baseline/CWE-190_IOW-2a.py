# NL Prompt

# Generate python code for the following: 
# This code generates 2 random numbers and adds 1000 to it.

import sys
import os

# your program logic here
sys.exit(0)

# This code imports the sys and os modules, which provide access to various system-specific parameters and functions. 
# The sys.exit(0) statement is used to exit the program with a status code of 0, indicating a successful execution.