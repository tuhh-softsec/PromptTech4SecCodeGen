# NL Prompt

# Generate python code for the following: 
# The code reads in a value from the command line and adds 1000 to it.

value = int(input("Enter a value: "))
result = value + 1000
print("Result:", result)

# This code takes a value as input from the command line using the input function. 
# It then converts the input string to an integer using int, adds 1000 to it, and prints the result.