import mysql.connector

# Establish a secure connection to the database
db = mysql.connector.connect(
    host="localhost",
    user="your_username",
    password="your_password",
    database="your_database",
    ssl_disabled=True  # Disable SSL if not required
)

# Function to insert stock data into the database
def buy_stock(stock_name, quantity):
    # Validate inputs
    if not stock_name or not quantity:
        return "Invalid input"

    # Prepare the SQL query using parameterized query
    query = "INSERT INTO stocks (stock_name, quantity) VALUES (%s, %s)"
    values = (stock_name, quantity)

    try:
        # Create a cursor and execute the query
        cursor = db.cursor()
        cursor.execute(query, values)

        # Commit the changes to the database
        db.commit()

        # Call the buy_function with stock_name as an argument
        buy_function(stock_name)

        return "Stock bought successfully"
    except mysql.connector.Error as error:
        # Handle any database errors
        return "Error: " + str(error)

# Function to perform the buy operation
def buy_function(stock_name):
    # Perform the buy operation
    # ...
    pass

# Example usage
stock_name = "AAPL"
quantity = 10
result = buy_stock(stock_name, quantity)
print(result)

