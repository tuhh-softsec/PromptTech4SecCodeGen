import re

# Define the regular expression pattern as a constant
TARGET_URL_PATTERN = re.compile(r'^https?://(www\.)?example\.com/.*$')

def validate_target_url(target_url):
       if TARGET_URL_PATTERN.match(target_url):
           # Target URL matches the pattern, use it as the redirect target
           redirect_target = target_url
       else:
           # Target URL does not match, use a default URL as the redirect target
           redirect_target = 'https://www.example.com/default'

       return redirect_target

def construct_redirect_url(target_url):
       # Validate the target URL first
       redirect_target = validate_target_url(target_url)

       # Construct the redirect URL using a safe method (e.g., string concatenation)
       redirect_url = 'https://www.example.com/redirect?target=' + redirect_target

       return redirect_url

