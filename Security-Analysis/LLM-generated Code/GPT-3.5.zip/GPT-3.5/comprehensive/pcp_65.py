from flask import Flask, request, flash, redirect, url_for
from werkzeug.utils import secure_filename
import os
import pymysql.cursors

app = Flask(__name__)

# Configuration
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'png', 'jpg', 'jpeg', 'gif'}
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16 MB maximum file size

# MySQL Database Configuration
db_config = {
    'host': 'your_mysql_host',
    'user': 'your_mysql_user',
    'password': 'your_mysql_password',
    'db': 'your_database_name',
    'charset': 'utf8mb4',
    'cursorclass': pymysql.cursors.DictCursor
}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

def connect_to_db():
    connection = pymysql.connect(**db_config)
    return connection

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        flash('No file part')
        return redirect(request.url)

    file = request.files['file']

    if file.filename == '':
        flash('No selected file')
        return redirect(request.url)

    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)

        try:
            # Connect to the MySQL database
            connection = connect_to_db()
            
            with connection.cursor() as cursor:
                # Insert the image into the database
                sql = "INSERT INTO images (filename, data) VALUES (%s, %s)"
                with open(file_path, 'rb') as img_file:
                    cursor.execute(sql, (filename, img_file.read()))
                connection.commit()
                flash('File successfully uploaded and saved in the database')
        except Exception as e:
            flash('Error occurred while saving the image: ' + str(e))
        finally:
            connection.close()
            os.remove(file_path)  # Delete the uploaded file from the server
        return redirect(url_for('uploaded_file', filename=filename))
    else:
        flash('Invalid file type or file too large')
        return redirect(request.url)

if __name__ == '__main__':
    app.secret_key = 'super_secret_key'
    app.run(debug=True)
