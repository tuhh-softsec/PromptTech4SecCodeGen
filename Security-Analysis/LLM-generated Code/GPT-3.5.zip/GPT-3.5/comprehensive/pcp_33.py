import sqlite3

def login(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = "SELECT * FROM users WHERE username = ? AND password = ?"
    cursor.execute(query, (username, password))
    result = cursor.fetchone()

    conn.close()

    if result:
        # Redirect to home page
        return True
    else:
        # Redirect to login page
        return False

import bcrypt

def login(username, password):
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    query = "SELECT * FROM users WHERE username = ?"
    cursor.execute(query, (username,))
    result = cursor.fetchone()

    conn.close()

    if result:
        hashed_password = result[1]  # Assuming password is stored in the second column
        if bcrypt.checkpw(password.encode('utf-8'), hashed_password.encode('utf-8')):
            # Redirect to home page
            return True

    # Redirect to login page
    return False

from flask import Flask, request, session, redirect

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if login(username, password):
        session['username'] = username
        # Redirect to home page
        return redirect('/home')
    else:
        # Redirect to login page
        return redirect('/login.html')

@app.route('/home')
def home():
    if 'username' in session:
        # Render home page
        return 'Welcome, ' + session['username']
    else:
        # Redirect to login page
        return redirect('/login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    # Redirect to login page
    return redirect('/login.html')

if __name__ == '__main__':
    app.run()

from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(app, key_func=get_remote_address)

@app.route('/login', methods=['POST'])
@limiter.limit("5/minute")  # Limit to 5 login attempts per minute
def login():
    # Login logic
    pass

