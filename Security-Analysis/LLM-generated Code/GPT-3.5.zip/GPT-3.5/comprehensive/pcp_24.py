def getMonthlySales(month):
    # Your implementation of getMonthlySales function
    # ...
    pass

def calculateTotalSales():
    sum = 0
    for i in range(3):
        sum += getMonthlySales(i)
    return sum

totalSales = calculateTotalSales()
print("Total sales for the first quarter:", totalSales)

