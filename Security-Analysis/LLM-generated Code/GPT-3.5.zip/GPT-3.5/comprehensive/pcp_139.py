import os
import psycopg2
from flask import Flask, request

app = Flask(__name__)

def get_db_connection():
       conn = psycopg2.connect(
           host=os.environ.get('DB_HOST'),
           port=os.environ.get('DB_PORT'),
           dbname=os.environ.get('DB_NAME'),
           user=os.environ.get('DB_USER'),
           password=os.environ.get('DB_PASSWORD')
       )
       return conn

def get_server_name():
       return request.headers.get('Host')

def get_database_name():
       return os.environ.get('DB_NAME')

def get_database_user():
       return os.environ.get('DB_USER')

def get_database_password():
       return os.environ.get('DB_PASSWORD')

