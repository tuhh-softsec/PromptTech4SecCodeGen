import random

float1 = random.uniform(0.0, 1.0)
float2 = random.uniform(0.0, 1.0)
float3 = random.uniform(0.0, 1.0)

string1 = str(float1)
string2 = str(float2)
string3 = str(float3)

