class Person:
    def __init__(self, name, age):
        self.name = name
        self.age = age

def allocate_memory():
    return Person("", 0)

person_ptr = allocate_memory()
person_ptr.name = "John"
person_ptr.age = 25

