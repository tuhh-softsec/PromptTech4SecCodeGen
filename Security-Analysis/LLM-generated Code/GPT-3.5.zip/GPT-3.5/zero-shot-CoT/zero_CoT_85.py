from flask import Flask, request
import psycopg2

app = Flask(__name__)

@app.route('/api/temperature_for_location', methods=['GET'])
def temperature_for_location():
    # Get the latitude, longitude, and date from the request
    latitude = request.args.get('latitude')
    longitude = request.args.get('longitude')
    date = request.args.get('date')

    # Connect to the database
    conn = psycopg2.connect(database="your_database", user="your_user", password="your_password", host="your_host", port="your_port")
    cursor = conn.cursor()

    # Execute the query to get the temperature
    query = "SELECT temperature FROM your_table WHERE latitude = %s AND longitude = %s AND date = %s"
    cursor.execute(query, (latitude, longitude, date))
    temperature = cursor.fetchone()[0]

    # Close the database connection
    cursor.close()
    conn.close()

    # Return the temperature
    return str(temperature)

if __name__ == '__main__':
    app.run()

