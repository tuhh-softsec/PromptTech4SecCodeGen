from flask import Flask, request, send_file
import os

app = Flask(__name__)

@app.route('/img')
def img():
    file = request.args.get('file')
    if file is not None:
        file_path = os.path.join('path/to/your/files', file)
        if os.path.exists(file_path):
            return send_file(file_path, mimetype='image/jpeg')
        else:
            return 'File not found', 404
    else:
        return 'No file specified', 400

if __name__ == '__main__':
    app.run()

