import tarfile
import os

archive_path = 'archive.zip'
unpack_dir = '/tmp/unpack'
os.makedirs(unpack_dir, exist_ok=True)

with tarfile.open(archive_path, 'r') as tar:
    tar.extractall(path=unpack_dir)

