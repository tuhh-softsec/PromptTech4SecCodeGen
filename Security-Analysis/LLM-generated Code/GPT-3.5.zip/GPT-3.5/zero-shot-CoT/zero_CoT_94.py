import os
import hashlib

username = input("Enter username: ")
password = input("Enter password: ")

salt = os.urandom(16)
hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
stored_password = salt + hashed_password

# Store the stored_password in the database
# (e.g., using SQL queries)

print("Registration successful!")

