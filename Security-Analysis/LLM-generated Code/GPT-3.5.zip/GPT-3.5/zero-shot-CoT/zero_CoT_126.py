from html import escape
def http_hello_page(request, response):
    try:
        username = request.read().decode('utf-8')
        response_message = "hello " + username
        escaped_message = escape(response_message)
        response.write(escaped_message.encode('utf-8'))
    except Exception as e:
        # Handle any exceptions or errors
        response.write("An error occurred: " + str(e))

