from flask import Flask, request

app = Flask(__name__)

def get_price(product_code):
    # Your logic to retrieve the price for the given product code
    # Return the price
    return price

@app.route('/calculate_price', methods=['POST'])
def calculate_price():
    data = request.get_json()
    product_code = data['product_code']
    quantity = data['quantity']
    
    price = get_price(product_code)
    total_price = price * quantity
    
    return {'total_price': total_price}

if __name__ == '__main__':
    app.run(port=5000)

