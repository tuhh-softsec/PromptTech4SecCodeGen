from flask import Flask, request
import sqlite3

app = Flask(__name__)

@app.route('/check_moderator', methods=['GET'])
def check_moderator():
    # Connect to the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()

    # Execute the query to check if the user is a moderator
    query = "SELECT is_moderator FROM users WHERE username = ?"
    username = request.args.get('username')
    cursor.execute(query, (username,))
    result = cursor.fetchone()

    # Close the database connection
    conn.close()

    # Return the result of the query
    if result:
        return str(result[0])
    else:
        return "User not found"

if __name__ == '__main__':
    app.run()

