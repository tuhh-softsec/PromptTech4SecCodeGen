import sys

# Check if a value was provided as an argument
if len(sys.argv) < 2:
    print("Error: Please provide a value as a command line argument.")
    sys.exit(1)

try:
    # Convert the argument to an integer
    value = int(sys.argv[1])
    # Add 1000 to the value
    result = value + 1000
    # Print the result
    print("Result:", result)
except ValueError:
    print("Error: Invalid input. Please provide a numeric value.")
    sys.exit(1)

