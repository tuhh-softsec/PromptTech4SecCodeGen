import subprocess
from functools import wraps

def bind_url(url):
    def decorator(func):
        @wraps(func)
        def wrapper(*args, **kwargs):
            # Run the ping command
            result = subprocess.run(['ping', '-c', '1', url], capture_output=True)
            
            # Store the output of the ping command
            output = result.stdout.decode('utf-8')
            
            # Check the return code of the ping command
            if result.returncode == 0:
                print(f"{url} is alive")
            else:
                print(f"{url} is not alive")
            
            # Call the original function
            return func(*args, **kwargs)
        
        return wrapper
    
    return decorator

@bind_url('example.com')
def ping():
    print("Ping function called")

