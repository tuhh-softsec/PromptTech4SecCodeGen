import sys

if len(sys.argv) != 2:
    print("Please provide exactly one argument.")
    sys.exit(1)

arg = sys.argv[1]
if not isinstance(arg, str):
    print("The argument must be a string.")
    sys.exit(1)

arg = arg.rstrip()
arg = arg.replace('\n', '')
arg += '\0'

