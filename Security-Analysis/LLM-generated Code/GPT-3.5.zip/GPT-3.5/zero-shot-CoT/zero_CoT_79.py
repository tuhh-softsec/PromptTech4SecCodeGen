buffer = bytearray(1024)
input_str = input("Enter 10 characters: ")
bu = input_str.encode()[:10]

