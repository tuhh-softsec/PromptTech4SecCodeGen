import subprocess

command = "ls"
subprocess.call([command])

