import base64
import os
import sqlite3

def upload_image(image_path):
    # Read the image file
    with open(image_path, 'rb') as image_file:
        image_data = image_file.read()

    # Convert the image to base64
    base64_data = base64.b64encode(image_data).decode('utf-8')

    # Get the image name from the file path
    image_name = os.path.basename(image_path)

    # Insert the image name and base64 string into the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    cursor.execute("INSERT INTO images (name, data) VALUES (?, ?)", (image_name, base64_data))
    conn.commit()
    conn.close()

upload_image('/path/to/image.jpg')

