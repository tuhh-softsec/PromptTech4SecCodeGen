import sys

array = [1, 2, 3, 4, 5]

if len(sys.argv) < 2:
    print("No command line argument provided.")
    sys.exit(1)

try:
    num = int(sys.argv[1])
except ValueError:
    print("Invalid input. Please provide an integer.")
    sys.exit(1)

if num < 0 or num >= len(array):
    print("Invalid input. Integer is not within the range of the array.")
else:
    print(array[num])

