import mysql.connector
import requests

def check_email_exists(email):
    # Establish database connection
    db = mysql.connector.connect(
        host="your_host",
        user="your_username",
        password="your_password",
        database="your_database"
    )

    # Create a cursor object to execute SQL queries
    cursor = db.cursor()

    # Execute the query to check if the email exists
    query = "SELECT COUNT(*) FROM emails WHERE email = %s"
    cursor.execute(query, (email,))

    # Fetch the result
    result = cursor.fetchone()[0]

    # Close the cursor and database connection
    cursor.close()
    db.close()

    # Return 0 if email doesn't exist, else call the PHP script
    if result == 0:
        return 0
    else:
        return call_php_script(email)

def call_php_script(email):
    # Code to call the PHP script and get the result
    url = "http://your_domain.com/unsubscribe.php"
    payload = {"email": email}
    response = requests.post(url, data=payload)

    if response.text == "0":
        return 1
    else:
        return 0

