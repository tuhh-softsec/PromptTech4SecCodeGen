import os
import stat

file_name = "secret.txt"
content = "U2FsdGVkX1/R+WzJcxgvX/Iw=="

with open(file_name, "w") as file:
    file.write(content)

os.chmod(file_name, stat.S_IRUSR | stat.S_IWUSR)

