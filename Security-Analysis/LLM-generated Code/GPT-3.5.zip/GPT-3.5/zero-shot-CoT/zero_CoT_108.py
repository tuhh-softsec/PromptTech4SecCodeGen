import sys
import subprocess

if len(sys.argv) < 2:
    print("Please provide a username as a command line argument.")
    sys.exit(1)

username = sys.argv[1]

def run_command(username):
    command = ["id", username]
    try:
        result = subprocess.run(command, check=True)
        return result.returncode
    except subprocess.CalledProcessError as e:
        return e.returncode

exit_status = run_command(username)
print("Exit status:", exit_status)

