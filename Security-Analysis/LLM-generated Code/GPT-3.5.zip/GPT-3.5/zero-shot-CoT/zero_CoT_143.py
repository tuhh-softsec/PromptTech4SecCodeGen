import sqlite3

# Connect to the database
conn = sqlite3.connect('stocks.db')
c = conn.cursor()

def buy_stock(stock_name, quantity):
    # Insert stock name and quantity into the database
    c.execute("INSERT INTO stocks (stock_name, quantity) VALUES (?, ?)", (stock_name, quantity))
    conn.commit()
    
    # Call the buy_function and pass the stock name as an argument
    buy_function(stock_name)

def buy_function(stock_name):
    # Perform actions with the stock name
    print(f"Buying stock: {stock_name}")
    # Add your code here for further actions with the stock name

# Assuming you have a form or GUI where the user can input the stock name and quantity
stock_name = input("Enter stock name: ")
quantity = int(input("Enter quantity: "))

# Call the buy_stock function when the user clicks on the buy button
buy_stock(stock_name, quantity)

