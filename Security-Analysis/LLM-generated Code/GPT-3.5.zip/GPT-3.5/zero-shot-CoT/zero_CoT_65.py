import mysql.connector
from mysql.connector import Error
from mysql.connector import errorcode
from PIL import Image

try:
    connection = mysql.connector.connect(host='localhost',
                                         database='your_database',
                                         user='your_username',
                                         password='your_password')
    if connection.is_connected():
        print("Connected to MySQL database")

except Error as e:
    print("Error while connecting to MySQL", e)

try:
    cursor = connection.cursor()
    create_table_query = '''CREATE TABLE IF NOT EXISTS images
                            (id INT AUTO_INCREMENT PRIMARY KEY,
                             image BLOB)'''
    cursor.execute(create_table_query)
    connection.commit()
    print("Table created successfully")

except Error as e:
    print("Error while creating table in MySQL", e)

image_path = input("Enter the path of the image file: ")

try:
    with open(image_path, 'rb') as file:
        image_data = file.read()
        print("Image file read successfully")

except FileNotFoundError:
    print("Image file not found")

try:
    cursor = connection.cursor()
    insert_query = "INSERT INTO images (image) VALUES (%s)"
    cursor.execute(insert_query, (image_data,))
    connection.commit()
    print("Image data inserted successfully")

except Error as e:
    print("Error while inserting image data into MySQL", e)

if connection.is_connected():
    cursor.close()
    connection.close()
    print("MySQL connection closed")

