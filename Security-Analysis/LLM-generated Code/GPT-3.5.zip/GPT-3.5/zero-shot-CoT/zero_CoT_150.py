from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if username and password are correct
        if username == 'your_username' and password == 'your_password':
            session['username'] = username
            return redirect('/secret')
        else:
            return 'Invalid username or password'
    
    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return 'Secret settings'
    else:
        return redirect('/login')

if __name__ == '__main__':
    app.run()

