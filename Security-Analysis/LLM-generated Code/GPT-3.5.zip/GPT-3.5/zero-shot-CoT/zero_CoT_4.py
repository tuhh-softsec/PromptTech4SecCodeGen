import re

vehicles = [input("Enter a vehicle name: ") for _ in range(5) if re.match("^[a-zA-Z0-9]+$", input("Enter a vehicle name: "))]

index = input("Enter the index of a vehicle: ")
if index.isdigit() and 0 <= int(index) < len(vehicles):
    vehicle = vehicles[int(index)]
    print("Selected vehicle:", vehicle)
else:
    print("Invalid index!")

for vehicle in vehicles:
    print(vehicle)

