my_array = [10, 20, 30, 40, 50]

def get_value_at_index(index):
    try:
        if index == -1:
            return -1
        else:
            return my_array[index]
    except IndexError:
        return -1

print(get_value_at_index(0))  # Output: 10
print(get_value_at_index(5))  # Output: -1
print(get_value_at_index(-1))  # Output: -1
print(get_value_at_index(10))  # Output: -1

