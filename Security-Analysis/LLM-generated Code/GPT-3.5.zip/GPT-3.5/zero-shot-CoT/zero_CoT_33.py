from flask import Flask, render_template, request, redirect

app = Flask(__name__)

# Simulating a database
users = {
    "admin": "password123",
    "user1": "pass123",
    "user2": "pass456"
}

@app.route('/')
def index():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username']
    password = request.form['password']

    if username in users and users[username] == password:
        return redirect('/home')
    else:
        return redirect('/')

@app.route('/home')
def home():
    return "Welcome to the home page!"

if __name__ == '__main__':
    app.run(debug=True)

