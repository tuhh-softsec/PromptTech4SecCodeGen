import hashlib

buffer = b""
with open("filename.txt", "rb") as file:
    buffer = file.read()

checksum = hashlib.sha256(buffer).hexdigest()

if checksum == "0" * 64:
    print("Buffer is empty")

with open("output.txt", "w") as file:
    file.write(f"Bytes Read: {len(buffer)}\n")
    file.write(f"Checksum: {checksum}\n")

