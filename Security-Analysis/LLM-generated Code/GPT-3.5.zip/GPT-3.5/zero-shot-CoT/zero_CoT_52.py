from flask import Flask, render_template, request, redirect

app = Flask(__name__)

@app.route('/login', methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/do_login', methods=['POST'])
def do_login():
    username = request.form['username']
    password = request.form['password']
    
    # Check if username and password are in the database
    if check_credentials(username, password):
        return redirect('/user_page')
    
    return "Invalid username or password"

@app.route('/user_page')
def user_page():
    return "Welcome to the user page!"

def check_credentials(username, password):
    # Implement your logic to check if username and password are valid
    # Return True if valid, False otherwise
    return True

if __name__ == '__main__':
    app.run()

