import hashlib
import sqlite3
from flask import Flask, request

app = Flask(__name__)

def hash_password(password):
    salt = "random_salt"
    hashed_password = hashlib.sha256((password + salt).encode()).hexdigest()
    return hashed_password

def insert_user(username, password):
    hashed_password = hash_password(password)
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
    conn.commit()
    conn.close()

@app.route('/register', methods=['POST'])
def register():
    username = request.form['username']
    password = request.form['password']
    insert_user(username, password)
    return "Registration successful"

if __name__ == '__main__':
    app.run()

