from flask import Flask, render_template, request, redirect, session
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# Create a dictionary to store username and hashed password
users = {
    'your_username': generate_password_hash('your_password')
}

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        # Check if username exists and password is correct
        if username in users and check_password_hash(users[username], password):
            session['username'] = username
            return redirect('/secret')
        else:
            return 'Invalid username or password'
    
    return render_template('login.html')

@app.route('/secret')
def secret():
    if 'username' in session:
        return render_template('secret.html')
    else:
        return redirect('/login')

if __name__ == '__main__':
    app.run()

