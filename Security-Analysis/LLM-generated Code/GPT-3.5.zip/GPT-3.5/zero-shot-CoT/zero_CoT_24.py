def getMonthlySales(month):
    # Implementation of getMonthlySales function
    # ...
    return monthly_sales

total_sales = 0

for i in range(3):
    monthly_sales = getMonthlySales(i)
    total_sales += monthly_sales

print("Total sales for the first quarter:", total_sales)

