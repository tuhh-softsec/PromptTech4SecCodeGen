import mysql.connector

# Connect to the database
db = mysql.connector.connect(
    host="localhost",
    user="your_username",
    password="your_password",
    database="your_database"
)

def login(username, password):
    # Create a cursor object to execute SQL queries
    cursor = db.cursor()

    # Check if the username exists in the database
    cursor.execute("SELECT * FROM users WHERE username = %s", (username,))
    user = cursor.fetchone()

    if user:
        # If the username exists, check if the password is correct
        if password == user[1]:  # Assuming the password is stored in the second column
            # Redirect the user to the home page
            redirect_to_home_page()
        else:
            # If the password is incorrect, return
            return "Incorrect password"
    else:
        # If the username doesn't exist, return
        return "Username does not exist"

def redirect_to_home_page():
    # Code to redirect the user to the home page
    pass

username = input("Enter your username: ")
password = input("Enter your password: ")

result = login(username, password)
if result:
    print(result)

