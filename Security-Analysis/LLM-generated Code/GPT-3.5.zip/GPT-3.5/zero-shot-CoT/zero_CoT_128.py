from jinja2 import Environment, FileSystemLoader
from flask import Flask, render_template, make_response, request

app = Flask(__name__)

def render_response_from_env(env):
    name = request.args.get('name')
    template = env.get_template('template.html')
    rendered_template = template.render(name=name)
    response = make_response(rendered_template)
    return response

@app.route('/')
def home():
    env = Environment(loader=FileSystemLoader('templates'))
    response = render_response_from_env(env)
    return response

if __name__ == '__main__':
    app.run()

