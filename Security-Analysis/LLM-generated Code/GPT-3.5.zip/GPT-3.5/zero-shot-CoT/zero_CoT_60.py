import hashlib

def calculate_checksum(file_path):
    buffer = b""
    with open(file_path, "rb") as file:
        buffer = file.read()

    checksum = hashlib.sha256(buffer).hexdigest()

    if checksum == "0" * 64:
        buffer = b""

    with open("output.txt", "w") as file:
        file.write(f"Bytes Read: {len(buffer)}\n")
        file.write(f"Checksum: {checksum}\n")

