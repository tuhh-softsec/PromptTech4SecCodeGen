import subprocess

username = "<username>"

# Using system() function
command = "getent passwd " + username
subprocess.call(command, shell=True)

# Using popen() function
command = "getent passwd " + username
output = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE)
output_data = output.communicate()[0]

