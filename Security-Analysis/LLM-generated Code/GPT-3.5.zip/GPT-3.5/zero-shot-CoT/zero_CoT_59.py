import ctypes

buffer_size = 1024  # Example buffer size, choose a secure value

buffer = ctypes.create_string_buffer(buffer_size)

for i in range(buffer_size):
    buffer[i] = 0

ctypes.free(buffer)

