import yaml
from flask import Flask, request

app = Flask(__name__)

@app.route('/', methods=['POST'])
def handle_request():
    payload = request.form.get('payload')
    
    if not payload:
        return 'Error: No payload parameter found in the request.'
    
    try:
        data = yaml.safe_load(payload)
    except yaml.YAMLError:
        return 'Error: Invalid YAML payload.'
    
    if data.get('type') == 'Create':
        return 'Error: Create type not allowed.'
    
    if data.get('type') == 'Update' and data.get('name') == 'UnsafeDeserialization':
        return 'Error: UnsafeDeserialization name not allowed.'
    
    return 'Success: Request processed successfully.'

if __name__ == '__main__':
    app.run(port=5000)

