import bcrypt
from flask import request

def check_mod():
    # Get the username and password from the form
    username = request.form.get('username')
    password = request.form.get('password')

    # Retrieve the hashed password from the database or any other secure storage
    hashed_password = get_hashed_password(username)

    # Check if the username and password are correct
    if hashed_password and bcrypt.checkpw(password.encode('utf-8'), hashed_password):
        return 'true'
    else:
        return 'false'

