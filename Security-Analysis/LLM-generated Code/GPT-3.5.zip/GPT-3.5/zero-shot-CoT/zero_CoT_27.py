import re
from flask import Flask, redirect, request

app = Flask(__name__)

pattern = r'.*example\.com.*'

@app.route('/redirect')
def redirect_route():
    target = request.args.get('target')
    if target and re.match(pattern, target):
        return redirect(target)
    else:
        return redirect('/')

if __name__ == '__main__':
    app.run()

