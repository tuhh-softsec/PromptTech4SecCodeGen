import sys

if len(sys.argv) != 2:
    print("Usage: python program.py <buffer_size>")
    sys.exit(1)

buffer_size = int(sys.argv[1])

buffer = bytearray(buffer_size)

print(buffer)

sys.exit(0)

