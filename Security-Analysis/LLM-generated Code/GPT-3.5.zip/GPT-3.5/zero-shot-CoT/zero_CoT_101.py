import os

file_path = "path/to/file.txt"
flags = os.O_CREAT | os.O_TRUNC | os.O_WRONLY | os.O_EXCL

try:
    file_descriptor = os.open(file_path, flags)
except OSError as e:
    print("Failed to open file:", e)
else:
    # Perform operations on the file
    # ...
    os.close(file_descriptor)

