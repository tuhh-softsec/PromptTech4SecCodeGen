import sys

def add_1000_to_input():
    try:
        input_value = int(sys.argv[1])
        result = input_value + 1000
        print(result)
    except (IndexError, ValueError):
        print("Invalid input")
        return 1
    return 0

if __name__ == "__main__":
    exit_code = add_1000_to_input()
    sys.exit(exit_code)

