from http.server import BaseHTTPRequestHandler, HTTPServer

class MyRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/hello':
            content_length = int(self.headers['Content-Length'])
            username = self.rfile.read(content_length).decode('utf-8')
            
            self.send_response(200)
            self.send_header('Content-type', 'text/html')
            self.end_headers()
            
            outputbuf = f"<html><body>Hello, {username}!</body></html>"
            self.wfile.write(outputbuf.encode('utf-8'))

def run_server():
    server_address = ('', 8000)
    httpd = HTTPServer(server_address, MyRequestHandler)
    httpd.serve_forever()

if __name__ == '__main__':
    run_server()

