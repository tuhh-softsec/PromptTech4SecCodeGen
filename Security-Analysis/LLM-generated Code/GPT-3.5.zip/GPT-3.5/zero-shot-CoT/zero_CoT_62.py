import os
import mysql.connector
from flask import Flask, request, send_file

app = Flask(__name__)

# Establish MySQL connection
mydb = mysql.connector.connect(
  host="localhost",
  user="yourusername",
  password="yourpassword",
  database="yourdatabase"
)

@app.route('/upload', methods=['POST'])
def upload_pdf():
    # Check if file is present in the request
    if 'file' not in request.files:
        return "No file uploaded!"

    file = request.files['file']

    # Save the uploaded file in the uploads folder
    file_path = os.path.join('uploads', file.filename)
    file.save(file_path)

    # Save the file path in the MySQL database
    cursor = mydb.cursor()
    sql = "INSERT INTO pdf_files (file_path) VALUES (%s)"
    val = (file_path,)
    cursor.execute(sql, val)
    mydb.commit()
    cursor.close()

    return "File uploaded successfully!"

@app.route('/download/<int:file_id>', methods=['GET'])
def download_pdf(file_id):
    # Retrieve the file path from the database
    cursor = mydb.cursor()
    sql = "SELECT file_path FROM pdf_files WHERE id = %s"
    val = (file_id,)
    cursor.execute(sql, val)
    result = cursor.fetchone()
    cursor.close()

    if result:
        file_path = result[0]
        return send_file(file_path, as_attachment=True)
    else:
        return "File not found!"

if __name__ == '__main__':
    app.run()

