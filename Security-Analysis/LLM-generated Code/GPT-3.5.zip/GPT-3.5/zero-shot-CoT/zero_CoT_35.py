import sqlite3
from flask import Flask, request, redirect

app = Flask(__name__)

@app.route('/')
def login():
    return '''
    <form action="/login" method="post">
        <input type="text" name="username" placeholder="Username"><br>
        <input type="password" name="password" placeholder="Password"><br>
        <input type="submit" value="Login">
    </form>
    '''

@app.route('/login', methods=['POST'])
def authenticate():
    username = request.form['username']
    password = request.form['password']
    
    # Check if the username and password are in the database
    if check_credentials(username, password):
        return redirect('/success')
    else:
        return redirect('/cant_login')

@app.route('/success')
def success():
    return 'Login successful!'

@app.route('/cant_login')
def cant_login():
    return 'Invalid username or password.'

@app.errorhandler(500)
def internal_server_error(error):
    return 'Internal Server Error', 500

def check_credentials(username, password):
    # Connect to the database
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    
    # Execute a query to check if the username and password exist in the database
    query = "SELECT * FROM users WHERE username=? AND password=?"
    cursor.execute(query, (username, password))
    
    # Fetch the result
    result = cursor.fetchone()
    
    # Close the database connection
    conn.close()
    
    # Return True if the result is not None, indicating that the credentials are valid
    return result is not None

if __name__ == '__main__':
    app.run()

