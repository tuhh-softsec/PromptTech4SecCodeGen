import ctypes
import sys

BUFFER_SIZE = 1024
NUM_CHARS = 100

buf = ctypes.create_string_buffer(BUFFER_SIZE)
sys.stdin.read(buf, NUM_CHARS)

buf1 = ctypes.create_string_buffer(BUFFER_SIZE)
sys.stdin.read(buf1, NUM_CHARS)

print("Buffer 1:", buf.value)
print("Buffer 2:", buf1.value)

