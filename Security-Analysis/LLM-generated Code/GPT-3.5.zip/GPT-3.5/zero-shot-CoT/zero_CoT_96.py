import bcrypt
import sqlite3

conn = sqlite3.connect('database.db')
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS users
             (id INTEGER PRIMARY KEY AUTOINCREMENT,
             username TEXT NOT NULL,
             password TEXT NOT NULL)''')

username = input("Enter username: ")
password = input("Enter password: ")

hashed_password = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt())

c.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
conn.commit()

conn.close()

