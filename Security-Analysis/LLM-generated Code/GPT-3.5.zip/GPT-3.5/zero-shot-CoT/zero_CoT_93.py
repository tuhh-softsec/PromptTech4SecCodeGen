import hashlib
import os
import sqlite3

def generate_salt():
    return os.urandom(16)

def hash_password(password, salt):
    hashed_password = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 100000)
    return hashed_password

def register(username, password):
    salt = generate_salt()
    hashed_password = hash_password(password, salt)
    
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute("INSERT INTO users (username, password, salt) VALUES (?, ?, ?)", (username, hashed_password, salt))
    
    conn.commit()
    conn.close()

def login(username, password):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    
    c.execute("SELECT password, salt FROM users WHERE username=?", (username,))
    result = c.fetchone()
    
    if result:
        stored_password = result[0]
        salt = result[1]
        hashed_password = hash_password(password, salt)
        
        if hashed_password == stored_password:
            print("Login successful")
        else:
            print("Invalid username or password")
    else:
        print("Invalid username or password")
    
    conn.close()

