from flask import Flask, request, session, redirect, url_for

app = Flask(__name__)

# Secret key for session management (change this to a long, random value)
app.secret_key = 'your_secret_key'

# Database of users (replace this with your actual user database)
users = {
    'user1@example.com': {'password': 'password1'},
    'user2@example.com': {'password': 'password2'}
}

# Route for the login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email in users and users[email]['password'] == password:
            session['logged_in'] = True
            session['email'] = email
            return redirect(url_for('change_email'))
        else:
            return "Invalid email or password"
    return '''
        <form method="post">
            <input type="text" name="email" placeholder="Email"><br>
            <input type="password" name="password" placeholder="Password"><br>
            <input type="submit" value="Login">
        </form>
    '''

# Route for changing email
@app.route('/change_email', methods=['GET', 'POST'])
def change_email():
    if 'logged_in' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        old_email = session['email']
        new_email = request.form['new_email']
        old_email_entered = request.form['old_email']
        password_entered = request.form['password']

        # Input validation
        if old_email_entered != old_email:
            return "Old email does not match"
        if new_email == old_email:
            return "New email must be different from old email"
        if not new_email or not password_entered:
            return "Please enter new email and password"

        # Password verification
        if users[old_email]['password'] != password_entered:
            return "Incorrect password"

        # Update email in the database
        users[old_email]['email'] = new_email
        return "Email changed successfully"

    return '''
        <form method="post">
            <input type="text" name="old_email" placeholder="Old Email"><br>
            <input type="text" name="new_email" placeholder="New Email"><br>
            <input type="password" name="password" placeholder="Password"><br>
            <input type="submit" value="Change Email">
        </form>
    '''

if __name__ == '__main__':
    app.run(debug=True)
