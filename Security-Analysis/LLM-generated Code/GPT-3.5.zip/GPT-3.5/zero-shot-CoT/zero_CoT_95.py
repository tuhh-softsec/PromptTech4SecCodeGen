import hashlib
import sqlite3

conn = sqlite3.connect('database.db')
c = conn.cursor()

c.execute('''CREATE TABLE IF NOT EXISTS users
             (username TEXT, password TEXT, first_name TEXT, last_name TEXT, email TEXT)''')

def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()

def username_exists(username):
    c.execute("SELECT * FROM users WHERE username=?", (username,))
    return c.fetchone() is not None

def register(username, password, first_name, last_name, email):
    if username_exists(username):
        return "Username already exists"
    hashed_password = hash_password(password)
    c.execute("INSERT INTO users VALUES (?, ?, ?, ?, ?)",
              (username, hashed_password, first_name, last_name, email))
    conn.commit()
    return "Registration succeeded"

conn.close()

result = register("john_doe", "password123", "John", "Doe", "john.doe@example.com")
print(result)

