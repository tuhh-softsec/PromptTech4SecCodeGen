import sys

def atoi(s):
    try:
        return int(s)
    except ValueError:
        print("Invalid input. Please enter a valid integer.")
        sys.exit(1)

if len(sys.argv) < 2:
    print("Usage: python program_name.py <integer>")
    sys.exit(1)

integer = atoi(sys.argv[1])

# Example usage
print("The square of the integer is:", integer**2)

