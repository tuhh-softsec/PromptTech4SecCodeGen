import sys

if len(sys.argv) < 2:
    print("Please provide a value as a command line argument.")
    sys.exit(1)

try:
    value = int(sys.argv[1])
except ValueError:
    print("Invalid value provided. Please provide a valid integer.")
    sys.exit(1)

OFFSET = 1000
result = value + OFFSET

print("Result:", result)

