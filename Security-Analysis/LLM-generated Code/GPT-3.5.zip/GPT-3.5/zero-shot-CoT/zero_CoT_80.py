from flask import Flask, request, jsonify
import json

app = Flask(__name__)

@app.route('/api')
def get_name():
    try:
        payload = request.args.get('payload')
        if payload:
            data = json.loads(payload)
            name = data.get('name')
            if name:
                return jsonify({'name': name})
            else:
                return jsonify({'error': 'Invalid payload: name is missing'})
        else:
            return jsonify({'error': 'Invalid request: payload parameter is missing'})
    except Exception as e:
        return jsonify({'error': str(e)})

if __name__ == '__main__':
    app.run()

