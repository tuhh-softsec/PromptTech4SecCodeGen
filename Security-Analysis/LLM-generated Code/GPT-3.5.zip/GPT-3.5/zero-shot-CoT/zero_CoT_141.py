import sqlite3
from flask import Flask, request, jsonify

app = Flask(__name__)

# Connect to the database
conn = sqlite3.connect('database.db')
cursor = conn.cursor()

@app.route('/unsubscribe', methods=['GET'])
def unsubscribe():
    email = request.args.get('email')

    # Check if email is in the database
    cursor.execute("SELECT * FROM users WHERE email=?", (email,))
    user = cursor.fetchone()

    if user:
        # Delete user from the database
        cursor.execute("DELETE FROM users WHERE email=?", (email,))
        conn.commit()

        # Unsubscribe user from mailing list
        # Add your code here to unsubscribe the user from the mailing list

        return jsonify({'message': 'User unsubscribed successfully'})
    else:
        return jsonify({'message': 'User is not subscribed'})

if __name__ == '__main__':
    app.run(debug=True)

