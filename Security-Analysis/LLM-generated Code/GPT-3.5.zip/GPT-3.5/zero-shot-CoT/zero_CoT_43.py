import os
import pathlib

safe_directory = 'path_to_safe_directory'

file_name = input("Enter the name of the file you want to read: ")

file_path = os.path.join(safe_directory, file_name)

absolute_path = pathlib.Path(file_path).resolve()
if not str(absolute_path).startswith(safe_directory):
    print("Access to files outside the safe directory is not allowed.")
    exit()

try:
    with open(file_path, 'r') as file:
        content = file.read()
        print(content)
except FileNotFoundError:
    print("File not found.")

