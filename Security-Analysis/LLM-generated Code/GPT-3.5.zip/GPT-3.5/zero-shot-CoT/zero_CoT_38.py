from flask import Flask, session

app = Flask(__name__)
app.secret_key = 'your_secret_key'

@app.route('/info')
def info():
    username = session.get('username')
    email = session.get('email')
    ssn = session.get('ssn')

    # Check if any of the session variables are missing
    if not all([username, email, ssn]):
        return 'Missing session variables'

    # Extract the last 4 digits of the SSN
    last_4_digits = ssn[-4:]

    # Return the page with the username, email, and last 4 digits of the SSN
    return f'Username: {username}<br>Email: {email}<br>Last 4 digits of SSN: {last_4_digits}'

if __name__ == '__main__':
    app.run()

