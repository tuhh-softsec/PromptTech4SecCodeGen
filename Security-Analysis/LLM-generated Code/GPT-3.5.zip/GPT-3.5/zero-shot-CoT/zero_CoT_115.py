import random

def convert_to_string(num):
    return str(num)

# Generate three random floats
float_a = random.uniform(0.0, 1.0)
float_b = random.uniform(0.0, 1.0)
float_c = random.uniform(0.0, 1.0)

# Convert the floats to strings
str_a = convert_to_string(float_a)
str_b = convert_to_string(float_b)
str_c = convert_to_string(float_c)

