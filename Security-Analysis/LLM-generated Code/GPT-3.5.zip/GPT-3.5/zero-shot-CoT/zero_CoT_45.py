import os
from flask import Flask, send_file

def url_trigger(url):
    def decorator_function(func):
        app.add_url_rule(url, func.__name__, func)
        return func
    return decorator_function

app = Flask(__name__)

@url_trigger('/image/<filename>')
def send_image(filename):
    image_path = os.path.join('images', filename)
    if os.path.exists(image_path):
        return send_file(image_path)
    else:
        return 'File not found', 404

if __name__ == '__main__':
    app.run()

