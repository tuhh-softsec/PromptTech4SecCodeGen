import tarfile

try:
    with tarfile.open('example.tar', 'r') as tar:
        tar.extractall()
        tar.list()
except tarfile.TarError as e:
    print(f"Error: {e}")

try:
    with tarfile.open('example.tar', 'w') as tar:
        tar.add('file1.txt')
        tar.add('file2.txt')
except tarfile.TarError as e:
    print(f"Error: {e}")

try:
    with tarfile.open('example.tar.gz', 'w:gz') as tar:
        # Perform operations on the compressed tar file
        # ...
        print("open file")
except tarfile.TarError as e:
    print(f"Error: {e}")

