from flask import Flask, redirect, url_for
from flask_login import LoginManager, login_required, current_user

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your_secret_key_here'

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

class User:
    def __init__(self, username, password, is_admin=False):
        self.username = username
        self.password = password
        self.is_admin = is_admin

    def is_authenticated(self):
        return True

    def is_active(self):
        return True

    def is_anonymous(self):
        return False

    def get_id(self):
        return self.username

users = {'admin': User('admin', 'admin_password', True)}

@app.route('/login')
def login():
    if current_user.is_anonymous:
        return redirect(url_for('login_page'))

    if not current_user.is_admin:
        return redirect(url_for('user_page'))

    return redirect(url_for('admin_page'))

@app.route('/user')
@login_required
def user_page():
    return 'User Page'

@app.route('/admin')
@login_required
def admin_page():
    if not current_user.is_admin:
        return redirect(url_for('login_page'))

    return 'Admin Page'

if __name__ == '__main__':
    app.run()

